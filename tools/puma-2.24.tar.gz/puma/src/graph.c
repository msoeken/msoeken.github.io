//****************************************************************************/
//
//    	Source for compilation of
//
//      PUMA`s Graphic Functions
//
//    	OKFDD-Package
//
//   	Copyright (C) 1996
//
//      Author: Andreas Hett
//      email:  hett@informatik.uni-freiburg.de
//      Web:    www.informatik.uni-freiburg.de/FREAK/hett.html
//
//      All rights reserved
//
/*****************************************************************************/

/*****************************************************************************/
//
//	>>>     INCLUDE FILES     <<<
//
/*****************************************************************************/

extern "C"
{
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>
}

#include "tc_time.h"
#include "puma.h"

#include <iostream>
using namespace std;

/*****************************************************************************/
//
//	>>>    MACRO DEFINITIONS     <<<
//
/*****************************************************************************/

// Loop definitions
// ----------------
#define	fui(x,y,z) 	  for(short x=y; x<=z; x++)
#define	fdi(x,y,z)  	  for(short x=y; x>=z; x--)
#define	fu(x,y,z)    	  for(      x=y; x<=z; x++)
#define	fd(x,y,z)	  for(      x=y; x>=z; x--)
#define	fu1(x,y,z)	  for(      x=y; x<z;  x++)

// Bit manipulators
// ----------------
#define	m_orh(x,y)	  (utnode*)((ulint)x |  (2*y))
#define	m_andh(x)	  (utnode*)((ulint)x & -3)
#define	m_or(x,y)	  (utnode*)((ulint)x |  y)
#define	m_xor(x,y)        (utnode*)((ulint)x ^  y)
#define	m_selh(x)	  ((ulint)x & 2) >> 1
#define	m_sel(x)	  ((ulint)x & 1)

#define NMAXCOLOR	  256
#define BDWIDTH	          1

#define borderWidth       1
#define x_min             800
#define y_min             800

#define DDC_background     "light gray"

#define DDC_lowedge        "blue"

#define DDC_nbackndav      "light blue"

#define DDC_highedge       "red"
#define DDC_nbackpdav      "red"
#define DDC_mark           "red"

#define DDC_coderback      "yellow1"

#define DDC_terminal       "black"
#define DDC_text           "black"
#define DDC_nodeframe      "black"

#define DDC_nbackground    "white"
#define DDC_topmark        "white"
#define DDC_topedge        "white"

#define security_offset 1000000000

#define circle_radius 20
#define textoffset_x  10
#define textoffset_y  25

#define Edges 0
#define Nodes 1


/*****************************************************************************/
//
//	>>>    GLOBAL VARIABLES    <<<
//
/*****************************************************************************/

long      IDTable1[10000];
long      IDTable2[10000];
long      IDTable3[10000];
long      IDTable4[10000];
long      IDTable5[10000];
long      IDTable6[10000];

long      glob1,glob2,glob3,glob4,glob5;
long      x_pos_h,x_pos_l,x_pos_n,y_pos_h,y_pos_l,y_pos_n;
long      Idnums;

int       mainWidth  = 0;
int       mainHeight = 0;

Window    rootWindow, mainWindow;
Display   *dpy;
GC        gc;

long      OKFDD_Xesult[10000];
long      OKFDD_Xesult_2[10000];

int       x_max,y_max;

/*****************************************************************************/
//
//	>>>     GRAPHIC FUNCTIONS    <<<
//
/*****************************************************************************/



/* ========================================================================= */
// Function:    dd_man::XShowDD // Shows DD in separate graphic window       //
/* ========================================================================= */
void dd_man::XShowDD(utnode* root)
{
	utnode** root_table = new utnode*[2]; root_table[0] = root; root_table[1] = NULL;

	XShowDD_mult(root_table); delete[] root_table;
}

/* ========================================================================= */
// Function:    dd_man::XShowDD_all // Shows all DDs in sep. graphic window  //
/* ========================================================================= */
void dd_man::XShowDD_all()
{
	utnode** root_table = new utnode*[OKFDD_P_O + 1];

	fu1(glob1,0,OKFDD_P_O) root_table[glob1] = toprime[All_Prime[pi_limit-1-glob1]]->root; root_table[OKFDD_P_O] = NULL;

	XShowDD_mult(root_table); delete[] root_table;
}

/* ========================================================================= */
// Function:    dd_man::XShowDD_mult // Shows DD in separate graphic window  //
/* ========================================================================= */
void dd_man::XShowDD_mult(utnode** root_table)
{ 
	Visual               visual;
	XGCValues            xgcv;
	XSetWindowAttributes xswa;
	XSizeHints           sizehints;
	char                 *ProgName, *server, *geom, *borderColor;
	int                  h, v, color, i;

	x_max = 800;
	y_max = 800;

	server      = "";
	geom        = "";
	borderColor = "black";

	dpy = XOpenDisplay(server);

	if (dpy == NULL) { cout << "XShowDD: Can't open display (exiting ...)\n"; return; }

	int  screen  = DefaultScreen(dpy);
        long BdPixel = BlackPixel   (dpy, screen);

	sizehints.flags       = PMinSize | PPosition | PSize;
	sizehints.min_width   = x_min;
	sizehints.min_height  = y_min;
	sizehints.width       = x_max;
	sizehints.height      = y_max;
	sizehints.x           = 0;
	sizehints.y           = 0;

	xswa.event_mask       = KeyPressMask | StructureNotifyMask;
	xswa.event_mask       |= ExposureMask;

	xswa.background_pixel = BdPixel;
	xswa.border_pixel     = BdPixel;

	visual.visualid       = CopyFromParent;

	rootWindow            = RootWindow(dpy, screen);

	mainWindow            = XCreateWindow(dpy,
                                              rootWindow,
			                      sizehints.x+50, sizehints.y,
			                      sizehints.width+50, sizehints.height,
			                      borderWidth,
			                      DefaultDepth(dpy,screen),
			                      InputOutput,
			                      &visual,
			                      CWEventMask | CWBackPixel | CWBorderPixel,
			                      &xswa);

        gc = XCreateGC(dpy, mainWindow, 0L, NULL);

	XMapWindow(dpy, mainWindow);

	XColor sdr, edr;

	XAllocNamedColor(dpy, DefaultColormap(dpy,screen), DDC_background, &sdr, &edr);     DDCV_background = sdr.pixel;

	XAllocNamedColor(dpy, DefaultColormap(dpy,screen), DDC_lowedge, &sdr, &edr);        DDCV_lowedge = sdr.pixel;

	XAllocNamedColor(dpy, DefaultColormap(dpy,screen), DDC_nbackndav, &sdr, &edr);      DDCV_nbackndav = sdr.pixel;

	XAllocNamedColor(dpy, DefaultColormap(dpy,screen), DDC_highedge, &sdr, &edr);       DDCV_highedge = sdr.pixel;
        DDCV_nbackpdav = sdr.pixel;
        DDCV_mark = sdr.pixel;

	XAllocNamedColor(dpy, DefaultColormap(dpy,screen), DDC_nodeframe, &sdr, &edr);      DDCV_nodeframe = sdr.pixel;
        DDCV_terminal = sdr.pixel;
        DDCV_text = sdr.pixel;

	XAllocNamedColor(dpy, DefaultColormap(dpy,screen), DDC_nbackground, &sdr, &edr);    DDCV_nbackground = sdr.pixel;
        DDCV_topmark = sdr.pixel;
        DDCV_topedge = sdr.pixel;

	XAllocNamedColor(dpy, DefaultColormap(dpy,screen), DDC_coderback, &sdr, &edr);      DDCV_coderback = sdr.pixel;

	eventloop(root_table);

        XFreeGC(dpy,gc);

	XDestroyWindow(dpy, mainWindow);

	XCloseDisplay(dpy);

	return;
}

/* ========================================================================= */
// Function:    dd_man::eventloop // Subfunction of XShowDD     	     //
/* ========================================================================= */
void dd_man::eventloop(utnode** root_table)
{  
	XEvent              event;

	XExposeEvent        *ee = (XExposeEvent *)&event;
	XKeyPressedEvent    *ke = (XKeyPressedEvent *)&event;
	XButtonPressedEvent *be = (XButtonPressedEvent *)&event;
        XConfigureEvent     *ce = (XConfigureEvent *)&event;

	char keybuff[10];
	int  nchar, color, h, v;

        int  x, y,label,idnum,mark;

	while(1)
        {
	    XNextEvent(dpy, &event);

            char step = 0;

	    switch(event.type)
            {
                // Exit display routine when RETURN, 'x' or 'X' is hit on keyboard
                // ---------------------------------------------------------------
     	        case KeyPress: nchar = XLookupString(ke, keybuff, 1, NULL, NULL);

		               if (nchar > 0)
                               {
			          switch (keybuff[0]) { case 13: case 'x': case 'X': return; }
		               }
		               break;

	        case ConfigureNotify:

                             x_max = ce->width; y_max = ce->height; step = 1;

		case Expose: if (ee->count) break;

// Attention: This version can only work properly with < First-Idnum (= 1000) variables
// ==========
                             XSetForeground(dpy, gc,DDCV_background);
                             XFillRectangle(dpy, mainWindow, gc, 0, 0, x_max, y_max);

			     // Show Table entries
			     // ------------------
/*			     cout << "\nPI_Order entries\n";

			     fu1(glob1,0,OKFDD_P_I)
			     {
			       cout << OKFDD_PI_Order_Table[glob1] << " ";
			     }		
			     cout << "\n";
*/

		             // Count Nodes per Levels that are in use and store (IDNUM, Position)-pair
			     // -----------------------------------------------------------------------
		             fu(glob1,0,OKFDD_P_I) OKFDD_Xesult[glob1] = 0;

                 glob1 = 0; OKFDD_Traverse_mult(root_table,T_Preorder,&dd_man::Trav_XInspect,NULL);

			     Idnums = glob1;
			     
			     glob3 = 0;

			     fu1(glob1,0,OKFDD_P_I)
			     {
			       if (((IDTable6[glob3] = OKFDD_Xesult[IDTable5[glob3] = OKFDD_PI_Order_Table[glob1]]) != 0))
//			         && (OKFDD_PI_Order_Table[glob1] > 32))
				 glob3++;
			     }

			     fu1(glob1,0,glob3)
			     {
			       OKFDD_Xesult_2[glob1] = IDTable5[glob1]; OKFDD_Xesult[glob1] = IDTable6[glob1];
			     }
	
			     /*		     
			     // Show Table entries
			     // ------------------
			     cout << "\nTable entries\n";

			     fu1(glob1,0,Idnums)
			     {
			       cout << "ID " << IDTable1[glob1] << " Pos N-L-H " << IDTable2[glob1] << "-";
			       cout << IDTable3[glob1] << "-" << IDTable4[glob1] << "\n";
			     }		
       			     */

			     OKFDD_Supported_Vars = glob3;

			     /*
			     cout << "OKFDD_Supported_Vars: " << OKFDD_Supported_Vars << "\n";
       			     */

			     // Substitution of Son-IDNUMs with Son-Positions in IDTables
			     // ---------------------------------------------------------
			     fu1(glob1,0,Idnums)
			     {
			       glob2 = IDTable1[glob1];

			       fu1(glob3,0,Idnums)
			       {
				 if (IDTable3[glob3] == glob2) IDTable3[glob3] = IDTable2[glob1] + security_offset;
				 if (IDTable4[glob3] == glob2) IDTable4[glob3] = IDTable2[glob1] + security_offset;
			       }
			     }

			     /*			     
			     // Show compressed variable table
			     // ------------------------------
			     cout << "\nVariable table\n";

			     fu1(glob1,0,OKFDD_Supported_Vars)
			     {
			       cout << "Lab " << OKFDD_Xesult_2[glob1] << " " << OKFDD_Xesult[glob1] << "\n";
			     }
			     */

			     /*     			     	     
			     // Show Table entries
			     // ------------------
			     cout << "\nTable entries\n";

			     fu1(glob1,0,Idnums)
			     {
			       cout << "ID " << IDTable1[glob1] << " Pos N-L-H " << IDTable2[glob1] << "-";
			       cout << IDTable3[glob1] << "-" << IDTable4[glob1] << "\n";
			     }
			     */
		     			     
			     // Draw Edges of DDs
			     // -----------------
			     glob4 = Edges; glob1 = 0; OKFDD_Traverse_mult(root_table,T_Preorder,&dd_man::Trav_XPerform,NULL);

			     glob5 = 0; while(root_table[glob5] != NULL) glob5++;

			     fu1(glob1,0,glob5)
			     {
			       utnode* uthelp = root_table[glob1];

			       utnode* mroot = m_and(uthelp);

			       if (mroot != OKFDD_ONE)
			       {
				 glob2 = 0; while(mroot->label_i != OKFDD_Xesult_2[glob2]) glob2++;
				 glob4 = 0; while(mroot->idnum   != IDTable1[glob4])       glob4++;

				 y_pos_n = y_max / (OKFDD_Supported_Vars+1) * (glob2+1);
				 x_pos_n = x_max / (OKFDD_Xesult[glob2]+1)  * IDTable2[glob4];

				 x_pos_h = x_pos_n+circle_radius;
				 y_pos_h = y_pos_n - 40;

				 XSetForeground(dpy,gc,DDCV_topedge);
				 XDrawLine (dpy, mainWindow, gc, x_pos_n+circle_radius,y_pos_n+circle_radius,
					    x_pos_h,y_pos_h);

				 if (m_sel(uthelp))
				 {
				   XSetForeground(dpy,gc,DDCV_topmark);
				   XFillArc(dpy, mainWindow, gc, x_pos_n+circle_radius-4,y_pos_n-20,8,8,0,360*64);	
				 }
			       }
			     }

                             // Draw Nodes of DDs
			     // -----------------
			     glob4 = Nodes; glob1 = 0; OKFDD_Traverse_mult(root_table,T_Preorder,&dd_man::Trav_XPerform,NULL);
		     
                             char copytext[100];

                             strcpy(copytext,"PUMA V2.22 Visualization of OKFDDs - Hit 'x' or CR in window to exit");

                             XSetForeground(dpy,gc,1);
                             XDrawString(dpy, mainWindow, gc, 30 , 30, copytext, strlen(copytext));
//                           strcpy(copytext,"                                           ~~~~~~~~~~~~~~~~~~~~~~~");
//                           XDrawString(dpy, mainWindow, gc, 30 , 45, copytext, strlen(copytext));

		             break;

		default:     break;
	    }
	}
}

/* ========================================================================= */
// Function:    dd_man::Trav_XInspect // Subfunction of XShowDD     	     //
/* ========================================================================= */
void dd_man::Trav_XInspect(utnode* root)
{
  utnode* mroot = m_and(root);

  if (mroot == OKFDD_ONE) return;

  IDTable1[glob1] = mroot->idnum;
  IDTable2[glob1] = ++OKFDD_Xesult[mroot->label_i];
  IDTable3[glob1] = (m_and(mroot->lo_p))->idnum;
  IDTable4[glob1] = (m_and(mroot->hi_p))->idnum;

  glob1++;

  return;
}

/* ========================================================================= */
// Function:    dd_man::Trav_XPerform // Subfunction of XShowDD     	     //
/* ========================================================================= */
void dd_man::Trav_XPerform(utnode* root)
{
  utnode* mroot = m_and(root);

  char idstring[10];
  char labelstring[10];
  char helpstring[10];

  int color1, color2;

  if (mroot == OKFDD_ONE) return;

  glob2 = 0; while(mroot->label_i != OKFDD_Xesult_2[glob2]) glob2++;

  y_pos_n = y_max / (OKFDD_Supported_Vars+1) * (glob2+1);
  x_pos_n = x_max / (OKFDD_Xesult[glob2]+1)  * IDTable2[glob1];

  if (glob4 == Edges)
  {
    if ((m_and(mroot->lo_p)) == OKFDD_ONE)
    {
      y_pos_l = y_pos_n + 2*circle_radius;
      x_pos_l = x_pos_n - 2*circle_radius;

      XSetForeground(dpy,gc,DDCV_lowedge);
      XDrawLine (dpy, mainWindow, gc, x_pos_n+circle_radius-3,y_pos_n+circle_radius,
		 x_pos_l+circle_radius-3,y_pos_l+circle_radius);
      XSetForeground(dpy,gc,DDCV_terminal);
      XFillRectangle(dpy, mainWindow, gc, x_pos_l+circle_radius-6,y_pos_l+circle_radius-2,6,6);	
    }
    else
    {
      glob2 = 0; while((m_and(mroot->lo_p))->label_i != OKFDD_Xesult_2[glob2]) glob2++;

      y_pos_l = y_max / (OKFDD_Supported_Vars+1) * (glob2+1);
      x_pos_l = x_max / (OKFDD_Xesult[glob2]+1) * (IDTable3[glob1] - security_offset);

      x_pos_l += circle_radius;
      y_pos_l += circle_radius;

      XSetForeground(dpy,gc,DDCV_lowedge);
      XDrawLine (dpy, mainWindow, gc, x_pos_n+circle_radius-3,y_pos_n+circle_radius,x_pos_l-3,y_pos_l);
    }

    if ((m_and(mroot->hi_p)) == OKFDD_ONE)
    {
      y_pos_h = y_pos_n + 2*circle_radius;
      x_pos_h = x_pos_n + 2*circle_radius;

      XSetForeground(dpy,gc,DDCV_highedge);
      XDrawLine (dpy, mainWindow, gc, x_pos_n+circle_radius+3,y_pos_n+circle_radius,
		 x_pos_h+circle_radius+3,y_pos_h+circle_radius);

      XSetForeground(dpy,gc,DDCV_terminal);
      XFillRectangle(dpy, mainWindow, gc, x_pos_h+circle_radius,y_pos_h+circle_radius-2,6,6);	

      if (m_sel(mroot->hi_p))
      {
	XSetForeground(dpy,gc,DDCV_mark);
	XFillArc(dpy, mainWindow, gc, (x_pos_n+2*circle_radius+8+x_pos_h)/2-3,
				                            (y_pos_n+2*circle_radius+y_pos_h)/2-2,8,8,0,360*64);	
      }
    }
    else
    {
      glob2 = 0; while((m_and(mroot->hi_p))->label_i != OKFDD_Xesult_2[glob2]) glob2++;

      y_pos_h = y_max / (OKFDD_Supported_Vars+1) * (glob2+1);
      x_pos_h = x_max / (OKFDD_Xesult[glob2]+1) * (IDTable4[glob1] - security_offset);

      x_pos_h += circle_radius;
      y_pos_h += circle_radius;

      XSetForeground(dpy,gc,DDCV_highedge);
      XDrawLine (dpy, mainWindow, gc, x_pos_n+circle_radius+3,y_pos_n+circle_radius,x_pos_h+3,y_pos_h);

      if (m_sel(mroot->hi_p))
      {
	XSetForeground(dpy,gc,DDCV_mark);
	XFillArc(dpy, mainWindow, gc, (x_pos_n+circle_radius+8+x_pos_h)/2-4,
				                            (y_pos_n+circle_radius+y_pos_h)/2-4,8,8,0,360*64);	
      }
    }
  }
  else
  {
    glob5 = mroot->label_i;
    fu1(glob3,0,4) { helpstring[glob3] = 48 + glob5 % 10; if (glob5 > 0) glob5 = (glob5 - glob5 % 10)/10; }
    fd(glob3,3,0) labelstring[glob3] = helpstring[3-glob3];

    glob5 = mroot->idnum;
    fu1(glob3,0,6) { helpstring[glob3] = 48 + glob5 % 10; if (glob5 > 0) glob5 = (glob5 - glob5 % 10)/10; }
    fd(glob3,5,0) idstring[glob3] = helpstring[5-glob3];

//  if (mroot->label_i > 32) XSetForeground(dpy,gc,DDCV_nbackground); else XSetForeground(dpy,gc,DDCV_coderback);

    XSetForeground(dpy,gc,DDCV_nbackground);
    if (OKFDD_PI_DTL_Table[mroot->label_i] == D_posD) XSetForeground(dpy,gc,DDCV_nbackpdav);
    if (OKFDD_PI_DTL_Table[mroot->label_i] == D_negD) XSetForeground(dpy,gc,DDCV_nbackndav);

    XFillArc   (dpy, mainWindow, gc, x_pos_n,y_pos_n,2*circle_radius,2*circle_radius,0,360*64);		     
    XSetForeground(dpy,gc,DDCV_nodeframe);
    XDrawArc   (dpy, mainWindow, gc, x_pos_n,y_pos_n,2*circle_radius,2*circle_radius,0,360*64);		     
    XSetForeground(dpy,gc,DDCV_text);
    XDrawString(dpy, mainWindow, gc, x_pos_n+textoffset_x,y_pos_n+textoffset_y, labelstring, 4);			     
    XDrawString(dpy, mainWindow, gc, x_pos_n+textoffset_x*5,y_pos_n+textoffset_y, idstring, 6);
  }

  glob1++;

  return;
}


