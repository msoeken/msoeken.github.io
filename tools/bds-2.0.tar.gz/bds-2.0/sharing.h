
/**CHeaderFile*****************************************************************

  FileName    [sharing.h]

  PackageName [BDS-pga]

  Synopsis    [Sharing extraction program]

  Description []

  SeeAlso     []

  Author      [Anda Congguang Yang]

  Last date   [5/22/99]

******************************************************************************/

#ifndef _BDSSHARING
#define _BDSSHARING

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "lopt.h"
#include "bnet.h"
#include "local.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/* Search depth on a Boolean network for transitive fans
*/
#define BDS_TRANSITIVE_DEEPTH 4

/* Maximum number of Boolean nodes will be allowed to be involved in a sharing
** extraction procedure
*/
#define BDS_MAX_SHARED_BNODES 8

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN int BDS_SharingExtractionGlobal ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN int BDS_SharingExtractionLocal ARGS((DdManager*,BnetNetwork*,bdsOptions*,FILE*));

#endif /* _BDSSHARING */



