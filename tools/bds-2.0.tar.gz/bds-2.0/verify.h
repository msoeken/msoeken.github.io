
/**CHeaderFile*****************************************************************

  FileName    [verify.h]

  PackageName [BDS-pga]

  Synopsis    [A Primitive Synthesis verification program]

  Description []

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#ifndef _BDSVERIFICATION
#define _BDSVERIFICATION

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "lopt.h"
#include "bnet.h"
#include "build.h"
#include "local.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN int bdsVerifyPartition ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN int bdsVerifySynthesis ARGS((DdManager*,BnetNetwork*,FactorTreeNode**,st_table*,bddPool**,st_table*,bdsOptions*));

#endif /* _BDSVERIFICATION */
