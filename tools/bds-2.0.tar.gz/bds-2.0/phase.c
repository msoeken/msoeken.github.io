
/**CFile***********************************************************************

  FileName    [phase.c]

  PackageName [BDS-pga]

  Synopsis    [Phase Assignment program]

  Description [This file contains the functions for phase assignment in FTree Processing.]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#include "lopt.h"
#include <stdio.h>

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/
static int BDS_XorTransform ARGS((FactorTreeNode**,bdsOptions*));


/**Function********************************************************************

  Synopsis    [Inverter propagation]

  Description [Only Xor transformation is done currently]

  SideEffects [The operator on an fnode may be modified]

  SeeAlso     []

  Last Date   [3/6/99]

*****************************************************************************/
extern
int
BDS_FtreePhaseAssignment(
  FactorTreeNode **FTreeNode,
  bdsOptions *option)
{
  int result;

  result = BDS_XorTransform(FTreeNode, option);
  if (result ==0) return(0);

  return(1);

} /* end of BDS_FtreePhaseAssignment */

/**Function********************************************************************

  Synopsis    [XOR and XNOR transformation]

  Description [Traverse on ftrees to transform the following cases: (XOR)' -> XNOR;
  (XNOR)'->XOR; Return 1 if successful; 0 otherwise]

  SideEffects [The operator on an fnode may be modified]

  SeeAlso     []

  Last Date   [3/6/99]

*****************************************************************************/
static
int
BDS_XorTransform(
  FactorTreeNode **FTreeNode,
  bdsOptions *option)
{
  int result;
  FactorTreeNode **q, *fnode;
  st_table *visited;
  st_generator *gen;

  visited = st_init_table(st_ptrcmp,st_ptrhash);

  for (q = FTreeNode; *q; q++) {
      result = bdsCollectFNodeslsList(visited, *q);
      if (result == 0) return(0);
  }

  gen = st_init_gen(visited);
  while (st_gen(gen, (char **) &fnode, NULL)) {
      if (!Fnode_Internal(fnode)) continue;

      if (Fnode_Operator(fnode) == BDS_BDD_XOR && Fnode_Negative(fnode)) {
          Fnode_Operator(fnode) = BDS_BDD_XNOR;
	  Fnode_Inverse(fnode);
      }
      else if (Fnode_Operator(fnode) == BDS_BDD_XNOR && Fnode_Negative(fnode)) {
          Fnode_Operator(fnode) = BDS_BDD_XOR;
	  Fnode_Inverse(fnode);
      }
  }
  st_free_gen(gen);

  st_free_table(visited);

  return(1);

} /* end of BDS_XorTransform */



