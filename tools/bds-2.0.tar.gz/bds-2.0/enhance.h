
/**CHeaderFile*****************************************************************

  FileName    [enhance.h]

  PackageName [BDS-pga]

  Synopsis    [Bnetwork enhancement program]

  Description []

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#ifndef _BNETENHANCE
#define _BNETENHANCE

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "bnet.h"
#include "build.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN int BDS_BnetEnhance ARGS((BnetNetwork*,bdsOptions*));
EXTERN int BDS_FindCriticalPath ARGS((BnetNetwork*,st_table*,bdsOptions*));
EXTERN int BDS_CritPathRecursive ARGS((BnetNetwork*,BnetNode*,st_table*,int*,int*));
#endif /* _BNETENHANCE */








