/// Queue structure and related functions

#include "lopt.h"

/* The Q program in BDS is very simple, even ridiculous. But think,
** it was implemented in 5 minutes .... */

void
BDS_Q_Init(
  SQueue *MasterQ)
{
  MasterQ->head = 0;
  MasterQ->tail = 0;
  MasterQ->queue = array_alloc(bddPool*, 0);

} /* end of BDS_Q_Init */


void
BDS_Q_Quit(
  SQueue *MasterQ)
{
  array_free(MasterQ->queue);
  FREE(MasterQ);

} /* end of BDS_Q_Quit */

void
BDS_RQ(
       SQueue *MasterQ)
{
  MasterQ->tail--;
}




void
BDS_EQ(
  SQueue *MasterQ,
  bddPool *element)
{
  array_insert_last(bddPool*, MasterQ->queue, element);
  MasterQ->tail ++;

} /* end of BDS_EQ */


bddPool *
BDS_DQ(
  SQueue *MasterQ)
{
  bddPool *element;

  if (MasterQ->tail == MasterQ->head) { return(NULL); }
  element = array_fetch(bddPool*, MasterQ->queue, MasterQ->head);
  MasterQ->head ++;
  return(element);

} /* end of BDS_DQ */

