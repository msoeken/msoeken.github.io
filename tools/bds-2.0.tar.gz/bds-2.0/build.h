
/**CHeaderFile*****************************************************************

  FileName    [build.h]

  PackageName [BDS-pga]

  Synopsis    [Build BDD for BDS]

  Description [Global and local BDDs construction programs. A couple of
  functions are borrowed from nanotrav package.]

  SeeAlso     []

  Author      [Congguang Yang]

******************************************************************************/

#ifndef _BDSBUILD
#define _BDSBUILD

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "bnet.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

#define BDS_GLOBAL_BDD_LIMIT 20000 /* During the process of constructing global
                       ** BDDs, if total number of BDD nodes is larger
                       ** then this number, the construction is aborted
                       */
#define BDS_LOCAL_GLOBAL 8   /* This is pure empirical value. When the size of
                 ** local BDDs is this times larger than global
                 ** BDDs, global BDDs are used for synthesis. By setting
                 ** this value to a even larger one will bias towards
                 ** local BDDs
                 */
#define PI_PS_FROM_FILE 0
#define PI_PS_DFS   1
#define PI_PS_GIVEN 2

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

typedef struct  bdsOptions {
    /* Options related to BDS. 10/20/98 */
    long    initialTime;    /* this is here for convenience */
    char    *file;      /* network file name */
    int     verb;       /* level of verbosity */
    int     cacheSize;  /* computed table initial size */
    unsigned long maxMemory;    /* computed table maximum size */
    int     slots;      /* unique subtable initial slots */
    int     maxGrowth;  /* maximum growth during reordering (%) */
    Cudd_ReorderingType reordering; /* NONE RANDOM PIVOT SIFTING ... */
    int     order;          /* FANIN DFS ... */
    char    *orderfile; /* file for externally provided order */

    /* Options created new for BDS 3/22/98 */
    int     useloc;     /* Use local BDD only */
    int     useglb;     /* Use global BDD only */
    int     autodyn;    /* Enable dynamic variable reordering */
    int     rodelim;    /* Use variable reordering in eliminate */
    int     globalLimit;    /* The limit for BDD nodes number, if > this limit, no global BDDs */
    int     ethred;     /* Elimination gain threshold. */
    int     glbEliminate;   /* Eliminate nodes using global BDDs */
    int     verify;     /* Verify the synthesis results */
    int     effort;     /* Amount of effort users want to put on the process */
    int     limitSize;  /* The #Node * #Var of a BDD, which can apply exact reorder. */
    int     miniMethod;     /* Methods for BDD minimizations. */
    int     dumpbdd;    /* Dump the BDD of the circuit in dot format */
    int     dumpblif;   /* Dump the ftree into BLIF format */
    int     dumpftree;  /* Dump ftree in the form of linking pointers */
    int     dumpfdot;   /* Dump ftree in dot format */
    int     dumpnet;    /* Dump bnet after eliminate */
    int     cutptl;     /* Cut PTLs from synthesis results */

    int     iconst;         /* Apply input constraint */
    int     kdecomp;        /* Apply decomp for level 0 */
    int     largefanout;    /* Apply the large fanout criteria */
    int     delay;          /* Apply delay based collapse */
    int     elim;           /* Apply the eliminate after 1000 iterations*/
    int     level1;         /* Allow decompositions at cut-level 1*/
    int     eps;            /* Set value for epsilon criticality
                               (real no?)- 0 for 1 longest path, 1
                               for all longest paths. 2 for
                               (longest path - 1) depth and so on*/
    int     sharing;
    int     performancedecomp; /* Apply performance directed decomposition in the delay phase */
    int     k;              /* to specify k-LUT value, default k value is 5 */
    int     heuristic;      /* to use heuristic variable partitioning decomposition */
    int     xhardcore;      /* to use generalized Boolean x-dominator in decomposition */

} bdsOptions;

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/* These are potential duplicates. */
#ifndef EXTERN
#   ifdef __cplusplus
#   define EXTERN extern "C"
#   else
#   define EXTERN extern
#   endif
#endif
#ifndef ARGS
#   if defined(__STDC__) || defined(__cplusplus)
#   define ARGS(protos) protos      /* ANSI C */
#   else /* !(__STDC__ || __cplusplus) */
#   define ARGS(protos) ()      /* K&R C */
#   endif /* !(__STDC__ || __cplusplus) */
#endif

#ifndef TRUE
#   define TRUE 1
#endif
#ifndef FALSE
#   define FALSE 0
#endif

/**Macro***********************************************************************

  Synopsis     [Returns 1 if the two arguments are identical strings.]

  Description  []

  SideEffects  [none]

  SeeAlso      []

******************************************************************************/
#define STRING_EQUAL(s1,s2) (strcmp((s1),(s2)) == 0)

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN int BDS_BuildGlobalBDD ARGS((DdManager*,BnetNetwork*,bdsOptions*,int*));
EXTERN int BDS_BuildLocalBDD ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN int BDS_BuildLocalBDD_ ARGS((DdManager*,BnetNetwork*,bdsOptions*,  DdNode *, int *, int,  DdNode *, int *, int));
EXTERN int BDS_buildDDs ARGS((BnetNetwork*,DdManager*,BnetNode*,bdsOptions*));
EXTERN int BDS_BuildNodeBDD ARGS((DdManager*,BnetNode*,st_table*));
EXTERN void BDS_BDD2ADD ARGS((DdManager*,BnetNode*));

#endif /* _BDSBUILD */










