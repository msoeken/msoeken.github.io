
/**CFile***********************************************************************

  FileName    [enhance.c]

  PackageName [BDS-pga]

  Synopsis    [Bnetwork enhancement program]

  Description [The Bnetwork coming with CUDD is too simple to perform network
               partitioning. Several new fields are added. This file provides
               functions filling those fields.
               This file contains the enhanced functions for building the
               Boolean network and also for finding critical paths.]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/
#include "enhance.h"
#include "array.h" ///pga

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis    [Bnetwork Enhancement function]

  Description [fanins and fanouts of each node are reformatted into lsList. A new
  hash table under Bnetwork, livenodes, is initialized to hold all live
  nodes during the network partitioning. Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
extern
int
BDS_BnetEnhance(
  BnetNetwork *net,
  bdsOptions *option)
{
    int         i, current_depth = 1;
    BnetNode    *newnode, *fanode, *tempnode;
    int         inter_level=0;
    int         prev_highest;

    net->livenodes = st_init_table(st_ptrcmp,st_ptrhash); // Current nodes in net

    newnode = net->nodes; /// the first node "nodes" of the linked-list of net
    while (newnode != NULL) { /// while there are more nodes in the linked-list of net

      //  printf("Enhance= %d %d  ; ", newnode->var, newnode->type);
        /* Add nodes to livenodes table. livenodes will keep track of all living
        ** nodes in the current Boolean network.
        */
        if (st_add_direct(net->livenodes, (char *) newnode, (char *) NULL) == ST_OUT_OF_MEM) { /// key for livenodes table: BnetNodes
            printf("Out of memory !"); return(0);
        }

        newnode->fanins = lsCreate(); /// initialize fanins list in ls format

        inter_level = -5;
        prev_highest = 0;

        for (i = 0; i < newnode->ninp; i++) { /// for each input node of the newnode
            if (!st_lookup(net->hash,newnode->inputs[i],(char **) &fanode)) { /// fetch that input node and put it in fanode pointer
                (void) fprintf(stdout,"%s not driven\n", newnode->inputs[i]);
                return(0);
            }

            if ((fanode->level) >= inter_level) {
                inter_level = fanode->level;
                prev_highest = i;
            }

            newnode->collapsed = 0;
            newnode->no_inputs = newnode->ninp; /// # inputs to the node initially
            newnode->updated_inputs = newnode->ninp;
            newnode->no_outputs = newnode->nfo; /// # fanouts of the node initially
            newnode->executeornot = 1;
            newnode->checked = 0;
            newnode->crit_node = 0;

            /* Add fanin to fanins */
            if (lsNewEnd(newnode->fanins, (lsGeneric) fanode, NULL) != LS_OK) {
                printf("Out of memory"); return(0);
            }

            /* Add newnode to fanouts of fanode */
            if (fanode->fanouts == NULL) fanode->fanouts = lsCreate(); /// initialize fanouts list in ls format
            if (lsNewEnd(fanode->fanouts, (lsGeneric) newnode, NULL) != LS_OK) {
                printf("Out of memory"); return(0);
            }

        }

        newnode->depth = newnode->level;
        newnode->prev_highest = prev_highest;
     //    printf(" %d %d\n ", newnode->depth,newnode->prev_highest);
        
        newnode = newnode->next; /// goto the next node of the linked-list of net
    }

    return(1);

} /* end of BDS_BnetEnhance */


/**Function********************************************************************

  Synopsis    [Finding Critical Path]

  Description [Determining critical path to do eliminate (Navin's paper: Page 18 Section 5.1.1)
               The critical path is the longest depth from a primary output to primary
               inputs. Onlu one single longest critical path is obtained for each primary
               output.]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
extern
int
BDS_FindCriticalPath (
  BnetNetwork *net,
  st_table *delayNodeTbl,
  bdsOptions *option)
{
    int         i;
    int         highest_depth = 0;
    int         index=0;
    char        *names;
    BnetNode    *node, *fan_in, *tempnode, *tempnode1;
    lsGen       fanins;
    array_t     *output_depths;
    int         BDS_sort_on_depth();
    int         effort = 0;
    int         total_nodes = 0, multi_fanout_nodes = 0;
    int         result = 0;

    output_depths = array_alloc(BnetNode *,0);

    highest_depth = 0;
    for (i=0; i < net->npos; i++) { /// copy primary output nodes into output_depths array
        names = net->outputs[i]; /// primary output name
        if (st_lookup(net->hash, names, (char **) &node)) {
            array_insert_last(BnetNode *, output_depths, node);
            if (node->depth >= highest_depth) {
                highest_depth = node->depth; /// not used later
                index = i; /// not used later
            }
        }
    }

    array_sort(output_depths, BDS_sort_on_depth); /// sort array in descending order, the first element now has highest depth among all primary outputs

    switch(option->eps) {
        case 0: /// if eps = 0: only go through the first node that has the longest depth
            effort = 0;
            break;
        case 1: /// if eps = 1: go through all primary output nodes until the last twos do not have the same depth ??? (wrong)
            effort = 0;
            for (i=1; i<array_n(output_depths); i++) {
                tempnode = array_fetch(BnetNode *, output_depths, (i-1));
                tempnode1 = array_fetch(BnetNode *, output_depths, i);
                if (tempnode1->depth == tempnode->depth)
                    effort = i;
                else
                    continue;
            }
            break;
        case 2: /// if eps = 2: go through all primary output nodes with the same depth of first node or depth-1 of first node
            effort = 0;
            tempnode = array_fetch(BnetNode *, output_depths, 0); /// the first element of the array
            for (i=1; i<array_n(output_depths); i++) {
                tempnode1 = array_fetch(BnetNode *, output_depths, i);
                if (tempnode1->depth >= ((tempnode->depth)-1))
                    effort = i;
                else
                    continue;
            }
            break;
    }

    printf("\n");
    for (i=0;i<array_n(output_depths);i++) {
        tempnode = array_fetch(BnetNode *, output_depths, i);
        printf("%s %i\n",tempnode->name,tempnode->depth);
        ///printf("%i\n",tempnode->depth);
        //printf("name: %s, crit_node: %i",tempnode->name,tempnode->crit_node);
    }

    printf("effort = %i\n",effort);
    for (i=0; i <= effort; i++) { /// based on # nodes to go through, if 0, only the first node (longest depth node)
        tempnode = array_fetch(BnetNode *, output_depths, i);
        if (st_lookup(net->hash, tempnode->name, (char **) &node)) {
            if (option->eps != 2)
                printf(".");
            if (st_add_direct(delayNodeTbl, (char *) node, (char *) NULL) == ST_OUT_OF_MEM) {
                printf("Out of memory"); return(0);
            }
            node->crit_node = 1;
            total_nodes++;
            if (node->no_outputs > 1)
                multi_fanout_nodes++;
            ///i = BDS_CritPathRecursive(net, node,delayNodeTbl,&total_nodes,&multi_fanout_nodes); /// infinite loop if effort=1 or 2
            result = BDS_CritPathRecursive(net, node,delayNodeTbl,&total_nodes,&multi_fanout_nodes);
        }
    }

    array_free(output_depths);

    printf("\n");
    printf("Total nodes = %i \t Multiple output nodes = %i\n",total_nodes,multi_fanout_nodes);
    if (result== 1)
        return(1);
    else
        return(0);

 }


   /*fanins = lsStart(node->fanins);
     while (lsNext(fanins, (lsGeneric *) &fan_in, NULL) != LS_NOMORE) {*/


/// Recursive function for finding critical paths in the boolean network

extern
int
BDS_CritPathRecursive (
  BnetNetwork *net,
  BnetNode *node,
  st_table *delayNodeTbl,
  int *total_nodes,
  int *multi_fanout_nodes)
{
    int i;
    BnetNode *fanin;

    if (st_lookup(net->hash, node->inputs[node->prev_highest], (char **) &fanin)) {
        if (fanin->type == BNET_INPUT_NODE) return(1);
        printf(".");
        if (st_add_direct(delayNodeTbl, (char *) fanin, (char *) NULL) == ST_OUT_OF_MEM) {
            printf("Out of memory"); return(0);
        }
        fanin->crit_node = 1;
        (*total_nodes)++;
        if (fanin->no_outputs > 1)
            (*multi_fanout_nodes)++;
        i = BDS_CritPathRecursive(net, fanin, delayNodeTbl,total_nodes,multi_fanout_nodes);
    }

    else { /// error
        i = 0;
    }

    if (i == 1)
        return(1);
    else
        return(0);

}

BDS_sort_on_depth(s1, s2)
     BnetNode **s1;
     BnetNode **s2;
{

    BnetNode *ssink1;
    BnetNode *ssink2;

    ssink1 = *s1;
    ssink2 = *s2;


    /*  if(ssink1->measure < ssink2->measure)  return (1);
    if(ssink1->measure > ssink2->measure)  return (-1);*/

    if(ssink1->depth < ssink2->depth) return (1); /*  it is -1 originally*/
    if(ssink1->depth > ssink2->depth) return (-1); /* -1 here sorts in
                                                    descending order*/
    return 0;

}
