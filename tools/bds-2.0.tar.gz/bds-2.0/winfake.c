#include <windows.h>
#include <direct.h>
#include "winfake.h"

pid_t getpid (void) {
    return 9999;
}
int mkdir (const char* path, mode_t mode) {
    return _mkdir (path);
}
int uname (struct utsname* uname) {
    int len = SYS_NMLN;
    if (GetComputerName (uname->nodename, &len)) return 0;
    return -1;
}
