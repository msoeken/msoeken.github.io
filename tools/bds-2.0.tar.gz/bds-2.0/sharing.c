
/**CFile***********************************************************************

  FileName    [sharing.c]

  PackageName [BDS-pga]

  Synopsis    [Sharing extraction program]

  Description [This file contains the functions for sharing extraction of the boolean network.
  The commons logic between multi-BDDs are extracted, new bnodes
  are created to hold those common logics. The sharing between multi-BDDs are
  roughly categorized into two classes, algebraic and Boolean. Algebraic
  sharing is described as follows, there is a node on BDDs which is shared by
  multi-BDDs, and the node is a simple dominator for all the participated BDDs.
  The extraction of algebraic common logic is equivalent to perform BDD decomposition
  on multi-BDDs based on common a simple dominator. Boolean sharing is much
  hard to be identified. It corresponds to the shared node which is not
  simple dominator of all participated BDDs.]

  SeeAlso     []

  Date        [5/24/99]

  Author      [Anda Congguang Yang]

  Copyright   [The file was created in Department of Electrical & Computer
    Engineering, University of Massachusetts Amherst. All source codes
    in BDS package are CONFIDENTIAL before a formal release is
    announced. The author reserve all right of the package.]

******************************************************************************/
#include "sharing.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static lsList bdsGenerateGroupFromSeed ARGS((BnetNetwork*,BnetNode*,bdsOptions*));
static int bdsExtractAlgebraicSharing ARGS((DdManager*,BnetNetwork*,lsList,bdsOptions*,FILE*));
static int bdsExtractBooleanSharing ARGS((DdManager*,BnetNetwork*,lsList,bdsOptions*));
static DdNode* bdsIdentifyAlgebraicSharing ARGS((DdManager*,DdNode**,lsList,bdsOptions*));
static st_table** bdsGenerateAlgeCands ARGS((DdManager*,DdNode**,int,bdsOptions*));
static int bdsLockAlgebraicSharing ARGS((BnetNetwork*,DdManager*,DdManager*,DdNode*,lsList,\
        st_table*,array_t*,array_t*,array_t*,array_t*,int microNewVarId));
static int bdsLockAlgebraicResub ARGS((BnetNetwork*,DdManager*,DdManager*,DdNode*,lsList,\
        st_table*,array_t*,array_t*,array_t*,array_t*));
static DdNode ** bdsPrepareAlgebraicSharing ARGS((DdManager*,DdNode**,lsList,DdNode*,int,st_table*));
static DdNode ** bdsPrepareAlgebraicResub ARGS((DdManager*,DdNode**,lsList,DdNode*,int,st_table*));
static void bdsGetTransitiveFans ARGS((BnetNode*,st_table*,int));
static void bdsGetTransitiveFanins ARGS((BnetNode*,st_table*,int));
static void bdsGetTransitiveFanouts ARGS((BnetNode*,st_table*,int));
static int bdsBnetNodeUnique ARGS((lsGeneric,lsGeneric));
static int bdsFaninSort ARGS((lsGeneric,lsGeneric));
static char* bdsGetSharedNodeName ARGS((char*));
static lsList bdsUniquefyBnodes ARGS((DdManager*,BnetNetwork*,lsList,bdsOptions*,int*));

/**Function********************************************************************

  Synopsis    [Extract sharing between global BDDs]

  Description [Extract logic sharing based on global BDDs. This function may not be
  useful for large test cases in which global BDDs just can not be built.]

  SideEffects [Boolean network is modified to hold common logic]

  SeeAlso     []

  Last Date   [5/24/99]

*****************************************************************************/
extern
int
BDS_SharingExtractionGlobal(
  DdManager* bddmgr,
  BnetNetwork* net,
  bdsOptions* option)
{


  return(1);

} /* end of BDS_SharingExtractionGlobal */

/**Function********************************************************************

  Synopsis    [Extract sharing between local BDDs]

  Description [Each node in a Boolean network is used as a seed to generate a
  group from which possible sharing in the group is extracted. Then all possible
  sharings are extracted in the order of algebraic and Boolean sharing.]

  SideEffects [Boolean network is modified to hold common logic]

  SeeAlso     []

  Last Date   [5/24/99]

*****************************************************************************/
extern
int
BDS_SharingExtractionLocal(
  DdManager* bddmgr,
  BnetNetwork* net,
  bdsOptions* option,
  FILE *recdfp)
{
  int result, *live, dead;
  lsList tobeExtracted;
  BnetNode *node;
  st_generator *gen;

  (void) printf("\n\nExtracting sharing ..");
  (void) fflush(stdout);

#ifndef DEBUG
  fprintf(recdfp, "\n\n<<<<<<<<<<  BDS_SharingExtractionLocal  >>>>>>>>>>>\n\n");
#else
  printf("\n\n<<<<<<<<<<  BDS_SharingExtractionLocal  >>>>>>>>>>>\n\n");
#endif

  /* Extract algebraic sharings. During the process of sharing extraction, functionally
  ** equivalent bnodes might be created. Those bnodes should be removed before sharing
  ** extraction, and removed bnodes are marked DEAD_BNODE. They will be removed from
  ** livenodes table later (not during the generation process!).
  */
  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &node, (char **) &live)) {
     //   printf("sharing= %d %d %d \n", node->no_inputs, node->no_outputs, node->type);
      if (node->type == BNET_CONSTANT_NODE || node->type == BNET_INPUT_NODE) continue;
      if (live == (int *) DEAD_BNODE) continue;

      /* Generate group based on node as seed */
      tobeExtracted = bdsGenerateGroupFromSeed(net,node,option);
      if (tobeExtracted == NULL) continue;

      /* Uniquefy bnodes from which sharing is to be extracted. Functionally duplicated
      ** bnodes are removed from tobeExtracted list. # of removed bnodes is passed out.
      */
      tobeExtracted = bdsUniquefyBnodes(bddmgr,net,tobeExtracted,option,&dead);
      if (tobeExtracted == NULL) continue;

      /* Extract sharing among the group */
      result = bdsExtractAlgebraicSharing(bddmgr,net,tobeExtracted,option,recdfp);
      if (result == 0) return(0);

/* For debug only. -cyang 8/16/99.
      result = bdsVerifyPartition(bddmgr,net,option);
      if (result == 0) printf("Not equal !\n");
*/

      lsDestroy(tobeExtracted, NULL);

#ifndef DEBUG
      (void) printf(".");
      (void) fflush(stdout);
#endif
  }
  st_free_gen(gen);

  /* Extract Boolean sharings. Not implemented yet. -cyang
  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &node, NULL)) {
      if (node->type == BNET_CONSTANT_NODE || node->type == BNET_INPUT_NODE) continue;

      tobeExtracted = bdsGenerateGroupFromSeed(net,node,option);
      if (tobeExtracted == NULL) continue;

      result = bdsExtractBooleanSharing(bddmgr,net,tobeExtracted,option);
      if (result == 0) return(0);

      lsDestroy(tobeExtracted, NULL);

#ifndef DEBUG
      (void) printf(".");
      (void) fflush(stdout);
#endif
  }
  st_free_gen(gen);
  */

  /* Remove dead bnodes from livenodes table */
  if (dead > 1) {
      gen = st_init_gen(net->livenodes);
      while (st_gen(gen, (char **) &node, (char **) &live)) {
          if (live == (int *) DEAD_BNODE) {
          if (!st_delete(net->livenodes, (char **) &node, (char **) NULL)) {
              printf("Fatal error in BDS_SharingExtractionLocal\n");
          }
          (void) bdsFreeBnetNode(bddmgr, node);
      }
      }
      st_free_gen(gen);
  }

  printf("Done\n\n");

  return(1);

} /* end of BDS_SharingExtractionLocal */

/**Function********************************************************************

  Synopsis    [Generate a group of bnodes which share >=2 common fanins]

  Description [The node passed in is used as a seed to grow into a group of
  nodes which share more than 2 common fanins. This technique will prevent
  us from traversing the whole Boolean network every time to generate the
  group of bnodes. The bi-directional traversal of Boolean netwok's data
  structure is useful for this function. Return the group in lsList; NULL
  if there is no such group for the seed.]

  SideEffects []

  SeeAlso     []

  Last Date   [5/24/99]

*****************************************************************************/
static
lsList
bdsGenerateGroupFromSeed(
  BnetNetwork *net,
  BnetNode *seed,
  bdsOptions *option)
{
  int numComm, i;
  lsList groupNodes;
  BnetNode *fanout_node, *fanin_node, *eachNode, *dummy_node;
  st_table *seed_fanins, *blockNodeTbl;
  lsGen fanins, fanouts, eachNodeGen;

  groupNodes = lsCreate();
  seed_fanins = st_init_table(st_ptrcmp,st_ptrhash);

  /* Put fanins of the seed to a st_table, it'll be used to check
  ** number of common fanins
  */
  fanins = lsStart(seed->fanins);
  while (lsNext(fanins, (lsGeneric *) &fanin_node, NULL) != LS_NOMORE) {
      if (st_add_direct(seed_fanins, (char *) fanin_node, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
  }
  lsFinish(fanins);

  /* Collect all bnodes which share at least one common fanin with seed. */
  fanins = lsStart(seed->fanins);
  while (lsNext(fanins, (lsGeneric *) &fanin_node, NULL) != LS_NOMORE) {
      fanouts = lsStart(fanin_node->fanouts);
      while (lsNext(fanouts, (lsGeneric *) &fanout_node, NULL) != LS_NOMORE) {
          if (fanout_node != seed) {
              if (lsNewEnd(groupNodes, (lsGeneric) fanout_node, NULL) != LS_OK) {
                  printf("Out of memory"); exit(2);
              }
      }
      }
      lsFinish(fanouts);
  }
  lsFinish(fanins);

  /* Remove the duplicates */
  (void) lsSort(groupNodes, bdsBnetNodeUnique);
  (void) lsUniq(groupNodes, bdsBnetNodeUnique, NULL);

  /* Remove the BnetNodes which have only one common fanin with seed */
  eachNodeGen = lsStart(groupNodes);
  while (lsNext(eachNodeGen, (lsGeneric *) &eachNode, NULL) != LS_NOMORE) {
      /* if (eachNode == seed) continue; */

      numComm = 0;
      fanins = lsStart(eachNode->fanins);
      while (lsNext(fanins, (lsGeneric *) &fanin_node, NULL) != LS_NOMORE) {
          if (st_is_member(seed_fanins, (char *) fanin_node)) {
          numComm++;
      }
      }
      lsFinish(fanins);

      /* Delete eachNode if it has less than 2 common fanins with seed.
      ** Otherwise, record the number of common fanins with the seed. */
      if (numComm < 2) {
          (void) lsDelBefore(eachNodeGen, (lsGeneric*) &dummy_node);
      }
      else {
          eachNode->aux = numComm;
      }
  }
  lsFinish(eachNodeGen);

  /* Remove the possibility that one bnode in the group is the fanin(out) node
  ** of another bnode in the group. Since a bnode which has more common logc with seed
  ** tends to have more common sharings, all bnodes in the group are sorted according
  ** to their number of common fanins with seed. Seed is the first element of the lsList.
  */
  (void) lsSort(groupNodes, bdsFaninSort);

  /* Add seed to the beginning of groupNodes list */
  if (lsNewBegin(groupNodes, (lsGeneric) seed, NULL) != LS_OK) {
      printf("Out of memory"); exit(2);
  }

  blockNodeTbl = st_init_table(st_ptrcmp,st_ptrhash);
  eachNodeGen = lsStart(groupNodes);
  while (lsNext(eachNodeGen, (lsGeneric *) &eachNode, NULL) != LS_NOMORE) {
      if (eachNode == seed) {
          /* Get block bnodes based on seed. */
      (void) bdsGetTransitiveFans(eachNode,blockNodeTbl,BDS_TRANSITIVE_DEEPTH);
          continue;
      }
      if (st_is_member(blockNodeTbl, (char *) eachNode)) {
          (void) lsDelBefore(eachNodeGen, (lsGeneric*) &dummy_node);
      }
      else {
          /* Get block bnodes based on eachNode. */
          (void) bdsGetTransitiveFans(eachNode,blockNodeTbl,BDS_TRANSITIVE_DEEPTH);
      }
  }
  lsFinish(eachNodeGen);

  st_free_table(blockNodeTbl);
  st_free_table(seed_fanins);

  /* Return the group */
  if (lsLength(groupNodes) < 2) {
      lsDestroy(groupNodes, NULL);
      return(NULL);
  }
  else {
      /* Remove some bnodes if number of bnodes is too large, which will consume
      ** long time to reorder. Since the list is already sorted according to the
      ** common fanins, just take first BDS_MAX_SHARED_BNODES ones.
      */
      if (lsLength(groupNodes) > BDS_MAX_SHARED_BNODES) {
          i = 0;
          eachNodeGen = lsStart(groupNodes);
      while (lsNext(eachNodeGen, (lsGeneric *) &eachNode, NULL) != LS_NOMORE) {
          i++;
          if (i > BDS_MAX_SHARED_BNODES)
              (void) lsDelBefore(eachNodeGen, (lsGeneric*) &dummy_node);
      }
      lsFinish(eachNodeGen);
      }
      return(groupNodes);
  }

} /* end of bdsGenerateGroupFromSeed */

/**Function*******************************************************************

  Synopsis    [Get the transitive fans of a bnode]

  Description [Transitive fanins and fanouts of a bnode are recorded. To prevent
  from traversing all the Boolean network, the traversal depth is limited by
  depth.]

  SideEffects []

  SeeAlso     []

  Last Date   [6/1/99]

*****************************************************************************/
static
void
bdsGetTransitiveFans(
  BnetNode *bnode,
  st_table *blockNodeTbl,
  int depth)
{
  lsGen bnodeGen;
  BnetNode *fanode;

  /* Get transitive fanins */
  if (bnode->type != BNET_INPUT_NODE && bnode->type != BNET_CONSTANT_NODE) {
      bnodeGen = lsStart(bnode->fanins);
      while (lsNext(bnodeGen, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
          (void) bdsGetTransitiveFanins(fanode, blockNodeTbl, depth);
      }
      lsFinish(bnodeGen);
  }

  /* Get transitive fanouts */
  if (bnode->type != BNET_OUTPUT_NODE) {
      bnodeGen = lsStart(bnode->fanouts);
      while (lsNext(bnodeGen, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
          (void) bdsGetTransitiveFanouts(fanode, blockNodeTbl, depth);
      }
      lsFinish(bnodeGen);
  }

  return;

} /* end of bdsGetTransitiveFans */

/**Function*******************************************************************

  Synopsis    [Get the transitive fans of a bnode]

  Description [Transitive fanins and fanouts of a bnode are recorded. To prevent
  from traversing all the Boolean network, the traversal depth is limited by
  depth.]

  SideEffects []

  SeeAlso     []

  Last Date   [6/1/99]

*****************************************************************************/
static
void
bdsGetTransitiveFanins(
  BnetNode *bnode,
  st_table *blockNodeTbl,
  int depth)
{
  static int level; /* Number of level away from seed */
  lsGen bnodeGen;
  BnetNode *fanode;

  level++;

  /* To prevent depth is zero */
  if (level > depth) {
      level--;
      return;
  }
  /* Add bnode to the blockNodeTbl */
  if (!st_is_member(blockNodeTbl, (char *) bnode)) {
      if (st_add_direct(blockNodeTbl, (char *) bnode, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
  }
  if (bnode->type == BNET_INPUT_NODE || bnode->type == BNET_CONSTANT_NODE) {
      level--;
      return;
  }
  /* Iterate over all fanins if next level is not larger than depth. */
  if (level != depth) {
      bnodeGen = lsStart(bnode->fanins);
      while (lsNext(bnodeGen, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
          (void) bdsGetTransitiveFanins(fanode, blockNodeTbl, depth);
      }
      lsFinish(bnodeGen);
  }

  level--;
  return;

} /* end of bdsGetTransitiveFanins */

/**Function*******************************************************************

  Synopsis    [Get the transitive fans of a bnode]

  Description [Transitive fanins and fanouts of a bnode are recorded. To prevent
  from traversing all the Boolean network, the traversal depth is limited by
  depth.]

  SideEffects []

  SeeAlso     []

  Last Date   [6/1/99]

*****************************************************************************/
static
void
bdsGetTransitiveFanouts(
  BnetNode *bnode,
  st_table *blockNodeTbl,
  int depth)
{
  static int level; /* Number of level away from seed */
  lsGen bnodeGen;
  BnetNode *fanode;

  level++;

  /* To prevent depth is zero */
  if (level > depth) {
      level--;
      return;
  }
  /* Add bnode to the blockNodeTbl */
  if (!st_is_member(blockNodeTbl, (char *) bnode)) {
      if (st_add_direct(blockNodeTbl, (char *) bnode, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
  }
  if (bnode->type == BNET_OUTPUT_NODE) {
      level--;
      return;
  }
  /* Iterate over all fanouts if next level is not larger than depth. */
  if (level != depth) {
      bnodeGen = lsStart(bnode->fanouts);
      while (lsNext(bnodeGen, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
          (void) bdsGetTransitiveFanouts(fanode, blockNodeTbl, depth);
      }
      lsFinish(bnodeGen);
  }

  level--;
  return;

} /* end of bdsGetTransitiveFanouts */

/**Function*******************************************************************

  Synopsis    [Remove functionally equivalent bnodes before extracting sharing.]

  Description [Functionally equivalent bnodes are marked DEAD_BNODE (except one),
  they are going to be removed from livenodes table later. Boolean network is
  also modified to hold this change.
  To minimize the complexity of this function, return NULL if duplication is
  found in tobeExtracted. Return the original tobeExtracted if there is no
  duplication.]

  SideEffects [Boolean network is modified.]

  SeeAlso     []

  Last Date   [8/16/99]

*****************************************************************************/
static
lsList
bdsUniquefyBnodes(
  DdManager *bddmgr,
  BnetNetwork *net,
  lsList tobeExtracted,
  bdsOptions *option,
  int *dead)
{
  static int total_dead;
  int result;
  BnetNode *bnode;
  lsList dupList;
  lsGen bnodeGen;
  st_table *dupTbl, *srchTbl;
  st_generator *gen;
  DdNode *bdd, *bddnode;

  dupTbl = st_init_table(st_ptrcmp,st_ptrhash); /* Hold bdd which is shared by bnodes */
  srchTbl = st_init_table(st_ptrcmp,st_ptrhash);

  bnodeGen = lsStart(tobeExtracted);
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
      bdd = bnode->localBdd;
      if (st_is_member(srchTbl, (char *) bdd) || st_is_member(srchTbl, (char *) Cudd_Not(bdd)) ) {
          total_dead++;

      if (!st_is_member(dupTbl, (char *) bdd) && !st_is_member(dupTbl, (char *) Cudd_Not(bdd)) ) {
              if (st_insert(dupTbl, (char *) bdd, (char *) NULL) == ST_OUT_OF_MEM) {
              printf("Out of memory"); exit(2);
          }
      }
      }
      else {
          if (st_insert(srchTbl, (char *) bdd, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
      }
  }
  lsFinish(bnodeGen);
  st_free_table(srchTbl);

  *dead = total_dead;

  if (st_count(dupTbl) == 0) { /* Do nothing */
      st_free_table(dupTbl);

      return(tobeExtracted);
  }
  else { /* Remove functionally duplicated bnodes and mark them as DEAD_BNODE. */

      /* Collect duplicated bnodes in the format required by bdsSweepDuplicate(). */
      gen = st_init_gen(dupTbl);
      while (st_gen(gen, (char **) &bdd, NULL)) {
          dupList = lsCreate();
      bnodeGen = lsStart(tobeExtracted);
      while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
          if (bnode->localBdd == bdd || bnode->localBdd == Cudd_Not(bdd)) {
              if (lsNewEnd(dupList, (lsGeneric) bnode, NULL) != LS_OK) {
               printf("Out of memory"); exit(2);
          }
          }
      }
      lsFinish(bnodeGen);

      st_insert(dupTbl, (char *) bdd, (char *) dupList);
      }
      st_free_gen(gen);

      /* Remove the duplicated bnodes */
      result = bdsSweepDuplicate(bddmgr, net, dupTbl, option);
      if (result == 0) {
          printf("Fatal error in bdsUniquefyBnodes"); exit(2);
      }

      gen = st_init_gen(dupTbl);
      while (st_gen(gen, (char **) &bdd, (char **) &dupList)) {
          lsDestroy(dupList, NULL);
      }
      st_free_gen(gen);
      st_free_table(dupTbl);

      lsDestroy(tobeExtracted, NULL);

      return(NULL);
  }

} /* end of bdsUniquefyBnodes */

/**Function*******************************************************************

  Synopsis    [Extract algebraic sharing between local BDDs]

  Description [This is the reverse operation of eliminate().
  All possible algebraic sharing (see definition in this file head) are extracted.
  The extraction is proceeded as, 1) extract one algebraic sharing,
  2) create a new BnetNode to hold the sharing, 3) iterate over the rest BDDs until
  no algebraic sharing is identified. All BDDs are carried over to a new bddmgr
  to do the sharing extraction. This will prevent reordering on the original heavy-duty
  bddmgr. All substituted BDDs must be converted back to the orginal bddmgr finally.
  This function assume all incoming bdds are unique. Return 1 if successful; 0 otherwise.]

  SideEffects [Boolean network is modified to hold common logic]

  SeeAlso     [bdsExtractBooleanSharing(), BDS_CheckEliminateGainWithReorder()]

  Last Date   [5/24/99]

*****************************************************************************/
static
int
bdsExtractAlgebraicSharing(
  DdManager *bddmgr,
  BnetNetwork *net,         /* Boolean network to be modified */
  lsList tobeExtracted,     /* A group of bnodes from which common logic is extracted. */
  bdsOptions *option,
  FILE *recdfp /* File handle to dump reordering information */)
{
  DdNode *sharedNode;       /* Algebraically shared BDD node */
  DdNode **bdd_array, **dummybdd_array, *jointSupportBdd;
  DdNode *realLocalBdd, *scan, *dummyVar, *sharedNodeNeg, **q;
  bddPool *tmpBddPool;
  DdManager *microbddmgr;   /* New bddmgr in which all operations are carried out */
  int origOrder;            /* Record the number of vars in microbddmgr. Since order
                            ** is in natural order, only number of vars is recorded. */
  st_table *unaffected;     /* No change has been made on the bnodes' localBdd */
  st_table *master2bnode;   /* Master BDD node vs. BnetNode assoc. */
  st_generator *gen;
  int *real2dummy, i, *dummy2realInt, *varOrderBeforeInt, result;
  array_t *dummy2real;      /* Since new vars may be created in microbddmgr, int* is not enough */
  array_t *localVar2bnode;  /* Local variable in bddmgr vs. bnode */
  array_t *varOrderBefore, *varOrderAfter;
  lsList masterList;        /* The master bdd nodes in which algebraic sharing is legal. */
  int newVarId;             /* Var ID of a newly created var in microbddmgr. */
  lsGen bnodeGen;
  BnetNode *bnode;
  int *live,index ;

  /* Put all bnodes in unaffected at the beginning; if sharing is extracted from
  ** a set of bnodes, those bnodes should be removed from unaffected. The bnodes
  ** left in unaffected, BDD should not be re-constructed (in bddmgr) for them.
  */
  unaffected = st_init_table(st_ptrcmp,st_ptrhash);
  bnodeGen = lsStart(tobeExtracted);
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
      if (st_add_direct(unaffected, (char *) bnode, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory \n");
      exit(0);
      }
  }
  lsFinish(bnodeGen);

  /* Initialize microbddmgr */
  microbddmgr = startCudd(option, 0);

#ifndef DEBUG
  Cudd_SetStdout(microbddmgr, recdfp);
#endif

  /* Transfer all BDDs to microbddmgr. All BDD-related operations are carried out
  ** in the new microbddmgr. Record the original variables order, when BDDs in microbddmgr
  ** are converted back into bddmgr, there is no need to swap variables in bddmgr, only
  ** variable swap in microbddmgr is needed which should be much faster.
  */
  bdd_array = ALLOC(DdNode*, lsLength(tobeExtracted) + 1);
  i = 0;
  bnodeGen = lsStart(tobeExtracted);
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
       printf("local= %d  \n", bnode->type, (bnode->localBdd)->index);
      bdd_array[i] = bnode->localBdd;
      i++;
  }
  lsFinish(bnodeGen);
  bdd_array[i] = NULL;

  /* Get the joint support on all BDDs in the order of level */
  jointSupportBdd = Cudd_VectorSupport(bddmgr, bdd_array, lsLength(tobeExtracted));
  if (jointSupportBdd == NULL) return(0);
  Cudd_Ref(jointSupportBdd);
  FREE(bdd_array);

  /* Create dummy vars in microbddmgr, record dummy2real and real2dummy. real2dummy is
  ** used to construct BDDs in microbddmgr. dummy2real is used to re-construct BDDs in
  ** bddmgr after sharing extraction. Since new vars may be created in microbddmgr to
  ** hold identified sharings, dummy2real is dynamic, array_t* is used instead of int*.
  */
  real2dummy = ALLOC(int, bddmgr->size);
  dummy2real = array_alloc(int, 0);
  scan = jointSupportBdd;
  while (!cuddIsConstant(scan)) {
      dummyVar = Cudd_bddNewVar(microbddmgr);
      if (dummyVar == NULL) return(0);
      Cudd_Ref(dummyVar);

      real2dummy[Cudd_NodeReadIndex(scan)] = Cudd_NodeReadIndex(dummyVar);
      (void) array_insert_last(int, dummy2real, Cudd_NodeReadIndex(scan));
      scan = cuddT(scan);
  }
  Cudd_RecursiveDeref(bddmgr, jointSupportBdd);

  dummyVar = Cudd_bddNewVar(microbddmgr);
  if (dummyVar == NULL) return(0);
  Cudd_Ref(dummyVar);
  int microVarId= Cudd_NodeReadIndex(dummyVar);
  index = ddMax(bddmgr->size, bddmgr->sizeZ)-1;
  real2dummy[Cudd_NodeReadIndex(Cudd_ReadVars(bddmgr,index))] =microVarId;


  /* Transfer BDDs in bddmgr into microbddmgr */
  master2bnode = st_init_table(st_ptrcmp,st_ptrhash);
  bdd_array = ALLOC(DdNode*, lsLength(tobeExtracted) + 1);
  bnodeGen = lsStart(tobeExtracted);
  i = 0;
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
      tmpBddPool = BDS_StoreBddPoolLocal(bddmgr, bnode->localBdd);
      bdd_array[i] = bdsBuildDDFromBddPoolLocalWithOutCreateDummy(microbddmgr,tmpBddPool,real2dummy);
      if (st_add_direct(master2bnode, (char *) bdd_array[i], (char *) bnode) == ST_OUT_OF_MEM) {
          printf("Out of memory \n");
      exit(0);
      }
      i++;
  }
  lsFinish(bnodeGen);
  bdd_array[i] = NULL;
  /* Until here, local BDDs have been successfully constructed in new microbddmgr. */

  /* Record the variable ordering before reordering. Since new vars are going to be created,
  ** array_t* is used instead of int*.
  */
  varOrderBefore = array_alloc(int, microbddmgr->size);
  for (i = 0; i < microbddmgr->size; i++) {
      (void) array_insert(int, varOrderBefore, i, i);
  }

  /* Reorder the BDDs before extracting sharing */
  option->reordering = CUDD_REORDER_SIFT;
  BDS_Reorder(microbddmgr, NULL, option);

  /* Figure out the variable order after reordering. */
  varOrderAfter = array_alloc(int, microbddmgr->size);
  for (i = 0; i < microbddmgr->size; i++) {
      (void) array_insert(int, varOrderAfter, i, Cudd_ReadInvPerm(microbddmgr, i));
  }

  /* For debug only; -cyang 6/1/99
  (void) debugSharing(microbddmgr,tobeExtracted,bdd_array,option);
  */

  /* Find out localVarId vs. Boolean node correspondency */
  localVar2bnode = array_alloc(BnetNode*, bddmgr->size);
  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &bnode, (char **) &live)) {
      if (live == (int *) DEAD_BNODE) continue;
      (void) array_insert(BnetNode*, localVar2bnode, bnode->localVar, bnode);
  }
  st_free_gen(gen);

  /* Carry out algebraic sharing extraction and resubstitution. To minimize the complexity
  ** of this process, in each iteration only ONE algebraic sharing is extracted.
  */
  masterList = lsCreate();
  while (1) {

      /* Identify the algebraic shared bdd node and its master bdd nodes. Master bdd nodes
      ** are used to mapped to corresponding bnodes in the Boolean network.
      */
      sharedNode = bdsIdentifyAlgebraicSharing(microbddmgr,bdd_array,masterList,option);
      if (sharedNode == NULL) break;

      /* Remove bnodes in the masterList from unaffected table, the bdds associated
      ** with these bnodes must be re-constructed in bddmgr.
      */
      bnodeGen = lsStart(masterList);
      while (lsNext(bnodeGen, (lsGeneric *) &scan, NULL) != LS_NOMORE) {
          if (!st_lookup(master2bnode, (char *) scan, (char **) &bnode)) {
          fail("Fatal error in bdsExtractAlgebraicSharing");
      }
      st_delete(unaffected, (char **) &bnode, (char **) NULL);
      }
      lsFinish(bnodeGen);

      /* Update Boolean network accordingly to hold the sharing. */
      if (!st_is_member(master2bnode, (char *) sharedNode) &&
          !st_is_member(master2bnode, (char *) Cudd_Not(sharedNode))) { /* Algebraic sharing */

          newVarId = bdsLockAlgebraicSharing(net,bddmgr,microbddmgr,sharedNode,masterList,\
                        master2bnode,dummy2real,localVar2bnode,varOrderBefore,varOrderAfter,microVarId);

          /* Prepare new set of BDDs for next iteration. Update master2bnode table,
          ** since reconstruction of bdds may not retain the original pointers. bdd_array is also
          ** changed. The BDDs in masterList are shrinked by substituting sharedNode with newVarId.
          */
          bdd_array = bdsPrepareAlgebraicSharing(microbddmgr,bdd_array,masterList,sharedNode,\
                                             newVarId,master2bnode);
          if (bdd_array == NULL) fail("Fatal error in bdsExtractAlgebraicSharing");
      }
      else { /* Algebraic resubsitution */
          newVarId = bdsLockAlgebraicResub(net,bddmgr,microbddmgr,sharedNode,masterList,\
                        master2bnode,dummy2real,localVar2bnode,varOrderBefore,varOrderAfter);

          bdd_array = bdsPrepareAlgebraicResub(microbddmgr,bdd_array,masterList,sharedNode,\
                                           newVarId,master2bnode);
          if (bdd_array == NULL) fail("Fatal error in bdsExtractAlgebraicSharing");

          /* Remove sharedNode from master2bnode to prevent the bdd at bnode is re-constructed.
      sharedNodeNeg = Cudd_Not(sharedNode);
      if (!st_delete(master2bnode, (char **) &sharedNode, (char **) NULL) &&
          !st_delete(master2bnode, (char **) &sharedNodeNeg, (char **) NULL)) {
              fail("Fatal error in bdsExtractAlgebraicSharing");
          }
      */
      }

      /* Clean up masterList. It will be re-used in the next iteration.
      */
      bnodeGen = lsStart(masterList);
      while (lsNext(bnodeGen, (lsGeneric *) &scan, NULL) != LS_NOMORE) {
          (void) lsDelBefore(bnodeGen, (lsGeneric*) &dummyVar);
      }
      lsFinish(bnodeGen);
  }
  lsDestroy(masterList, NULL);

  /* Converted BDDs in microbddmgr back into bddmgr. Since all newly created bnodes have
  ** been completed, only master bdd nodes are converted. The conversion does not invlove
  ** bnodes which are in unaffected table.
  */
  dummy2realInt = array_data(int, dummy2real);
  varOrderBeforeInt = array_data(int, varOrderBefore);

  result = Cudd_ShuffleHeap(microbddmgr, varOrderBeforeInt);
  if (result == 0) fail("Fatal error in bdsExtractAlgebraicSharing");

  for (q = bdd_array; *q; q++) {
      if (!st_lookup(master2bnode, (char *) *q, (char **) &bnode)) {
          fail("Fatal error in bdsExtractAlgebraicSharing");
      }
      if (!st_is_member(unaffected, (char *) bnode)) {
          tmpBddPool = BDS_StoreBddPoolLocal(microbddmgr, *q);
          realLocalBdd = bdsBuildDDFromBddPoolLocalWithOutCreateDummy(bddmgr,tmpBddPool,dummy2realInt);
          if (realLocalBdd == NULL) fail("Fatal error in bdsLockAlgebraicSharing");

      Cudd_RecursiveDeref(bddmgr, bnode->localBdd);
      bnode->localBdd = realLocalBdd;
      }
  }

  FREE(bdd_array);
  FREE(real2dummy);
  FREE(dummy2realInt);
  FREE(varOrderBeforeInt);
  array_free(dummy2real);
  array_free(localVar2bnode);
  array_free(varOrderBefore);
  array_free(varOrderAfter);
  st_free_table(unaffected);
  st_free_table(master2bnode);
  Cudd_Quit(microbddmgr);

  return(1);

} /* end of bdsExtractAlgebraicSharing */

/**Function*******************************************************************

  Synopsis    [Identify an algebraic sharing from a set of BDDs.]

  Description [All BDD nodes are categorized into levels. The search procedure is
  started in a bottom-up fashion. Once a legal algebraic sharing is found, the
  corresponding bdd node is returned immediately. The definition of an algebraically
  legal sharing can be found in the corresponding function. Return NULL if no
  algebraic sharing has been found.]

  SideEffects []

  SeeAlso     [bdsExtractAlgebraicSharing(), BDS_CheckEliminateGainWithReorder()]

  Last Date   [8/3/99]

*****************************************************************************/
static
DdNode *
bdsIdentifyAlgebraicSharing(
  DdManager* bddmgr,
  DdNode **bdd_array, /* NULL-ended BDD array from which sharing is to be extracted. */
  lsList masterList,  /* A list of master BDD nodes in which algebraic sharing is contained. */
  bdsOptions *option)
{
  DdNode *aShared = NULL; /* Algebraic shared node, always in regular. */
  int i, j, result, numBdd, numMaster, level, *level2id, *id2level;
  DdNode *support, **q, *scan, *node;
  st_table *allNodes, **algeCands;
  st_generator *gen;
  array_t *master;   /* A list of master nodes */
  lsList *nodesOnLevel;
  lsGen nodeGen;

  /* Figure out number of bdds passed in */
  numBdd = 0;
  for (q = bdd_array; *q; q++){
      numBdd++;
  }

  /* Find out level information */
  support = Cudd_VectorSupport(bddmgr,bdd_array,numBdd);
  if (support == NULL) fail("Out of memory");
  Cudd_Ref(support);

  id2level = ALLOC(int, bddmgr->size);
  (void) memset((int *)id2level,0xFFFF,(bddmgr->size) * sizeof(int));
  level = Cudd_SupportSize(bddmgr, support);
  level2id = ALLOC(int, level);
  scan = support;
  i = 0;
  while (!cuddIsConstant(scan)) {
      level2id[i] = scan->index;
      id2level[scan->index] = i;
      scan = cuddT(scan);
      i++;
  }
  Cudd_RecursiveDeref(bddmgr,support);

  /* Categorize all nodes into levels */
  allNodes = st_init_table(st_ptrcmp, st_ptrhash);
  if (allNodes == NULL) return(0);
  for (q = bdd_array; *q; q++) {
      result = cuddCollectNodes(Cudd_Regular(*q), allNodes);
      if (result == 0) fail("Out of memory");
  }
  nodesOnLevel = ALLOC(lsList, level);
  for (i = 0; i < level; i++) {
      nodesOnLevel[i] = lsCreate();
  }
  gen = st_init_gen(allNodes);
  if (gen == NULL) return(0);
  while (st_gen(gen, (char **) &node, NULL)) {
      if (cuddIsConstant(node)) continue;
      if (lsNewEnd(nodesOnLevel[id2level[node->index]], (lsGeneric) node, NULL) != LS_OK) {
          fail("Out of memory");
      }
  }
  st_free_gen(gen);

  /* Generate all algebraic candidates from bdd_array. If an algebraic candidate
  ** is shared by more than one master bdds, it is the algebraic shared node.
  */
  algeCands = bdsGenerateAlgeCands(bddmgr, bdd_array, numBdd,option);
  if (algeCands == NULL) fail("Fatal error in bdsIdentifyAlgebraicSharing");

  /* Check if a bdd node is an algebraic shared node. The checking is proceeded in a bottom-up
  ** fashion. Whenever an algebraic shared node is identified, return immediately.
  ** The bottom level is bypassed, because sharing should contain at least two variables.
  */
  for (i = level - 2; i > 0; i--) {
      nodeGen = lsStart(nodesOnLevel[i]);
      while (lsNext(nodeGen, (lsGeneric *) &node, NULL) != LS_NOMORE) {
          numMaster = 0;
          for (j = 0; j < numBdd; j++) {
          if (st_is_member(algeCands[j], (char *) Cudd_Regular(node))) numMaster++;
      }
      if (numMaster > 1) { /* Find an algebraic sharing */
          for (j = 0; j < numBdd; j++) {
              if (st_is_member(algeCands[j], (char *) Cudd_Regular(node))) {
              if (lsNewEnd(masterList, (lsGeneric) bdd_array[j], NULL) != LS_OK) {
                  fail("Out of memory");
              }
                  }
          }
          aShared = node;
          break;
      }
      }
      lsFinish(nodeGen);

      if (aShared != NULL) {
          break;
      }
  }

  /* Free memory allocated in this function */
  FREE(id2level); FREE(level2id);
  for (i = 0; i < level; i++) {
      lsDestroy(nodesOnLevel[i],NULL);
  }
  FREE(nodesOnLevel);
  for (i = 0; i < numBdd; i++) {
      st_free_table(algeCands[i]);
  }
  FREE(algeCands);
  st_free_table(allNodes);

  return(aShared);

} /* end of bdsIdentifyAlgebraicSharing */

/**Function*******************************************************************

  Synopsis    [Find out all algebraic nodes on bdds]

  Description [The algebraic eligible node is a bdd node which either is a
  simple dominator or a support disjoint node. Caller's responsibility to free
  returned st_table array.]

  SideEffects []

  SeeAlso     []

  Last Date   [8/3/99]

*****************************************************************************/
static
st_table **
bdsGenerateAlgeCands(
  DdManager *bddmgr,
  DdNode **bdd_array,
  int numBdd /* Number of BDDs */,
  bdsOptions *option)
{
  st_table **algeCands; /* Return value */
  int i, j, *support, level;
  edgeMark **edgeProperty;
  DdNode *bottom;

  algeCands = ALLOC(st_table*, numBdd);
  for (i = 0; i < numBdd; i++) {
      algeCands[i] = st_init_table(st_ptrcmp,st_ptrhash);

      /* Put the master node into hash table if reference count > 1. The master node
      ** could be shared by other BDDs.
      */
      if (Cudd_Regular(bdd_array[i])->ref > 1) {
          if (st_add_direct(algeCands[i], (char *) Cudd_Regular(bdd_array[i]) , (char *) NULL)
                                                     == ST_OUT_OF_MEM) {
          fail("Out of memory");
      }
      }

      support = BDS_SupportArray(bddmgr, bdd_array[i], &level);
      if (support == NULL) fail("Fatal error in bdsGenerateAlgeCands");

      /* Find out property of each level */
      edgeProperty = BDS_MarkEdges(bddmgr, bdd_array[i], support, level,1,option);
      if (edgeProperty == NULL) fail("Fatal error in bdsGenerateAlgeCands");

      for (j = 0; j < level; j++) {
          bottom = edgeProperty[j]->bottom;
          if (st_count(edgeProperty[j]->table) == 1 && bottom->ref > 1 &&
                   !(Cudd_IsConstant(Cudd_T(bottom)) && Cudd_IsConstant(Cudd_E(bottom))) ) {
          if (st_add_direct(algeCands[i], (char *) bottom, (char *) NULL)
                                    == ST_OUT_OF_MEM) {
              fail("Out of memory");
          }
          }
      }
      BDS_FreeEdgeProperty(support,edgeProperty,level);
  }

  return(algeCands);

} /* end of bdsGenerateAlgeCands */

/**Function*******************************************************************

  Synopsis    [Lock algebraic sharing]

  Description [The algebraic sharing is locked by creating a new var in microbddmgr,
  a new Boolean node in the Boolean network and a new local var in bddmgr. The bdd
  corresponding to the algebraic sharing is converted into bddmgr. Boolean netowrk
  is modified to accommdate this new bnode. The newly created var in microbddmgr
  is returned for the following bdd_array updating purpose. dummy2real and localVar2bnode
  are also updated.]

  SideEffects [Boolean netowrk is modified.]

  SeeAlso     []

  Last Date   [8/6/99]

*****************************************************************************/
static
int
bdsLockAlgebraicSharing(
  BnetNetwork *net,       /* net is going to be modified. */
  DdManager *bddmgr,      /* mgr in the original Boolean network */
  DdManager *microbddmgr, /* mgr in which the sharing is identified. */
  DdNode *sharedNode,     /* The algebraic sharing */
  lsList masterList,      /* The master BDD nodes in which algebraic sharing contained. */
  st_table *master2bnode, /* Master BDD nodes vs. Boolean nodes */
  array_t *dummy2real,    /* The correspondency between var in microbddmgr vs. bddmgr. */
  array_t *localVar2bnode,/* Correspondency between local Var (in bddmgr) and bnodes */
  array_t *varOrderBefore,/* Original variable order in microbddmgr */
  array_t *varOrderAfter,  /* Variable order after reordering */
  int microNewVarId
)
{
  int newVarId,  varId, result, realId,index;
  int *dummy2realInt, *varOrderBeforeInt, *varOrderAfterInt;
  DdNode *newVar, *microNewVar, *bddnode, *support, *scan, *realLocalBdd;
  BnetNode *newBnode, *bnode, *bnode2, *masterBnode, *dummy_node;
  bddPool *bddPoolShared;
  st_table *suppShared, *masterTable;
  st_generator *gen;
  lsGen nodeGen, nodeGen2;

  /* Created a newVar in both bddmgr and microbddmgr. Create a new Boolean node in net.
  */
  index = ddMax(bddmgr->size, bddmgr->sizeZ)-1;
  newVar = Cudd_ReadVars(bddmgr,index);
  if (newVar == NULL) fail("Can not create new vars");
 // Cudd_Ref(newVar);
  newVarId = newVar->index;

  microNewVar =Cudd_ReadVars(microbddmgr,microNewVarId);
  if (microNewVar == NULL) fail("Can not create new vars");
 // Cudd_Ref(microNewVar);
  // = microNewVar->index;

  /* Put the new var in varOrder */
  array_insert_last(int, varOrderBefore, microNewVarId);
  array_insert_last(int, varOrderAfter, microNewVarId);

  newBnode = ALLOC(BnetNode, 1);
  if (newBnode == NULL) fail("Out of memory");
  memset((char *) newBnode, 0, sizeof(BnetNode));
  newBnode->name = bdsGetSharedNodeName("bdsShared");
  newBnode->type = BNET_INTERNAL_NODE;
  newBnode->fanins = lsCreate();
  newBnode->fanouts = lsCreate();
  newBnode->localActive = TRUE;
  newBnode->localVar = newVarId;
  if (st_add_direct(net->livenodes, (char *) newBnode, (char *) LIVE_BNODE) == ST_OUT_OF_MEM) {
      printf("Out of memory"); exit(2);
  }

  /* Re-structure the Boolean network by figure out the fanins and fanouts...
  */
  suppShared = st_init_table(st_ptrcmp,st_ptrhash);
  support = Cudd_Support(microbddmgr, sharedNode);
  if (support == NULL) fail("Fatal error in bdsLockAlgebraicSharing");
  Cudd_Ref(support);
  scan = support;
  while (!cuddIsConstant(scan)) {
      realId = array_fetch(int, dummy2real, scan->index);
      bnode = array_fetch(BnetNode*, localVar2bnode, realId);
      if (st_add_direct(suppShared, (char *) bnode, NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory\n"); exit(2);
      }
      scan = cuddT(scan);
  }
  Cudd_RecursiveDeref(microbddmgr, support);

  /* Fix fanins of newBnode */
  gen = st_init_gen(suppShared);
  while (st_gen(gen, (char **) &bnode, NULL)) {
      if (lsNewEnd(newBnode->fanins, (lsGeneric) bnode, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }
  }
  st_free_gen(gen);

  /* Fix fanouts of newBnode and transform masterList into a table which will
  ** facilitate the following operations
  */
  masterTable = st_init_table(st_ptrcmp,st_ptrhash);
  nodeGen = lsStart(masterList);
  while (lsNext(nodeGen, (lsGeneric *) &bddnode, NULL) != LS_NOMORE) {
      if (!st_lookup(master2bnode, (char *) bddnode, (char **) &bnode)) {
          fail("Fatal error in bdsLockAlgebraicSharing");
      }
      if (lsNewEnd(newBnode->fanouts, (lsGeneric) bnode, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }
      if (st_add_direct(masterTable, (char *) bnode, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
  }
  lsFinish(nodeGen);

  /* Fix the fanins of bnodes in masterList. Delete nodes in suppShared, add newBnode.
  */
  nodeGen = lsStart(masterList);
  while (lsNext(nodeGen, (lsGeneric *) &bddnode, NULL) != LS_NOMORE) {
      if (!st_lookup(master2bnode, (char *) bddnode, (char **) &bnode)) {
          fail("Fatal error in bdsLockAlgebraicSharing");
      }
      nodeGen2 = lsStart(bnode->fanins);
      while (lsNext(nodeGen2, (lsGeneric *) &bnode2, NULL) != LS_NOMORE) {
          if (st_is_member(suppShared, (char *) bnode2)) {
          (void) lsDelBefore(nodeGen2, (lsGeneric*) &dummy_node);
      }
      }
      lsFinish(nodeGen2);

      if (lsNewEnd(bnode->fanins, (lsGeneric) newBnode, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }
      (void) lsSort(bnode->fanins, bdsUniqueBnetNode);
      (void) lsUniq(bnode->fanins, bdsUniqueBnetNode, NULL);
  }
  lsFinish(nodeGen);

  /* Fix the fanouts of nodes in suppShared. Delete nodes in masterList from fanouts,
  ** add newBnode as new fanout.
  */
  gen = st_init_gen(suppShared);
  while (st_gen(gen, (char **) &bnode, NULL)) {
      nodeGen = lsStart(bnode->fanouts);
      while (lsNext(nodeGen, (lsGeneric *) &bnode2, NULL) != LS_NOMORE) {
          if (st_is_member(masterTable, (char *) bnode2)) {
          (void) lsDelBefore(nodeGen, (lsGeneric*) &dummy_node);
      }
      }
      lsFinish(nodeGen);

      if (lsNewEnd(bnode->fanouts, (lsGeneric) newBnode, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }
      (void) lsSort(bnode->fanouts, bdsUniqueBnetNode);
      (void) lsUniq(bnode->fanouts, bdsUniqueBnetNode, NULL);
  }
  st_free_gen(gen);

  /* Convert BDD associated with sharedNode into bddmgr and updated the corresponding
  ** Boolean node's fields. This is proceeded as, 1) Swap var order in microbddmgr into
  ** the original var order; 2) dump and re-construct sharedNode's bdd; 3) Swap var
  ** order back into varOrderAfter.
  */
  Cudd_Ref(sharedNode);
  dummy2realInt = array_data(int, dummy2real);
  varOrderBeforeInt = array_data(int, varOrderBefore);
  varOrderAfterInt = array_data(int, varOrderAfter);

  result = Cudd_ShuffleHeap(microbddmgr, varOrderBeforeInt);
  if (result == 0) fail("Fatal error in bdsLockAlgebraicSharing");

  bddPoolShared = BDS_StoreBddPoolLocal(microbddmgr, sharedNode);
  realLocalBdd = bdsBuildDDFromBddPoolLocalWithOutCreateDummy(bddmgr,bddPoolShared,dummy2realInt);
  if (realLocalBdd == NULL) fail("Fatal error in bdsLockAlgebraicSharing");
  newBnode->localBdd = realLocalBdd;

  result = Cudd_ShuffleHeap(microbddmgr, varOrderAfterInt);
  if (result == 0) fail("Fatal error in bdsLockAlgebraicSharing");
  Cudd_RecursiveDeref(microbddmgr, sharedNode);

  /* Update dummy2real and localVar2bnode. */
  (void) array_insert(int, dummy2real, microNewVarId, newVarId);
  (void) array_insert(BnetNode*, localVar2bnode, newVarId, newBnode);

  st_free_table(suppShared);
  st_free_table(masterTable);
  FREE(dummy2realInt);
  FREE(varOrderBeforeInt);
  FREE(varOrderAfterInt);

  return(microNewVarId);

} /* end of bdsLockAlgebraicSharing */

/**Function*******************************************************************

  Synopsis    [Algebraic resubstitution.]

  Description [No new var and bnode are created, just network restructuring.]

  SideEffects [The network connection is modified]

  SeeAlso     []

  Last Date   [8/9/99]

*****************************************************************************/
static
int
bdsLockAlgebraicResub(
  BnetNetwork *net,       /* net is going to be modified. */
  DdManager *bddmgr,      /* mgr in the original Boolean network */
  DdManager *microbddmgr, /* mgr in which the sharing is identified. */
  DdNode *sharedNode,     /* The algebraic sharing */
  lsList masterList,      /* The master BDD nodes in which algebraic sharing contained. */
  st_table *master2bnode, /* Master BDD nodes vs. Boolean nodes */
  array_t *dummy2real,    /* The correspondency between var in microbddmgr vs. bddmgr. */
  array_t *localVar2bnode,/* Correspondency between local Var (in bddmgr) and bnodes */
  array_t *varOrderBefore,/* Original microbddmgr variable order */
  array_t *varOrderAfter  /* Variable order after reordering */)
{
  int realId, microNewVarId;
  DdNode *bddnode, *support, *scan, *microNewVar;
  BnetNode *newBnode, *bnode, *bnode2, *dummy_node;
  st_table *suppShared, *masterTable;
  st_generator *gen;
  lsGen nodeGen, nodeGen2;

  /* Figure out the bnode (newBnode) with which other bnodes will be substituted.
  */
  if (!st_lookup(master2bnode, (char *) sharedNode, (char **) &newBnode) &&
      !st_lookup(master2bnode, (char *) Cudd_Not(sharedNode), (char **) &newBnode)) {
      fail("Fatal error in bdsLockAlgebraicResub");
  }

  /* Created a newVar in microbddmgr only. */
  microNewVar = Cudd_bddNewVar(microbddmgr);
  if (microNewVar == NULL) fail("Can not create new vars");
  Cudd_Ref(microNewVar);
  microNewVarId = microNewVar->index;

  /* Put the new var in varOrder */
  array_insert_last(int, varOrderBefore, microNewVarId);
  array_insert_last(int, varOrderAfter, microNewVarId);

  /* Fix dummy2real */
  (void) array_insert(int, dummy2real, microNewVarId, newBnode->localVar);

  /* Obtain commom fanins of the sharing.
  */
  suppShared = st_init_table(st_ptrcmp,st_ptrhash);
  support = Cudd_Support(microbddmgr, sharedNode);
  if (support == NULL) fail("Fatal error in bdsLockAlgebraicResub");
  Cudd_Ref(support);
  scan = support;
  while (!cuddIsConstant(scan)) {
      realId = array_fetch(int, dummy2real, scan->index);
      bnode = array_fetch(BnetNode*, localVar2bnode, realId);
      if (st_add_direct(suppShared, (char *) bnode, NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory\n"); exit(2);
      }
      scan = cuddT(scan);
  }
  Cudd_RecursiveDeref(microbddmgr, support);

  /* Fix fanouts of newBnode and transform masterList into a table which will
  ** facilitate the following operations. newBnode is excluded from this table.
  */
  masterTable = st_init_table(st_ptrcmp,st_ptrhash);
  nodeGen = lsStart(masterList);
  while (lsNext(nodeGen, (lsGeneric *) &bddnode, NULL) != LS_NOMORE) {
      if (!st_lookup(master2bnode, (char *) bddnode, (char **) &bnode)) {
          fail("Fatal error in bdsLockAlgebraicSharing");
      }
      if (bnode == newBnode) continue;
      if (newBnode->fanouts == NULL) newBnode->fanouts = lsCreate();
      if (lsNewEnd(newBnode->fanouts, (lsGeneric) bnode, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }
      if (st_add_direct(masterTable, (char *) bnode, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
  }
  lsFinish(nodeGen);

  (void) lsSort(newBnode->fanouts, bdsUniqueBnetNode);
  (void) lsUniq(newBnode->fanouts, bdsUniqueBnetNode, NULL);

  /* Fix the fanins of bnodes in masterList (not include newBnode. Delete nodes in
  ** suppShared, add newBnode.
  */
  nodeGen = lsStart(masterList);
  while (lsNext(nodeGen, (lsGeneric *) &bddnode, NULL) != LS_NOMORE) {
      if (bddnode == sharedNode || Cudd_Not(bddnode) == sharedNode) continue;
      if (!st_lookup(master2bnode, (char *) bddnode, (char **) &bnode)) {
          fail("Fatal error in bdsLockAlgebraicSharing");
      }
      nodeGen2 = lsStart(bnode->fanins);
      while (lsNext(nodeGen2, (lsGeneric *) &bnode2, NULL) != LS_NOMORE) {
          if (st_is_member(suppShared, (char *) bnode2)) {
          (void) lsDelBefore(nodeGen2, (lsGeneric*) &dummy_node);
      }
      }
      lsFinish(nodeGen2);

      if (lsNewEnd(bnode->fanins, (lsGeneric) newBnode, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }
      (void) lsSort(bnode->fanins, bdsUniqueBnetNode);
      (void) lsUniq(bnode->fanins, bdsUniqueBnetNode, NULL);
  }
  lsFinish(nodeGen);

  /* Fix the fanouts of nodes in suppShared. Delete nodes in masterList (not include newBnode)
  ** from fanouts
  */
  gen = st_init_gen(suppShared);
  while (st_gen(gen, (char **) &bnode, NULL)) {
      nodeGen = lsStart(bnode->fanouts);
      while (lsNext(nodeGen, (lsGeneric *) &bnode2, NULL) != LS_NOMORE) {
          if (st_is_member(masterTable, (char *) bnode2)) {
          (void) lsDelBefore(nodeGen, (lsGeneric*) &dummy_node);
      }
      }
      lsFinish(nodeGen);
  }
  st_free_gen(gen);

  st_free_table(suppShared);
  st_free_table(masterTable);

  return(microNewVarId);

} /* end of bdsLockAlgebraicResub */

/**Function*******************************************************************

  Synopsis    [Reconstruct bdd_array by using newly created locking var.]

  Description [The BDDs which have algebraic sharing are sharinked by using sharedNode.]

  SideEffects [The pointers for BDDs in bdd_array will be modofied.]

  SeeAlso     []

  Last Date   [8/9/99]

*****************************************************************************/
static
DdNode **
bdsPrepareAlgebraicSharing(
  DdManager *bddmgr,
  DdNode **bdd_array,     /* Bdd array from which sharing is extracted. */
  lsList masterList,      /* A list bdds from which sharing is extracted. */
  DdNode *sharedNode,     /* The bdd node to be substituted. */
  int newVarId,           /* The newVar used for substitution. */
  st_table *master2bnode)
{
  DdNode **new_bdd_array = NULL, **q, *bddnode, *newbdd, *subVar;
  BnetNode *bnode;
  int i, numBdd;
  st_table *masterTable;
  lsGen nodeGen;
  bddPool *tmpBddPool;

  /* Figure out number of bdds passed in */
  numBdd = 0;
  for (q = bdd_array; *q; q++){
      numBdd++;
  }
  new_bdd_array = ALLOC(DdNode*, numBdd + 1);

  /* Put masterList in masterTable for easy checking */
  masterTable = st_init_table(st_ptrcmp,st_ptrhash);
  nodeGen = lsStart(masterList);
  while (lsNext(nodeGen, (lsGeneric *) &bddnode, NULL) != LS_NOMORE) {
      if (st_add_direct(masterTable, (char *) bddnode, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
  }
  lsFinish(nodeGen);

  subVar = Cudd_ReadVars(bddmgr, newVarId);
  Cudd_Ref(subVar);

  for (i = 0; i < numBdd; i++) {
      if (st_is_member(masterTable, (char *) bdd_array[i])) { /* Re-construct the bdd */

          tmpBddPool = bdsDumpResubBddPool(bddmgr, bdd_array[i], sharedNode, subVar);
      if (tmpBddPool == NULL) fail("Fatal error in bdsPrepareAlgebraicSharing");

      newbdd = bdsBuildResubBddFromBddPool(bddmgr, tmpBddPool);
      if (newbdd == NULL) fail("Fatal error in bdsPrepareAlgebraicSharing");

      new_bdd_array[i] = newbdd;
      Cudd_RecursiveDeref(bddmgr, bdd_array[i]);

      /* update master2bnode table */
      if (!st_delete(master2bnode, (char **) &bdd_array[i], (char **) &bnode)) {
          fail("Fatal error in bdsPrepareAlgebraicSharing");
      }
          if (st_add_direct(master2bnode, (char *) newbdd, (char *) bnode) == ST_OUT_OF_MEM) {
              printf("Out of memory"); exit(2);
          }
      }
      else { /* No need to re-construct */
          new_bdd_array[i] = bdd_array[i];
      }
  }
  new_bdd_array[i] = NULL;

  Cudd_RecursiveDeref(bddmgr, subVar);
  FREE(bdd_array);
  st_free_table(masterTable);

  return(new_bdd_array);

} /* end of bdsPrepareAlgebraicSharing */

/**Function*******************************************************************

  Synopsis    [Re-construct bdd_array by using the newVar]

  Description [The bdds in masterList are shrinked by using sharedNode]

  SideEffects [Boolean network is modified to hold common logic]

  SeeAlso     []

  Last Date   [8/9/99]

*****************************************************************************/
static
DdNode **
bdsPrepareAlgebraicResub(
  DdManager *bddmgr,
  DdNode **bdd_array,
  lsList masterList,
  DdNode *sharedNode,
  int newVarId,
  st_table *master2bnode)
{
  DdNode **new_bdd_array = NULL, **q, *bddnode, *newbdd, *subVar, *mbdd;
  BnetNode *bnode;
  int i, j, numBdd;
  st_table *masterTable;
  lsGen nodeGen;
  bddPool *tmpBddPool;

  /* Figure out number of bdds passed in */
  numBdd = 0;
  for (q = bdd_array; *q; q++){
      numBdd++;
  }
  new_bdd_array = ALLOC(DdNode*, numBdd + 1);

  /* Put masterList (not include sharedNode) in masterTable for easy checking */
  masterTable = st_init_table(st_ptrcmp,st_ptrhash);
  nodeGen = lsStart(masterList);
  while (lsNext(nodeGen, (lsGeneric *) &bddnode, NULL) != LS_NOMORE) {
      if (bddnode == sharedNode || bddnode == Cudd_Not(sharedNode)) {
          mbdd = bddnode;
      }
      if (st_add_direct(masterTable, (char *) bddnode, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
  }
  lsFinish(nodeGen);

  subVar = Cudd_ReadVars(bddmgr, newVarId);
  Cudd_Ref(subVar);
  if (mbdd == Cudd_Not(sharedNode)) subVar = Cudd_Not(subVar);

  /* Since bdd associated with sharedNode has been the sharing, there is no algebraic
  ** sharing between it and other bdds, delete it from bdd_array. index j is used to prevent
  ** a NULL element in the array.
  */
  for (i = 0; i < numBdd; i++) {
      if (st_is_member(masterTable, (char *) bdd_array[i]) && bdd_array[i] != mbdd) {
          /* Re-construct the bdd */

          tmpBddPool = bdsDumpResubBddPool(bddmgr, bdd_array[i], sharedNode, subVar);
      if (tmpBddPool == NULL) fail("Fatal error in bdsPrepareAlgebraicSharing");

      newbdd = bdsBuildResubBddFromBddPool(bddmgr, tmpBddPool);
      if (newbdd == NULL) fail("Fatal error in bdsPrepareAlgebraicSharing");

      new_bdd_array[i] = newbdd;
      Cudd_RecursiveDeref(bddmgr, bdd_array[i]);

      /* update master2bnode table */
      if (!st_delete(master2bnode, (char **) &bdd_array[i], (char **) &bnode)) {
          fail("Fatal error in bdsPrepareAlgebraicSharing");
      }
          if (st_add_direct(master2bnode, (char *) newbdd, (char *) bnode) == ST_OUT_OF_MEM) {
              printf("Out of memory"); exit(2);
          }
      }
      else { /* No need to re-construct */
          new_bdd_array[i]= bdd_array[i];
      }
  }
  new_bdd_array[i] = NULL;

  Cudd_RecursiveDeref(bddmgr, subVar);
  FREE(bdd_array);
  st_free_table(masterTable);

  return(new_bdd_array);

} /* end of bdsPrepareAlgebraicResub */

/**Function*******************************************************************

  Synopsis    [Extract Boolean sharing between local BDDs]

  Description []

  SideEffects [Boolean network is modified to hold common logic]

  SeeAlso     [bdsExtractAlgebraicSharing(), BDS_CheckEliminateGainWithReorder()]

  Last Date   [5/24/99]

*****************************************************************************/
static
int
bdsExtractBooleanSharing(
  DdManager* bddmgr,
  BnetNetwork* net,
  lsList tobeExtracted,
  bdsOptions* option)
{

  return(1);

} /* end of bdsExtractBooleanSharing */

/**Function********************************************************************

  Synopsis    [Compare() used for lsSort and lsUniq]

  Description []

  SideEffects []

  SeeAlso     []

  Last Date   [3/24/99]

*****************************************************************************/
static
int
bdsBnetNodeUnique(
  lsGeneric node1,
  lsGeneric node2)
{
  BnetNode *bnet_node1, *bnet_node2;

  bnet_node1 = (BnetNode *) node1;
  bnet_node2 = (BnetNode *) node2;

  if (bnet_node1 < bnet_node2) {
    return(-1);
  }
  else if (bnet_node1 == bnet_node2) {
    return(0);
  }
  else {
    return(1);
  }

} /* end of bdsBnetNodeUnique */

/**Function********************************************************************

  Synopsis    [Compare() used for lsSort and lsUniq]

  Description []

  SideEffects []

  SeeAlso     []

  Last Date   [3/24/99]

*****************************************************************************/
static
int
bdsFaninSort(
  lsGeneric node1,
  lsGeneric node2)
{
  BnetNode *bnet_node1, *bnet_node2;

  bnet_node1 = (BnetNode *) node1;
  bnet_node2 = (BnetNode *) node2;

  if (bnet_node1->aux < bnet_node2->aux) {
      return(1);
  }
  else if (bnet_node1->aux == bnet_node2->aux) {
      return(0);
  }
  else {
      return(-1);
  }

} /* end of bdsFaninSort */

/**Function*******************************************************************

  Synopsis    [Generate a name for a newly created Boolean node]

  Description [The name is the combination of inputed string and a sequence number.]

  SideEffects [There is a potential disadvantage of this implementation. When somebody
  wants to re-run BDS on the blif generated by BDS, it may end up with wrong results,
  becasue there are more than one node with the same name.]

  SeeAlso     []

  Last Date   [8/6/99]

*****************************************************************************/
static
char *
bdsGetSharedNodeName(
  char *string)
{
  char *retName, *numChar;
  static int number;

  retName = ALLOC(char, strlen(string) + 6);
  strcpy(retName, string);

  numChar = ALLOC(char, 6);
  sprintf(numChar, "%d", number);

  strcat(retName, numChar);
  FREE(numChar);

  number++;

  return(retName);

} /* end of bdsGetSharedNodeName */



