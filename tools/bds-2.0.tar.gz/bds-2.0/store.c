
/**CFile***********************************************************************

  FileName    [store.c]

  PackageName [BDS-pga]

  Synopsis    [BDD store/load program]

  Description [This file contains the functions for BddPool processing.]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#include "lopt.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static bddNode * BDS_DumpBddPoolRecursive ARGS((DdManager*,DdNode*,st_table*));
static DdNode * BDS_BuildDDFromBddPoolRecursive ARGS((DdManager*,bddNode*));
static bddNode * BDS_DumpBddPoolAtLevelRecursive ARGS((DdManager*,DdNode*,st_table*,st_table*,edgeMark*,int));
static void BDS_ClearDD ARGS((DdManager*,bddPool*));
static void BDS_FreeBddPoolRecursive ARGS((DdManager*,bddNode*,st_table*));
static void BDS_ClearDDRecursive ARGS((DdManager*,bddNode*,st_table*));
static bddNode * bdsDumpResubBddPoolRecursive ARGS((DdManager*,DdNode*,DdNode*,DdNode*,st_table*));

/**Function********************************************************************

  Synopsis    [Dump a BDD into a structure]

  Description [The function works for both BDD and 0-1 ADD. Return bddPool* if successful;
  NULL otherwise]

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
bddPool *
BDS_DumpBddPool(
  DdManager *bddmgr,
  DdNode *bdd)
{
  int i, id, *order; /* Variable order when this BDD is dumped */
  bddPool *ddPool; /* return pointer */
  st_table *inPool; /* nodes already dumped */
  bddNode *inode;

  /* Record variable order */
  order = ALLOC(int, bddmgr->size);
  if(order == NULL) return(NULL);

  for (i = 0; i < bddmgr->size; i++) {
      id = Cudd_ReadInvPerm(bddmgr, i);
      order[i] = id;
  }

  inPool = st_init_table(st_ptrcmp,st_ptrhash);
  if(inPool == NULL) return(NULL);

  inode = BDS_DumpBddPoolRecursive(bddmgr, bdd, inPool);
  if (inode == NULL) return(NULL);

  st_free_table(inPool);

  /* Construct return value */
  ddPool = ALLOC(bddPool, 1);
  if(ddPool == NULL) return(NULL);

  ddPool->order = order;
  ddPool->bnode = inode;

  return(ddPool);

} /* end of BDS_DumpBddPool */

/**Function********************************************************************

  Synopsis    [Build a BDD from a bddPool structure]

  Description [The original variable order when the BDD was dumped is restored
  when shuffle = 1]

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
DdNode *
BDS_BuildDDFromBddPool(
  DdManager *bddmgr,
  bddPool *ddPool,
  int shuffle)
{
  int result;
  DdNode *retBdd;

  /* Shuffle variables */
  if (shuffle == 1) {
      result = Cudd_ShuffleHeap(bddmgr, ddPool->order);
      if (result == 0) return(NULL);
  }

  /* Reconstruct BDD */
  retBdd = BDS_BuildDDFromBddPoolRecursive(bddmgr,ddPool->bnode);
  if (retBdd == 0) return(NULL);

  /* Clear dd field on each bddNode */
  BDS_ClearDD(bddmgr, ddPool);

  retBdd = DumpNode_IsComplement(ddPool->bnode) ? Cudd_Not(retBdd) : retBdd;

  return(retBdd);

} /* end of BDS_BuildDDFromBddPool */

/**Function********************************************************************

  Synopsis    [Dump bddPool at a specific level]

  Description [This function simulates a cut on a specific level]

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
bddPool *
BDS_DumpBddPoolAtLevel(
  DdManager *bddmgr,
  DdNode *bdd,
  st_table *specialTbl, /* Store a set of special nodes */
  edgeMark *levelTable,
  int decompType)
{
  int i, id, *order;        /* Variable order when this BDD is dumped */
  bddPool *ddPool;      /* return pointer */
  st_table *inPool;         /* nodes already dumped */
  bddNode *inode;
  DdNode *oneMark = NULL;   /* Used for non-ne branch decomposition */

  /* Record variable order */
  order = ALLOC(int, bddmgr->size);
  if(order == NULL) return(NULL);

  for (i = 0; i < bddmgr->size; i++) {
      id = Cudd_ReadInvPerm(bddmgr, i);
      order[i] = id;
  }

  inPool = st_init_table(st_ptrcmp,st_ptrhash);
  if(inPool == NULL) return(NULL);

  inode = BDS_DumpBddPoolAtLevelRecursive(bddmgr,bdd,specialTbl,inPool,levelTable,decompType);
  if (inode == NULL) return(NULL);

  st_free_table(inPool);

  /* Construct return value */
  ddPool = ALLOC(bddPool, 1);
  if(ddPool == NULL) return(NULL);

  ddPool->order = order;
  ddPool->bnode = inode;

  return(ddPool);

} /* end of BDS_DumpBddPoolAtLevel */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_DumpBddPool]

  Description [Return bddNode if successful; NULL otherwise]

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
bddNode *
BDS_DumpBddPoolRecursive(
  DdManager *bddmgr,
  DdNode *bdd,
  st_table *inPool)
{
  bddNode *inode, *tnode, *enode, *poolNode;
  DdNode *idd, *tdd, *edd;

  if (Cudd_IsConstant(bdd)) {
      inode = (bddNode *)bdd;
      return(inode);
  }

  idd = Cudd_Regular(bdd);
  if (st_lookup(inPool, (char *)idd, (char **) &poolNode)) { /* Already dumped */
      inode = poolNode;
      ///inode = Cudd_IsComplement(bdd) ? DumpNode_Complement(inode) : inode; ///pga r
      if (Cudd_IsComplement(bdd)) { ///pga
          DumpNode_Complement(inode); ///pga
      } ///pga
      return(inode);
  }

  tdd = Cudd_Regular(Cudd_T(bdd));
  edd = Cudd_Regular(Cudd_E(bdd));

  /* Dump T branch */
  if (st_lookup(inPool, (char *)tdd, (char **) &poolNode)) {
      tnode = Cudd_IsComplement(Cudd_T(bdd)) ? DumpNode_Complement(poolNode) : poolNode;
  }
  else {
      tnode = BDS_DumpBddPoolRecursive(bddmgr, Cudd_T(bdd), inPool);
  }

  /* Dump E branch */
  if (st_lookup(inPool, (char *)edd, (char **) &poolNode)) {
      enode = Cudd_IsComplement(Cudd_E(bdd)) ? DumpNode_Complement(poolNode) : poolNode;
  }
  else {
      enode = BDS_DumpBddPoolRecursive(bddmgr, Cudd_E(bdd), inPool);
  }

  /* Construct bddNode */
  inode = ALLOC(bddNode, 1);
  inode->index = Cudd_NodeReadIndex(bdd);
  inode->dd = NULL;
  inode->t_nd = tnode;
  inode->e_nd = enode;

  if (st_add_direct(inPool, (char *)idd, (char *)inode) == ST_OUT_OF_MEM) {
      printf("Out of memeory !\n");
      return(NULL);
  }

  inode = Cudd_IsComplement(bdd) ? DumpNode_Complement(inode) : inode;

  return(inode);

} /* end of BDS_DumpBddPoolRecursive */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_BuildDDFromBddPool]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
DdNode *
BDS_BuildDDFromBddPoolRecursive(
  DdManager *bddmgr,
  bddNode *bnode)
{
  int result; ///pga
  bddNode *inode, *tnode, *enode;
  DdNode *idd, *tdd, *edd, *var;
  DdNode *f0, *f1; ///pga

  if (Cudd_IsConstant((DdNode *) bnode)) {
      return((DdNode *) bnode);
  }

  inode = DumpNode_Regular(bnode);

  if (inode->dd != NULL) {
      Cudd_Ref(inode->dd);
      return(inode->dd);
  }

  tnode = inode->t_nd;
  enode = inode->e_nd;

  var = Cudd_ReadVars(bddmgr, inode->index);
  Cudd_Ref(var);

  if (!Cudd_IsConstant((DdNode *)tnode)) {
      tdd = BDS_BuildDDFromBddPoolRecursive(bddmgr, tnode);
      tdd = DumpNode_IsComplement(tnode) ? Cudd_Not(tdd) : tdd;
  }
  else {
      tdd = (DdNode *)tnode;
  }

  if (!Cudd_IsConstant((DdNode *)enode)) {
      edd = BDS_BuildDDFromBddPoolRecursive(bddmgr, enode);
      edd = DumpNode_IsComplement(enode) ? Cudd_Not(edd) : edd;
  }
  else {
      edd = (DdNode *)enode;
  }

  idd = Cudd_bddIte(bddmgr, var, tdd, edd);
  if (idd == NULL) return(NULL);
  Cudd_Ref(idd);

  Cudd_Deref(var);
  if (!Cudd_IsConstant(tdd)) Cudd_Deref(tdd);
  if (!Cudd_IsConstant(edd)) Cudd_Deref(edd);

  inode->dd = idd;

  return(idd);

} /* end of BDS_BuildDDFromBddPoolRecursive */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_DumpBddPoolAtLevel]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
bddNode *
BDS_DumpBddPoolAtLevelRecursive(
  DdManager *bddmgr,
  DdNode *bdd,
  st_table *specialTbl, /* Store a set of special nodes */
  st_table *inPool,
  edgeMark *levelTable,
  int decompType)
{
  bddNode *inode, *tnode, *enode, *poolNode;
  DdNode *idd, *tdd, *edd;

  if (bdd == bddmgr->background) { /* 0-1 ADD case */
      inode = (bddNode *)Cudd_ReadLogicZero(bddmgr);
      return(inode);
  }
  else if (Cudd_IsConstant(bdd)) { /* BDD case */
      inode = (bddNode *)bdd;
      return(inode);
  }

  idd = Cudd_Regular(bdd);

  if (st_lookup(inPool, (char *) idd, (char **) &poolNode)) { /* Dumped */
      inode = poolNode;
      ///inode = Cudd_IsComplement(bdd) ? DumpNode_Complement(inode) : inode; ///pga r
      if (Cudd_IsComplement(bdd)) { ///pga
          DumpNode_Complement(inode); ///pga
      } ///pga
      return(inode);
  }
  else if (st_is_member(levelTable->table, (char *) idd) == 1) { /* On the cut */

      if (decompType == BDS_BDD_DECOMP_DISJ) {
      inode = (bddNode *)Cudd_ReadLogicZero(bddmgr);
      }
      else if (decompType == BDS_BDD_DECOMP_CONJ) {
      inode = (bddNode *)Cudd_ReadOne(bddmgr);
      }
      else if (decompType == BDS_BDD_DECOMP_X) { /* 12/4/98 */
      if (Cudd_IsComplement(bdd))
          inode = (bddNode *)Cudd_ReadLogicZero(bddmgr);
      else
          inode = (bddNode *)Cudd_ReadOne(bddmgr);
      }
      else if (decompType == BDS_BDD_DECOMP_B) { /* 12/16/98 */
      if (st_is_member(specialTbl, (char *) idd) == 1)
          inode = (bddNode *)Cudd_ReadOne(bddmgr);
      else
          inode = (bddNode *)Cudd_ReadLogicZero(bddmgr);
      }
      else {
      printf("Not supported decomposition type !\n");
      return(NULL);
      }
      return(inode);
  }

  tdd = Cudd_Regular(Cudd_T(bdd));
  edd = Cudd_Regular(Cudd_E(bdd));

  /* Dump T branch */
  if (st_lookup(inPool, (char *)tdd, (char **) &poolNode)) {
      tnode = Cudd_IsComplement(Cudd_T(bdd)) ? DumpNode_Complement(poolNode) : poolNode;
  }
  else {
      tnode = BDS_DumpBddPoolAtLevelRecursive(bddmgr,Cudd_T(bdd),specialTbl,inPool,levelTable,decompType);
  }

  /* Dump E branch */
  if (st_lookup(inPool, (char *)edd, (char **) &poolNode)) {
      enode = Cudd_IsComplement(Cudd_E(bdd)) ? DumpNode_Complement(poolNode) : poolNode;
  }
  else {
      enode = BDS_DumpBddPoolAtLevelRecursive(bddmgr,Cudd_E(bdd),specialTbl,inPool,levelTable,decompType);
  }

  /* Construct I bddNode */
  inode = ALLOC(bddNode, 1);
  inode->index = Cudd_NodeReadIndex(bdd);
  inode->dd = NULL;
  inode->t_nd = tnode;
  inode->e_nd = enode;

  if (st_add_direct(inPool, (char *)idd, (char *)inode) == ST_OUT_OF_MEM) {
      printf("Out of memeory !\n");
      return(NULL);
  }

  inode = Cudd_IsComplement(bdd) ? DumpNode_Complement(inode) : inode;

  return(inode);

} /* end of BDS_DumpBddPoolAtLevelRecursive */

/**Function********************************************************************

  Synopsis    [Clear dd field on bddNode]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
void
BDS_ClearDD(
  DdManager *bddmgr,
  bddPool *ddPool)
{
  bddNode *bnode;
  st_table *cleared;

  cleared = st_init_table(st_ptrcmp, st_ptrhash);

  bnode = ddPool->bnode;
  BDS_ClearDDRecursive(bddmgr, bnode, cleared);

  st_free_table(cleared);

} /* end of BDS_ClearDD */

/**Function********************************************************************

  Synopsis    [Free bddPool structure]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
void
BDS_FreeBddPool(
  DdManager *bddmgr,
  bddPool *ddPool)
{
  bddNode *bnode;
  st_table *deleted;

  deleted = st_init_table(st_ptrcmp, st_ptrhash);

  bnode = ddPool->bnode;
  BDS_FreeBddPoolRecursive(bddmgr, bnode, deleted);

  st_free_table(deleted);
  FREE(ddPool->order);
  FREE(ddPool);

} /* end of BDS_FreeBddPool */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_ClearDD]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
void
BDS_ClearDDRecursive(
  DdManager *bddmgr,
  bddNode *bnode,
  st_table *cleared)
{
  bddNode *inode, *tnode, *enode;

  inode = DumpNode_Regular(bnode);

  if (st_is_member(cleared, (char *)inode) == 1) { /* Already cleared */
      return;
  }
  if (Cudd_IsConstant((DdNode *)bnode)) { /* Terminal */
      return;
  }

  tnode = inode->t_nd;
  enode = inode->e_nd;

  BDS_ClearDDRecursive(bddmgr, tnode, cleared);
  BDS_ClearDDRecursive(bddmgr, enode, cleared);

  if (st_add_direct(cleared, (char *) inode, NULL) == ST_OUT_OF_MEM) {
      printf("Out of memeory !");
      exit(2);
  }

  inode->dd = NULL;

  return;

} /* end of BDS_ClearDDRecursive */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_FreeBddPool]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
void
BDS_FreeBddPoolRecursive(
  DdManager *bddmgr,
  bddNode *bnode,
  st_table *deleted)
{
  bddNode *inode, *tnode, *enode;

  inode = DumpNode_Regular(bnode);

  if (st_is_member(deleted, (char *)inode) == 1) { /* Already deleted */
      return;
  }
  if (Cudd_IsConstant((DdNode *)bnode)) { /* Terminal */
      return;
  }

  tnode = inode->t_nd;
  enode = inode->e_nd;

  BDS_FreeBddPoolRecursive(bddmgr, tnode, deleted);
  BDS_FreeBddPoolRecursive(bddmgr, enode, deleted);

  if (st_add_direct(deleted, (char *) inode, NULL) == ST_OUT_OF_MEM) {
      printf("Out of memeory !");
      exit(2);
  }

  FREE(inode);
  return;

} /* end of BDS_FreeBddPoolRecursive */

/**Function********************************************************************

  Synopsis    [Build resubstituted bdd]

  Description [The only difference with BDS_BuildDDFromBddPool is, no var shuffle.]

  SideEffects []

  SeeAlso     []

  Last Date   [8/9/99]

*****************************************************************************/
extern
DdNode *
bdsBuildResubBddFromBddPool(
  DdManager *bddmgr,
  bddPool *ddPool)
{
  int result;
  DdNode *retBdd;

  /* Reconstruct BDD */
  retBdd = BDS_BuildDDFromBddPoolRecursive(bddmgr,ddPool->bnode);
  if (retBdd == 0) return(NULL);

  /* Clear dd field on each bddNode */
  BDS_ClearDD(bddmgr, ddPool);

  retBdd = DumpNode_IsComplement(ddPool->bnode) ? Cudd_Not(retBdd) : retBdd;

  return(retBdd);

} /* end of bdsBuildResubBddFromBddPool */


/**Function********************************************************************

  Synopsis    [Recursive function of bdsDumpResubBddPool]

  Description [Whenever a source is hit, resubsitute it with variable target.]

  SideEffects []

  SeeAlso     []

  Last Date   [8/9/99]

*****************************************************************************/
static
bddNode *
bdsDumpResubBddPoolRecursive(
  DdManager *bddmgr,
  DdNode *bdd,
  DdNode *source,
  DdNode *target,
  st_table *inPool)
{
  bddNode *inode, *tnode, *enode;
  DdNode *idd, *tdd, *edd;

  if (Cudd_IsConstant(bdd)) {
      inode = (bddNode *)bdd;
      return(inode);
  }

  idd = Cudd_Regular(bdd);
  if (st_lookup(inPool, (char *)idd, (char **) &inode)) { /* Already dumped */
      inode = Cudd_IsComplement(bdd) ? DumpNode_Flip(inode) : inode;
      if (bdd == source || idd == source) {
          inode = Cudd_IsComplement(target) ? DumpNode_Flip(inode) : inode;
      }
      return(inode);
  }

  if (bdd == source || idd == source) { /* Hit the node to be substituted */
      inode = ALLOC(bddNode, 1);
      inode->index = Cudd_NodeReadIndex(target);
      inode->dd = NULL;
      inode->t_nd = (bddNode *)Cudd_ReadOne(bddmgr);
      inode->e_nd = (bddNode *)Cudd_ReadLogicZero(bddmgr);

      if (st_add_direct(inPool, (char *) idd, (char *) inode) == ST_OUT_OF_MEM) {
          printf("Out of memeory !\n"); exit(2);
      }

      inode = Cudd_IsComplement(bdd) ? DumpNode_Flip(inode) : inode;
      inode = Cudd_IsComplement(target) ? DumpNode_Flip(inode) : inode;

      return(inode);
  }

  tdd = Cudd_T(bdd);
  edd = Cudd_E(bdd);

  /* Dump T branch */
  tnode = bdsDumpResubBddPoolRecursive(bddmgr,tdd,source,target,inPool);

  /* Dump E branch */
  enode = bdsDumpResubBddPoolRecursive(bddmgr,edd,source,target,inPool);

  /* Construct bddNode */
  inode = ALLOC(bddNode, 1);
  inode->index = Cudd_NodeReadIndex(bdd);
  inode->dd = NULL;
  inode->t_nd = tnode;
  inode->e_nd = enode;

  if (st_add_direct(inPool, (char *)idd, (char *)inode) == ST_OUT_OF_MEM) {
      printf("Out of memeory !\n");
      return(NULL);
  }

  inode = Cudd_IsComplement(bdd) ? DumpNode_Complement(inode) : inode;

  return(inode);

} /* end of bdsDumpResubBddPoolRecursive */


/**Function********************************************************************

  Synopsis    [Dump bddPool with node substitution (more general than var sub.]

  Description [The function is very similar to BDS_DumpBddPool. Whenever source
  is hit, it is replaced by target. When target is in complmentary form, the source
  is replaced by the complementary of target. Return bddPool* if successful;
  NULL otherwise.]

  SideEffects []

  SeeAlso     []

  Last Date   [8/9/99]

*****************************************************************************/
extern
bddPool *
bdsDumpResubBddPool(
  DdManager *bddmgr,
  DdNode *bdd,
  DdNode *source,  /* Node to be substituted */
  DdNode *target   /* Subsitute target */)
{
  int i, id;
  bddPool *ddPool;   /* return pointer */
  st_table *inPool;  /* nodes already dumped */
  bddNode *inode;

  inPool = st_init_table(st_ptrcmp,st_ptrhash);
  if(inPool == NULL) return(NULL);

  inode = bdsDumpResubBddPoolRecursive(bddmgr,bdd,source,target,inPool);
  if (inode == NULL) return(NULL);

  st_free_table(inPool);

  /* Construct return value */
  ddPool = ALLOC(bddPool, 1);
  if(ddPool == NULL) return(NULL);

  ddPool->order = NULL;
  ddPool->bnode = inode;

  return(ddPool);

} /* end of bdsDumpResubBddPool */









