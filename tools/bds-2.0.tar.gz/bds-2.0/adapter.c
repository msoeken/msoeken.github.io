#include "adapter.h"
#include "enhance.h"
#include "sweep.h"
#include "sharing.h"
#include "eliminate.h"
#include "local.h"
#include "verify.h"
#include <stdio.h>


/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static bdsOptions * bds_init ARGS(());
static void free_option ARGS((bdsOptions *option));

/**AutomaticEnd***************************************************************/

/*---------------------------------------------------------------------------*/
/* Definition of exported functions                                          */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis    [Main program for BDS]

  Description []

  SideEffects [None]

  SeeAlso     []

 ******************************************************************************/

extern  DdNode ** bds_decomposition (DdManager *mgr, DdNode *function,int *op,int *size){
    /***** Declaring variables ***********************************************/

    int i,j, *varOrderBeforeInt, result, vars = 0, npos, localOrGlobal = 0, globalReady = 0, num1, num2; /* extra variable */
    int *order ,*dummy2realId, *n1, *n2, *tab, *permutation, *real2dumbo, *no_nodes,*live; /* used in delay reorder */

    long BDDDecompStartTime, BDDDecompEndTime, BDDDecompTotalTime, netProcesStartTime, netProcesEndTime, netProcesTotalTime;
    char *recordDump, **PIvariables; /* association list of PI name and index in a BDD */
    DdManager *decompBddmgr ;
    FILE *fp, *recdfp; /* delay resynthesis critical-path collapsed network file pointer */

    DdNode *f, **nd ,**fn_array, *dd, *cc ,*cn, **bdd_array; /* regular BDD used to get no_nodes */

    bdsOptions *option; /* Command line holder (structure in build.h) */
    BnetNetwork *net = NULL, *net_copy = NULL; /* network */
    BnetNode *node,bnode; /* auxiliary pointer to network node (structure in bnet.h) */
    FactorTreeNode **FTreeNode; /* an array of PO nodes in the factor tree (structure in lopt.h) */
    bddPool **bddPoolArray, **q, *c, *d, *control,*tmp1,*tmp2,*tmp3; /* All to be decomposed BDD array (structure in lopt.h) */
    st_table *bddPoolBnodeAssoc, *factorTreeNode2BnetNode;
    st_generator *gen;
    array_t *varOrderBefore, *varOrderAfter;

    /********** Reading command line *****************************************/

    *op=0;
    /* Command line parser */
    option = bds_init(); /* Initializations. Set default values for options (function in this file) */
    // printf("---------------------------------------------------------------------\n");

#ifndef DEBUG
    recordDump = "/tmp/reorder.stat";
    recdfp = fopen(recordDump, "w");
    if (recdfp == NULL) {
        printf("Can not create files !\n");
        exit(2);
    }
    Cudd_SetStdout(mgr, recdfp);
#endif
    int    fd;
    fpos_t pos;

   fflush(stdout);
    fgetpos(stdout, &pos);
    fd = dup(fileno(stdout));
    freopen("/tmp/file.dat", "w", stdout);


    // printf("second step done\n");
    netProcesStartTime = util_cpu_time(); /* function in CUDD\util\cpu_time.c */

    fp = fopen("/tmp/bdd9.dot", "w");
    Cudd_DumpDot(mgr, 1, &function, NULL, NULL, fp);
    fclose(fp);
    tab = BDS_Support_Index(mgr, function, &vars, &npos);
 
    net = build_net(vars, tab, npos);
    result = ddMax(mgr->size, mgr->sizeZ);

    printf("bdd vars:");
    for (i = 0; i < result; i++) {
        printf("%d;", (mgr->vars[i])->index);
    }
    printf("\n");
    //   Cudd_AutodynDisable(mgr); /* function from CUDD package */
    result = BDS_BuildLocalBDD_(mgr, net, option, function, tab, vars, function, tab, vars); /* function in build.c */
    if (result == 0) exit(2);

    result = BDS_BnetEnhance(net, option); /* function in enhance.c */
    if (result == 0) exit(2);
    /* Build local BDDs */
    //  cuddCheck(mgr, "", 3); /* function in debug.c */
    bddPoolBnodeAssoc = st_init_table(st_ptrcmp,st_ptrhash); /* function in st.c in CUDD/st/ */

    /* Store all local BDDs in a BDD Pool */
    bddPoolArray = bdsStoreBDDInBddPoolLocal(mgr, net, option, bddPoolBnodeAssoc); /* function in prepare.c */
    //  cuddCheck(mgr, "", 4); /* function in debug.c */
    if (bddPoolArray == NULL) exit(2);
    /* Free all BDDs from the bdd manager */
    result = bdsFreeAllBDDs(mgr, net, option, globalReady);
    // cuddCheck(mgr, "", 5); /* function in debug.c */
    if (result == 0) exit(2);
    /* Build varId and char* name association */
    PIvariables = bdsBuildVarNameAssocLocal(mgr, net, option); /* function in prepare.c */
    if (PIvariables == NULL) exit(2);

    // cuddCheck(mgr, "", 6); /* function in debug.c */
    /********** Decomposition preliminaries **********************************/

    /* Allocate a root FTreeNode for each BDD */
    i = 0;
    for (q = bddPoolArray; *q; q++) {
        i++;
    }
    /* This gives the total number of local and global bdds */

    //   printf("There are %d local/global Bdds\n", i);

    FTreeNode = ALLOC(FactorTreeNode *, i + 1); /* ALLOC(): defined in util.h in CUDD/util/ */
    FTreeNode[i] = NULL;
    netProcesEndTime = util_cpu_time();
    netProcesTotalTime = netProcesEndTime - netProcesStartTime;
    BDDDecompStartTime = util_cpu_time();

    /* Start decomposing BDDs, one by one */
    factorTreeNode2BnetNode = st_init_table(st_ptrcmp, st_ptrhash);
    i = 0;
    // printf("Decomposing BDDs\n");
    (void) fflush(stdout);

#ifndef DEBUG
    fprintf(recdfp, "\n\n<<<<<<<<<<  Decomposing BDDs  >>>>>>>>>>\n\n");
#endif
 
    /********** Decomposition Loop *******************************************/

    /* Start of for loop to decompose each BDD one by one:
     ** Decompostion is performed on each BDD one by one from the BDD Pool array.
     ** A new dummy BDD with simple variable indices is created from an actual
     ** BDD before loading it into a new BDD manager "decompBddmgr" to do decomposition.
     ** As decomposition is performed on each individual BDD, it doesn't need to
     ** know the actual indices in the Boolean network structure. A BDD is iteratively
     ** decomposed until it has a single variable (terminal node) and corresponding
     ** FTreeNodes are also created in the process. Dummy indices are also converted
     ** back to real indices for FTreeNodes.
     */
    i = 0;
    for (q = bddPoolArray; *q; q++) {

        if (!st_lookup(bddPoolBnodeAssoc, (char *) *q, (char **) &node)) {
            fail("Fatal error in bddPoolBnodeAssoc!");
        }


        /* Record FactorTreeNode vs. BnetNode correspondency */
        FTreeNode[i] = ALLOC(FactorTreeNode, 1);
        FTreeNode[i]->name = node->name;
        /* Add node with key FTreeNode (only have node name for now) to factorTreeNode2BnetNode */
        if (st_add_direct(factorTreeNode2BnetNode, (char *) FTreeNode[i], (char *) node) == ST_OUT_OF_MEM) {
            printf("\nOut of memory !\n");
            exit(2);
        }

        decompBddmgr = startCudd(option,0);
        if (decompBddmgr == NULL) { exit(2); }

#ifndef DEBUG
        Cudd_SetStdout(decompBddmgr, recdfp);
#endif
        /* Build dummy BDD on this node */

        f = BDS_BuildDDFromBddPoolLocal(decompBddmgr, *q, &dummy2realId, mgr->size, option, &real2dumbo);

        /********** Decompose a BDD iteratively ******************************/
        /* Main BDD decomposition engine entry. Used for BDD-based and heuristic decomposition */
        /*function in lopt.c */
        printf("There are %d local/global Bdds\n", decompBddmgr->size);

        result = BDS_DDDecompose_alternative(decompBddmgr, net, f, option, &FTreeNode[i], permutation, real2dumbo, no_nodes, &c, &d,&control, op); /* function in lopt.c */
        if (result == 0) {
            printf("fail !\n");
            return (NULL);
        }

        printf("deco done\n");

        bdd_array = ALLOC(DdNode*,5);
        j=0;
        printf("ddpool 0 done %d\n",j);
        cc = BDS_BuildDDFromBddPool(decompBddmgr, c, 1);
        tmp1= BDS_StoreBddPoolLocal(decompBddmgr, cc);
        bdd_array[j++] = bdsBuildDDFromBddPoolLocalWithOutCreateDummy(mgr,tmp1,dummy2realId);
        printf("ddpool 1 done %d\n",j);

        dd = BDS_BuildDDFromBddPool(decompBddmgr, d, 1);
        tmp2 = BDS_StoreBddPoolLocal(decompBddmgr, dd);
        bdd_array[j++] = bdsBuildDDFromBddPoolLocalWithOutCreateDummy(mgr,tmp2,dummy2realId);

        printf("ddpool 2 done %d\n",j);
        printf("ddpool 2 done %d\n",*op);
        if(*op==BDS_BDD_MUX){
        	cn=BDS_BuildDDFromBddPool(decompBddmgr, control, 1);
            tmp3 = BDS_StoreBddPoolLocal(decompBddmgr, cn);

            bdd_array[j++] = bdsBuildDDFromBddPoolLocalWithOutCreateDummy(mgr, tmp3,dummy2realId);
        }
        *size=j;
        printf("ddpool 3 done %d\n",*size);
        Cudd_Quit(decompBddmgr);
        bdd_array[j++]=NULL;

        fflush(stdout);
        dup2(fd, fileno(stdout));
        close(fd);
        clearerr(stdout);
        fsetpos(stdout, &pos);
        return(bdd_array);
        printf("finished\n");

        i++; /* goto the next BDD in the BDD Pool */

    } /* end of for loop */


} /* end of adapter */

/*---------------------------------------------------------------------------*/
/* Definition of internal functions                                          */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Definition of static functions                                            */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis    [Set the default options]

  Description [Initialization of default options for the program]

  SideEffects [none]

  SeeAlso     [bdsReadOptions]

 ******************************************************************************/
static bdsOptions * bds_init() {
    bdsOptions *option;
    /* Initialize option structure. */
    option = ALLOC(bdsOptions, 1);
    option->initialTime = util_cpu_time();
    option->file = NULL;
    option->cacheSize = BDS_BDD_STARTUP_CACHE; /// = 10*1024
    option->maxMemory = BDS_BDD_STARTUP_MEMORY; /// = 10*1024*1024
    option->slots = CUDD_UNIQUE_SLOTS; /// = 256 = initial size of subtables
    option->order = PI_PS_FROM_FILE; /// = 0
    option->orderfile = NULL;
    option->reordering = CUDD_REORDER_NONE;
    option->maxGrowth = 20;
    option->verb = BDS_VERBOSE_MORE; /// = 1 in lopt.h
    option->iconst = 100000; /// in eliminate.c: input constriant
    option->kdecomp = FALSE;
    option->largefanout = FALSE;
    option->delay = FALSE;
    option->performancedecomp = FALSE;
    option->heuristic = TRUE;
    option->useloc = TRUE;
    option->useglb = FALSE;
    option->ethred = BDS_ELIMINATE_THRESHOLD; /// = 0
    option->autodyn = FALSE;
    option->rodelim = FALSE;
    option->globalLimit = BDS_GLOBAL_BDD_LIMIT; /// = 20000
    option->glbEliminate = FALSE;
    option->verify = FALSE;
    option->effort = 1;
    option->limitSize = BDS_BDD_REORDER_LIMIT; /// = 200 (The largest BDD on which exact reordering can apply)
    option->miniMethod = BDS_BDD_RESTRICT; /// = 0
    option->dumpbdd = FALSE;
    option->dumpblif = TRUE;
    option->dumpftree = TRUE;
    option->dumpfdot = FALSE;
    option->dumpnet = FALSE;
    option->cutptl = FALSE;
    option->elim = FALSE;
    option->level1 = FALSE;
    option->eps = 0;
    option->sharing = TRUE;
    option->xhardcore = FALSE;
    option->k = 5; /// default k value is 5
    return (option);
} /* end of mainInit */

/**Function********************************************************************

  Synopsis    [Frees the option structure and its appendages.]

  Description []

  SideEffects [None]

  SeeAlso     []

 *****************************************************************************/
static void
free_option(
    bdsOptions * option) {
    if (option->file != NULL) FREE(option->file);
    if (option->orderfile != NULL) FREE(option->orderfile);
    FREE(option);
} /* end of free_option */

