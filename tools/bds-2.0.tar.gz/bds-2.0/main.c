
/**CFile***********************************************************************

   FileName    [main.c]

   PackageName [BDS-pga]

   Synopsis    [Main program for the BDS program.]

   Description [This file contains the main() function and some related functions.
                The flow of the BDS-pga program is as follows:

                    The program first initializes the command line options with default values
                by calling the mainInit() function. It reads the command line by
                calling bdsReadOptions(). It reads the BLIF file and creates the
                Boolean network by calling Bnet_ReadNetwork(). For each .names
                entry in a BLIF file, a Boolean-network Node (BnetNode) is created to
                build a Boolean network for the design netlist. BDS_BnetEnhance()
                is then called to fill in additional variables for each BnetNode.
                It initializes the main BDD manager by calling startCudd().

                    If the -useglb option (to use global BDDs only) is specified,
                only global BDDs will be built for the Boolean network and
                the Eliminate routine will not be performed on global BDDs. A BDD is
                created for each BnetNode in the Boolean network. If the size of
                the global BDD is greater than the default global BDD limit of
                20000, the program will exit. Global BDDs are built from primary
                inputs to the primary outputs of the Boolean network.

                    If -useloc option (to use local BDDs only) is specified,
                only the local BDDs will be built for the boolean network. The Sweep
                operation is performed on the Boolean network to remove constant
                and duplicate BnetNodes by calling BDS_SweepBnetwork(). The
                Eliminate routine: BDS_EliminateBasedOnLocal() is called to perform
                MFFC-based iterative eliminate (partial collapsing) on the Boolean
                network for the local BDDs to get the supernodes of the Boolean
                network. Eliminate is based on MFFC collapsing and also on the threshold value
                of node size (recommended threshold value is 10). Use -ethred option to specify
                the threshold value for local BDD eliminate process. To perform
                multi-fanout collapsing on a BnetNode in the first iteration, -largefanout
                option can be specified. If -rodelim option (to do variable reordering
                while performing eliminate) is specified, the iterative eliminate procedure 
                will be performed a second time using BDD variable ordering.
                After performing eliminate, the Boolean network will be swept again
                to remove constant and duplicate BnetNodes.

                    If neither -useglb nor -useloc option is specified, the program
                will build using both global (if successful) and local BDDs for the
                Boolean network and sweep and iterative eliminate will be performed on local
                BDDs. The program will then choose either global or local BDDs to do
                decomposition by comparing the complexity of both global and local
                BDDs by calling bdsGlobalOrLocalBDD(). If the size of global BDDs is
                significantly smaller than local BDDs, the global BDDs will be used
                for synthesis. Otherwise, the local BDDs will be used for synthesis.

                    If the -sharing option is specified, sharing extraction is performed
                on local BDDs by calling BDS_SharingExtractionLocal().

                    After eliminate, global and local BDDs are stored in respective
                BDD Pools, and the BDD manager is freed. The root (factoring tree) FTreeNodes
                corresponding to the BnetNodes are initialized to record FTreeNodes
                for later FTree optimization after BDD decompostions.

                    Decompostion is performed on each BDD one by one from the BDD
                Pool by calling BDS_DDDecompose(). A new dummy BDD with simple variable
                indices is created from a BDD before loading it into a new
                BDD manager to do decomposition. As decomposition is performed on
                each individual BDD, the program doesn't need to know the actual indices in
                the Boolean network structure. A BDD is iteratively decomposed until
                it has a single variable (terminal node). Corresponding FTreeNodes
                are created in the process. Dummy indices are converted back
                to real indices for FTreeNodes.

                    After all BDDs in the BDD Pool have been decomposed,
                BDS_FTreeProcessing() is called to perform Sharing extraction,
                Homogeneous collapsing, and Phase assignment on FTreeNodes to
                optimize the final network before writing it out to the final
                BLIF file. When doing Homogeneous collapsing of FTreeNodes, the size of
                the resulting node is limited to k inputs (default k=5)
                for mapping an to FPGA with k-inputs LUTs.

                    For the delay re-synthesis phase, -delay option should be
                specified. In the delay phase, only the critical path is collapsed
                in the eliminate process and the collapsed supernode along with the
                replicated logic nodes and the rest of the unchanged nodes are written
                out to BLIF file with a .delay extension. Logic simplification is done on an 
                individual, manually-extracted supernode 
                and on replicated logic nodes with Espresso.
                After Espresso, the simplified supernode and replicated logic
                nodes are re-decomposed using this BDS-pga program (-perform option) before
                the .blif output is tech mapped with Flowmap. To collapse all largest critical paths,
                the -eps 2 option can be used. All these paths have the same depth.

                    The final synthesized netlist from the program can be mapped
                to LUT-based FPGA by using the Flowmap tech mapping tool without using
                tech_decomp and dmig options to get the final results. These options resturcture the 
                optimizations performed by BDS-pga and should be avoided.]

   SeeAlso     []

   Author      [Congguang Yang, Navin Vemuri]

  Copyright    [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

 ******************************************************************************/
#include "lopt.h"
#include "enhance.h"
#include "sweep.h"
#include "prepare.h"
#include "sharing.h"
#include "eliminate.h"
#include "local.h"
#include "verify.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

int numLocal; /* BDD count */

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static bdsOptions * mainInit ARGS(());
static void bdsReadOptions ARGS((int argc, char **argv, bdsOptions *option));
static void freeOption ARGS((bdsOptions *option));



/**AutomaticEnd***************************************************************/

/*---------------------------------------------------------------------------*/
/* Definition of exported functions                                          */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis    [Main program for BDS]

  Description []

  SideEffects [None]

  SeeAlso     []

 ******************************************************************************/
int
main(
 int argc,
 char ** argv) {

  /***** Declaring variables ***********************************************/

  bdsOptions *option; /* Command line holder (structure in build.h) */
  FILE *fp; /* network file pointer (structure in bnet.h) */
  BnetNetwork *net = NULL, *net_bdd = NULL, *net_copy = NULL; /* network */
  int result; /* stores the return value of functions */
  BnetNode *node, *bnode,*newnode; /* auxiliary pointer to network node (structure in bnet.h) */
  int i, j, op; /* loop index */
  DdManager *bddmgr, *netmgr, *decompBddmgr, *mgr; /* BDD manager (structure in cuddInt.h) */
  //DdManager *decompBddmgr; /* Dummy BDD manager */
  char **PIvariables; /* association list of PI name and index in a BDD */
  FactorTreeNode **FTreeNode; /* an array of PO nodes in the factor tree (structure in lopt.h) */
  char *recordDump; /* File to which reordering information is dumped */
  FILE *recdfp; /* file handle for recordDump */
  int globalReady = 0; /* global BDDs ready flag */
  int localOrGlobal = 0; /* Use local(0) or global(1) BDD to do lopt */
  bddPool **bddPoolArray, **q, *c, *d; /* All to be decomposed BDD array (structure in lopt.h) */
  st_table *bddPoolBnodeAssoc; /* bddPool and BnetNode assoc (structure in st.h in CUDD/st/) */
  st_table *factorTreeNode2BnetNode; /* FTNode and BnetNode assoc */
  DdNode *f,  **bddPoolArray_,**nd; /* to be decomposed bdd holder (structure in cudd.h) */
  int *dummy2realId; /* substitute Id and real Id assoc */
  long BDDDecompStartTime, BDDDecompEndTime, BDDDecompTotalTime;
  long netProcesStartTime, netProcesEndTime, netProcesTotalTime;
  int a = 0, *n1, *n2, *tab, vars = 0; /* extra variable */
  int *permutation; /* Array for variable ordering based on delay */
  int *real2dumbo; /* dummy index in performdecomp */
  array_t *Nodes; /* used in performdecomp (structure in array.h) */
  int *Perm; /* used in delay reorder */
  lsGen fan_ins; /* fanins of a node on delay (list generator handle in list.h) */
  BnetNode *tempnode; /* temporary variable used in performdecomp */
  int no_inputs = 0; /* number of inputs of a node on delay */
  int *no_nodes, num1, num2; /* number of nodes used in performdecomp */
  DdNode *N, *dd, *cc; /* regular BDD used to get no_nodes */
  FILE *fileBlif; /* delay resynthesis critical-path collapsed network file pointer */
  char *fileBlifNameCopy; /* critical-path collapsed network file name */

  /********** Reading command line *****************************************/


  /* Command line parser */
  option = mainInit(); /* Initializations. Set default values for options (function in this file) */
  (void) bdsReadOptions(argc, argv, option); /* Read the command line options */

  /********** Reading BLIF file to create Boolean Network ******************/

  /* Read the Boolean network */
  fp = fopen(option->file, "r");
  if (fp == NULL) {
    fprintf(stderr, "Can not open file: %s\n", option->file);
    exit(2);
  }

  net_bdd = Bnet_ReadNetwork(fp, option->verb); /* function in bnet.c */
  (void) fclose(fp);
  if (net_bdd == NULL) {
    (void) fprintf(stderr, "Syntax error in %s.\n", option->file);
    exit(2);
  }
printf("%d-%d\n",net_bdd->ninputs,net_bdd->npis);
  /* Enhance the network. Internal Boolean network data structure in CUDD is
   ** augumented to enable network partitioning operation.
   */
  result = BDS_BnetEnhance(net_bdd, option); /* function in enhance.c */
  if (result == 0) exit(2);

  /* Initialize bdd manager. */
  netmgr = startCudd(option, net_bdd->npis); /* function in this file */
  if (netmgr == NULL) {
    exit(2);
  }
#ifndef DEBUG
  /* Redirect the message related to variable reordering to a record file 
   */
  recordDump = BDS_CreateFname(option, "reorder.stat");
  recdfp = fopen(recordDump, "w");
  if (recdfp == NULL) {
    printf("Can not create files !\n");
    exit(2);
  }
  Cudd_SetStdout(netmgr, recdfp);
#endif

  netProcesStartTime = util_cpu_time(); /* function in CUDD\util\cpu_time.c */


  /* Automatic dynamic variable reordering is disabled throughout. Variable reordering
   ** when local BDDs are built may cause wrong BDD nodes recorded on each Bnode.
   */

  Cudd_AutodynDisable(netmgr); /* function from CUDD package */


  /********** Building local BDDs ******************************************/

  /* If -useglb is specific, don't build local BDDs, all BDD will collapse
   ** into the PO nodes and the final circuit is synthesized from global BDDs.
   */
//printf("%d-%d\n",net_bdd->ninputs,net_bdd->npis);
  /* Build local BDDs */
  result = BDS_BuildLocalBDD(netmgr, net_bdd, option); /* function in build.c */
  if (result == 0) exit(2);
  cuddCheck(netmgr, "", 1); /* function in debug.c */
  //printf("%d-%d\n",net_bdd->ninputs,net_bdd->npis);
  newnode = net_bdd->nodes; /// the first newnode is the first node "nodes" of the linked-list of net
  while (newnode != NULL) {
     printf("type= %d.\n",newnode->type);
    if (newnode->type == BNET_OUTPUT_NODE){ 
       printf("found\n");
      
      break;
    }
       printf("ls\n");
    newnode = newnode->next; /// goto the next newnode
  }
printf("*************************************************************\n\n");
  fp = fopen("/tmp/bdd9.dot", "w");
  Cudd_DumpDot(netmgr, 1, &(newnode->localBdd), NULL, NULL, fp);
  fclose(fp);
  tab = BDS_Support_Index(netmgr, newnode->localBdd, &vars);
  printf("%d\n",vars);
  
  net = build_net(vars,net_bdd->npis, tab,  net_bdd->inputs, net_bdd->outputs);
 printf("net->npos %d\n",net->npos);
  for (i = 0; i < net->npos; i++) {
    printf("di= %s.\n",net->outputs[i]);
}
  bddmgr = startCudd(option, net_bdd->npis); /* function in this file */
  if (bddmgr == NULL) {
    exit(2);
  }
 
  Cudd_AutodynDisable(bddmgr); /* function from CUDD package */
  result = BDS_BuildLocalBDD_(bddmgr, net, option,  newnode->localBdd, tab, vars,  newnode->localBdd, tab, vars); /* function in build.c */
  if (result == 0) exit(2);

  cuddCheck(bddmgr, "", 1); /* function in debug.c */
  result = BDS_BnetEnhance(net, option); /* function in enhance.c */
  if (result == 0) exit(2);
  /* Build local BDDs */


  /********** Sweep befor Eliminate ************************************/

  /* Sweep the Bnetwork to remove constant and duplicate bnodes */
  if (option->delay != TRUE) {
    result = BDS_SweepBnetwork(bddmgr, net, option); /* function in sweep.c */
    if (result == 0) exit(2);
    cuddCheck(bddmgr, "", 1);
  }

  /********** Eliminate based on Local *********************************/

  /* Eliminate nodes based on MFFC and elimination gain threshold. If -rodelim is specified
   ** the network is first eliminated using non-reorder, then uses reorder-based eliminate.
   ** Collapsible nodes are collapsed together to form supernodes. In the first iteration,
   ** MFFCs are identified and collapsed, by allowing only nodes with one output to be collapsed
   ** into their fan-outs. But -largefanout option can be used to allow the collapse of multiple
   ** fan-out nodes. In subsequent iterations, multiple fan-out nodes can be collapsed into their
   ** fan-outs. The threshold limit option: -ethred allows setting a limit on the
   ** size differential between the old BDD before collapsing and the new BDD after collapsing.
   */

  result = BDS_EliminateBasedOnLocal(bddmgr, net, option, globalReady, 0, recdfp, a); /* 0=no reorder, a=0 */
  if (result == 0) exit(2);
  if (option->rodelim) {
    result = BDS_EliminateBasedOnLocal(bddmgr, net, option, globalReady, 1, recdfp, a);
    if (result == 0) exit(2);
  }
  cuddCheck(bddmgr, "", 1);

 

  /********** Sweep again after Eliminate ******************************/

  /* Sweep the Bnetwork again to remove constant and duplicate bnodes */
  result = BDS_SweepBnetwork(bddmgr, net, option);
  if (result == 0) exit(2);
  cuddCheck(bddmgr, "", 1);
 
  /* Network partition is verified only if global BDDs can be built. */
  if (option->verify == TRUE && globalReady) {
    result = bdsVerifyPartition(bddmgr, net, option); /* function in verify.c */
    if (result == 0) {
      printf("Fatal error in partition");
      exit(2);
    }
  }


  localOrGlobal = 0;

  /* Sharing extraction based on multi-BDDs, new bnodes are created to hold
   ** those shared logic. All BDDs on each node are stored in bddPool format
   ** and wait to be decomposed.
   */
  bddPoolBnodeAssoc = st_init_table(st_ptrcmp, st_ptrhash); /* function in st.c in CUDD/st/ */

  /********** Use local BDDs ***********************************************/

  /* Use local BDD */
  printf("Local BDDs are used for synthesis\n\n");

  /* Sharing extraction engine entry. Activated in v-1.2. */
  result = BDS_SharingExtractionLocal(bddmgr, net, option, recdfp); /* function in sharing.c */
  if (result == 0) {
    printf("Sharing extraction (local) fails !\n\n");
    exit(2);
  }

  /* Store all local BDDs in a BDD Pool */
  bddPoolArray = bdsStoreBDDInBddPoolLocal(bddmgr, net, option, bddPoolBnodeAssoc); /* function in prepare.c */
  if (bddPoolArray == NULL) exit(2);
  /* Free all BDDs from the bdd manager */
  result = bdsFreeAllBDDs(bddmgr, net, option, globalReady);
  if (result == 0) exit(2);
  /* Build varId and char* name association */
  PIvariables = bdsBuildVarNameAssocLocal(bddmgr, net, option); /* function in prepare.c */
  if (PIvariables == NULL) exit(2);


  /********** Decomposition preliminaries **********************************/

  /* Allocate a root FTreeNode for each BDD */
  i = 0;
  for (q = bddPoolArray; *q; q++) {
    i++;
  }
  /* This gives the total number of local and global bdds */
  numLocal = i;
  printf("There are %d local/global Bdds\n", numLocal);
  FTreeNode = ALLOC(FactorTreeNode *, i + 1); /* ALLOC(): defined in util.h in CUDD/util/ */
  FTreeNode[i] = NULL;
  netProcesEndTime = util_cpu_time();
  netProcesTotalTime = netProcesEndTime - netProcesStartTime;
  BDDDecompStartTime = util_cpu_time();

  /* Start decomposing BDDs, one by one */
  factorTreeNode2BnetNode = st_init_table(st_ptrcmp, st_ptrhash);
  i = 0;
  printf("Decomposing BDDs\n");
  (void) fflush(stdout);

#ifndef DEBUG
  fprintf(recdfp, "\n\n<<<<<<<<<<  Decomposing BDDs  >>>>>>>>>>\n\n");
#endif

  if (option->performancedecomp == TRUE)
    printf("Performance Driven Decomposition Start\n");

  /********** Decomposition Loop *******************************************/

  /* Start of for loop to decompose each BDD one by one:
   ** Decompostion is performed on each BDD one by one from the BDD Pool array.
   ** A new dummy BDD with simple variable indices is created from an actual
   ** BDD before loading it into a new BDD manager "decompBddmgr" to do decomposition.
   ** As decomposition is performed on each individual BDD, it doesn't need to
   ** know the actual indices in the Boolean network structure. A BDD is iteratively
   ** decomposed until it has a single variable (terminal node) and corresponding
   ** FTreeNodes are also created in the process. Dummy indices are also converted
   ** back to real indices for FTreeNodes.
   */
  i = 0;
  for (q = bddPoolArray; *q; q++) {
    printf("BDD %d\n", i);
    if (!st_lookup(bddPoolBnodeAssoc, (char *) *q, (char **) &node)) {
      fail("Fatal error in bddPoolBnodeAssoc!");
    }


    /* Record FactorTreeNode vs. BnetNode correspondency */
    FTreeNode[i] = ALLOC(FactorTreeNode, 1);
    FTreeNode[i]->name = node->name;
    /* Add node with key FTreeNode (only have node name for now) to factorTreeNode2BnetNode */
    if (st_add_direct(factorTreeNode2BnetNode, (char *) FTreeNode[i], (char *) node) == ST_OUT_OF_MEM) {
      printf("\nOut of memory !\n");
      exit(2);
    }

    decompBddmgr = startCudd(option, 0);
    if (decompBddmgr == NULL) {
      exit(2);
    }

    /* Build dummy BDD on this node */
    f = BDS_BuildDDFromBddPoolLocal(decompBddmgr, *q, &dummy2realId, bddmgr->size, option, &real2dumbo); /* function in local.c */
    if (f == NULL) exit(2);

    /* For performance decomposition of delay re-synthesis phase, reorder the variables in the BDD first
     ** before doing decomposition by calling BDS_Delay_Reorder().
     */

    printf("#");

    /********** Decompose a BDD iteratively ******************************/

    /* Main BDD decomposition engine entry. Used for BDD-based and heuristic decomposition */
    result = BDS_DDDecompose_alternative(decompBddmgr, net, f, option, &FTreeNode[i], permutation, real2dumbo, no_nodes, &c, &d, &op); /* function in lopt.c */

    /*function in lopt.c */

    if (result == 0) {
      printf("fail !\n");
      exit(2);
    }

    /* Convert dummy Ids back to real Ids */
    result = bdsConvertDummy2Real(FTreeNode[i], dummy2realId, option); /* function in local.c */
    if (result == 0) exit(2);


    i++; /* goto the next BDD in the BDD Pool */

  } /* end of for loop */

  printf("Done\n\n");
  printf("****************************\n\n");

  cc = BDS_BuildDDFromBddPool(decompBddmgr, c, 1);
  /* Build the 'dominator' BDD from SOP form */
  dd = BDS_BuildDDFromBddPool(decompBddmgr, d, 1);
  fp = fopen("/tmp/bdd1.dot", "w");
  Cudd_DumpDot(decompBddmgr, 1, &cc, NULL, NULL, fp);
  fclose(fp);
  fp = fopen("/tmp/bdd2.dot", "w");
  Cudd_DumpDot(decompBddmgr, 1, &dd, NULL, NULL, fp);
  fclose(fp);
  printf("\n");
  n1 = BDS_Support_Index(decompBddmgr, cc, &num1);
  n2 = BDS_Support_Index(decompBddmgr, dd, &num2);

  printf("decomposition %d %d %d\n", num1, op, num2);
  //Bnet_PrintNetwork(net);
  net_copy = special_copy_net(n1, num1, n2, num2, net);
  Bnet_PrintNetwork(net_copy);
  printf("Done copy\n\n");
  Bnet_PrintNetwork(net);





  netProcesStartTime = util_cpu_time(); /* function in CUDD\util\cpu_time.c */
  result = BDS_BnetEnhance(net_copy, option); /* function in enhance.c */
  if (result == 0) exit(2);
  printf("Done enhance\n\n");


  /* Build local BDDs */
  result = BDS_BuildLocalBDD_(decompBddmgr, net_copy, option, cc, n1, num2, dd, n2, num2); /* function in build.c */
  if (result == 0) exit(2);
  cuddCheck(decompBddmgr, "", 1); /* function in debug.c */


  /********** Eliminate based on Local *********************************/

  /* Eliminate nodes based on MFFC and elimination gain threshold. If -rodelim is specified
   ** the network is first eliminated using non-reorder, then uses reorder-based eliminate.
   ** Collapsible nodes are collapsed together to form supernodes. In the first iteration,
   ** MFFCs are identified and collapsed, by allowing only nodes with one output to be collapsed
   ** into their fan-outs. But -largefanout option can be used to allow the collapse of multiple
   ** fan-out nodes. In subsequent iterations, multiple fan-out nodes can be collapsed into their
   ** fan-outs. The threshold limit option: -ethred allows setting a limit on the
   ** size differential between the old BDD before collapsing and the new BDD after collapsing.
   */

  result = BDS_EliminateBasedOnLocal(decompBddmgr, net_copy, option, globalReady, 0, recdfp, a); /* 0=no reorder, a=0 */
  if (result == 0) exit(2);
  if (option->rodelim) {
    result = BDS_EliminateBasedOnLocal(decompBddmgr, net_copy, option, globalReady, 1, recdfp, a);
    if (result == 0) exit(2);
  }
  cuddCheck(decompBddmgr, "", 1);

  /********** Sweep again after Eliminate ******************************/

  /* Sweep the Bnetwork again to remove constant and duplicate bnodes */
  result = BDS_SweepBnetwork(decompBddmgr, net_copy, option);
  if (result == 0) exit(2);
  cuddCheck(decompBddmgr, "", 1);
  if (option->dumpnet == TRUE)
    netPrint(net_copy, option); /* function in debug.c */

  /* Network partition is verified only if global BDDs can be built. */
  if (option->verify == TRUE && globalReady) {
    result = bdsVerifyPartition(decompBddmgr, net_copy, option); /* function in verify.c */
    if (result == 0) {
      printf("Fatal error in partition");
      exit(2);
    }
  }




  printf("Local BDDs are used for synthesis\n\n");
  /* Sharing extraction engine entry. Activated in v-1.2. */
  result = BDS_SharingExtractionLocal(decompBddmgr, net_copy, option, recdfp); /* function in sharing.c */
  if (result == 0) {
    printf("Sharing extraction (local) fails !\n\n");
    exit(2);
  }

  /* Store all local BDDs in a BDD Pool */
  bddPoolArray_ = bdsStoreBDDInBddPoolLocal_(decompBddmgr, net_copy, option, bddPoolBnodeAssoc); /* function in prepare.c */
  printf("stored\n");

  i = 0;
  for (nd = bddPoolArray_; *nd; nd++) {
    printf("%d", i);
    char str[30], buf[4];
    strcpy(str, "/tmp/bdd");
    snprintf(buf, sizeof (buf), "%d", i);
    strcat(str, buf);
    strcat(str, "_F.dot");
    printf("%s", str);
    fp = fopen(str, "w");
    Cudd_DumpDot(decompBddmgr, 1, nd, NULL, NULL, fp);
    fclose(fp);
    i++;
  }

  if (bddPoolArray == NULL) exit(2);
  /* Free all BDDs from the bdd manager */
  result = bdsFreeAllBDDs(decompBddmgr, net_copy, option, globalReady);
  if (result == 0) exit(2);
  /* Build varId and char* name association */
  PIvariables = bdsBuildVarNameAssocLocal(decompBddmgr, net_copy, option); /* function in prepare.c */
  if (PIvariables == NULL) exit(2);



  /********** Factoring Tree Processing and outputting to final BLIF file **/

  /* Factoring trees processing engine entry:
   ** Perform Sharing extraction, Homogeneous collapsing, and Phase assignment
   ** on FTreeNodes to optimize the final network before writing it out to the
   ** final BLIF file. When collapsing an FTreeNode, the size of the final node is
   ** limited to k for mapping to FPGA with k-inputs LUTs.
   */

  //  result = BDS_FTreeProcessing(bddmgr, net, FTreeNode, option, PIvariables, factorTreeNode2BnetNode, a); /* function in ftree.c */
  if (result == 0) {
    printf("Final ftree processing fails !\n");
    exit(2);
  }

  /* Verify the final synthesis results */
  if (option->verify == TRUE) {
    //    result = bdsVerifySynthesis(bddmgr, net, FTreeNode, factorTreeNode2BnetNode, bddPoolArray, bddPoolBnodeAssoc, option); /* function in verify.c */

    //    BDS_Stats(BDS_VERIFY, NULL, result, "after", NULL, NULL, NULL); /* function in loptutil.c */
  }

  /* Everything is done. So, free everything now before exiting the program. */

  st_free_table(bddPoolBnodeAssoc); /* function from CUDD/st/ */
  st_free_table(factorTreeNode2BnetNode);

  /* Free factoring tree */
  (void) BDS_FreeFTree(bddmgr, FTreeNode); /* function in ftree.c */
  FREE(FTreeNode);

#ifndef DEBUG
  fclose(recdfp);
#endif

  FREE(FTreeNode);
  FREE(PIvariables);
  for (q = bddPoolArray; *q; q++) {

    (void) bdsFreeBddPoolLocal(bddmgr, *q); /* function in local.c */
  }
  FREE(bddPoolArray);
  FREE(newnode);
  
  BDDDecompEndTime = util_cpu_time();
  BDDDecompTotalTime = BDDDecompEndTime - BDDDecompStartTime;
  BDS_Stats(BDS_CLOSE, NULL, BDDDecompTotalTime, NULL, NULL, bddmgr, option);
  Cudd_Quit(bddmgr);
  Cudd_Quit(decompBddmgr);
  /* Free Boolean network */
  (void) BDS_FreeNetworkAfterEliminate(net); /* function in eliminate.c */
  printf("\nTotal time used to do network preprocessing = %s\n", util_print_time(netProcesTotalTime));
  printf("Total time used to do BDD decomposition = %s\n\n", util_print_time(BDDDecompTotalTime));
  freeOption(option); /* function in this file */
  util_print_cpu_stats(stdout);
  exit(0);

} /* end of main */

/*---------------------------------------------------------------------------*/
/* Definition of internal functions                                          */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Definition of static functions                                            */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis    [Set the default options]

  Description [Initialization of default options for the program]

  SideEffects [none]

  SeeAlso     [bdsReadOptions]

 ******************************************************************************/
static bdsOptions *
mainInit() {
  bdsOptions *option;
  /* Initialize option structure. */
  option = ALLOC(bdsOptions, 1);
  option->initialTime = util_cpu_time();
  option->file = NULL;
  option->cacheSize = BDS_BDD_STARTUP_CACHE; /// = 10*1024
  option->maxMemory = BDS_BDD_STARTUP_MEMORY; /// = 10*1024*1024
  option->slots = CUDD_UNIQUE_SLOTS; /// = 256 = initial size of subtables
  option->order = PI_PS_FROM_FILE; /// = 0
  option->orderfile = NULL;
  option->reordering = CUDD_REORDER_NONE;
  option->maxGrowth = 20;
  option->verb = BDS_VERBOSE_MORE; /// = 1 in lopt.h
  option->iconst = 100000; /// in eliminate.c: input constriant
  option->kdecomp = FALSE;
  option->largefanout = FALSE;
  option->delay = FALSE;
  option->performancedecomp = FALSE;
  option->heuristic = TRUE;
  option->useloc = TRUE;
  option->useglb = FALSE;
  option->ethred = BDS_ELIMINATE_THRESHOLD; /// = 0
  option->autodyn = FALSE;
  option->rodelim = FALSE;
  option->globalLimit = BDS_GLOBAL_BDD_LIMIT; /// = 20000
  option->glbEliminate = FALSE;
  option->verify = FALSE;
  option->effort = 1;
  option->limitSize = BDS_BDD_REORDER_LIMIT; /// = 200 (The largest BDD on which exact reordering can apply)
  option->miniMethod = BDS_BDD_RESTRICT; /// = 0
  option->dumpbdd = FALSE;
  option->dumpblif = TRUE;
  option->dumpftree = TRUE;
  option->dumpfdot = FALSE;
  option->dumpnet = FALSE;
  option->cutptl = FALSE;
  option->elim = FALSE;
  option->level1 = FALSE;
  option->eps = 0;
  option->sharing = TRUE;
  option->xhardcore = TRUE;
  option->k = 5; /// default k value is 5
  return (option);
} /* end of mainInit */

/**Function********************************************************************

  Synopsis    [Reads the command line options]

  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static void
bdsReadOptions(
 int argc,
 char ** argv,
 bdsOptions * option) {
  int i = 0;
  if (argc < 2) goto usage; /// if only one args (./bds)
  for (i = 1; i < argc; i++) {
    if (argv[i][0] != '-') {
      if (option->file == NULL) {
        option->file = util_strsav(argv[i]); /// Save string (file name)
      } else {
        goto usage; /// if option is not defined
      }
    }/// STRING_EQUAL: defined in build.h [Compare two string (strcmp)]
    else if (STRING_EQUAL(argv[i], "-xhardcore")) {
      option->xhardcore = TRUE;
    } else if (STRING_EQUAL(argv[i], "-k")) {
      i++;
      option->k = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-verify")) {
      option->verify = TRUE;
    } else if (STRING_EQUAL(argv[i], "-kdecomp")) {
      option->kdecomp = TRUE;
    } else if (STRING_EQUAL(argv[i], "-largefanout")) {
      option->largefanout = TRUE;
    } else if (STRING_EQUAL(argv[i], "-delay")) {
      option->delay = TRUE;
    } else if (STRING_EQUAL(argv[i], "-perform")) {
      option->performancedecomp = TRUE;
    } else if (STRING_EQUAL(argv[i], "-heuristic")) {
      option->heuristic = TRUE;
    } else if (STRING_EQUAL(argv[i], "-useloc")) {
      option->useloc = TRUE;
    } else if (STRING_EQUAL(argv[i], "-useglb")) {
      option->useglb = TRUE;
    } else if (STRING_EQUAL(argv[i], "-autodyn")) {
      option->autodyn = TRUE;
    } else if (STRING_EQUAL(argv[i], "-rodelim")) {
      option->rodelim = TRUE;
    } else if (STRING_EQUAL(argv[i], "-sharing")) {
      option->sharing = TRUE;
    } else if (STRING_EQUAL(argv[i], "-elim")) {
      option->elim = TRUE;
    } else if (STRING_EQUAL(argv[i], "-level1")) {
      option->level1 = TRUE;
    } else if (STRING_EQUAL(argv[i], "-glbEliminate")) {
      option->glbEliminate = TRUE;
    } else if (STRING_EQUAL(argv[i], "-cache")) {
      i++;
      option->cacheSize = (int) atoi(argv[i]); /// atoi: Convert string to int
    } else if (STRING_EQUAL(argv[i], "-maxmem")) {
      i++;
      option->maxMemory = 1048576 * (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-slots")) {
      i++;
      option->slots = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-order")) {
      i++;
      option->order = PI_PS_GIVEN;
      option->orderfile = util_strsav(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-reordering")) {
      i++;
      if (STRING_EQUAL(argv[i], "none")) {
        option->reordering = CUDD_REORDER_NONE;
      } else if (STRING_EQUAL(argv[i], "random")) {
        option->reordering = CUDD_REORDER_RANDOM;
      } else if (STRING_EQUAL(argv[i], "bernard") ||
       STRING_EQUAL(argv[i], "pivot")) {
        option->reordering = CUDD_REORDER_RANDOM_PIVOT;
      } else if (STRING_EQUAL(argv[i], "sifting")) {
        option->reordering = CUDD_REORDER_SIFT;
      } else if (STRING_EQUAL(argv[i], "converge")) {
        option->reordering = CUDD_REORDER_SIFT_CONVERGE;
      } else if (STRING_EQUAL(argv[i], "symm")) {
        option->reordering = CUDD_REORDER_SYMM_SIFT;
      } else if (STRING_EQUAL(argv[i], "cosymm")) {
        option->reordering = CUDD_REORDER_SYMM_SIFT_CONV;
      } else if (STRING_EQUAL(argv[i], "tree") ||
       STRING_EQUAL(argv[i], "group")) {
        option->reordering = CUDD_REORDER_GROUP_SIFT;
      } else if (STRING_EQUAL(argv[i], "cotree") ||
       STRING_EQUAL(argv[i], "cogroup")) {
        option->reordering = CUDD_REORDER_GROUP_SIFT_CONV;
      } else if (STRING_EQUAL(argv[i], "win2")) {
        option->reordering = CUDD_REORDER_WINDOW2;
      } else if (STRING_EQUAL(argv[i], "win3")) {
        option->reordering = CUDD_REORDER_WINDOW3;
      } else if (STRING_EQUAL(argv[i], "win4")) {
        option->reordering = CUDD_REORDER_WINDOW4;
      } else if (STRING_EQUAL(argv[i], "win2conv")) {
        option->reordering = CUDD_REORDER_WINDOW2_CONV;
      } else if (STRING_EQUAL(argv[i], "win3conv")) {
        option->reordering = CUDD_REORDER_WINDOW3_CONV;
      } else if (STRING_EQUAL(argv[i], "win4conv")) {
        option->reordering = CUDD_REORDER_WINDOW4_CONV;
      } else if (STRING_EQUAL(argv[i], "annealing")) {
        option->reordering = CUDD_REORDER_ANNEALING;
      } else if (STRING_EQUAL(argv[i], "genetic")) {
        option->reordering = CUDD_REORDER_GENETIC;
      } else if (STRING_EQUAL(argv[i], "linear")) {
        option->reordering = CUDD_REORDER_LINEAR;
      } else if (STRING_EQUAL(argv[i], "linconv")) {
        option->reordering = CUDD_REORDER_LINEAR_CONVERGE;
      } else if (STRING_EQUAL(argv[i], "exact")) {
        option->reordering = CUDD_REORDER_EXACT;
      } else {
        goto usage;
      }
    } else if (STRING_EQUAL(argv[i], "-growth")) {
      i++;
      option->maxGrowth = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-verb")) {
      i++;
      option->verb = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-miniMethod")) {
      i++;
      if (STRING_EQUAL(argv[i], "restrict")) {
        option->miniMethod = BDS_BDD_RESTRICT;
      } else if (STRING_EQUAL(argv[i], "licompaction")) {
        option->miniMethod = BDS_BDD_LICOMPACTION;
      } else {
        goto usage;
      }
    } else if (STRING_EQUAL(argv[i], "-effort")) {
      i++;
      option->effort = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-limitSize")) {
      i++;
      option->limitSize = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-iconst")) {
      i++;
      option->iconst = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-globalLimit")) {
      i++;
      option->globalLimit = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-ethred")) {
      i++;
      option->ethred = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-eps")) {
      i++;
      option->eps = (int) atoi(argv[i]);
    } else if (STRING_EQUAL(argv[i], "-dumpbdd")) {
      option->dumpbdd = TRUE;
    } else if (STRING_EQUAL(argv[i], "-dumpblif")) {
      option->dumpblif = TRUE;
    } else if (STRING_EQUAL(argv[i], "-dumpftree")) {
      option->dumpftree = TRUE;
    } else if (STRING_EQUAL(argv[i], "-dumpfdot")) {
      option->dumpfdot = TRUE;
    } else if (STRING_EQUAL(argv[i], "-dumpnet")) {
      option->dumpnet = TRUE;
    } else if (STRING_EQUAL(argv[i], "-cutptl")) {
      option->cutptl = TRUE;
    } else {
      goto usage;
    }
  }

  if (option->useloc && option->useglb) {
    printf("\nCommand line error: -useloc and -useglb can NOT be both specified !\n\n");
    exit(0);
  }
  if (option->file == NULL) {
    printf("\nPlease specify a circuit file !\n\n");
    exit(0);
  }

  (void) printf("# %s\n", BDS_VERSION);
  /* echo command line and arguments */
  (void) printf("#");
  for (i = 0; i < argc; i++) {
    (void) printf(" %s", argv[i]);
  }
  (void) printf("\n");
  (void) printf("# CUDD Version ");

  Cudd_PrintVersion(stdout); /// function from CUDD package
  (void) fflush(stdout);
  printf("\n\n");

  BDS_Stats(BDS_INIT, NULL, argc, BDS_VERSION, argv, NULL, option);

  return;

usage: /* convenient goto */
  printf("Usage: please read man page\n");

  if (i == 0) {
    (void) fprintf(stdout, "too few arguments\n");
  } else {
    (void) fprintf(stdout, "option: %s is not defined\n", argv[i]);
  }
  exit(-1);

} /* end of bdsReadOptions */

/**Function********************************************************************

  Synopsis    [Frees the option structure and its appendages.]

  Description []

  SideEffects [None]

  SeeAlso     []

 *****************************************************************************/
static void
freeOption(
 bdsOptions * option) {
  if (option->file != NULL) FREE(option->file);
  if (option->orderfile != NULL) FREE(option->orderfile);
  FREE(option);
} /* end of freeOption */



/**Function********************************************************************

  Synopsis    [Traverse BDD in the DdNode data structure to check for variable order before AND after Performance directed reordering]

  Description []

  SideEffects [None]

  SeeAlso     []

 *****************************************************************************/
extern
int
BDS_traverse_beforeafter_delay_reorder(
 DdNode *f,
 bddPool *pool) {
  int i, *order;
  DdNode *temp_node;
  DdHalfWord index;
  order = pool->order;
  printf("NumVar = %i\n", pool->numVar);
  for (i = 0; i < pool->numVar; i++) {
    index = f->index;
    printf("Index is %i\n", index);
  }
  return (1);
}
