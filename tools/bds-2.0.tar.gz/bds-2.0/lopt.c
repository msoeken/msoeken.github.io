
/**CFile***********************************************************************

  FileName    [lopt.c]

  PackageName [BDS-pga]

  Synopsis    [BDD Decomposition Program for FPGAs]

  Description [This file contains the functions for BDD decompositions.
               Each BDD is decomposed iteratively using a queue until all BBDs
               have been decomposed into a single variable terminal node. The
               top-level BDD Decomposition function: BDS_DDDecompose() decomposes
               a BDD into 'decomposed' and 'dominator' sub-BDD-nodes by
               calling BDS_BddDecomposeMain(). Then 'decomposed' and 'dominator'
               are decomposed one after another by calling BDS_DDDecomposeAll(),
               which calls BDS_BddDecomposeMain() in a loop until all BDD nodes
               have been decomposed into a single variable terminal node. In the
               process, the corresponding FTreeNodes are created to do
               factoring tree processing stages to optimize the decomposed
               network before the final result is outputted to the final BLIF
               file.
                   Decompostion is first tried with heuristic variable partitioning
               approach if -heuristic option is specified. The heuristic approach does
               variable swappings between the bound set and free set before doing
               decomposition. If it is not successful, the simple dominator
               approach for algebraic decompositions of AND (1-dominator), OR
               (0-dominator), or XNOR (x-dominator) decomposition are tried next.
               If it also is not successful, the variables in the BDD are
               reordered before trying the simple dominator approach the second time.
               If it is still not successful, it performs MUX branch
               decomposition based on branches found on the BDD. If no branch is found,
               it will check for balance in the BDD. If the BDD is not balanced,
               it will try to decompose with respect to the top variable. If it is not
               successful, it will finally try the general Boolean decomposition approach.
               If it still has no luck, it will continue to try generalized Boolean
               x-dominators approach if -xhardcore option is specified.
               Finally, if no efficient decomposition can be detected, it will take
               cofactor with respect to the top variable.]

  SeeAlso     []

  Author      [Congguang Yang, Navin Vemuri]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

 ******************************************************************************/

#include "lopt.h"
#include <stdio.h>
#define PTL 1
/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static int BDS_CheckTerminal ARGS((DdManager*, DdNode*, FactorTreeNode*));
static int BDS_FindBestDecomp ARGS((DdManager*, DdNode*, DdNode*, int*, bdsOptions*, bddPool**, bddPool**, int*, int, edgeMark**));
static int BDS_XHardCore ARGS((DdManager*, DdNode*, bdsOptions*, bddPool**, bddPool**, int*, int*, int, edgeMark**));
extern int BDS_HeuristicDecomp ARGS((DdManager*, DdNode*, DdNode*, int*, bdsOptions*, bddPool**, bddPool**, int*, int));
extern int BDS_GoodSwap ARGS((DdManager*, DdNode*, DdNode*, int, bdsOptions*));
extern int BDS_DoSwap ARGS((DdManager*, DdNode*, edgeMark**, int, int, int*, bdsOptions*));
extern int BDS_HMark ARGS((DdManager*, DdNode *, int*, int, int*, int));
extern int BDS_HMarkRecursive ARGS((DdManager*, DdNode*, DdNode*, st_table*, int*, int, int*, int, int*, int*, int*));
extern int * BDS_VariableArray ARGS((DdManager*, DdNode*, int*));
extern int * BDS_ChangeVariableArray ARGS((DdManager*, DdNode*, int, int));
static int BDS_BHardCore ARGS((DdManager*, DdNode*, DdNode*, bdsOptions*, bddPool**, bddPool**, bddPool**, int*, int*, int, edgeMark**));
static int BDS_XDecompOnBdd ARGS((DdManager*, DdNode*, int, int*, int, edgeMark*, XdecompCost*, bdsOptions*));
static DdNode * BDS_addXCandidate ARGS((DdManager*, edgeMark*));
static DdNode * BDS_bddXCandidate ARGS((DdManager*, DdNode*, edgeMark*));
static int BDS_BddDecomposeMain ARGS((DdManager*, DdNode*, bdsOptions*, bddPool**, bddPool**, bddPool**, int*, int*, int*, int*, int*, int, int*));
static decompCost* BDS_CalculateDecompCost ARGS((DdManager *, DdNode *, DdNode *, DdNode *, bdsOptions *));
static int BDS_PerformDecomp ARGS((DdManager *, DdNode *, DdNode *, edgeMark *, decompCost **, bdsOptions *, int, int, int, decompCost **, int *, int *));
static int BDS_DDDecomposeAll ARGS((DdManager*, bddPool*, bdsOptions*, FactorTreeNode**, int, int, bddPool*, int, int, int*));
static int BDS_SimpleDominator ARGS((DdManager*, DdNode*, DdNode*, int*, int, int*, edgeMark**, bddPool**, bddPool**, int*, bdsOptions*, int));
static DdNode * BDS_SpecialCheck ARGS((DdManager*, DdNode*, DdNode*, int*, int, int*, edgeMark**, int*, bdsOptions*));
static int BDS_CofactorOnTop ARGS((DdManager*, DdNode*, bdsOptions*, bddPool**, bddPool**, bddPool**, int*, int*));
static DdNode * BDS_SearchXD ARGS((DdManager*, DdNode*, int*, int, bdsOptions*));
static DdNode * BDS_SearchOneD ARGS((DdManager*, int*, int, int*, edgeMark**));
static DdNode * BDS_SearchZeroD ARGS((DdManager*, int*, int, int*, edgeMark**));
static DdNode * BDS_XDecompose ARGS((DdManager*, DdNode*, DdNode*, int*, bdsOptions*));
static DdNode * BDS_ANDDecompose ARGS((DdManager*, DdNode*, DdNode*, bdsOptions*));
static DdNode * BDS_ORDecompose ARGS((DdManager*, DdNode*, DdNode*, bdsOptions*));
static DdNode * BDS_BranchCandidateX ARGS((DdManager*, DdNode*, edgeMark*));
static DdNode * BDS_BranchCandidateB ARGS((DdManager*, DdNode*, edgeMark*, DdNode**, DdNode**));
static DdNode * BDS_FindOneMark ARGS((DdManager*, DdNode*, edgeMark*));
static DdNode * BDS_FindOneMarkRecursive ARGS((DdManager*, DdNode*, st_table*, edgeMark*));
static int BDS_OneMoreTry ARGS((DdManager*, DdNode*, bdsOptions*, bddPool**, bddPool**, int*, int*));
static decompCost* BDS_InitBestCost ARGS(());
static XdecompCost* BDS_InitXdecompCost ARGS(());
static float BDS_CalXdecompCost ARGS((DdManager*, DdNode*, int, DdNode*, int, DdNode*, int, DdNode*, int));
extern int BDS_Heuristic_Simple ARGS((DdManager*, DdNode*, int*, int*, bdsOptions*, int*));
extern int Swap_Variable ARGS((DdManager*, int**, int, int));
extern void Rebuild_Partition_Table ARGS((int**, int, int));

/**Function********************************************************************

  Synopsis    [Main Program for BDD Decomposition-Based BDS]

  Description [Top-level BDD Decomposition function that decomposes a BDD into
               'decomposed' and 'dominator' sub-BDD-nodes by calling BDS_BddDecomposeMain().
               Then 'decomposed' and 'dominator' are decomposed one after another by calling
               BDS_DDDecomposeAll(), which in turn calls BDS_BddDecomposeMain() in a loop
               using a queue until all nodes have been decomposed into terminal node with
               one variable. Decomposition functions are called from BDS_BddDecomposeMain().
               result = 1, successful. 0 otherwise]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
//int *index( bddPool **decomposed){



//}

extern
int
BDS_DDDecompose_alternative(
 DdManager *bddmgr,
 BnetNetwork* net,
 DdNode *bdd, /* BDD to be decomposed */
 bdsOptions *option,

 FactorTreeNode **FTNode, /* a FTreeNode[i] array element to be recorded after decomposition on BDD */
 int *permutation, /* for performancedecomp, passed to DecomposeMain */
 int *real2dumbo, /* for performancedecomp, passed to DecomposeMain and DecomposeAlls */
 int *no_nodes,  /* for performancedecomp, passed to DecomposeMain */
 bddPool **decomposed, bddPool **dominator, bddPool **control, int *operator
 ) /* for performancedecomp, passed to DecomposeMain */ {
  BnetNode * newnode, *last_node;
  DdNode *decomp_temp = NULL, *dominate_temp = NULL, *N, *G, *cc, *dd; /* for debugDump */
  int result, *support1, level1, num1, num2; /* num1, num2 = support sizes */
  int *n1, *n2,*support_decomp, *support_dominate; /* for debugDump */
  int level_decomp, level_dominate; /* for debugDump */
 FactorTreeNode *decomposedFTNode, *dominatorFTNode, *controlFTNode;
  int p; /* If decompBdd is complementary or not after reordering, passed to DecomposeMain for value then to DecomposeAlls */
  int which = 0; /* = 0 for first DecomposeMain, = 1 for two DecomposeAlls */
  int *original; /* for performancedecomp, passed to DecomposeMain */
  int num, i; /* num = # variables of BDD for performancedecomp, i = for loop for performancedecomp */
  int dumbo; /* for performancedecomp */
  *decomposed = NULL;
  *dominator = NULL;
  *control= NULL;
  last_node = NULL;
  if (bdd == NULL) {
    printf("WARNING: Can not decompose NULL BDD !\n");
    return (0);
  }



  /* When the BDD is a terminal, no decomposition, only create FTree association */
  result = BDS_CheckTerminal(bddmgr, bdd, *FTNode);
  if (result != 0) return (1);


  /* Decompose the BDD */

  which = 0; /* = 0 to do performancedecomp variable reordering the first time */
  support1 = BDS_SupportArray(bddmgr, bdd, &level1); /* support in the form of int* (level) */
  if (support1 == NULL) return (0);

  /* Do decomposition on a top BDD super-node. Two decomposed BDDs:
   ** 'dominator' and 'decomposed' are obtained after decomposition
   */
  result = BDS_BddDecomposeMain(bddmgr, bdd, option, decomposed, dominator, control, operator, &p, permutation, original, no_nodes, which, real2dumbo);
  if (result == 0) {

    return 0;
  }
  printf("op=%d !\n",*operator);
#ifdef DEBUG
  cuddCheck(bddmgr, "BDS_DDDecompose", 2);
#endif

 // which = 1; /* = 1 not to do performancedecomp variable reordering after the first time */
  /* Build the 'decomposed' BDD from SOP form */
 // decomp_temp = BDS_BuildDDFromBddPool(bddmgr, *decomposed, 1);

  /* Build the 'dominator' BDD from SOP form */
 // dominate_temp = BDS_BuildDDFromBddPool(bddmgr, *dominator, 1);
  /* Get the supports (level information for variables) for 'decomposed'
   ** and 'dominator' BDDs
   */
  //n1 = BDS_Support_Index(bddmgr, decomp_temp,&num1);
 // n2 = BDS_Support_Index(bddmgr, dominate_temp,&num2);
 //printf("num1=%d\n",(num1));
 //  printf("\n");
 // i = 0;
 // while (i<(num1)) {
   
 //   printf("%d  ; \n",n1[i]);
  //  i++;
  //}
 // printf("\n");
 
 //printf("num2=%d\n",(num2));

 // i = 0;
 // while (i<(num2)) {
   
  //  printf("%d  ; \n", n2[i]);
 //   i++;
 // }
  
  /* Initialize factoring trees for 'decomposed' and 'dominator' BDDs */
 // decomposedFTNode = ALLOC(FactorTreeNode, 1);
//  (*FTNode)->siblings[0] = decomposedFTNode;
//  dominatorFTNode = ALLOC(FactorTreeNode, 1);
//  (*FTNode)->siblings[1] = dominatorFTNode;


  return (1);





}

extern
int
BDS_DDDecompose(
 DdManager *bddmgr,
 DdNode *bdd, /* BDD to be decomposed */
 bdsOptions *option,
 FactorTreeNode **FTNode, /* a FTreeNode[i] array element to be recorded after decomposition on BDD */
 int *permutation, /* for performancedecomp, passed to DecomposeMain */
 int *real2dumbo, /* for performancedecomp, passed to DecomposeMain and DecomposeAlls */
 int *no_nodes) /* for performancedecomp, passed to DecomposeMain */ {
  DdNode *decomp_temp = NULL, *dominate_temp = NULL, *N, *G; /* for debugDump */
  int result, operator, *support1, level1, num1, num2; /* num1, num2 = support sizes */
  int *support_decomp, *support_dominate; /* for debugDump */
  int level_decomp, level_dominate; /* for debugDump */
  int decompordom; /* = 1 passed to DecomposeAll for dp, = 0 passed to DecomposeAll for dm */
  bddPool *decomposed = NULL, *dominator = NULL, *control = NULL; /* control = for PTL */
  FactorTreeNode *decomposedFTNode, *dominatorFTNode, *controlFTNode;
  int p; /* If decompBdd is complementary or not after reordering, passed to DecomposeMain for value then to DecomposeAlls */
  int which = 0; /* = 0 for first DecomposeMain, = 1 for two DecomposeAlls */
  int *original; /* for performancedecomp, passed to DecomposeMain */
  int num, i; /* num = # variables of BDD for performancedecomp, i = for loop for performancedecomp */
  int dumbo; /* for performancedecomp */

  if (bdd == NULL) {
    printf("WARNING: Can not decompose NULL BDD !\n");
    return (0);
  }

  N = Cudd_Regular(bdd); /* Returns the regular version of BDD pointer */

  /* Avoid huge bdd */
  num = Cudd_SupportSize(bddmgr, N); /* Counts # variables on which a DD depends */
  original = ALLOC(int, num); /* original has the int array size of # variables of BDD */

  /* For performance decomposition of delay re-synthesis phase, create separate real and
     dummy node associations. */
  if (option->performancedecomp == TRUE) {
    for (i = 0; i < num; i++) {
      dumbo = permutation[i];
      original[i] = real2dumbo[dumbo];
    }
  }

#ifndef DEBUG
  (void) printf(".");
  (void) fflush(stdout);
#endif

#ifdef DEBUG
  cuddCheck(bddmgr, "BDS_DDDecompose", 0); /* function in debug.c to check for !(Cudd_DebugCheck(bddmgr) && (!Cudd_CheckKeys(bddmgr))) */
#endif

  /* When the BDD is a terminal, no decomposition, only create FTree association */
  result = BDS_CheckTerminal(bddmgr, bdd, *FTNode);
  if (result != 0) return (1);

#ifdef DEBUG
  cuddCheck(bddmgr, "BDS_DDDecompose", 1);
#endif

  /* Decompose the BDD */

  which = 0; /* = 0 to do performancedecomp variable reordering the first time */
  support1 = BDS_SupportArray(bddmgr, bdd, &level1); /* support in the form of int* (level) */
  if (support1 == NULL) return (0);

  /* Do decomposition on a top BDD super-node. Two decomposed BDDs:
   ** 'dominator' and 'decomposed' are obtained after decomposition
   */
  result = BDS_BddDecomposeMain(bddmgr, bdd, option, &decomposed, &dominator, &control, &operator, &p, permutation, original, no_nodes, which, real2dumbo);
  if (result == 0) {
    return 0;
  }
  printf("decomposition %d %d %d\n", (decomposed)->numVar, operator, (dominator)->numVar);
#ifdef DEBUG
  cuddCheck(bddmgr, "BDS_DDDecompose", 2);
#endif

  which = 1; /* = 1 not to do performancedecomp variable reordering after the first time */
  /* Build the 'decomposed' BDD from SOP form */
  decomp_temp = BDS_BuildDDFromBddPool(bddmgr, decomposed, 1);
  /* Build the 'dominator' BDD from SOP form */
  dominate_temp = BDS_BuildDDFromBddPool(bddmgr, dominator, 1);

  /* Get the supports (level information for variables) for 'decomposed'
   ** and 'dominator' BDDs
   */
  support_decomp = BDS_SupportArray(bddmgr, decomp_temp, &level_decomp);
  if (support_decomp == NULL) return (0);
  support_dominate = BDS_SupportArray(bddmgr, dominate_temp, &level_dominate);
  if (support_dominate == NULL) return (0);

  /* Returns the regular version of 'decomposed' BDD */
  N = Cudd_Regular(decomp_temp);
  /* Get # variables on which 'decomposed' DD depends */
  num2 = Cudd_SupportSize(bddmgr, N);

  /* Returns the regular version of 'decomposed' BDD */
  G = Cudd_Regular(dominate_temp);
  /* Get # variables on which 'dominator' DD depends */
  num1 = Cudd_SupportSize(bddmgr, G);

  /* Initialize factoring trees for 'decomposed' and 'dominator' BDDs */
  decomposedFTNode = ALLOC(FactorTreeNode, 1);
  (*FTNode)->siblings[0] = decomposedFTNode;
  dominatorFTNode = ALLOC(FactorTreeNode, 1);
  (*FTNode)->siblings[1] = dominatorFTNode;

#ifdef PTL
  /* MUX-related operation */
  if (operator == BDS_BDD_MUX && control != NULL) {
    controlFTNode = ALLOC(FactorTreeNode, 1);
    (*FTNode)->siblings[2] = controlFTNode;
  }
#endif

  /* Update this FTree Node */
  BDS_WriteFnode(*FTNode, p, operator, BDS_FTREE_INTERNAL);

  /* Do decomposition on 'decomposed' BDD */
  decompordom = 1;
  result = BDS_DDDecomposeAll(bddmgr, decomposed, option, &decomposedFTNode, operator, p, dominator, decompordom, which, real2dumbo);
  if (result == 0) {
    return 0;
  }

#ifdef DEBUG
  cuddCheck(bddmgr, "BDS_DDDecompose", 3);
#endif

  /* Do decomposition on 'dominator' BDD */
  decompordom = 0;
  result = BDS_DDDecomposeAll(bddmgr, dominator, option, &dominatorFTNode, operator, p, decomposed, decompordom, which, real2dumbo);
  if (result == 0) {
    return 0;
  }

#ifdef DEBUG
  cuddCheck(bddmgr, "BDS_DDDecompose", 4);
#endif

#ifdef PTL
  /* Decompose control */
 // if (operator == BDS_BDD_MUX && control != NULL) {
 //   result = BDS_DDDecomposeAll(bddmgr, control, option, &controlFTNode);
//    if (result == 0) {
//      return 0;
//    }
 // }
#endif

#ifdef DEBUG
  cuddCheck(bddmgr, "BDS_DDDecompose", 5);
#endif
  return (1);

} /* end of BDS_DDDecompose */

/**Function********************************************************************

   Synopsis    [Program for BDD Decomposition-Based BDS]

   Description [An BDD is decomposed into *dominator and *decomposed at the best level,
                the factoring tree is built along with the decomposition. A queue is used
                to line up the BDDs waited to be decomposed. If a decomposed BDD is still
                not a terminal node, it is put back into the queue to farther decompose
                again until all the BDDs become terminal nodes with one variable.

                All the possible cuts on the 0-1 ADD are tried, and both Boolean divisor
                and subtractor is evaluated based on that cut. The BEST Boolean divisor
                or subtractor is found by storing all the COST of each cut. The BEST has
                the LEAST cost.

                Special cases like 0-, 1- and x-dominators are detected separately.
                Return 1 success; 0 otherwise]

   SideEffects []

   SeeAlso     []

 ******************************************************************************/
static
int
BDS_DDDecomposeAll(
 DdManager *bddmgr,
 bddPool *topSop, /* top BDD from BDS_DDDecompose(): either 'decpomposed' or 'dominator' BDD */
 bdsOptions *option,
 FactorTreeNode **FTNode, /* FTree Node */
 int tempoperator, /* operator (not used, passed a new operator to DecomposeMain) */
 int temppolarity, /* p (not used, passed a new p to DecomposeMain) */
 bddPool *temp_decomp_or_dominator, /* dm or dp (not used anywhere) */
 int dord, /* decompordom = 1 for dp, = 0 for dm (not used) */
 int which, /* = 1 passed to DecomposeMain for performancedecomp */
 int *real2dumbo) /* passed to DecomposeMain for performancedecomp */ {
  int iterno = 0, result, operator, *support1, level1;
  bddPool *decomposed = NULL, *dominator = NULL, *control = NULL;
  DdNode *decompBdd;
  FactorTreeNode *decomposedFTNode, *dominatorFTNode, *controlFTNode, *currentFTNode, *FTNodeInCache, *terminalFTNode;
  bddPool *toBeDecomposed, *topElementQ, *tmpElementQ;
  bddPool *next_tobedecomp;
  SQueue *decompositionQ; /* Queue used for subsequent decompositions */
  st_table *sopFTNodeTbl; /* bddPool* vs FTNode* association */
  st_table *recognize_node; /* not used */
  int p; /* If decompBdd is complementary or not after reordering */

  /* Initialize a Queue for bddPool* */
  decompositionQ = ALLOC(SQueue, 1);
  BDS_Q_Init(decompositionQ);
  /* Enqueue the top BDD */
  BDS_EQ(decompositionQ, topSop);

  /* recognize_node is not used */
  recognize_node = st_init_table(st_ptrcmp, st_ptrhash);

  iterno = 0;

  /* If there is a BDD to be decomposed in the Queue */
  if (decompositionQ != NULL)
    /* Initialize a hash table to store bddPool* vs FTNode* association */
    sopFTNodeTbl = st_init_table(st_ptrcmp, st_ptrhash);

  /* Add the top BDD to sopFTNodeTbl table */
  if (st_add_direct(sopFTNodeTbl, (char *) topSop, (char *) (*FTNode)) == ST_OUT_OF_MEM) {
    printf("Out of memory !");
    exit(2);
  }

  /* While there are more nodes to be decomposed in the Queue,
   ** do decomposition of the next node in the Queue.
   */
  while ((toBeDecomposed = BDS_DQ(decompositionQ)) != NULL) {

    ///printf("1: Q Tail: %i ",decompositionQ->tail);
    ///printf(" Q Head: %i\n",decompositionQ->head);

    /* Build the BDD from SOP form */
    decompBdd = BDS_BuildDDFromBddPool(bddmgr, toBeDecomposed, 1);
    if (decompBdd == NULL) {
      return (0);
    }

    if (Cudd_IsConstant(decompBdd)) {
      fail("Cannot decompose a constant node !!\n");
    }

    /* Obtain the currentFTNode from association tbl before it is freed */
    if (!st_delete(sopFTNodeTbl, (char **) &toBeDecomposed, (char **) &currentFTNode)) {
      return (0);
    }

    /* Free the elementQ immediately. */
    BDS_FreeBddPool(bddmgr, toBeDecomposed);

    /* When the BDD has one variable, reach a terminal node, create FTree
     ** association and go to next Queue.
     */
    result = BDS_CheckTerminal(bddmgr, decompBdd, currentFTNode);
    if (result != 0) continue;

    /* Get the supports (level information for variables) for the BDD */
    support1 = BDS_SupportArray(bddmgr, decompBdd, &level1);
    if (support1 == NULL) return (0);

    which = 1;

    /* Do decomposition on the BDD. Two decomposed BDDs:
     ** 'dominator' and 'decomposed' are obtained after decomposition
     */
    result = BDS_BddDecomposeMain(bddmgr, decompBdd, option, &decomposed, &dominator, &control, &operator, &p, NULL, NULL, NULL, which, real2dumbo);
    if (result == 0) {
      return 0;
    }

    /* Enqueue decomposed and dominator SOPs and build the Factor Trees */

    decomposedFTNode = ALLOC(FactorTreeNode, 1);
    currentFTNode->siblings[0] = decomposedFTNode;
    BDS_EQ(decompositionQ, decomposed);
    if (st_add_direct(sopFTNodeTbl, (char *) decomposed, (char *) decomposedFTNode) == ST_OUT_OF_MEM) {
      return (0);
    }

    dominatorFTNode = ALLOC(FactorTreeNode, 1);
    currentFTNode->siblings[1] = dominatorFTNode;
    BDS_EQ(decompositionQ, dominator);
    if (st_add_direct(sopFTNodeTbl, (char *) dominator, (char *) dominatorFTNode) == ST_OUT_OF_MEM) {
      return (0);
    }

#ifdef PTL
    /* MUX-related operation */
    if (operator == BDS_BDD_MUX && control != NULL) {
      controlFTNode = ALLOC(FactorTreeNode, 1);
      currentFTNode->siblings[2] = controlFTNode;
      BDS_EQ(decompositionQ, control);
      if (st_add_direct(sopFTNodeTbl, (char *) control, (char *) controlFTNode) == ST_OUT_OF_MEM) {
        return (0);
      }
    }
#endif

    /*Update this FTNode */
    BDS_WriteFnode(currentFTNode, p, operator, BDS_FTREE_INTERNAL);

    ///printf("2: Q Tail: %i ",decompositionQ->tail);
    ///printf(" Q Head: %i\n\n\n",decompositionQ->head);

  } /* end of while loop */

  BDS_Q_Quit(decompositionQ);
  st_free_table(recognize_node);
  st_free_table(sopFTNodeTbl);

  return (1);

} /* end of BDS_DDDecomposeAll*/

/**Function********************************************************************

  Synopsis    [Main Bdd decomposition program for BDS]

  Description [Decompostion is first tried with heuristic variable partitioning
               approach by swapping variables by calling BDS_HeuristicDecomp().
               If it is not successful, the simple dominator approach is tried
               next to perform Algebraic AND (1-Dominator), Algebraic OR
               (0-Dominator), or Algebraic XNOR (x-dominator) decomposition by
               calling BDS_SimpleDominator(). If it is also not successful, the
               variables in the BDD are reordered before trying the simple
               dominator approach the second time. If it is still not
               successful, it performs branch decomposition based on branches
               found on the BDD (MUX decomposition) by calling BDS_BHardCore().
               If no branch is found, it will check for balance in the BDD. If
               the BDD is unbalanced, it will try to decompose with respect
               to the top variable by calling BDS_CofactorOnTop(). If it is
               balanced, it will finally try the general Boolean decomposition
               approach based on generalized dominators by calling
               BDS_FindBestDecomp(). If it still has no luck, it will
               continue to try generalized x-dominators by calling
               BDS_XHardCore() if -xhardcore option is specified. Finally, if no
               efficient decomposition can be detected, it will take cofactor
               with respect to the top variable.

               result = 1, success; 0 otherwise]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
int
BDS_BddDecomposeMain(
 DdManager *bddmgr,
 DdNode *bdd, /* BDD to be decomposed */
 bdsOptions *option,
 bddPool **decomposed, /* 'decomposed' BDD to be recorded */
 bddPool **dominator, /* 'dominator' BDD to be recorded */
 bddPool **control, /* 'control' for PTL */
 int *operator, /* operator to be recorded */
 int *polarity, /* polarity to be recorded */
 int *permutation, /* used for first time from BDS_DDDecompose() for performancedecomp */
 int *original, /* used for first time from BDS_DDDecompose() for performancedecomp */
 int *no_nodes, /* used for first time from BDS_DDDecompose() for performancedecomp */
 int which, /* = 0 from BDS_DDDecompose to execute performancedecomp blocks, = 1 from DecomposeAll */
 int *real2dumbo) /* for performancedecomp (not changed in DecomposeAll) */ {
  int i, decompType, result, level, number_decomps = 0, simp_dom = 0;
  int decompLevel, delevel, dolevel;
  int *support = NULL;
  int *support_decomp = NULL, *support_dominate = NULL;
  int bddSize, numVar;
  int kdecomp = 0;
  edgeMark **edgeProperty = NULL;
  DdNode *add = NULL;
  DdNode *N = NULL; /* Regular version of bdd */
  int nodes_orig, nodes_delay;

  /* for performancedecomp of delay re-synthesis phase */
  if ((option->performancedecomp == TRUE) && (which == 0)) { /* which=0 when called from BDS_DDDecompose */
    nodes_orig = no_nodes[0];
    nodes_delay = no_nodes[1];
  }

  /* option->kdecomp is not used anymore */
  if (option->kdecomp == TRUE)
    kdecomp = 1;
  else
    kdecomp = 0;

  /* Always pass the regular version of bdd for decomposition */
  N = Cudd_Regular(bdd);

  /* Avoid huge bdd */

  /* Get # nodes in a DD. Returns # nodes in the graph rooted at node. */
  bddSize = Cudd_DagSize(N);

  /* Get # variables on which a DD depends */
  numVar = Cudd_SupportSize(bddmgr, N);

  /* If BDD is too large, perform reording before doing decomposition */
  if (bddSize > numVar * 50) {
   // printf("BDD too large, reodering\n");
    option->reordering = CUDD_REORDER_SIFT;
    BDS_Reorder(bddmgr, NULL, option);
  }

  /* for performancedecomp of delay re-synthesis phase */
  if ((option->performancedecomp == TRUE) && (which == 0)) { /* which=0 when called from BDS_DDDecompose */
    N = Cudd_Regular(bdd);
    result = BDS_Heuristic_Simple(bddmgr, bdd, permutation, original, option, real2dumbo);
    if (result == 0) {
      result = Cudd_ShuffleHeap(bddmgr, original);
    }
  }

  /* Always pass the regular version of bdd for decomposition */
  N = Cudd_Regular(bdd);

  /* Transform incoming BDD into 0-1 ADD */
  add = Cudd_BddToAdd(bddmgr, N);
  Cudd_Ref(add);

  /* Record polarity after reordering */
  *polarity = Cudd_IsComplement(bdd) ? 0 : 1;

  /* Get the supports (level information for variables) of the BDD */
  support = BDS_SupportArray(bddmgr, N, &level); /* get level here */
  if (support == NULL) return (0);

  /* Go through the BDD and record edges properties for all levels
   ** Mark edges at each level with required information to prepare for
   ** decomposition. For each level, record decomposition types, number
   ** of Sigma_0, number of Sigma_1, and number of incident edges.
   */
  edgeProperty = BDS_MarkEdges(bddmgr, add, support, level, kdecomp, option);
  if (edgeProperty == NULL) return (0);

  result = 1;

  /* Perform heuristic variable partitioning decomposition for BDDs with 6
   ** or more levels
   */

  if ((option->heuristic == TRUE) && (level >3)) {

    /* Heuristic variable partitioning decomposition by swapping variables
     ** between free set and bount set.
     */

    result = BDS_HeuristicDecomp(bddmgr, N, add, support, option, decomposed, dominator, operator, level);

    if (result == 1) { /* successful */
      BDS_FreeEdgeProperty(support, edgeProperty, level);
      return (1);
    } else { /* unsuccessful, continue with other types of decomposition */
      BDS_FreeEdgeProperty(support, edgeProperty, level);
      Cudd_RecursiveDeref(bddmgr, add);
      /* Always pass the regular version of bdd for decomposition */
      N = Cudd_Regular(bdd);
      /* Transform incoming BDD into 0-1 ADD */
      add = Cudd_BddToAdd(bddmgr, N);
      Cudd_Ref(add);
      /* Record polarity after reordering */
      *polarity = Cudd_IsComplement(bdd) ? 0 : 1;
      /* Get the supports of the BDD */
      support = BDS_SupportArray(bddmgr, N, &level);
      if (support == NULL) return (0);
      /* Go through the BDD and mark all levels to record edges properties */
      edgeProperty = BDS_MarkEdges(bddmgr, add, support, level, kdecomp, option);
      if (edgeProperty == NULL) return (0);
    }
  }

  /* Perform Algebraic AND (1-Dominator), Algebraic OR (0-Dominator), or
   ** Algebraic XNOR (x-Dominator) decomposition on the BDD
   */

  result = BDS_SimpleDominator(bddmgr, N, add, support, level, &decompLevel, edgeProperty, decomposed, dominator, operator, option, kdecomp);
  if (result == 1) {
    BDS_FreeEdgeProperty(support, edgeProperty, level);
     printf("first simple dominator worked!\n");
    return (1);
  }
   printf("first simple dominator didnt work!\n");

  Cudd_RecursiveDeref(bddmgr, add);

  /* Until here, no simple decomposition is found on the BDD, reorder the
   ** BDD before doing Algebraic decomposition on the BDD again.
   */

  /* Get # nodes in a DD. Returns # nodes in the graph rooted at node. */
  bddSize = Cudd_DagSize(N);

  /* Get # variables on which a DD depends */
  numVar = Cudd_SupportSize(bddmgr, N);

  /* Do reordering before doing decomposition on the BDD the second time */
  if (option->performancedecomp == FALSE) {
    if ((option->effort > 3) && (bddSize * numVar < option->limitSize)) {
      option->reordering = CUDD_REORDER_EXACT;
    } else { /* Use sifting in reordering normally */
      option->reordering = CUDD_REORDER_SIFT;
    }
    BDS_Reorder(bddmgr, NULL, option);
  }

  /* Record polarity after reordering */
  *polarity = Cudd_IsComplement(bdd) ? 0 : 1;

  /* Transform incoming BDD into 0-1 ADD */
  add = Cudd_BddToAdd(bddmgr, N);
  Cudd_Ref(add);

  /* Get the supports (level information for variables) of the BDD */
  support = BDS_SupportArray(bddmgr, N, &level);
  if (support == NULL) return (0);

  /* Go through the BDD and record edges properties for all levels */
  edgeProperty = BDS_MarkEdges(bddmgr, add, support, level, kdecomp, option);
  if (edgeProperty == NULL) return (0);

  /* Perform Algebraic AND (1-Dominator), Algebraic OR (0-Dominator), or
   ** Algebraic XNOR (x-Dominator) decomposition on the BDD the second time
   ** after reordering.
   */

  if ((option->performancedecomp == FALSE)) {
    result = BDS_SimpleDominator(bddmgr, N, add, support, level, &decompLevel, edgeProperty, decomposed, dominator, operator, option, kdecomp);
    if (result == 1) {
      /// printf("SECOND simple dominator worked!\n");
      BDS_FreeEdgeProperty(support, edgeProperty, level);
      return (1);
    }
  }
  /// printf("Second simple dominator ALSO didn't work!\n");

  /* Search for branch decomposition (MUX). Perform branch decomposition
   ** based on branches found on the BDD.
   */

  result = BDS_BHardCore(bddmgr, N, add, option, decomposed, dominator, control, operator, support, level, edgeProperty);
  if (result == 1) {
     printf("First Hardcore worked! %d\n",*operator);
    BDS_FreeEdgeProperty(support, edgeProperty, level);
    return (1);
  }
  /// printf("First Hardcore didn't work!\n");

  /* If the BDD is unbalanced, decompose it using topVar */

  result = BDS_TestBalance(bddmgr, N);
  if (result == 1) { /* Decompose with respect to topVar */
    Cudd_RecursiveDeref(bddmgr, add);
    result = BDS_CofactorOnTop(bddmgr, bdd, option, decomposed, dominator, control, operator, polarity);
    BDS_FreeEdgeProperty(support, edgeProperty, level);
    return (result);
  }
   printf("Balancing didn't work!\n");

  /* Perform Boolean decomposition based on Generalized Dominators
   ** by finding the best cost among levels
   */

  result = BDS_FindBestDecomp(bddmgr, N, add, support, option, decomposed, dominator, operator, level, edgeProperty); /* N = Cudd_Regular(bdd), add = 0-1 ADD, */
  BDS_FreeEdgeProperty(support, edgeProperty, level);
  if (result == 0) return (0);

  /* If Boolean decomposition is not successful, take cofactor with
   ** respect to topVar.
   */

  if (result == BDS_BDD_NO_DECOMP || result == BDS_BDD_NO_MINIMI || result == BDS_DECOMP_DISQUALIFY) {
    support = BDS_SupportArray(bddmgr, N, &level);
    if (support == NULL) return (0);
    edgeProperty = BDS_MarkEdges(bddmgr, N, support, level, kdecomp, option);
    if (edgeProperty == NULL) return (0);

    /* If -xhardcore option is specified, perform Boolean decomposition
     ** based on generalized x-dominator for Boolean XNOR decomposition
     */
    if (option->xhardcore == TRUE) {
      result = BDS_XHardCore(bddmgr, N, option, decomposed, dominator, operator, support, level, edgeProperty);
      if (result == 1) {
        BDS_FreeEdgeProperty(support, edgeProperty, level);
        return (1);
      }
    }
    BDS_FreeEdgeProperty(support, edgeProperty, level);

    /* No efficient decompositions are detected, take cofactor with respect to topVar */

    result = BDS_CofactorOnTop(bddmgr, bdd, option, decomposed, dominator, control, operator, polarity);
    if (result == 0) return (0);
  }
  return (1);

} /* end of BDS_BddDecomposeMain */

/**Function********************************************************************

  Synopsis    [Find the best decomposition of a BDD using generalized
               dominators (Boolean decomposition)]

  Description [A Boolean BDD decomposition is tried at all possible level.
               Four cases may happen:
               BDS_BDD_DECOMP_NONE : when there is no Sigma_0 or Sigma_1 edge
                                     at a level (No valid decomposition can be
                                     performed on that level);
               BDS_BDD_DECOMP_CONJ : when there is a Sigma_0 edge at a level
                                     (Conjunctive Boolean BDD decomposition can
                                     be performed at that level);
               BDS_BDD_DECOMP_DISJ : when there is a Sigma_1 edge at a level
                                     (Disjunctive Boolean BDD decomposition can
                                     be performed at that level);
               BDS_BDD_DECOMP_BOTH : when there are both Sigma_1 AND Sigma_0
                                     edges at a level (Both Conjunctive and
                                     Disjunctive BDD decomposition can be
                                     performed at that level).

               The function takes BDDs in the form of bddPool*, return
               'decomposed' and 'dominator' BDDs also in the form of bddPool*.
               If the best decomposition cost is larger than a predefined
               theshold, the decomposition is disqualified. Under this case,
               if a good decomposition can not be found on this bdd, the
               corresponding ADD is freed. Only regular version of BDD is
               decomposed. ADD is freed at the end.]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
int
BDS_FindBestDecomp(
 DdManager *bddmgr,
 DdNode *N, /* The regular version of BDD to be decomposed. */
 DdNode *add, /* The ADD of BDD */
 int *support, /* The supports of BDD */
 bdsOptions *option,
 bddPool **decomposed, /* Q or R */
 bddPool **dominator, /* D */
 int *operator,
 int level,
 edgeMark **edgeProperty) {
  int decompType, result, i;
  int numSigmaZero, numSigmaOne;
  decompCost *bestDecompCost;
  int best_level = 0;
  decompCost *temp_cost;
  bddStats *bddMonitor;
  int decompLevel;
  bddPool *decomposedSOP, *dominatorSOP;
  DdNode *decomposedBdd, *dominatorBdd;
  int shuru = 0, anth = 0;
  int RESULT_LEVEL = 0;
  int qualify = 0, qual_level = 0, index = 0;


  /* Prepare to record decomposition information */
  if (option->verb > BDS_VERBOSE_MOST) {
    bddMonitor = ALLOC(bddStats, 1);
    BDS_UpdateBddMonitor(bddmgr, bddMonitor, N, NULL, NULL, NULL, 0, 0, 0);
  }

  /* Initialize the decomposition cost with the default value of 0xFFFF (a
   ** huge number). This cost will be changed when the actual costs are found
   ** in each level.
   */
  temp_cost = BDS_InitBestCost();
  bestDecompCost = BDS_InitBestCost();

  /* Set the initial number of SigmaZero and SigmaOne to zero. */
  numSigmaZero = 0;
  numSigmaOne = 0;

  /* The following code for best_level is not used anymore */
  if (level == 10) {
    best_level = 5;
  }
  if ((level <= 9) && (level >= 2)) {
    if (level % 2 == 0) {
      best_level = level / 2;
    }
    if (level % 2 != 0) {
      best_level = (level + 1) / 2;
    }
  }
  if (level > 10) {
    if (level % 2 == 0) {
      best_level = level / 2;
    }
    if (level % 2 != 0) {
      best_level = (level + 1) / 2;
    }
  }

  /* option->kdecomp is not used anymore */
  if ((option->kdecomp == TRUE) && (level > 6)) {
    shuru = 4;
    anth = 5;
  } else {
    shuru = 0;
    anth = level;
  }

  /* Foreach level find out the decomposition and update the best cost. */

  qualify = 0;
  qual_level = level;

  for (i = shuru; i < anth; i++) {

    /* Try Boolean decomposition at each level in a BDD.
     ** If there is no Sigma_0 or Sigma_1 at a level, we can't do
     ** decompostion at that level. So skip that level.
     */
    if (edgeProperty[i]->decompType == BDS_BDD_DECOMP_NONE) continue;

    /* If there is a Sigma_0 on the level, do conjunctive Boolean BDD
     ** decomposition by calling BDS_PerformDecomp()
     */
    if ((edgeProperty[i]->decompType == BDS_BDD_DECOMP_CONJ) || (edgeProperty[i]->decompType == BDS_BDD_DECOMP_BOTH)) {

      /* See if need to do conjunctive decomposition by checking number of
      Sigma_0. Since the number of Sigma_0 on level(i+1) >= level(i), if
      |Sigma_0| on level(i+1) = |Sigma_0| on level(i), it means the level(i+1)
      has the same set of Sigma_0 with level(i), therefore no need to do
      decomposition on this level.
       */

      /* Do conjunctive decomposition. */
      if (numSigmaZero < edgeProperty[i]->numSigmaZero) {
        numSigmaZero = edgeProperty[i]->numSigmaZero;

        /* Do decomposition and update the cost by putting 'dominator'
         ** and 'decomposed' and the cost in bestDecompCost structure
         */
        result = BDS_PerformDecomp(bddmgr, N, add, edgeProperty[i], &bestDecompCost, option, BDS_BDD_DECOMP_CONJ, i, best_level, &bestDecompCost, &qualify, &qual_level); ///pga added last 4

        if (result == 0) return (0);
      }
    }

    /* If there is a Sigma_1 on the level, do disjunctive Boolean BDD
     ** decomposition by calling BDS_PerformDecomp()
     */
    if ((edgeProperty[i]->decompType == BDS_BDD_DECOMP_DISJ) || (edgeProperty[i]->decompType == BDS_BDD_DECOMP_BOTH)) {

      /* Do disjunctive decomposition */
      if (numSigmaOne < edgeProperty[i]->numSigmaOne) {
        numSigmaOne = edgeProperty[i]->numSigmaOne;

        /* Do decomposition and update the cost by putting 'dominator'
         ** and 'decomposed' and the cost in bestDecompCost structure
         */
        result = BDS_PerformDecomp(bddmgr, N, add, edgeProperty[i], &bestDecompCost, option, BDS_BDD_DECOMP_DISJ, i, best_level, &bestDecompCost, &qualify, &qual_level);

        if (result == 0) return (0);
      }
    }
  }

  /* For invalid decompositions */

  /* Disqualify this decomposition if the cost is too high
   ** (if best cost > Disqualify Threshold of 0.80)
   */
  if (bestDecompCost->cost > BDS_DISQUALIFY_THRESHOLD && bestDecompCost->dominator != NULL) {
    if (option->verb > BDS_VERBOSE_MOST) {
      BDS_UpdateBddMonitor(bddmgr, bddMonitor, NULL, NULL, NULL, NULL, 0, bestDecompCost->cost, 0);
    //  BDS_Stats(BDS_BDD_DECOMP, bddMonitor, 0, NULL, NULL, NULL, NULL);
      FREE(bddMonitor);
    }
    /*printf("Decomposition Disqualified\n");*/
    Cudd_RecursiveDeref(bddmgr, add);
    BDS_FreeBddPool(bddmgr, bestDecompCost->dominator);
    FREE(bestDecompCost);
    FREE(temp_cost);
    return (BDS_DECOMP_DISQUALIFY);
  }

  /* No decomposition can be performed if there is no Sigam_0 or Sigma_1
   ** exist on this BDD (some possiblility at the beginning of the
   ** decomposition of a supernode BDD.)
   */
  if ((numSigmaZero == 0) && (numSigmaOne == 0)) {
    FREE(bestDecompCost);
    FREE(temp_cost);
    Cudd_RecursiveDeref(bddmgr, add);
    return (BDS_BDD_NO_DECOMP);
  }

  /* If Boolean BDD decomposition was successful, construct return
   ** parameters for 'dominator' and 'decomposed' BDDs
   */
  if (bestDecompCost->dominator != NULL) {

    /* 'dominator' BDD to be returned */
    *dominator = bestDecompCost->dominator;
    *operator = bestDecompCost->op;

    /* Build dominator BDD from the dominator BDD Pool */
    dominatorBdd = BDS_BuildDDFromBddPool(bddmgr, *dominator, 0);
    if (dominatorBdd == NULL) return (0);

    /* Do minimization on 'decomposed' BDD */
    decomposedBdd = BDS_BddMinimization(bddmgr, N, dominatorBdd, bestDecompCost->decompType, option);
    if (decomposedBdd == NULL) return (0);

    /* If there is no minimization done on the 'decomposed' BDD, the
     ** same BDD is returned, So the decomposition is not useful at all.
     */
    if (decomposedBdd == N) {

      BDS_FreeBddPool(bddmgr, bestDecompCost->dominator);
      FREE(bestDecompCost);
      FREE(temp_cost);
      Cudd_RecursiveDeref(bddmgr, dominatorBdd);
      Cudd_RecursiveDeref(bddmgr, decomposedBdd);
      Cudd_RecursiveDeref(bddmgr, add);
      return (BDS_BDD_NO_MINIMI);
    }

    /* 'decomposed' BDD to be returned */
    *decomposed = BDS_DumpBddPool(bddmgr, decomposedBdd);
    if (decomposed == NULL) return (0);

    /* Record the decomposition if required */
    if (option->verb > BDS_VERBOSE_MOST) {
      BDS_UpdateBddMonitor(bddmgr, bddMonitor, NULL, decomposedBdd, dominatorBdd, NULL, bestDecompCost->level, bestDecompCost->cost, bestDecompCost->op);
     // BDS_Stats(BDS_G_DOMI, NULL, 0, NULL, NULL, NULL, NULL);
    //  BDS_Stats(BDS_BDD_DECOMP, bddMonitor, 0, NULL, NULL, NULL, NULL);
    } else if (option->verb > BDS_VERBOSE_LESS) {
     // BDS_Stats(BDS_G_DOMI, NULL, 0, NULL, NULL, NULL, NULL);
    }

    Cudd_RecursiveDeref(bddmgr, dominatorBdd);
    Cudd_RecursiveDeref(bddmgr, decomposedBdd);
    Cudd_RecursiveDeref(bddmgr, N);
    Cudd_RecursiveDeref(bddmgr, add);

    FREE(bestDecompCost);
    FREE(temp_cost);
    if (option->verb > BDS_VERBOSE_MOST) FREE(bddMonitor);
   // printf("dec type %d\n", decompType);
    return (1);
  }    /* If Boolean BDD decomposition was not successful, do not construct
     ** return parameters for 'dominator' and 'decomposed' BDDs.
     */
  else {
    Cudd_RecursiveDeref(bddmgr, add);
    FREE(bestDecompCost);
    if (option->verb > BDS_VERBOSE_MOST) FREE(bddMonitor);

    return (BDS_BDD_NO_MINIMI);
  }

} /* end of BDS_FindBestDecomp */

/**Function********************************************************************

  Synopsis    [Check if a BDD is a constant or has single variable]

  Description [If the bdd is a terminal, the corresponding fnode is updated inside
  this function.  Return 1, if the bdd is a termianl; 0 otherwise]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
int
BDS_CheckTerminal(
 DdManager *bddmgr,
 DdNode *tBdd,
 FactorTreeNode *fnode) {

  if (Cudd_SupportSize(bddmgr, tBdd) == 1 || Cudd_IsConstant(tBdd)) {
    /* Build the element in a fnode */
    if (cuddT(Cudd_Regular(tBdd)) == Cudd_ReadOne(bddmgr) &&
     cuddE(Cudd_Regular(tBdd)) == Cudd_ReadLogicZero(bddmgr)) {
      fnode->polarity = 1;
    } else if (cuddT(Cudd_Regular(tBdd)) == Cudd_ReadLogicZero(bddmgr) &&
     cuddE(Cudd_Regular(tBdd)) == Cudd_ReadOne(bddmgr)) {
      fnode->polarity = 0;
    } else if (Cudd_Regular(tBdd) == Cudd_ReadOne(bddmgr)) { /* Constant 1 */
      fnode->value = BDS_FTREE_ONE;
    } else if (Cudd_Regular(tBdd) == Cudd_ReadLogicZero(bddmgr)) { /* Constant 0 */
      fnode->value = BDS_FTREE_ZERO;
    } else {
      fail("Unknown BDD value.");
    }
    if (Cudd_IsComplement(tBdd) && !Cudd_IsConstant(tBdd)) {
      fnode->polarity = 1 - fnode->polarity;
    }

    BDS_WriteFnode(fnode, fnode->polarity, 0, Cudd_NodeReadIndex(tBdd));

    fnode->siblings[0] = NULL;
    fnode->siblings[1] = NULL;
    fnode->siblings[2] = NULL;

    Cudd_RecursiveDeref(bddmgr, tBdd);
    return (1);

  } /* end of when BDD is a constant or single variable */

  return (0);

} /* end of BDS_CheckTerminal */

/**Function********************************************************************

  Synopsis    [Special property check]

  Description [Check if there are any special properties on the BDD. Currently,
  0-dominator, 1-dominator and x-dominator are checked. Once there is a dominator
  existing on this BDD or 0-1 ADD, the decomposition is algebraic, perform the
  decomposition immediately. Return 1 if found a simple dominator; 0 otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_SimpleDominator(
 DdManager *bddmgr,
 DdNode *N, /* always in regular, therefore no xor */
 DdNode *add,
 int *support,
 int level, /* The total level of incoming BDD */
 int *decompLevel, /* The level where decomposition is taken */
 edgeMark **edgeProperty,
 bddPool **decomposed, /* Q or R */
 bddPool **dominator, /* D */
 int *operator,
 bdsOptions *option,
 int kdecomp) {
  DdNode *specialDominator = NULL, *f; /* for special check */
  bddPool *decomposedSOP, *dominatorSOP;
  int i, result, specialOperator;
  bddStats *bddMonitor;
  int *support_decomp, *support_dominate;
  int level_decomp, level_dominate;


  /* Search for 0, 1 and x-dominators
   */
  if (specialDominator = (DdNode *) BDS_SpecialCheck(bddmgr, N, add, support, level,
   decompLevel, edgeProperty, &specialOperator, option)) {
    if (((level > 5) && ((*decompLevel == 4) || (*decompLevel == 5)) && (kdecomp == 1)) || (option->kdecomp == FALSE)) {
      switch (specialOperator) {
        case BDS_BDD_OR:
          f = BDS_ORDecompose(bddmgr, N, specialDominator, option);
          if (f == 0) fail("Serious error in BDS_FindBestDecomp()");
          break;
        case BDS_BDD_AND:
          f = BDS_ANDDecompose(bddmgr, N, specialDominator, option);
          if (f == 0) fail("Serious error in BDS_FindBestDecomp()");
          break;
        case BDS_BDD_XNOR:
          f = BDS_XDecompose(bddmgr, N, specialDominator, &specialOperator, option);
          if (f == 0) fail("Serious error in BDS_FindBestDecomp()");
          break;
        default:
          fail("Unknown decomposition type in BDS_FindBestDecomp()");
      }



      support_decomp = BDS_SupportArray(bddmgr, f, &level_decomp);
      if (support_decomp == NULL) return (0);
      support_dominate = BDS_SupportArray(bddmgr, specialDominator, &level_dominate);
      if (support_dominate == NULL) return (0);
     // printf("deco\n");
      decomposedSOP = BDS_DumpBddPool(bddmgr, f);
    //  for (i = 0; i < bddmgr->size; i++) {
    //    printf("%d  ; ", decomposedSOP->order[i]);
    //  }
      if (decomposedSOP == NULL) fail("Error in BDS_FindBestDecomp()");
      *decomposed = decomposedSOP;
    //  printf("denoo\n");
      dominatorSOP = BDS_DumpBddPool(bddmgr, specialDominator);
    //  for (i = 0; i < bddmgr->size; i++) {
   //     printf("%d  ; ", dominatorSOP->order[i]);
   //   }
    //  printf("\n");
      if (dominatorSOP == NULL) fail("Error in BDS_FindBestDecomp()");
      *dominator = dominatorSOP;

      *operator = specialOperator;


      /*printf("SIMPLE DOMINATE Decomposed Level is %i\t Dominator level is %i\n",level_decomp, level_dominate);*/

      /* Record the decomposition statistical information if required */
      if (option->verb > BDS_VERBOSE_MOST) {
        bddMonitor = ALLOC(bddStats, 1);
        BDS_UpdateBddMonitor(bddmgr, bddMonitor, N, NULL, NULL, NULL, 0, 0, 0);
        BDS_UpdateBddMonitor(bddmgr, bddMonitor, NULL, f, specialDominator, NULL,
         *decompLevel, 0, specialOperator);
       // BDS_Stats(BDS_BDD_DECOMP, bddMonitor, 0, NULL, NULL, NULL, NULL);
        FREE(bddMonitor);
      }


      /* printf("DECOMP LEVEL = %i\n",decompLevel);*/
      Cudd_RecursiveDeref(bddmgr, f);
      Cudd_RecursiveDeref(bddmgr, specialDominator);
      Cudd_RecursiveDeref(bddmgr, N);
      Cudd_RecursiveDeref(bddmgr, add);

      return (1);
    }
  }

  return (0);

} /* end of BDS_SimpleDominator */

/**Function********************************************************************

  Synopsis    [Initialize a cost monitor for generalized dominator-based decomp]

  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
decompCost *
BDS_InitBestCost(
 ) {
  decompCost *cost;

  cost = ALLOC(decompCost, 1);
  cost->dominator = NULL;
  cost->decomposed = NULL;
  cost->cost = BDS_HUGE_NUMBER;
  cost->numQR = 0;
  cost->numD = 0;

  return (cost);

} /* end of BDS_InitBestCost */

/**Function********************************************************************

  Synopsis    [Initialize a cost monitor for X decomp]

  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
XdecompCost *
BDS_InitXdecompCost(
 ) {
  XdecompCost *cost;

  cost = ALLOC(XdecompCost, 1);
  cost->cost = BDS_HUGE_NUMBER;
  cost->f = NULL;
  cost->g = NULL;
  cost->h = NULL;

  return (cost);

} /* end of BDS_InitXdecompCost */

/**Function********************************************************************

  Synopsis    [Perform a decomposition on a level]

  Description [The decomposition result is compared with bestDecompCost. The best
    decomposition's level, bddPool are stored in bestDecompCost.

    result = 1, success; 0 otherwise]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
int
BDS_PerformDecomp(
 DdManager *bddmgr,
 DdNode *bdd, /* BDD to be decomposed. */
 DdNode *add, /* BDD in 0-1 ADD form. */
 edgeMark *edgeTbl, /* edges on this level are stored in this hash table. */
 decompCost **bestDecompCost, /* = BDS_InitBestCost() */
 bdsOptions *option,
 int decompType, /* decompType is AND or OR */
 int level,
 int best_level, /* = level/2 or (level+1)/2 */
 decompCost **temp_cost, /* = **bestDecompCost */
 int *qualify, /* = 0 */
 int *qual_level) /* = level */ {
  bddPool *dominatorSOP;
  DdNode *dominatorBdd, *decomposedBdd;
  int result, i;
  decompCost *thisCost;
  int *support_decomp, *support_dominate;
  int level_decomp, level_dominate;

  /* Create the dominator SOP by dumping BDD Pool at the decomposed level */
  dominatorSOP = BDS_DumpBddPoolAtLevel(bddmgr, add, NULL, edgeTbl, decompType);
  if (dominatorSOP == NULL) return (0);

  /* Build 'dominator' BDD from BDD Pool */
  dominatorBdd = BDS_BuildDDFromBddPool(bddmgr, dominatorSOP, 0);
  if (dominatorBdd == NULL) return (0);

  /* Do BDD minimization to get 'decomposed' BDD. */
  decomposedBdd = BDS_BddMinimization(bddmgr, bdd, dominatorBdd, decompType, option);

  /* If minimization is not successful, return(0) */
  if (decomposedBdd == NULL) {
    Cudd_RecursiveDeref(bddmgr, dominatorBdd);
    BDS_FreeBddPool(bddmgr, dominatorSOP);
    return (0);
  }

  /* If no minimization is done on 'decomposed' BDD, don't update cost.
   ** The decomposition at that level is not useful at all.
   */
  if (decomposedBdd == bdd) {
    /*printf("NO MINIMIZATION DONE!\n");*/
    Cudd_RecursiveDeref(bddmgr, dominatorBdd);
    Cudd_RecursiveDeref(bddmgr, decomposedBdd);
    BDS_FreeBddPool(bddmgr, dominatorSOP);
    return (BDS_BDD_NO_MINIMI); /// = 0xFFF1
  }

  /* Calculate the decomposition cost */

  thisCost = BDS_CalculateDecompCost(bddmgr, bdd, decomposedBdd, dominatorBdd, option);

  /* Update the best decomposition found so far. A balanced decomposition
   ** is prefered to reduce delay.
   */
  if ((thisCost->cost < (*bestDecompCost)->cost) || ((thisCost->cost == (*bestDecompCost)->cost) &&
   (thisCost->numQR * thisCost->numD > (*bestDecompCost)->numQR * (*bestDecompCost)->numD))) {

    /* avoid the 1st iteration error. */
    if ((*bestDecompCost)->dominator != NULL) {
      BDS_FreeBddPool(bddmgr, (*bestDecompCost)->dominator);
    }

    /* Put operator in bestDecompCost based on the decompType at that level. */
    switch (decompType) {
      case BDS_BDD_DECOMP_CONJ:
        (*bestDecompCost)->op = BDS_BDD_AND;
        (*temp_cost)->op = BDS_BDD_AND;
        break;
      case BDS_BDD_DECOMP_DISJ:
        (*bestDecompCost)->op = BDS_BDD_OR;
        (*temp_cost)->op = BDS_BDD_OR;
        break;
      default:
        fail("Unknown decomposition type in BDS_PerformDecomp");
    }

    /* Find supports for 'decomposed' and 'dominator' BDDs */
    support_decomp = BDS_SupportArray(bddmgr, decomposedBdd, &level_decomp);
    if (support_decomp == NULL) return (0);
    support_dominate = BDS_SupportArray(bddmgr, dominatorBdd, &level_dominate);
    if (support_dominate == NULL) return (0);
  //  printf("%");

    /* The following code for temp_cost is not used anymore.
     ** It was used for greedy decomposition before.
     */
    if ((level == best_level) && (dominatorSOP != NULL)) {
      /*printf("Best level has been reached\n");*/
      *qualify = 1;
      *qual_level = level;
      (*temp_cost)->cost = 0.0;
      (*temp_cost)->dominator = dominatorSOP;
      (*temp_cost)->level = level;
      (*temp_cost)->numQR = thisCost->numQR;
      (*temp_cost)->numD = thisCost->numD;
      (*temp_cost)->decompType = decompType;
    }

    /* Update the cost */
    (*bestDecompCost)->cost = thisCost->cost;
    (*bestDecompCost)->dominator = dominatorSOP;
    (*bestDecompCost)->level = level;
    (*bestDecompCost)->numQR = thisCost->numQR;
    (*bestDecompCost)->numD = thisCost->numD;
    (*bestDecompCost)->decompType = decompType;
  }    /* If the new cost is higher than the old best cost, don't update the cost */
  else {
    BDS_FreeBddPool(bddmgr, dominatorSOP);
  }

  Cudd_RecursiveDeref(bddmgr, decomposedBdd);
  Cudd_RecursiveDeref(bddmgr, dominatorBdd);
  FREE(thisCost);

  return (1);

} /* end of BDS_PerformDecomp */

/**Function********************************************************************

  Synopsis    [Calculate the cost of a decomposition]

  Description [Return cost struct]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
decompCost *
BDS_CalculateDecompCost(
 DdManager *bddmgr,
 DdNode *oriBdd,
 DdNode *decBdd,
 DdNode *domBdd,
 bdsOptions *option) {
  DdNode *oriSupp, *decSupp, *domSupp, *commSupp;
  int result, oriSize, decSize, domSize, oriSuppSize, commSuppSize;
  decompCost *thisCost;

  thisCost = ALLOC(decompCost, 1);

  oriSize = Cudd_DagSize(oriBdd);
  decSize = Cudd_DagSize(decBdd);
  domSize = Cudd_DagSize(domBdd);

  result = Cudd_ClassifySupport(bddmgr, decBdd, domBdd, &commSupp, &decSupp, &domSupp);
  if (result == 0) return (NULL);
  Cudd_Ref(commSupp);
  Cudd_Ref(decSupp);
  Cudd_Ref(domSupp);

  commSuppSize = Cudd_SupportSize(bddmgr, commSupp);
  oriSuppSize = Cudd_SupportSize(bddmgr, decSupp) +
   Cudd_SupportSize(bddmgr, domSupp) + commSuppSize;

  Cudd_RecursiveDeref(bddmgr, commSupp);
  Cudd_RecursiveDeref(bddmgr, decSupp);
  Cudd_RecursiveDeref(bddmgr, domSupp);

  /* Cost function for generalized Boolean decomposition (ALPHA = 0.5) */
  thisCost->cost = ALPHA * (decSize + domSize) / oriSize + (1 - ALPHA) * commSuppSize / oriSuppSize;
  thisCost->numQR = decSize;
  thisCost->numD = domSize;

  return (thisCost);

} /* end of BDS_CalculateDecompCost */

/**Function********************************************************************

  Synopsis    [Calculate the cost of a X decomposition]

  Description [Return cost]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
float
BDS_CalXdecompCost(
 DdManager *bddmgr,
 DdNode *bdd, /* Original bdd */
 int base, /* Negative edges on bdd */
 DdNode *f,
 int nef, /* ne on f */
 DdNode *g,
 int neg, /* ne on g */
 DdNode *h,
 int decompType) {
  DdNode *fSupp, *gSupp, *hSupp, *commSupp, *fgCommSupp, *fhCommSupp;
  int result;
  int oriSize, oriSuppSize, fSize, gSize, hSize, fSuppSize, gSuppSize, hSuppSize, commSuppSize;
  int fgCommSuppSize, fhCommSuppSize;
  float cost;

  fSize = (float) Cudd_DagSize(f);

  if (f != NULL) gSize = Cudd_DagSize(g);
  if (h != NULL) hSize = Cudd_DagSize(h);

  oriSize = Cudd_DagSize(bdd);
  oriSuppSize = Cudd_SupportSize(bddmgr, bdd);

  switch (decompType) {
    case BDS_BDD_DECOMP_X:
      result = Cudd_ClassifySupport(bddmgr, f, g, &commSupp, &fSupp, &gSupp);
      if (result == 0) exit(2);

      Cudd_Ref(commSupp);
      Cudd_Ref(fSupp);
      Cudd_Ref(gSupp);
      commSuppSize = Cudd_SupportSize(bddmgr, commSupp);

      Cudd_RecursiveDeref(bddmgr, commSupp);
      Cudd_RecursiveDeref(bddmgr, fSupp);
      Cudd_RecursiveDeref(bddmgr, gSupp);

      cost = BETA * (fSize + gSize) / oriSize
       + (1.0 - BETA) * commSuppSize / oriSuppSize
       + (float) (nef + neg) / base;
      break;

    case BDS_BDD_DECOMP_B:
      result = Cudd_ClassifySupport(bddmgr, f, g, &fgCommSupp, &fSupp, &gSupp);
      if (result == 0) exit(2);

      Cudd_Ref(fgCommSupp);
      Cudd_Ref(fSupp);
      Cudd_Ref(gSupp);
      fgCommSuppSize = Cudd_SupportSize(bddmgr, fgCommSupp);

      Cudd_RecursiveDeref(bddmgr, fgCommSupp);
      Cudd_RecursiveDeref(bddmgr, fSupp);
      Cudd_RecursiveDeref(bddmgr, gSupp);

      result = Cudd_ClassifySupport(bddmgr, f, h, &fhCommSupp, &fSupp, &hSupp);
      if (result == 0) exit(2);

      Cudd_Ref(fhCommSupp);
      Cudd_Ref(fSupp);
      Cudd_Ref(hSupp);
      fhCommSuppSize = Cudd_SupportSize(bddmgr, fhCommSupp);

      Cudd_RecursiveDeref(bddmgr, fhCommSupp);
      Cudd_RecursiveDeref(bddmgr, fSupp);
      Cudd_RecursiveDeref(bddmgr, hSupp);

      cost = BETA * (fSize + gSize + hSize) / oriSize
       + (1.0 - BETA) * (fgCommSuppSize + fhCommSuppSize) / oriSuppSize;
      break;

    default:
      printf("Unknown decomposition type !\n");
      exit(2);
  }

  return (cost);

} /* end of BDS_CalXdecompCost */

/**Function********************************************************************

  Synopsis    [Check if there are any special properties on the BDD. Currently,
    0-dominator, 1-dominator and x-dominator are checked.]

  Description [Dominator closest to median is returned]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
DdNode *
BDS_SpecialCheck(
 DdManager *bddmgr,
 DdNode *bdd, /* always in regular, therefore no xor */
 DdNode *add,
 int *support,
 int level, /* The total level of incoming BDD */
 int *decompLevel, /* The level where decomposition is taken */
 edgeMark **edgeProperty,
 int *operator,
 bdsOptions *option) {
  DdNode *dominator;
  int kdecomp = 0;

  kdecomp = 0;
  if (option->kdecomp == TRUE)
    kdecomp = 1;


  /* 0-dominator */
  if (dominator = (DdNode *) BDS_SearchZeroD(bddmgr, support, level, decompLevel, edgeProperty)) {
    *operator = BDS_BDD_OR;
    if (option->verb > BDS_VERBOSE_LESS) {
    //  BDS_Stats(BDS_ZERO_DOMI, NULL, 0, NULL, NULL, NULL, NULL);
    }
    return (dominator);
  }
  /* 1-dominator */
  if (dominator = (DdNode *) BDS_SearchOneD(bddmgr, support, level, decompLevel, edgeProperty)) {
    *operator = BDS_BDD_AND;
    if (option->verb > BDS_VERBOSE_LESS) {
   //   BDS_Stats(BDS_ONE_DOMI, NULL, 0, NULL, NULL, NULL, NULL);
    }
    return (dominator);
  }
  /* x-dominator */
  if (dominator = (DdNode *) BDS_SearchXD(bddmgr, bdd, decompLevel, kdecomp, option)) {
    *operator = BDS_BDD_XNOR;
    if (option->verb > BDS_VERBOSE_LESS) {
     // BDS_Stats(BDS_X_DOMI, NULL, 0, NULL, NULL, NULL, NULL);
    }
    return (dominator);
  }
  return (NULL);

} /* end of BDS_SpecialCheck */

/**Function********************************************************************

  Synopsis    [Detect if there is a 0-dominator]

  Description [0-dominator closest to median is returned]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
DdNode *
BDS_SearchZeroD(
 DdManager *bddmgr,
 int *support,
 int level,
 int *decompLevel,
 edgeMark **edgeProperty) {
  int i, median, position, distance, best = 0xFFFF, index = 0;
  DdNode *dominator = NULL, *addNode;

  if (edgeProperty == NULL) return (NULL);

  median = level / 2;

  for (i = 0; i < level; i++) {
    if ((edgeProperty[i]->decompType == BDS_BDD_DECOMP_DISJ) &&
     (st_count(edgeProperty[i]->table) == 1)) {

      /* A 0-dominator is found */
      if (edgeProperty[i]->bottom == NULL) {
        return (NULL);
      }
      distance = abs(i - median);
      if (distance < best) {
        position = i;
        best = distance;
        if (best == 0) break;
      } else { /* Stop searching */
        break;
      }
    }
  }

  if (best != 0xFFFF) { /* Found a 0-dominator */
    /*printf("Position = %i\n",position);
      printf("Level = %i\n",level);*/
    addNode = edgeProperty[position]->bottom;
    dominator = Cudd_addBddPattern(bddmgr, addNode);
    Cudd_Ref(dominator);
    *decompLevel = position;
    index = edgeProperty[position]->k_feasible;
  }
  if (index == 1) {
    /*printf("YES 0\n");*/
    return (dominator);
  }
  if (index == 0) {
    /* printf("NO 0\n");*/
    dominator = NULL;
    return (dominator);
  }

} /* end of BDS_SearchZeroD */

/**Function********************************************************************

  Synopsis    [Detect if there is a 1-dominator]

  Description [1-dominator closest to median is returned]

  SideEffects []

  SeeAlso     []

  LastDate    [2/23/99]

 *****************************************************************************/
static
DdNode *
BDS_SearchOneD(
 DdManager *bddmgr,
 int *support,
 int level,
 int *decompLevel,
 edgeMark **edgeProperty) {
  int i, median, position, distance, best = 0xFFFF, index = 0;
  DdNode *dominator = NULL, *addNode;

  if (edgeProperty == NULL) return (NULL);

  median = level / 2;

  for (i = 0; i < level; i++) {
    if ((edgeProperty[i]->decompType == BDS_BDD_DECOMP_CONJ) &&
     (st_count(edgeProperty[i]->table) == 1)) {

      /* A 1-dominator is found */
      if (edgeProperty[i]->bottom == NULL) {
        return (NULL);
      }
      distance = abs(i - median);
      if (distance < best) {
        position = i;
        best = distance;
        if (best == 0) break;
      } else { /* Stop searching */
        break;
      }
    }
  }

  if (best != 0xFFFF) { /* Found a 0-dominator */
    /* printf("Position = %i\n",position);
       printf("Level = %i\n",level);*/
    addNode = edgeProperty[position]->bottom;
    dominator = Cudd_addBddPattern(bddmgr, addNode);
    Cudd_Ref(dominator);
    *decompLevel = position;
    index = edgeProperty[position]->k_feasible;
  }
  if (index == 1) {
    return (dominator);
  }
  if (index == 0) {
    dominator = NULL;
    return (dominator);
  }

} /* end of BDS_SearchOneD */

/**Function********************************************************************

  Synopsis    [Detect if there are any x-dominator on this BDD]

  Description []

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
DdNode *
BDS_SearchXD(
 DdManager *bddmgr,
 DdNode *bdd,
 int *decompLevel,
 int kdecomp,
 bdsOptions *option) {
  int *support, level, i, result, naya_level = 0;
  int median, position, distance, best = 0xFFFF;
  int index = 0;
  edgeMark **edgeProperty = NULL;
  DdNode *xDominator = NULL;


  if (option->heuristic == 1)
    level = level + 1;
  else level = level;

  support = BDS_SupportArray(bddmgr, bdd, &level);
  if (support == NULL) {
    return (0);
  }

  /* Init. a hash table for each level */
  edgeProperty = BDS_MarkEdges(bddmgr, bdd, support, level, kdecomp, option);
  if (edgeProperty == NULL) return (0);

  median = level / 2;

  for (i = 0; i < level; i++) {
    if ((edgeProperty[i]->decompType == BDS_BDD_DECOMP_NONE) && (st_count(edgeProperty[i]->table) == 1)) {

      /* A x-dominator is found */
      if (edgeProperty[i]->bottom == NULL) {
        return (NULL);
      }
      distance = abs(i - median);
      if (distance < best) {
        position = i;
        best = distance;
        if (best == 0) break;
      } else { /* Stop searching */
        break;
      }
    }
  }

  if (best != 0xFFFF) {
    /*printf("Position = %i\n",position);
    printf("Level = %i\n",level);*/
    xDominator = edgeProperty[position]->bottom;
    Cudd_Ref(xDominator);
    *decompLevel = position;
    index = edgeProperty[position]->k_feasible;
  }


  for (i = 0; i < level; i++) {
    st_free_table(edgeProperty[i]->table);
    FREE(edgeProperty[i]);
  }
  FREE(edgeProperty);
  FREE(support);

  if (index == 1) {
    return (xDominator);
  }
  if (index == 0) {
    xDominator = NULL;
    return (xDominator);
  }

} /* end of BDS_SearchXD */

/**Function********************************************************************

  Synopsis    [Reorder the BDD to find out x-dominator]

  Description [Return 1 if found a x-dominator, return 0 otherwise. The incoming
    bdd is freed if found a x-dominator]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_OneMoreTry(
 DdManager *bddmgr,
 DdNode *bdd,
 bdsOptions *option,
 bddPool **decomposed,
 bddPool **dominator,
 int *operator,
 int *polarity) {
  int bddSize, numVar, result, decompLevel;
  DdNode *xDominator, *f, *N;
  int kdecomp = 0;

  if (option->kdecomp)
    kdecomp = 1;
  else
    kdecomp = 0;

  N = Cudd_Regular(bdd);

  /* Since there are hard cores in this BDD, whenever the size is less than
     the predefined value, apply exact.
   */
  bddSize = Cudd_DagSize(bdd);
  numVar = Cudd_SupportSize(bddmgr, bdd);
  if (bddSize * numVar < option->limitSize) {
    option->reordering = CUDD_REORDER_EXACT;
    BDS_Reorder(bddmgr, NULL, option);

    *polarity = Cudd_IsComplement(bdd) ? 0 : 1;
    N = Cudd_Regular(bdd);

    if (xDominator = (DdNode *) BDS_SearchXD(bddmgr, N, &decompLevel, kdecomp, option)) {
      f = BDS_XDecompose(bddmgr, N, xDominator, operator, option);
      if (f == NULL) {
        Cudd_RecursiveDeref(bddmgr, xDominator);
        return (0);
      }

      /* Build return values, operator is updated inside BDS_XDecompose() */
      *decomposed = BDS_DumpBddPool(bddmgr, xDominator);
      *dominator = BDS_DumpBddPool(bddmgr, f);

      Cudd_RecursiveDeref(bddmgr, xDominator);
      Cudd_RecursiveDeref(bddmgr, f);
      Cudd_RecursiveDeref(bddmgr, bdd);

      return (1);
    } else {
      return (0);
    }
  }
  return (0);

} /* end of BDS_OneMoreTry */

/**Function********************************************************************

  Synopsis    [Perform OR decomposition on a BDD.]

  Description [Since F = f + g, g is given, then f = F/g']

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
DdNode *
BDS_ORDecompose(
 DdManager *bddmgr,
 DdNode *bdd,
 DdNode *cBdd,
 bdsOptions *option) {
  DdNode *retBdd;

  retBdd = BDS_BddMinimization(bddmgr, bdd, cBdd, BDS_BDD_DECOMP_DISJ, option);
  if (retBdd == NULL) return (NULL);

  return (retBdd);

} /* end of BDS_ORDecompose */

/**Function********************************************************************

  Synopsis    [Perform AND decomposition on a BDD.]

  Description [Since F = fg, g is given, then f = F/g]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
DdNode *
BDS_ANDDecompose(
 DdManager *bddmgr,
 DdNode *bdd,
 DdNode *cBdd,
 bdsOptions *option) {
  DdNode *retBdd;

  retBdd = BDS_BddMinimization(bddmgr, bdd, cBdd, BDS_BDD_DECOMP_CONJ, option);
  if (retBdd == NULL) return (NULL);

  return (retBdd);

} /* end of BDS_ANDDecompose */

/**Function********************************************************************

  Synopsis    [Perform XOR decomposition on a BDD.]

  Description [F = f xnor d; d is given, then f = (Fd)/d]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
DdNode *
BDS_XDecompose(
 DdManager *bddmgr,
 DdNode *bdd,
 DdNode *xDominator,
 int *operator,
 bdsOptions *option) {
  DdNode *F, *d, *u, *tmp, *retBdd;

  d = xDominator;

  F = Cudd_Regular(bdd);
  if (Cudd_IsComplement(bdd)) {
    *operator = BDS_BDD_XOR;
  } else {
    *operator = BDS_BDD_XNOR;
  }

  tmp = Cudd_bddAnd(bddmgr, F, d);
  if (tmp == NULL) return (NULL);
  Cudd_Ref(tmp);

  retBdd = BDS_BddMinimization(bddmgr, tmp, d, BDS_BDD_DECOMP_CONJ, option);
  if (retBdd == NULL) return (NULL);
  Cudd_RecursiveDeref(bddmgr, tmp);

  return (retBdd);

} /* BDS_XDecompose */

/**Function********************************************************************

  Synopsis    [Perform XOR decomposition]

  Description [Usually this type of BDDs have a lot of negative edges. It's unlikely
  to have non-algebraic decomposition on these BDDs. All algebraic cases have been
  found in simple dominators. Two types action can be taken here, F = f @ g or
  F = f ^ g(based on BDD), and F = fg + f'h(based on ADD). These types of decompositions
  are good candidates for PTL. Return 1, successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_XHardCore(
 DdManager *bddmgr,
 DdNode *bdd, /* The BDD to be decomposed. */
 bdsOptions *option,
 bddPool **f,
 bddPool **g,
 int *operator,
 int *support,
 int level,
 edgeMark **edgeProperty) {
  int result, i, negativeEdge;
  XdecompCost *bestDecomp;
  bddStats *bddMonitor;
  printf("In mux bds\n");
  negativeEdge = BDS_GetNegative(bddmgr, bdd, 0);
  if (negativeEdge == 0) return (0);

  /* Foreach level find out all XOR decomp */
  bestDecomp = BDS_InitXdecompCost();
  for (i = 0; i < level; i++) {
    result = BDS_XDecompOnBdd(bddmgr, bdd, negativeEdge, support, i, edgeProperty[i], bestDecomp, option);
  }
  if (bestDecomp->f != NULL && bestDecomp->g != NULL) {

    *f = BDS_DumpBddPool(bddmgr, bestDecomp->f);
    *g = BDS_DumpBddPool(bddmgr, bestDecomp->g);
    *operator = BDS_BDD_XNOR;

    /* Record the decomposition statistical information if required */
    if (option->verb > BDS_VERBOSE_MOST) {
      bddMonitor = ALLOC(bddStats, 1);
      BDS_UpdateBddMonitor(bddmgr, bddMonitor, bdd, bestDecomp->f, bestDecomp->g, NULL, 0,
       bestDecomp->cost, *operator);
     // BDS_Stats(BDS_XHARDCORE, bddMonitor, 0, NULL, NULL, NULL, NULL);
      FREE(bddMonitor);
    } else if (option->verb > BDS_VERBOSE_LESS) {
     // BDS_Stats(BDS_XHARDCORE, NULL, 0, NULL, NULL, NULL, NULL);
    }

    /* Free related BDDs */
    Cudd_RecursiveDeref(bddmgr, bestDecomp->f);
    Cudd_RecursiveDeref(bddmgr, bestDecomp->g);
    Cudd_RecursiveDeref(bddmgr, bdd);
    FREE(bestDecomp);
    return (1);
  } else {
    FREE(bestDecomp);
    return (0);
  }

} /* end of BDS_XHardCore */

/**Function********************************************************************

  Synopsis    [Perform branch decomposition]

  Description [Usually this type of BDDs are good candidates for F = fg + f'h;
  The decomposition can be more effciently implemented as PTL. Both static CMOS and
  PTL style are supported in this function. In static CMOS case, fg is returned as
  decomposed, f'h is returned as dominators. The coverage between g and h is tested
  to save one more literal. In PTL case, f is returned as control, g is returned
  as decomposed and h is returned as dominator. Return 1, successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_BHardCore(
 DdManager *bddmgr,
 DdNode *bdd, /* The BDD to be decomposed. */
 DdNode *add,
 bdsOptions *option,
 bddPool **decomposed, /* g or fg */
 bddPool **dominator, /* h or f'h */
 bddPool **control, /* f or useless in static CMOS */
 int *operator, /* BDS_BDD_MUX or BDS_BDD_OR */
 int *support,
 int level,
 edgeMark **edgeProperty) {
  int result, i, negativeEdge, lowest = 0;
  DdNode *f, *g, *h;
#ifndef PTL
  DdNode *fg, *fh, *cover;
#endif
  DdNode *gBranch, *hBranch;
  XdecompCost *bestDecomp;
  bddStats *bddMonitor;
printf("In mux\n");
  /* Find the lowest two-branch level. Start from level 1, instead of 0 */
  for (i = 1; i < level; i++) {
    if (st_count(edgeProperty[i]->table) == 2 && edgeProperty[i]->numSigmaOne == 0
     && edgeProperty[i]->numSigmaZero == 0) {
      lowest = i;
    }
  }
  if (lowest == 0) return (0);

  /* Generate f */
  f = BDS_BranchCandidateB(bddmgr, add, edgeProperty[lowest], &gBranch, &hBranch);

  /* Calculate g and h */
  g = Cudd_addBddPattern(bddmgr, gBranch);
  if (g == NULL) return (0);
  Cudd_Ref(g);
  Cudd_RecursiveDeref(bddmgr, gBranch);

  h = Cudd_addBddPattern(bddmgr, hBranch);
  if (h == NULL) return (0);
  Cudd_Ref(h);
  Cudd_RecursiveDeref(bddmgr, hBranch);

#ifdef PTL
  printf("In mux def\n");
  /* Dump f, g and h in bddPool */
  *decomposed = BDS_DumpBddPool(bddmgr, g);
  *dominator = BDS_DumpBddPool(bddmgr, h);
  *control = BDS_DumpBddPool(bddmgr, f);
  *operator = BDS_BDD_MUX;

#else

  /* Find out if g covers h, or reverse */
  cover = Cudd_bddAnd(bddmgr, g, h);
  if (cover == NULL) return (0);
  Cudd_Ref(cover);

  if (cover == g) { /* g < h */
    fg = g;
    Cudd_Ref(fg);
    fh = Cudd_bddAnd(bddmgr, Cudd_Not(f), h);
    if (fh != NULL) Cudd_Ref(fh);
  } else if (cover == h) { /* g > h*/
    fg = Cudd_bddAnd(bddmgr, f, g);
    if (fg != NULL) Cudd_Ref(fg);
    fh = h;
    Cudd_Ref(fh);
  } else { /* g and h don't cover each other */
    fg = Cudd_bddAnd(bddmgr, f, g);
    if (fg != NULL) Cudd_Ref(fg);
    fh = Cudd_bddAnd(bddmgr, Cudd_Not(f), h);
    if (fh != NULL) Cudd_Ref(fh);
  }
  *decomposed = BDS_DumpBddPool(bddmgr, fg);
  *dominator = BDS_DumpBddPool(bddmgr, fh);
  *operator = BDS_BDD_OR;

#endif

  /* Record the decomposition if required */
  if (option->verb > BDS_VERBOSE_MOST) {
    bddMonitor = ALLOC(bddStats, 1);
    BDS_UpdateBddMonitor(bddmgr, bddMonitor, bdd, g, h, f, 0, 0, 0);
  //  BDS_Stats(BDS_BHARDCORE, bddMonitor, 0, NULL, NULL, NULL, NULL);
    FREE(bddMonitor);
  } else if (option->verb > BDS_VERBOSE_LESS) {
   // BDS_Stats(BDS_BHARDCORE, NULL, 0, NULL, NULL, NULL, NULL);
  }

  Cudd_RecursiveDeref(bddmgr, g);
  Cudd_RecursiveDeref(bddmgr, h);
  Cudd_RecursiveDeref(bddmgr, f);

#ifndef PTL
  Cudd_RecursiveDeref(bddmgr, cover);
  Cudd_RecursiveDeref(bddmgr, fg);
  Cudd_RecursiveDeref(bddmgr, fh);
#endif

  Cudd_RecursiveDeref(bddmgr, bdd);
  Cudd_RecursiveDeref(bddmgr, add);

  return (1);

} /* end of BDS_BHardCore */

/**Function********************************************************************

  Synopsis    [Find candidate for 2-branch decomposition on BDD(with ne case)]

  Description [BDD is returned if found; return NULL otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
DdNode *
BDS_BranchCandidateX(
 DdManager *bddmgr,
 DdNode *bdd,
 edgeMark *levelTable) {
  DdNode *xcand;
  bddPool *pool;

  /* A possible branch-candidate is found */
  pool = BDS_DumpBddPoolAtLevel(bddmgr, bdd, NULL, levelTable, BDS_BDD_DECOMP_X);
  xcand = BDS_BuildDDFromBddPool(bddmgr, pool, 0);
  BDS_FreeBddPool(bddmgr, pool);

  if (Cudd_IsConstant(xcand))
    return (NULL);
  else
    return (xcand);

} /* end of BDS_BranchCandidateX */

/**Function********************************************************************

  Synopsis    [Find candidate for 2-branch decomposition on BDD(without ne case)]

  Description [BDD is returned if found; return NULL otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
DdNode *
BDS_BranchCandidateB(
 DdManager *bddmgr,
 DdNode *add,
 edgeMark *levelTable,
 DdNode **gBranch,
 DdNode **hBranch) {
  DdNode *bcand, *oneNode, *f;
  bddPool *pool;
  st_table *oneMark;
  int result;
  st_generator *gen;

  oneMark = st_init_table(st_ptrcmp, st_ptrhash);

  oneNode = BDS_FindOneMark(bddmgr, add, levelTable);
  if (st_add_direct(oneMark, (char *) oneNode, NULL) == ST_OUT_OF_MEM) {
    printf("Out of memory !");
    exit(2);
  }

  gen = st_init_gen(levelTable->table);
  while (st_gen(gen, (char **) &f, NULL)) {
    if (f != oneNode) {
      Cudd_Ref(f);
      *hBranch = f;
      break;
    }
  }
  Cudd_Ref(oneNode);
  *gBranch = oneNode;
  st_free_gen(gen);

  pool = BDS_DumpBddPoolAtLevel(bddmgr, add, oneMark, levelTable, BDS_BDD_DECOMP_B);
  bcand = BDS_BuildDDFromBddPool(bddmgr, pool, 0);

  BDS_FreeBddPool(bddmgr, pool);
  st_free_table(oneMark);

  if (Cudd_IsConstant(bcand))
    return (NULL);
  else
    return (bcand);

} /* end of BDS_BranchCandidateB */

/**Function********************************************************************

  Synopsis    [Perform Branch decomposition on BDD. The decomposer f is obtained top down.]

  Description [F = fg + f'h is seeking; Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_BranchDecompTopDown(
 DdManager *bddmgr,
 DdNode *bdd,
 edgeMark *levelTable) {
  DdNode *f, *g, *h;
  DdNode *cover;

  f = BDS_BranchCandidateX(bddmgr, bdd, levelTable);
  if (f == NULL) return (0);

  g = Cudd_bddConstrain(bddmgr, bdd, f);
  if (g != NULL) Cudd_Ref(g);

  h = Cudd_bddConstrain(bddmgr, bdd, Cudd_Not(f));
  if (h != NULL) Cudd_Ref(h);

  cover = Cudd_bddAnd(bddmgr, g, h);
  if (cover != NULL) Cudd_Ref(cover);

  Cudd_RecursiveDeref(bddmgr, g);
  Cudd_RecursiveDeref(bddmgr, h);
  Cudd_RecursiveDeref(bddmgr, f);
  Cudd_RecursiveDeref(bddmgr, cover);

  return (0);

} /* end of BDS_BranchDecompTopDown */

/**Function********************************************************************

  Synopsis    [Perform Branch decomposition on BDD. The decomposer f is obtained bottom up.]

  Description [F = fg + f'h is seeking; Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_BranchDecompBottomUp(
 DdManager *bddmgr,
 DdNode *bdd,
 int *support,
 int level,
 edgeMark *levelTable,
 XdecompCost *bestDecomp,
 bdsOptions *option) {
  DdNode *f, *g, *h;
  DdNode *cover;
  float cost;
  st_generator *gen;
  int result, base, nef, neg, retVal = 0;

  gen = st_init_gen(levelTable->table);
  while (st_gen(gen, (char **) &f, NULL)) {

#ifdef DEBUG
    cuddCheck(bddmgr, "BDS_BranchDecompBottomUp", 1);
#endif

    if (Cudd_Regular(f)->ref == 1) continue;
    if (support[Cudd_Regular(f)->index] != level + 1) continue;
    Cudd_Ref(f);

    g = Cudd_bddConstrain(bddmgr, bdd, f);
    if (g != NULL) Cudd_Ref(g);

    h = Cudd_bddConstrain(bddmgr, bdd, Cudd_Not(f));
    if (h != NULL) Cudd_Ref(h);

    cost = BDS_CalXdecompCost(bddmgr, bdd, 0, f, 0, g, 0, h, BDS_BDD_DECOMP_B);

#ifdef DEBUG
    cuddCheck(bddmgr, "BDS_BranchDecompBottomUp", 1);
#endif

    if (cost > bestDecomp->cost) {
      Cudd_RecursiveDeref(bddmgr, g);
      Cudd_RecursiveDeref(bddmgr, h);
      Cudd_RecursiveDeref(bddmgr, f);
    } else {
      if (bestDecomp->cost < BDS_HUGE_NUMBER) {
        Cudd_RecursiveDeref(bddmgr, bestDecomp->g);
#ifdef DEBUG
        cuddCheck(bddmgr, "BDS_BranchDecompBottomUp", 1);
#endif
        Cudd_RecursiveDeref(bddmgr, bestDecomp->h);
#ifdef DEBUG
        cuddCheck(bddmgr, "BDS_BranchDecompBottomUp", 1);
#endif
        Cudd_RecursiveDeref(bddmgr, bestDecomp->f);

#ifdef DEBUG
        cuddCheck(bddmgr, "BDS_BranchDecompBottomUp", 1);
#endif

      }
      bestDecomp->cost = cost;
      bestDecomp->op = BDS_BDD_DECOMP_B;
      bestDecomp->f = f;
      bestDecomp->g = g;
      bestDecomp->h = h;

      retVal = 1;
    }
  }
  st_free_gen(gen);

  return (retVal);

} /* end of BDS_BranchDecompBottomUp */

/**Function********************************************************************

  Synopsis    [Perform X decomposition on BDD]

  Description [A X candidate, f, is found on each level. Two types of decompositions
  are performed. F = f@g; and F = fh + f'i; Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_XDecompOnBdd(
 DdManager *bddmgr,
 DdNode *bdd,
 int base, /* # of negative edges on the BDD */
 int *support,
 int level,
 edgeMark *levelTable,
 XdecompCost *bestDecomp,
 bdsOptions *option) {
  DdNode *f, *g;
  float cost;
  st_generator *gen;
  int result, nef, neg, retVal = 0;

  gen = st_init_gen(levelTable->table);
  while (st_gen(gen, (char **) &f, NULL)) {

    if (support[Cudd_Regular(f)->index] != level + 1) continue;
    Cudd_Ref(f);
    nef = BDS_GetNegative(bddmgr, f, 1);

    g = Cudd_bddXnor(bddmgr, f, bdd);
    if (g != NULL) Cudd_Ref(g);
    neg = BDS_GetNegative(bddmgr, g, 1);

    if (nef + neg >= base) { /* Disqualify this decomp */
      Cudd_RecursiveDeref(bddmgr, g);
      Cudd_RecursiveDeref(bddmgr, f);
    } else { /* Compare the decomp with the previous best one */
      cost = BDS_CalXdecompCost(bddmgr, bdd, base, f, nef, g, neg, NULL, BDS_BDD_DECOMP_X);
      if (cost >= bestDecomp->cost) {
        Cudd_RecursiveDeref(bddmgr, g);
        Cudd_RecursiveDeref(bddmgr, f);
      } else {
        if (bestDecomp->cost < BDS_HUGE_NUMBER) {
          Cudd_RecursiveDeref(bddmgr, bestDecomp->f);
          Cudd_RecursiveDeref(bddmgr, bestDecomp->g);
        }
        bestDecomp->cost = cost;
        bestDecomp->op = BDS_BDD_XNOR;
        bestDecomp->f = f;
        bestDecomp->g = g;
        bestDecomp->h = NULL;

        retVal = 1;
      }
    }
  }
  st_free_gen(gen);

  return (retVal);

} /* end of BDS_XDecompOnBdd */

/**Function********************************************************************

  Synopsis    [Perform GX decomposition on BDD]

  Description [Decomposition F = f@g + h is seeking; f is known.
    F = fg + f'g' + h; Ff = f(g+h); Ff' = f'(g'+h); Therefore,
    h = (Ff/f)(Ff'/f');

    g = (F/h')@f;

    Intermediate variables: i = Ff; j = Ff'; k = Ff/f; l = Ff'/f';
                m = F/h';

    Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_GXDecompOnBdd(
 DdManager *bddmgr,
 DdNode *bdd,
 int *support,
 int level,
 edgeMark *levelTable,
 bdsOptions *option) {
  DdNode *f, *g, *h;
  DdNode *i, *j, *k, *l, *m;
  DdNode *try1, *try2;
  st_generator *gen;

  gen = st_init_gen(levelTable->table);
  while (st_gen(gen, (char **) &f, NULL)) {
    if (Cudd_Regular(f)->ref == 1) continue;
    if (support[Cudd_Regular(f)->index] != level + 1) continue;
    Cudd_Ref(f);

    i = Cudd_bddAnd(bddmgr, bdd, f);
    if (i != NULL) Cudd_Ref(i);

    j = Cudd_bddAnd(bddmgr, bdd, Cudd_Not(f));
    if (j != NULL) Cudd_Ref(j);

    k = Cudd_bddLICompaction(bddmgr, i, f);
    if (k != NULL) Cudd_Ref(k);

    l = Cudd_bddLICompaction(bddmgr, j, Cudd_Not(f));
    if (l != NULL) Cudd_Ref(l);

    h = Cudd_bddAnd(bddmgr, k, l);
    if (h != NULL) Cudd_Ref(h);

    m = Cudd_bddLICompaction(bddmgr, bdd, Cudd_Not(h));
    if (m != NULL) Cudd_Ref(m);

    g = Cudd_bddXnor(bddmgr, f, m);
    if (g != NULL) Cudd_Ref(g);

    /* Debug */
    try1 = Cudd_bddXnor(bddmgr, f, g);
    if (try1 != NULL) Cudd_Ref(try1);

    try2 = Cudd_bddOr(bddmgr, try1, h);
    if (try2 != NULL) Cudd_Ref(try2);

    Cudd_RecursiveDeref(bddmgr, f);
    Cudd_RecursiveDeref(bddmgr, g);
    Cudd_RecursiveDeref(bddmgr, h);
    Cudd_RecursiveDeref(bddmgr, i);
    Cudd_RecursiveDeref(bddmgr, j);
    Cudd_RecursiveDeref(bddmgr, k);
    Cudd_RecursiveDeref(bddmgr, l);
    Cudd_RecursiveDeref(bddmgr, m);
    Cudd_RecursiveDeref(bddmgr, try1);
    Cudd_RecursiveDeref(bddmgr, try2);
  }
  st_free_gen(gen);

  return (1);

} /* end of BDS_GXDecompOnBdd */

/**Function********************************************************************

  Synopsis    [Co-factor with respect to the top variable, this a basic MUX decomposition]

  Description [Decomposition F = fg + f'h; Both static CMOS and PTL style are
  supported in this function. Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

  Last Date   [6/15/98]

 *****************************************************************************/
static
int
BDS_CofactorOnTop(
 DdManager *bddmgr,
 DdNode *bdd,
 bdsOptions *option,
 bddPool **decomposed,
 bddPool **dominator,
 bddPool **control,
 int *operator,
 int *polarity) {
  DdNode *N, *var;
  DdNode *g, *h;
#ifndef PTL
  DdNode *fg, *fh, *cover;
#endif
  int result;
  bddStats *bddMonitor;

  /* Always pass the regular version of bdd for decomposition */
  *polarity = Cudd_IsComplement(bdd) ? 0 : 1;
  N = Cudd_Regular(bdd);

  /* Find top variable */
  var = bddmgr->vars[N->index];
  cuddRef(var);

  /* Find co-factors */
  g = cuddT(N);
  cuddRef(g);
  h = cuddE(N);
  cuddRef(h);

#ifdef PTL

  /* Dump f, g and h into bddPool */
  *decomposed = BDS_DumpBddPool(bddmgr, g);
  *dominator = BDS_DumpBddPool(bddmgr, h);
  *control = BDS_DumpBddPool(bddmgr, var);
  *operator = BDS_BDD_MUX;

#else

  cover = Cudd_bddAnd(bddmgr, g, h);
  if (cover == NULL) return (0);
  cuddRef(cover);

  if (cover == g) { /* g < h */
    fg = g;
    cuddRef(fg);
    fh = Cudd_bddAnd(bddmgr, Cudd_Not(var), h);
    if (fh != NULL) cuddRef(fh);
  } else if (cover == h) { /* g > h */
    fg = Cudd_bddAnd(bddmgr, var, g);
    if (fg != NULL) cuddRef(fg);
    fh = h;
    cuddRef(fh);
  } else { /* f and g don't cover each other */
    fg = Cudd_bddAnd(bddmgr, var, g);
    if (fg != NULL) cuddRef(fg);
    fh = Cudd_bddAnd(bddmgr, Cudd_Not(var), h);
    if (fh != NULL) cuddRef(fh);
  }
  *decomposed = BDS_DumpBddPool(bddmgr, fg);
  *dominator = BDS_DumpBddPool(bddmgr, fh);
  *operator = BDS_BDD_OR;

#endif

  /* Record if required */
  if (option->verb > BDS_VERBOSE_MOST) {
    bddMonitor = ALLOC(bddStats, 1);
    BDS_UpdateBddMonitor(bddmgr, bddMonitor, N, g, h, var, 0, 0, 0);
   // BDS_Stats(BDS_COFACTOR, bddMonitor, 0, NULL, NULL, NULL, NULL);
    FREE(bddMonitor);
  } else {
    //BDS_Stats(BDS_COFACTOR, NULL, 0, NULL, NULL, NULL, NULL);
  }

  Cudd_RecursiveDeref(bddmgr, g);
  Cudd_RecursiveDeref(bddmgr, h);
  Cudd_RecursiveDeref(bddmgr, var);

#ifndef PTL
  Cudd_RecursiveDeref(bddmgr, cover);
  Cudd_RecursiveDeref(bddmgr, fg);
  Cudd_RecursiveDeref(bddmgr, fh);
#endif

  Cudd_RecursiveDeref(bddmgr, bdd);

  return (1);

} /* end of BDS_CofactorOnTop */

/**Function********************************************************************

  Synopsis    [Find out the node which should be connected to 1]

  Description [This function is only used for branch decomposition]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
DdNode *
BDS_FindOneMark(
 DdManager *bddmgr,
 DdNode *bdd,
 edgeMark *levelTable) {
  DdNode *oneMark;
  st_table *visited;

  visited = st_init_table(st_ptrcmp, st_ptrhash);

  oneMark = BDS_FindOneMarkRecursive(bddmgr, bdd, visited, levelTable);

  st_free_table(visited);

  return (oneMark);

} /* end of BDS_FindOneMark */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_FindOneMark()]

  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
static
DdNode *
BDS_FindOneMarkRecursive(
 DdManager *bddmgr,
 DdNode *bdd,
 st_table *visited,
 edgeMark *levelTable) {
  DdNode *N, *oneMark;

  N = Cudd_Regular(bdd);

  if (st_is_member(levelTable->table, (char *) N) == 1) {
    return (N);
  }

  if (st_is_member(visited, (char *) N) == 1) {
    return (NULL);
  }

  oneMark = BDS_FindOneMarkRecursive(bddmgr, cuddT(N), visited, levelTable);
  if (oneMark != NULL) return (oneMark);

  oneMark = BDS_FindOneMarkRecursive(bddmgr, cuddE(N), visited, levelTable);
  if (oneMark != NULL) return (oneMark);

  if (st_add_direct(visited, (char *) N, NULL) == ST_OUT_OF_MEM) {
    printf("Out of memeory !");
    exit(2);
  }

} /* end of BDS_FindOneMarkRecursive */

/**Function********************************************************************

  Synopsis    [Variable reordering for performance decomposition in delay re-synthesis phase]

  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
extern
int
BDS_Heuristic_Simple(
 DdManager *bddmgr,
 DdNode *bdd,
 int *permutation,
 int *original,
 bdsOptions *option,
 int *real2dumbo) {
  int i, result;
  DdNode *add, *N;
  int numVar;
  int partition;
  int level, *support;
  int kdecomp = 0;
  edgeMark **edgeProperty;
  int specialOperator;
  array_t *cost;
  int decompLevel;
  int Heuristic_sort_decomp_level();
  Cost *tempcost;
  DdNode *specialDominator;
  int polarity;
  int dumbo;
  int *permute;
  int validate = 0;
  int iterate = 0;

  tempcost = ALLOC(Cost, 1);
  partition = 4;

  /* Get # variables in the BDD */
  numVar = Cudd_SupportSize(bddmgr, bdd);
  //printf("Num of variables = %i\n", numVar);
  cost = array_alloc(Cost *, 0);
  permute = ALLOC(int, numVar);

  /* Iteratively Swap Variables, reorder BDDs and check for special dominators
   ** Collect the levels of the best decompositions and store in cost array.
   */

  for (i = 0; i < numVar; i++) {
    dumbo = permutation[i];
    permute[i] = real2dumbo[dumbo];
  }

  if (numVar > ((partition + 1)*2)) {
    iterate = partition;
  }
  if (numVar == ((partition + 1)*2)) {
    iterate = partition;
  }
  if (numVar < ((partition + 1)*2)) {
    iterate = numVar - (partition + 1);
  }

  for (i = 0; i < iterate; i++) {

   // printf("Total iterations = %i\n", (numVar - (partition + 1)));
  //  printf("Iteration no. %i\n", i);
    result = Swap_Variable(bddmgr, &permute, partition, i);
    if (result == 0) return (0);

    /* Always use regular version of the BDD */
    N = Cudd_Regular(bdd);

    /* Transform incoming BDD into 0-1 ADD */
    add = Cudd_BddToAdd(bddmgr, N);
    Cudd_Ref(add);

    /* Record polarity after reordering */
    polarity = Cudd_IsComplement(N) ? 0 : 1;

    /* Get the supports of the BDD */
    support = BDS_SupportArray(bddmgr, N, &level);
    if (support == NULL) return (0);

    /* Get edge properties of the BDD */
    edgeProperty = BDS_MarkEdges(bddmgr, add, support, level, kdecomp, option);
    if (edgeProperty == NULL) return (0);

    if (specialDominator = (DdNode *) BDS_SpecialCheck(bddmgr, N, add, support, level,
     &decompLevel, edgeProperty, &specialOperator, option)) {
      validate++;
      tempcost->index = i;
      tempcost->cost = decompLevel;
  //    printf("Index = %i \t Cost = %i\n", i, decompLevel);
      array_insert_last(Cost *, cost, tempcost);
    }

  //  printf("Validate = %i\n", validate);
    BDS_FreeEdgeProperty(support, edgeProperty, level);
    Cudd_RecursiveDeref(bddmgr, add);
    if (specialDominator != NULL)
      Cudd_RecursiveDeref(bddmgr, specialDominator);

    /* Reorder the BDD to original DELAY variable order BEFORE reordering with BEST partition */
    result = Cudd_ShuffleHeap(bddmgr, original);
    if (result == 0) return (0);
  }

  /* Reorder the BDD to original DELAY variable order BEFORE reordering with BEST partition */
  result = Cudd_ShuffleHeap(bddmgr, original);
  if (result == 0) return (0);

  /*Sort the cost array to get the Best Partition*/
  if (validate > 0) {
    array_sort(cost, Heuristic_sort_decomp_level);
    for (i = 0; i < array_n(cost); i++) {
      tempcost = array_fetch(Cost *, cost, i);
      if ((tempcost->cost == partition) || (tempcost->cost == partition - 1))
        continue;
    }

    /* With the best partition, get the permutation of variables in order to reconstruct BDDs */

    for (i = 0; i < tempcost->index; i++) {
      (void) Rebuild_Partition_Table(&original, i, partition);
    }
    /* With the best partition (one that is closer to the k-feasible level) re-construct BDDs */
    result = Cudd_ShuffleHeap(bddmgr, original);
  }
  FREE(permute);
  FREE(tempcost);
  if (validate == 0) return (0);
  else
    return (1);

}

/**Function********************************************************************

  Synopsis    [Variable Swap routing for the Variable Partitioning Program]

  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
extern
int
Swap_Variable(
 DdManager *bddmgr,
 int **permutation,
 int partition,
 int i) {
  int j, var, result;

  var = (*permutation)[partition - i];
  j = (*permutation)[partition + i + 1];
  (*permutation)[partition - i] = j;
  (*permutation)[partition + i + 1] = var;

  /* Perform the final reordering */
  result = Cudd_ShuffleHeap(bddmgr, (*permutation));
  if (result == 0) {
 //   printf("didnt work\n");
    return (0);
  }
  return (1);

}

/**Function********************************************************************

  Synopsis    [Rebuilds partition Table after choosing the best Partition]

  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
extern
void
Rebuild_Partition_Table(
 int **original,
 int i,
 int partition) {
  int j, var;

  var = (*original)[partition - i];
  j = (*original)[partition + i + 1];
  (*original)[partition - i] = j;
  (*original)[partition + i + 1] = var;

}

/**Function********************************************************************

  Synopsis    [Array sort]

  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
Heuristic_sort_decomp_level(s1, s2)
Cost **s1;
Cost **s2;

{
  Cost *ssink1;
  Cost *ssink2;

  ssink1 = *s1;
  ssink2 = *s2;

  /*  1st line is -1 originally to get ascending sort*/
  if (ssink1->cost < ssink2->cost) return (1);
  if (ssink1->cost > ssink2->cost) return (-1);
  return 0;
}

/**Function********************************************************************

  Synopsis    [Heuristic Variable Partitioning Decomposition]

  Description [Heuristic Variable Partitioning for Area.
               Decompose a node into two sub-nodes: 'decomposed' and 'dominator'
               based on the best cost. The function takes BDDs in the form of
               bddPool*, return 'decomposed' and 'dominator' also in the form of
               bddPool*. It identifies the bound-set swapped variable (variable
               with the fewest incident edges) and free-set swapped variable
               (variable with the largest incident edges) and do the swapping.
               The swapped variables are then locked. The unswapped variables
               between bound-set and free-set are swapped in subsequent rounds
               until all variables in either bound-set or free-set have been
               swapped. The costs for each swap is recorded in each swapping.
               The cost is just the number of sub-functions based on number of
               cut-set nodes. If the new cost is greater than the original
               cost before swappings, the decomposition is disqualified. If
               is no Sigma_0 or Sigma_1 edge at the cut level, the decomposition
               will also disqualified. If the size of the BDD manager is not
               the same as the number of active variable in the BDD, the variable
               swapping can not be performed.
               If successful, return 1, otherwise return 0]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
BDS_HeuristicDecomp(
 DdManager *bddmgr,
 DdNode *N, /* The regular version of the BDD to be decomposed. */
 DdNode *add, /* The ADD of the BDD */
 int *support, /* The supports of the BDD */
 bdsOptions *option,
 bddPool **decomposed, /* Q or R */
 bddPool **dominator, /* D */
 int *operator,
 int level) {
  int k = 0;
  int decompType, result, i;
  int numSigmaZero, numSigmaOne;
  decompCost *bestDecompCost;
  int best_level = 0;
  decompCost *temp_cost;
  bddStats *bddMonitor;
  int decompLevel;
  bddPool *decomposedSOP, *dominatorSOP;
  DdNode *decomposedBdd, *dominatorBdd;
  int RESULT_LEVEL = 0;
  int qualify = 0, qual_level = 0, index = 0;
  int hresult3, *support1;
  edgeMark **edgeProperty = NULL;

  /* Prepare to record decomposition information */
  if (option->verb > BDS_VERBOSE_MOST) {
    bddMonitor = ALLOC(bddStats, 1);
    BDS_UpdateBddMonitor(bddmgr, bddMonitor, N, NULL, NULL, NULL, 0, 0, 0);
  }

  /* Initialize the best decomposition cost structure */
  temp_cost = BDS_InitBestCost();
  bestDecompCost = BDS_InitBestCost();
  numSigmaZero = 0;
  numSigmaOne = 0;

  /* Set the best level to do the cut. For k-LUT, k = 5 (default)
   ** If the total number of levels is less than 15, the best level to do cut
   ** is set to k-1 = 4. If the the total number of levels in the BDD is
   ** greater than 15, the best level is set to level/2.
   */

  k = option->k;

  if (option->k == 5) { /* default k-LUT value is 5 */
    best_level = 4;
    if ((level == 9) || (level == 10)) {
      best_level = 4;
    }
    if ((level < 9)) {
      if (level % 2 == 0) {
        best_level = 4;
      }
      if (level % 2 != 0) {
        best_level = 4;
      }
    }
    if ((level == 14) || (level == 15)) {
      best_level = 4;
    }
    if ((level < 14)) {
      best_level = 4;
    }
    if ((level > 15) && ((level + 1) % 2 == 0))
      best_level = (level + 1) / 2;
    if ((level > 15) && ((level + 1) % 2 != 0))
      best_level = level / 2;
  } else {
    best_level = (k - 1);
    if ((level > 15) && ((level + 1) % 2 == 0))
      best_level = (level + 1) / 2;
    if ((level > 15) && ((level + 1) % 2 != 0))
      best_level = level / 2;
  }

  qualify = 0;
  qual_level = level;

  i = best_level;

  /* Find the best swap variables in the BDD and do the swapping by calling BDS_GoodSwap */

  hresult3 = BDS_GoodSwap(bddmgr, N, add, i, option);
  if (hresult3 == 0) return (0);

  /* Get the supports of the BDD after swappings */
  support1 = BDS_SupportArray(bddmgr, add, &level);
  if (support1 == NULL) return (0);

  /* Get the edge properties of the BDD */
  edgeProperty = BDS_MarkEdges(bddmgr, add, support1, (level + 1), 0, option);
  if (edgeProperty == NULL) return (0);

  /* If the cut level has no Sigma_1 or Sigma_0, decomposition at that level
   ** cannot be performed.
   */
  if (edgeProperty[i]->decompType == BDS_BDD_DECOMP_NONE) {
    ///printf("best_level = %i 's decompType is BDS_BDD_DECOMP_NONE, b/c no Sigma0 or Sigma1 at cut level\n",i);
    return (0);
  }

  /* If there is a Sigma_0 on the level, do conjunctive Boolean BDD
   ** decomposition by calling BDS_PerformDecomp()
   */
  if ((edgeProperty[i]->decompType == BDS_BDD_DECOMP_CONJ) || (edgeProperty[i]->decompType == BDS_BDD_DECOMP_BOTH)) {

    numSigmaZero = edgeProperty[i]->numSigmaZero;

    /* Do conjunctive decomposition */
    result = BDS_PerformDecomp(bddmgr, N, add, edgeProperty[i], &bestDecompCost, option, BDS_BDD_DECOMP_CONJ, i, best_level, &bestDecompCost, &qualify, &qual_level);

    if (result == 0) {
      return (0);
    }
  }

  /* If there is a Sigma_1 on the level, do disjunctive Boolean BDD
   ** decomposition by calling BDS_PerformDecomp()
   */
  if ((edgeProperty[i]->decompType == BDS_BDD_DECOMP_DISJ) || (edgeProperty[i]->decompType == BDS_BDD_DECOMP_BOTH)) {

    numSigmaOne = edgeProperty[i]->numSigmaOne;

    /* Do disjunctive decomposition */
    result = BDS_PerformDecomp(bddmgr, N, add, edgeProperty[i], &bestDecompCost, option, BDS_BDD_DECOMP_DISJ, i, best_level, &bestDecompCost, &qualify, &qual_level);

    if (result == 0) {
      return (0);
    }
  }

  /* Disqualify this decomposition if the decomposition is not successful */
  if (bestDecompCost->dominator == NULL) { /* Not valid decomposition */
    if (option->verb > BDS_VERBOSE_MOST) {
      BDS_UpdateBddMonitor(bddmgr, bddMonitor, NULL, NULL, NULL, NULL, 0, bestDecompCost->cost, 0);
     // BDS_Stats(BDS_BDD_DECOMP, bddMonitor, 0, NULL, NULL, NULL, NULL);
      FREE(bddMonitor);
    }
    Cudd_RecursiveDeref(bddmgr, add);
    FREE(bestDecompCost);
    FREE(temp_cost);
    ///printf("Disqualify decomposition as dominator is NULL\n");
    return (BDS_DECOMP_DISQUALIFY);
  }

  /* No decomposition if there is no Sigam_0 and Sigma_1 exist at the cut level. */
  if ((numSigmaZero == 0) && (numSigmaOne == 0)) {
    FREE(bestDecompCost);
    FREE(temp_cost);
    Cudd_RecursiveDeref(bddmgr, add);
    ///printf("No Sigma_0 and Sigma_1 at the cut level\n");
    return (0);
  }

  /* If decomposition was successful, construct return parameters for
   ** 'dominator' and 'decomposed' BDDs.
   */
  if (bestDecompCost->dominator != NULL) {

    /* 'dominator' BDD to be returned */
    *dominator = bestDecompCost->dominator;
    *operator = bestDecompCost->op;

    /* Build dominator BDD from the dominator BDD Pool */
    dominatorBdd = BDS_BuildDDFromBddPool(bddmgr, *dominator, 0);
    if (dominatorBdd == NULL) return (0);

    /* Do minimization on 'decomposed' BDD */
    decomposedBdd = BDS_BddMinimization(bddmgr, N, dominatorBdd, bestDecompCost->decompType, option);
    if (decomposedBdd == NULL) return (0);

    /* If there is no minimization done on the 'decomposed' BDD, the
     ** same BDD is returned, So the decomposition is not useful at all.
     */
    if (decomposedBdd == N) {

      BDS_FreeBddPool(bddmgr, bestDecompCost->dominator);
      FREE(bestDecompCost);
      FREE(temp_cost);
      Cudd_RecursiveDeref(bddmgr, dominatorBdd);
      Cudd_RecursiveDeref(bddmgr, decomposedBdd);
      Cudd_RecursiveDeref(bddmgr, add);
      return (BDS_BDD_NO_MINIMI);
    }

    /* 'decomposed' BDD to be returned */
    *decomposed = BDS_DumpBddPool(bddmgr, decomposedBdd);
    if (decomposed == NULL) return (0);

    /* Record the decomposition if required */
    if (option->verb > BDS_VERBOSE_MOST) {
      BDS_UpdateBddMonitor(bddmgr, bddMonitor, NULL, decomposedBdd, dominatorBdd, NULL, bestDecompCost->level, bestDecompCost->cost, bestDecompCost->op);
    //  BDS_Stats(BDS_G_DOMI, NULL, 0, NULL, NULL, NULL, NULL);
   //   BDS_Stats(BDS_BDD_DECOMP, bddMonitor, 0, NULL, NULL, NULL, NULL);
    } else if (option->verb > BDS_VERBOSE_LESS) {
   //   BDS_Stats(BDS_G_DOMI, NULL, 0, NULL, NULL, NULL, NULL);
    }

    Cudd_RecursiveDeref(bddmgr, dominatorBdd);
    Cudd_RecursiveDeref(bddmgr, decomposedBdd);
    Cudd_RecursiveDeref(bddmgr, N);
    Cudd_RecursiveDeref(bddmgr, add);

    FREE(bestDecompCost);
    FREE(temp_cost);
    if (option->verb > BDS_VERBOSE_MOST) FREE(bddMonitor);

    return (1);
  } else {
    Cudd_RecursiveDeref(bddmgr, add);
    FREE(bestDecompCost);
    if (option->verb > BDS_VERBOSE_MOST) FREE(bddMonitor);

    return (BDS_BDD_NO_MINIMI);
  }

} /* end of BDS_HeuristicDecomp */

/**Function********************************************************************

  Synopsis    [Good Swap]

  Description [Identify the best swapped variables and do the swapping in order
               by calling BDS_DoSwap().]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
extern
int
BDS_GoodSwap(
 DdManager *bddmgr,
 DdNode *N, /* The regular version of the BDD to be decomposed */
 DdNode *add, /* The ADD of the BDD */
 int boundary, /* = i = best_level */
 bdsOptions *option) {
  int level;
  int kdecomp = 0;
  int cutset = 0; /* # variables in the cut-set */
  int sub_functions; /* cost function */
  int sub_functions_old;
  int result;
  int i, j;
  int *var_order = NULL; /* variable order */
  double path_count;
  int *no_levels = NULL;
  float price = 0.0;
  int newlevel;
  DdNode *add1 = NULL;
  edgeMark **edgeProperty = NULL;
  int *support = NULL;

  /* Get the supports of the BDD */
  support = BDS_SupportArray(bddmgr, add, &level);
  if (support == NULL) return (0);

  /* Get the edge properties of the BDD */
  edgeProperty = BDS_MarkEdges(bddmgr, add, support, (level + 1), kdecomp, option);
  if (edgeProperty == NULL) {
  //  printf("1: edgeProperty Error!!!\n");
    return (0);
  }
  BDS_FreeEdgeProperty(support, edgeProperty, (level + 1));
  edgeProperty = NULL;
  support = NULL;

  /* Get the supports of the BDD */
  support = BDS_SupportArray(bddmgr, add, &level);
  if (support == NULL) return (0);

  /* Get the edge properties of the BDD */
  edgeProperty = BDS_MarkEdges(bddmgr, add, support, (level + 1), kdecomp, option);
  if (edgeProperty == NULL) {
    //printf("2: edgeProperty Error!!!\n");
    return (0);
  }

  /* Now we HAVE TO traverse the Bdd to find a good swap and carry out the swap */

  cutset = 0;

  /* Get the number of variables in the cutset before swappings */
  result = BDS_HMark(bddmgr, add, support, (level + 1), &cutset, boundary);

  /* Calculate the cost function based on the cutset before swappings */
  sub_functions = ceil((log(cutset) / log(2)));
  sub_functions_old = sub_functions;

  /* Get path count */
  path_count = Cudd_CountPath(add);

  /* Get variable order of the BDD */
  var_order = BDS_VariableArray(bddmgr, add, &newlevel);

  /* Call BDS_DoSwap() to identify and swap variables */
  result = BDS_DoSwap(bddmgr, add, edgeProperty, boundary, (level), var_order, option);
  if (result == 0) return (0);

  /* Get the supports of the BDD */
  support = BDS_SupportArray(bddmgr, add, &level);
  if (support == NULL) return (0);

  /* Get the edge properties of the BDD */
  edgeProperty = BDS_MarkEdges(bddmgr, add, support, (level + 1), kdecomp, option);
  if (edgeProperty == NULL) return (0);

  /* Get the number of variables in the cutset after swappings */
  cutset = 0;
  result = BDS_HMark(bddmgr, add, support, (level + 1), &cutset, boundary);

  /* Calculate the cost function based on the cutset after swappings */
  sub_functions = ceil((log(cutset) / log(2)));

  ///printf("old = %i, new = %i\n",sub_functions_old,sub_functions);

  /* If the new cost after swappings is greater than or equal to the
   ** original cost before swappings, the decomposition is disqualified.
   */
  if (sub_functions_old <= sub_functions) return (0);

  return (1);
}

/**Function********************************************************************

  Synopsis    [Do Swap]

  Description [Identify the best swapped variables in the bound set and the
               free set by counting the incident edges at each variable. The
               bound-set swapped variable is the one with the fewest number of
               incident edges that is closest to the cut, and the free-set
               swapped variable is the one with the largest number of incident
               edges that is closest to the cut. After swapping. the swapped
               variables are locked, and do the subsequent swapping of the next
               best swapped variables between the bound set and the free set
               until all variables in either the bound set or the free set have
               been swapped. The costs for each swap is recorded in each swapping.
               The cost is just the number of sub-functions based on number of
               cut-set nodes. If the new cost is greater than the original
               cost before swappings, the decomposition is disqualified. If there
               is no Sigma_0 or Sigma_1 edge at the cut level, the decomposition
               will also disqualified. If the size of the BDD manager is not
               the same as the number of active variable in the BDD, the variable
               swapping can not be performed because the variable swapping is
               done on the BDD manager, not on the BDD itself.]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
extern
int
BDS_DoSwap(
 DdManager *bddmgr,
 DdNode *N,
 edgeMark **edgeProperty,
 int boundary,
 int level,
 int *var_order,
 bdsOptions *option) {
  int i, j, l, z;
  array_t *BS_edges, *FS_edges;
  HCost *edges, *edges1, *FS_variable, *BS_variable;
  int BDS_sort_edges(), BDS_sort_edges_complement(), BDS_sort_costs();
  int temp_edge, temp_level, BS_level, FS_level;
  int result;
  int sub_functions; /* the cost function */
  int incident; /* # incident edges */
  int after, last;
  int cutset; /* # variables in the cut-set */
  int *support;
  int flag = 0;
  int level1, result1;
  int *lock, counter = 0;
  int *templtt;
  st_table *visited; /* used to lock the already swapped variable */
  int extreme, newlevel, k, *newvar_order;
  array_t *best_decomps; /* used to store costs and variable orders after each swap */
  HCost *cost1, *cost2;
  int *var_order1;
  int breakat = 0;
  int *neworder;

  /* Set the number of iteration for swapping */
  if ((level - boundary) <= (boundary + 1))
    extreme = level - boundary;
  else
    extreme = boundary + 1;

  /* Initialize the 'visited' table to store the locked variables after each swapping */
  visited = NULL;
  visited = st_init_table(st_ptrcmp, st_ptrhash);
  if (visited == NULL) return (0);

  /* Get the supports of the BDD */
  support = BDS_SupportArray(bddmgr, N, &level1);

 // for (z = 0; z <= level1; z++)
 //   printf("bddmgr->size = %i, Support = %i\t Iteration %i\n", bddmgr->size, support[z], z);

  BDS_FreeEdgeProperty(support, edgeProperty, (level + 1));
  FREE(var_order);
  var_order = NULL;
  newlevel = 0;

  /* Get the initial variable order */
  var_order = BDS_VariableArray(bddmgr, N, &newlevel);
  if (var_order == NULL) return (0);

  //for (z = 0; z <= level1; z++)
 //   printf("bddmgr->size = %i, var_order = %i\t Iteration %i\n", bddmgr->size, var_order[z], z);

  /* The variable swapping can only be performed if BDD manager size is
   ** the same as the number of active variables in the BDD.
   */
  if (bddmgr->size == newlevel) {
    /* Initialize the best_decomps array to store the costs and variable
     ** orders after each swap
     */
    best_decomps = array_alloc(HCost *, 0);
  } else {
   // printf("newlevel = %d, bddmgr->size = %d\n", newlevel, bddmgr->size);
    return (0);
  }

  /* The main loop for identifing the best swapped variables and performing
   ** variable swappings.
   */
  for (j = 0; j < (extreme - 1); j++) {

    /* Get the supports of the BDD */
    support = BDS_SupportArray(bddmgr, N, &level1);

    /* Initialize BS_edges and FS_edges array to store incident edges counts at each level */
    BS_edges = array_alloc(HCost *, 0);
    FS_edges = array_alloc(HCost *, 0);

   // printf("***** j = %i, extreme (-2) = %i\n", j, extreme);

    if (support == NULL) return (0);

    /* Get edge properties of the BDD to know # incident edges at each level */
    edgeProperty = BDS_MarkEdges(bddmgr, N, support, (level + 1), 0, option);
    if (edgeProperty == NULL) return (0);

    /* For each level, get the number of incident edges. */
    for (i = 0; i <= level; i++) {
      edges = ALLOC(HCost, 1);
      if (i == 0)
        edges->edges = 0;
      if ((i > 0) && (i <= level)) {
        incident = edgeProperty[i]->numIncident;
        edges->edges = incident;
      //  printf("i: %i, incident = %i\n", i, edges->edges);
      }
      /* Also record the levels */
      edges->level = i;

      /* Insert the variables information into BS_edges and FS_edges
       ** for the bound set variables and the free set variables respectively.
       */
      if (i <= boundary)
        array_insert(HCost *, BS_edges, i, edges);
      if (i > boundary)
        array_insert(HCost *, FS_edges, (i - (boundary + 1)), edges);
    }

    for (i = 0; i <= boundary; i++) {
      BS_variable = array_fetch(HCost *, BS_edges, i);
     // printf("i: %i, BS_variable->edges: %i, BS_variable->level: %i\n", i, BS_variable->edges, BS_variable->level);
    }
    for (i = 0; i < (level - boundary); i++) {
      FS_variable = array_fetch(HCost *, FS_edges, i);
    //  printf("i: %i, FS_variable->edges: %i, FS_variable->level: %i\n", i, FS_variable->edges, FS_variable->level);
    }

    /* Sort the arrays in descending orders */
    array_sort(BS_edges, BDS_sort_edges_complement);
    array_sort(FS_edges, BDS_sort_edges_complement);

  //  printf("After sort\n");
    for (i = 0; i <= boundary; i++) {
      BS_variable = array_fetch(HCost *, BS_edges, i);
  //    printf("i: %i, BS_variable->edges: %i, BS_variable->level: %i\n", i, BS_variable->edges, BS_variable->level);
    }
    for (i = 0; i < (level - boundary); i++) {
      FS_variable = array_fetch(HCost *, FS_edges, i);
  //    printf("i: %i, FS_variable->edges: %i, FS_variable->level: %i\n", i, FS_variable->edges, FS_variable->level);
    }

    /* Start from the variable with the second fewest number of incident
     ** edges for the bound set because the variable with the fewest
     ** number of incident edges is the root node of the BDD.
     */
    i = boundary - 1;
    BS_variable = array_fetch(HCost *, BS_edges, i);
    breakat = i;

    /* Get the next variable with the fewest number of incident
     ** edges that is closest to the cut level from the bound set.
     */
    if ((st_is_member(visited, (char *) BS_variable->level) == 1)) {

      for (k = (boundary - 2); k >= 0; k--) {
        BS_variable = array_fetch(HCost *, BS_edges, k);
        if (!(st_is_member(visited, (char *) BS_variable->level) == 1)) {
          breakat = k;
          break;
        }
      }
    }

    /* Lock the swapped variable by adding its level to the 'visited' table */
    BS_level = BS_variable->level;
    if (st_add_direct(visited, (char *) BS_variable->level, NULL) == ST_OUT_OF_MEM)
      return (0);

    /* Start from the variable with the largest number of incident edges
     ** that is closest to the cut for the free set.
     */
    FS_variable = array_fetch(HCost *, FS_edges, 0);

    /* Get the next variable with the largest number of incident
     ** edges that is closest to the cut level from the free set.
     */
    if ((st_is_member(visited, (char *) FS_variable->level) == 1)) {
      for (k = 1; k < (level - boundary); k++) {
        FS_variable = array_fetch(HCost *, FS_edges, k);
        if (!(st_is_member(visited, (char *) FS_variable->level) == 1))
          break;
      }
    }

    /* Lock the swapped variable by adding its level to the 'visited' table */
    FS_level = FS_variable->level;
    if (st_add_direct(visited, (char *) FS_variable->level, NULL) == ST_OUT_OF_MEM)
      return (0);

   // printf("Selected BS node = %i\t Selected FS node = %i\n", BS_level, FS_level); ///kv

    temp_level = 0;
    temp_edge = 0;

    /* Change the variable order of the bound-set swapped variable
     ** and the free-set swapped variable.
     */
    if ((BS_level < 100 && BS_level >= 0) && (FS_level < 100 && FS_level >= 0)) {
      temp_level = var_order[BS_level];
      temp_edge = var_order[FS_level];
      var_order[BS_level] = temp_edge;
      var_order[FS_level] = temp_level;

      /* If the BDD manager's size is not equal to the number of active
       ** variables currently in the BDD, cannot do variable swapping.
       */
      if (bddmgr->size != newlevel) {
        return (0);
      }/* Do swapping by calling Cudd_ShuffleHeap() with the new variable order */
      else {
        /* Get the supports of the BDD */
        support = BDS_SupportArray(bddmgr, N, &level);
        cutset = 0;

        /* Swap the variables by reordering with the new order */
        result = Cudd_ShuffleHeap(bddmgr, var_order);
        if (result == 0) return (0);

        /* Get the # cutset variables */
        result1 = BDS_HMark(bddmgr, N, support, (level + 1), &cutset, boundary);

        /* Get the cost function of the new variable order */
        sub_functions = ceil((log(cutset) / log(2)));

        /* Create a cost structure to store the cost and variable order
         ** of the new swap.
         */
        cost1 = ALLOC(HCost, 1);
        cost1->order = (int *) malloc((level + 1) * sizeof (int));
        for (l = 0; l <= level; l++)
          cost1->order[l] = var_order[l];
        cost1->cost = sub_functions;

        /* Put the new cost and variable order in the best_decomps array */
        array_insert(HCost*, best_decomps, counter, cost1);
        counter++;
        flag = 1;
      }
      if (result == 0) return (0);
    }
    array_free(FS_edges);
    array_free(BS_edges);
    BDS_FreeEdgeProperty(support, edgeProperty, (level + 1));
  }

  if ((bddmgr->size == newlevel) && (flag == 1)) {

    /* Sort the best_decomps array so that the best cost will be the last
     ** element of the array.
     */
    array_sort(best_decomps, BDS_sort_costs);

    for (j = 0; j < array_n(best_decomps); j++) {
      cost2 = array_fetch(HCost *, best_decomps, j);
    }

    /* Put the last element of the best_decomps into a new cost structure */
    cost2 = array_fetch(HCost *, best_decomps, (array_n(best_decomps) - 1));
    neworder = (int *) malloc(newlevel * sizeof (int));

    /* Get the final variable order */
    for (j = 0; j < newlevel; j++) {
      neworder[j] = cost2->order[j];
    }

    /* Do the final swapping according to the best variable order */
    result = Cudd_ShuffleHeap(bddmgr, neworder);
    if (result == 0) return (0);
    FREE(neworder);
  }
  if (bddmgr->size == newlevel) {
    array_free(best_decomps);
  }
  st_free_table(visited);
  return (1);
}

/**Function********************************************************************

  Synopsis    [Mark edges to do variable swapping in variable partitioning
               decomposition.]

  Description [An edge(node) can appear in several hash tables, in case an edge
               spans more than one level. It gets the number of cut-set
               variables.]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
extern
int
BDS_HMark(
 DdManager *bddmgr,
 DdNode *bdd,
 int *support,
 int level,
 int *cutset,
 int boundary) {
  int i, result, K;
  st_table *visited;
  DdNode *N;
  DdNode *Then, *Else;
  int constantZero = 0, constantOne = 0;
  int *LevelCheck;

  LevelCheck = ALLOC(int, level);

  for (i = 0; i < level; i++)
    LevelCheck[i] = 0;

  N = Cudd_Regular(bdd);

  Then = cuddT(N);
  Else = cuddE(N);

  visited = st_init_table(st_ptrcmp, st_ptrhash);
  if (visited == NULL) return (0);

  result = BDS_HMarkRecursive(bddmgr, N, Then, visited, support, level, cutset, boundary, &constantZero, &constantOne, LevelCheck);
  if (result == 0) return (0);

  result = BDS_HMarkRecursive(bddmgr, N, Else, visited, support, level, cutset, boundary, &constantZero, &constantOne, LevelCheck);
  if (result == 0) return (0);

  st_free_table(visited);

  if (result == 1) return (1);

} /* end of BDS_MarkEdges */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_MarkEdges]

  Description [Get the number of variables n the cut-set]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
extern
int
BDS_HMarkRecursive(
 DdManager *bddmgr,
 DdNode *hBdd,
 DdNode *lBdd,
 st_table *visited,
 int *support,
 int level,
 int *cutset,
 int boundary,
 int *constantZero,
 int *constantOne,
 int *LevelCheck) {
  int result;
  DdNode *Nh, *Nl;
  DdNode *background;
  int highLevel;

  Nh = Cudd_Regular(hBdd);
  Nl = Cudd_Regular(lBdd);

  background = bddmgr->background;

  /* if N is marked as visited, all edges below bdd have been visited. */
  if (st_is_member(visited, (char *) lBdd) == 1) {
    return (1);
  }

  if (Cudd_IsConstant(Nl)) {
    if (((lBdd == Cudd_ReadLogicZero(bddmgr)) || (lBdd == background)) && ((*constantZero) == 0)) {
      (*constantZero) = 1;
      (*cutset)++;
    }

    if ((lBdd == Cudd_ReadOne(bddmgr)) && ((*constantOne) == 0)) {
      (*constantOne) = 1;
      (*cutset)++;
    }
    return (1);
  } else {
    highLevel = support[Cudd_NodeReadIndex(Nl)];
    if (highLevel > boundary) {
      if (LevelCheck[highLevel] == 0) {
        (*cutset)++;
        LevelCheck[highLevel] = 1;
      }
      /* Mark bdd as visited */
      if (st_add_direct(visited, (char *) lBdd, NULL) == ST_OUT_OF_MEM)
        return (0);
      return (1);
    }

    if (highLevel <= boundary) {

      result = BDS_HMarkRecursive(bddmgr, hBdd, cuddT(Nl), visited, support, level, cutset, boundary, constantZero, constantOne, LevelCheck);
      if (result == 0) return (0);

      result = BDS_HMarkRecursive(bddmgr, hBdd, cuddE(Nl), visited, support, level, cutset, boundary, constantZero, constantOne, LevelCheck);
      if (result == 0) return (0);

      /* Mark bdd as visited */
      if (st_add_direct(visited, (char *) lBdd, NULL) == ST_OUT_OF_MEM)
        return (0);

    }

  }

  return (1);

} /* end of BDS_MarkEdgesRecursive */

BDS_sort_edges(s1, s2)
HCost **s1;
HCost **s2;

{
  HCost *ssink1;
  HCost *ssink2;

  ssink1 = *s1;
  ssink2 = *s2;


  /* && (ssink1->level > ssink2->level)  1st line is -1 originally to get ascending sort*/
  if ((ssink1->edges > ssink2->edges) && (ssink1->level > ssink2->level)) return (1);
  if ((ssink1->edges < ssink2->edges)) return (-1);
  return 0;
}

BDS_sort_edges_complement(s1, s2)
HCost **s1;
HCost **s2;

{
  HCost *ssink1;
  HCost *ssink2;

  ssink1 = *s1;
  ssink2 = *s2;


  /* && (ssink1->level > ssink2->level)  1st line is -1 originally to get ascending sort*/
  if ((ssink1->edges > ssink2->edges) && (ssink1->level > ssink2->level)) return (-1);
  if ((ssink1->edges < ssink2->edges)) return (1);
  if ((ssink1->edges == ssink2->edges) && (ssink1->level > ssink2->level)) return (1);
  return 0;
}

BDS_sort_costs(s1, s2)
HCost **s1;
HCost **s2;

{
  HCost *ssink1;
  HCost *ssink2;

  ssink1 = *s1;
  ssink2 = *s2;


  /* && (ssink1->level > ssink2->level)  1st line is -1 originally to get ascending sort*/
  if ((ssink1->cost > ssink2->cost)) return (-1);
  if ((ssink1->cost < ssink2->cost)) return (1);
  return 0;
}

/**Function********************************************************************

  Synopsis    [Get the variable order of a BDD]

  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
extern
int *
BDS_VariableArray(
 DdManager *bddmgr,
 DdNode *f,
 int *i) {
  DdNode *support, *var, *scan;
  int *result, j, k, id;

  support = NULL;
  support = Cudd_Support(bddmgr, f);
  if (support == NULL) return (NULL);
  cuddRef(support);

  result = ALLOC(int, bddmgr->size);
  for (k = 0; k < bddmgr->size; k++) {
    result[k] = 0xFFFF; /* A variable is unlikely to sit at this level */
  }

  *i = 0;

  /* Figure out result[id] = level information. */
  for (j = 0; j < bddmgr->size; j++) {
    id = Cudd_ReadInvPerm(bddmgr, j);
    scan = support;
    while (!cuddIsConstant(scan)) {
      ///printf("j = %i, scan->index = %i, id = %i\n",j,scan->index,id);
      if (scan->index == id) {
        result[*i] = id;

     //   printf("BDD index = %i \t Iteration %i\n", id, j);
        /*result[id] = i;*/
        (*i)++;

        break;
      }
      scan = cuddT(scan);
    }
  }

 // printf("Size of BDDmgr = %i, NO of level = %i\n", bddmgr->size, (*i));

  Cudd_RecursiveDeref(bddmgr, support);
  /*(*level) = i - 1;  The number of decomp level is 1 less than # of variables. */

  return (result);

} /* end of BDS_VariableArray */

/**Function********************************************************************

  Synopsis    [Build hash table for each level.]

  Description [An edge(node) can appear in several hash tables, in case an edge
                spans more than one level. The function capture the precise information
                about 0-1 ADD. When the input is a BDD, it is used to find x-dominator,
                in which case only lower end of edges are important.]

  SideEffects []

  SeeAlso     []
 ******************************************************************************/
extern
edgeMark **
BDS_HeuristicEdgeMark(
 DdManager *bddmgr,
 DdNode *bdd,
 int *support,
 int level,
 int option,
 bdsOptions *choice) {
  int i, result, K, highLevel;
  st_table *visited;
  edgeMark **edgeProperty = NULL, *oneHash;
  DdNode *N;
  int new_level = 0;

  K = 5;

  N = Cudd_Regular(bdd);

  edgeProperty = ALLOC(edgeMark *, level);

  if (choice->heuristic == TRUE)
    new_level = level + 1;
  else
    new_level = level;

  /* Initialize a hash table for each level. */
  for (i = 0; i < new_level; i++) {
    oneHash = ALLOC(edgeMark, 1);
    oneHash->decompType = 0;
    oneHash->numSigmaOne = 0;
    oneHash->numSigmaZero = 0;
    oneHash->numNegative = 0;
    oneHash->bottom = NULL;
    oneHash->table = st_init_table(st_ptrcmp, st_ptrhash);
    oneHash->numIncident = 0;

    if (option == 1) {
      if (((i + 1) % K) == 0) {
        oneHash->k_feasible = 1;
      }
      if (((i + 1) % K) != 0) {
        oneHash->k_feasible = 0;
      }
      if (((i + 1) % (K - 1)) == 1) {
        oneHash->k_feasible = 1;
      }
      if (i == 0)
        oneHash->k_feasible = 1;
    } else {
      oneHash->k_feasible = 1;
    }

    if (oneHash->table == NULL) return (0);
    edgeProperty[i] = oneHash;
  }

  visited = st_init_table(st_ptrcmp, st_ptrhash);
  if (visited == NULL) return (0);

  result = BDS_HeuristicMarkEdgesRecursive(bddmgr, N, cuddT(N), visited, edgeProperty, support, level, choice);
  if (result == 0) return (0);

  result = BDS_HeuristicMarkEdgesRecursive(bddmgr, N, cuddE(N), visited, edgeProperty, support, level, choice);
  if (result == 0) return (0);

  st_free_table(visited);

  /* Sum up the number of negative edges. Exact number is not needed */
  for (i = 1; i < new_level; i++) {
    edgeProperty[i]->numNegative += edgeProperty[i - 1]->numNegative;
  }

  return (edgeProperty);

} /* end of BDS_MarkEdges */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_MarkEdges]

  Description [The distance between two DdNodes are measured, and all hash tables
  between this distance are enabled]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
extern
int
BDS_HeuristicMarkEdgesRecursive(
 DdManager *bddmgr,
 DdNode *hBdd,
 DdNode *lBdd,
 st_table *visited,
 edgeMark **edgeProperty,
 int *support,
 int level,
 bdsOptions *option) {
  int result, temp = 0;
  DdNode *Nh, *Nl;
  int incident;

  Nh = Cudd_Regular(hBdd);
  Nl = Cudd_Regular(lBdd);

  /* There is no need to put constant nodes into hash tables. The recursive program
     which dumps bddPool from 0-1 ADD will stop at constant nodes automatically.
   */
  result = BDS_HeuristicLevelHash(bddmgr, hBdd, lBdd, edgeProperty, support, level);
  if (result == 0) return (0);

  /* if lBdd is marked as visited, all edges below lBdd have been visited. */
  if (st_is_member(visited, (char *) Nl) == 1) {
    return (1);
  }

  if (!Cudd_IsConstant(Nl)) {

    if (option->heuristic == TRUE) {
      incident = support[Cudd_NodeReadIndex(Nl)];
      temp = edgeProperty[incident]->numIncident;
      edgeProperty[incident]->numIncident = temp + 1;
      /*printf("Level = %i\t Num = %i\n",level,edgeProperty[(incident-1)]->numIncident);*/
    }

    result = BDS_HeuristicMarkEdgesRecursive(bddmgr, Nl, cuddT(Nl), visited, edgeProperty, support, level, option);
    if (result == 0) return (0);

    result = BDS_HeuristicMarkEdgesRecursive(bddmgr, Nl, cuddE(Nl), visited, edgeProperty, support, level, option);
    if (result == 0) return (0);

    /* Mark lBdd as visited */
    if (st_add_direct(visited, (char *) Nl, NULL) == ST_OUT_OF_MEM) {
      return (0);
    }
  }

  return (1);

} /* end of BDS_MarkEdgesRecursive */

/**Function********************************************************************

  Synopsis    [Hash internal edges into corresponding hash tables]

  Description [This function works on both 0-1 ADD and BDD.]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
extern
int
BDS_HeuristicLevelHash(
 DdManager *bddmgr,
 DdNode *hBdd,
 DdNode *lBdd,
 edgeMark **edgeProperty,
 int *support,
 int level) {
  int i, highLevel, lowLevel, decompType;
  DdNode *background, *Nh, *Nl;

  Nh = Cudd_Regular(hBdd);
  Nl = Cudd_Regular(lBdd);
  background = bddmgr->background;
  highLevel = support[Cudd_NodeReadIndex(Nh)];

  if (Cudd_IsConstant(lBdd)) { /* Constant node processing */

    if (highLevel == level) { /* The cut is on the bottom of this BDD. */
      return (1);
    } else {
      if ((lBdd == background) || (lBdd == Cudd_ReadLogicZero(bddmgr))) {
        decompType = BDS_BDD_DECOMP_CONJ;
      } else if (lBdd == Cudd_ReadOne(bddmgr)) { /* 0-1 ADD and BDD share this node. */
        decompType = BDS_BDD_DECOMP_DISJ;
      }
      for (i = highLevel; i < level; i++) {
        edgeProperty[i]->decompType |= decompType;
        if (decompType == BDS_BDD_DECOMP_CONJ) { /* Sigma_0 */
          edgeProperty[i]->numSigmaZero++;
        } else if (decompType == BDS_BDD_DECOMP_DISJ) { /* Sigma_1 */
          edgeProperty[i]->numSigmaOne++;
        } else { /* not supported now */
          fail("This type is not supported now.");
        }
      }
      return (1);
    }
  } else { /* Internal nodes processing */
    lowLevel = support[Cudd_NodeReadIndex(Nl)];
    for (i = highLevel; i < lowLevel; i++) {
      if (Cudd_IsComplement(lBdd)) edgeProperty[i]->numNegative++;
      if (st_is_member(edgeProperty[i]->table, (char *) Nl) == 1) {
        continue;
      } else if (st_add_direct(edgeProperty[i]->table, (char *) Nl, NULL) == ST_OUT_OF_MEM) {
        return (0);
      }
      edgeProperty[i]->bottom = Nl; /* Store possible 0, 1 and x-dominators */
    }
    return (1);
  }

} /* end of BDS_LevelHash */

/**Function********************************************************************

  Synopsis    [Get the support of a BDD]

  Description [return support in the form of int*. result[id] = level. This function
  is called every time when a variable reordering is performed. The variable which
  is not on this BDD, it's level is marked as 0xFFFF.]

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
extern
int *
BDS_ChangeVariableArray(
 DdManager *bddmgr,
 DdNode *f,
 int BS,
 int FS) {
  DdNode *support, *var, *scan;
  int *result, j, k, id, temp_BS, temp_FS;

  support = Cudd_Support(bddmgr, f);
  if (support == NULL) return (NULL);
  cuddRef(support);

  /* A variable is unlikely to sit at this level
  result = ALLOC(int, bddmgr->size);
  for (k = 0; k < bddmgr->size; k++) {
      result[k] = 0xFFFF;
      } */

  /* Figure out result[id] = level information. */
  for (j = 0; j < bddmgr->size; j++) {
    id = Cudd_ReadInvPerm(bddmgr, j);
    scan = support;
    result[j] = id;
    if (scan->index == BS)
      temp_BS = id;
    if (scan->index == FS)
      temp_FS = id;
    //printf("BDD index = %i \t Iteration %i\t scan %i\n", id, j, scan->index);
    scan = cuddT(scan);
  }

  result[BS] = temp_FS;
  result[FS] = temp_BS;

  Cudd_RecursiveDeref(bddmgr, support);

  return (result);

} /* end of BDS_ChangeVariableArray */





/**Function********************************************************************

  Synopsis    [Starts the CUDD manager with the desired options.]

  Description []

  SideEffects [None]

  SeeAlso     []

 *****************************************************************************/
EXTERN
DdManager *
startCudd(
 bdsOptions * option,
 int nvars) {
  DdManager *dd;
  int result;
  dd = Cudd_Init(0, 0, option->slots, option->cacheSize, option->maxMemory); /// initial # BDD variables (subtables), # ZDD variables
  if (dd == NULL) return (NULL);
  Cudd_SetGroupcheck(dd, CUDD_GROUP_CHECK7);
  dd->nextDyn = DD_FIRST_REORDER;
  dd->countDead = FALSE;
  dd->maxGrowth = 1.0 + ((float) option->maxGrowth / 100.0);
  dd->recomb = DD_DEFAULT_RECOMB;
  dd->arcviolation = 10;
  dd->symmviolation = 10;
  dd->populationSize = 0;
  dd->numberXovers = 0;

#ifndef DD_STATS
  result = Cudd_EnableReorderingReporting(dd);
  if (result == 0) {
    (void) fprintf(stderr, "Error reported by Cudd_EnableReorderingReporting\n");
    Cudd_Quit(dd);
    return (NULL);
  }
#endif

  return (dd);

} /* end of startCudd */

/**Function********************************************************************

  Synopsis    [Build BDD Id vs. char* name association for local BDDs]

  Description [The assoc is invariant through out the rest process.
  Return value is a NULL-ended array. Return assoc if successful; NULL otherwise]

  SideEffects [None]

  SeeAlso     []

 *****************************************************************************/
extern
int
BDS_Extract_ArrivalTimesLocal(
 BnetNetwork *net,
 BnetNode *node,
 array_t *Nodes,
 int **permutation) {
  int i, no_inputs = 0;
  BnetNode *tempnode, *internode;
  lsGen fanins;
  int sort_on_depths();
  fanins = lsStart(node->fanins);
  while (lsNext(fanins, (lsGeneric *) & tempnode, NULL) != LS_NOMORE) {
    no_inputs++;
    array_insert_last(BnetNode *, Nodes, tempnode);
  }
  lsFinish(fanins);
  *permutation = ALLOC(int, no_inputs);
  array_sort(Nodes, sort_on_depths);
  for (i = 0; i < no_inputs; i++) {
    internode = array_fetch(BnetNode *, Nodes, i);
    /*printf("Depth = %i\n",internode->depth);*/
    (*permutation)[i] = internode->localVar;
  }
  return (1);
} /* end of BDS_Extract_ArrivalTimesLocal */

sort_on_depths(s1, s2)
BnetNode **s1;
BnetNode **s2;
{
  BnetNode *ssink1;
  BnetNode *ssink2;
  ssink1 = *s1;
  ssink2 = *s2;
  /*  if(ssink1->measure < ssink2->measure)  return (1);
  if(ssink1->measure > ssink2->measure)  return (-1);*/
  /*  1st line is -1 originally to get ascending sort*/
  if (ssink1->level < ssink2->level) return (-1);
  if (ssink1->level > ssink2->level) return ( 1);
  /*if(ssink1->depth < ssink2->depth) return (-1);
  if(ssink1->depth > ssink2->depth) return ( 1);*/
  return 0;
}
