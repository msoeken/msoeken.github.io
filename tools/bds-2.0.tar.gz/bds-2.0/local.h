
/**CHeaderFile*****************************************************************

  FileName    [local.h]

  PackageName [BDS-pga]

  Synopsis    [BDD decomposition-based logic optimization program]

  Description []

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#ifndef _DUMMYBDD
#define _DUMMYBDD

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "lopt.h"
#include "cuddInt.h"
#include "bnet.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

#define BDDPOOL_LOCAL_ONE  0xFFFF
#define BDDPOOL_LOCAL_ZERO 0xFFFE

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN DdNode * BDS_BuildDummyLocalBdd ARGS((DdManager*,SopPool*,BnetNode*,int**,int,bdsOptions*));
EXTERN SopPool * BDS_DumpSopLocal ARGS((DdManager*,DdNode*));
EXTERN int bdsConvertDummy2Real ARGS((FactorTreeNode*,int*,bdsOptions*));
EXTERN DdNode * BDS_BuildDDFromSopLocal ARGS((DdManager*,SopPool*,int*,bdsOptions*));
EXTERN bddPool * BDS_StoreBddPoolLocal ARGS((DdManager*,DdNode*));
EXTERN DdNode * BDS_BuildDDFromBddPoolLocal ARGS((DdManager*,bddPool*,int**,int,bdsOptions*,int**));
EXTERN DdNode * bdsBuildDDFromBddPoolLocalWithOutCreateDummy ARGS((DdManager*,bddPool*,int*));
EXTERN DdNode * BDS_BuildDDFromBddPoolLocalRecursive ARGS((DdManager*,bddNode*,int,int*));
EXTERN void bdsFreeBddPoolLocal ARGS((DdManager*,bddPool*));


#endif /* _DUMMYBDD */



