
/**CFile***********************************************************************

  FileName    [debug.c]

  PackageName [BDS-pga]

  Synopsis    [Debug utility for BDS]

  Description [The file contains a set of functions used for development purpose]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#include "lopt.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

static int bdsDumpBnodeArray ARGS((lsList,bdsOptions*,FILE*));
static void bdsNetwotkTraverseDebugRecursive ARGS((DdManager*,BnetNode*,st_table*));
EXTERN void net2dot ARGS((BnetNetwork*,FILE*));
///static void net2dot ARGS((BnetNetwork*,FILE*));

/**Function********************************************************************

  Synopsis    [Print out the structure and BDDs on an array of bnodes]

  Description []

  SideEffects []

  SeeAlso     []

  Last Date   [6/1/99]

*****************************************************************************/
extern
void
debugSharing(
  DdManager * bddmgr,
  lsList tobeExtracted,
  DdNode **bdd_array,
  bdsOptions *option)
{
  int   ret, numBdd, i;
  FILE  *dfp;
  char  *dumpfile, *file_head, *dot = ".dot", *blif = ".blif", *file_count, **onames;
  char  *dotfile,*blifile,*structfile,*dotdfp,*blifdfp,*structdfp;
  char  *bdd = "_bdd",*stu="_struct";
  static count;
  lsGen bnodeGen;
  BnetNode *bnode;

  numBdd = lsLength(tobeExtracted);
  onames = ALLOC(char*, numBdd);

  /* Create file names */
  dotfile = ALLOC(char, 100);
  blifile = ALLOC(char, 100);
  structfile = ALLOC(char, 100);
  dumpfile = ALLOC(char, 100);
  file_count = ALLOC(char, 6);

  sprintf(file_count, "_%d", count);

  file_head = BDS_GetFileHead(option->file);
  strcpy(dumpfile, file_head);
  strcat(dumpfile, file_count);

  strcpy(dotfile, dumpfile);
  strcpy(blifile, dumpfile);
  strcpy(structfile, dumpfile);

  strcat(dotfile, bdd);
  strcat(structfile, stu);

  strcat(dotfile, dot);
  strcat(structfile, dot);
  strcat(blifile, blif);

  /* Figure out output names */
  bnodeGen = lsStart(tobeExtracted);
  i = 0;
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
      onames[i] = bnode->name;
      i++;
  }
  lsFinish(bnodeGen);

  dotdfp = BDS_CreateFname(option,dotfile);
  dfp = fopen(dotdfp,"w");
  ret = Cudd_DumpDot(bddmgr,numBdd,bdd_array,NULL,onames,dfp);
  if (ret != 0) fclose(dfp);

  blifdfp = BDS_CreateFname(option,blifile);
  dfp = fopen(blifdfp,"w");
  ret = Cudd_DumpBlif(bddmgr,numBdd,bdd_array,NULL,onames,NULL,dfp,0);
  if (ret != 0) fclose(dfp);

  structdfp = BDS_CreateFname(option,structfile);
  dfp = fopen(structdfp,"w");
  ret = bdsDumpBnodeArray(tobeExtracted,option,dfp);
  if (ret != 0) fclose(dfp);

  FREE(file_head);FREE(dumpfile);FREE(file_count);FREE(dotdfp);FREE(blifdfp);
  FREE(dotfile);FREE(blifile);FREE(structfile);FREE(structdfp);

  count++;

} /* end of debugSharing */

/**Function********************************************************************

  Synopsis    [Print out the structure of an array of bnodes]

  Description [It is mainly used for sharing extraction debug.]

  SideEffects []

  SeeAlso     []

  Last Date   [6/1/99]

*****************************************************************************/
static
int
bdsDumpBnodeArray(
  lsList tobeExtracted,
  bdsOptions *option,
  FILE *fp)
{
  int i;
  BnetNode *POnode, *fanode, *bnode, *seed;
  st_table *printed;
  st_generator *gen;
  lsGen fanins, bnodeGen;

  /* Seed is the first item of the lsList */
  if (lsFirstItem(tobeExtracted, (lsGeneric *) &seed, NULL) != LS_OK) {
      printf("lsList retrieve fails in bdsDumpBnodeArray()");
      exit(2);
  }

  fprintf(fp,"// The file is generated by net2dot in University of Massachusetts\n");
  fprintf(fp,"//\n");

  /* Write header information */
  (void) fprintf(fp,"digraph \"struct\" {\n");
  (void) fprintf(fp, "size = \"7.5,10\"\ncenter = true;\nedge [dir = none];\n");

  /* Write output nodes */
  (void) fprintf(fp,"{ rank = same; node [shape = box]; edge [style = invis];\n");
  bnodeGen = lsStart(tobeExtracted);
  i = 0;
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
      (void) fprintf(fp,"\"  %s  \"", bnode->name);
      if (i == lsLength(tobeExtracted) - 1) {
          (void) fprintf(fp,"; }\n");
      } else {
          (void) fprintf(fp," -> ");
      }
      i++;
  }
  lsFinish(bnodeGen);

  /* Write outputs -> top nodes */
  bnodeGen = lsStart(tobeExtracted);
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
      (void) fprintf(fp,"\"  %s  \"", bnode->name);
      (void) fprintf(fp," -> \"%lx\" [style = solid];\n", ((long) bnode) / sizeof(BnetNode));
  }
  lsFinish(bnodeGen);

  /* Print all onodes and input nodes */
  printed = st_init_table(st_ptrcmp,st_ptrhash);
  bnodeGen = lsStart(tobeExtracted);
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
      if (st_is_member(printed, (char *) bnode)) {
          continue;
      }
      if (bnode == seed)
          (void) fprintf(fp,"\"%lx\" [label = \"%s\",color=red];\n",((long) bnode)/sizeof(BnetNode),bnode->name);
      else
          (void) fprintf(fp,"\"%lx\" [label = \"%s\"];\n",((long) bnode)/sizeof(BnetNode),bnode->name);
      st_add_direct(printed, (char *) bnode, (char *) NULL);
  }
  lsFinish(bnodeGen);

  bnodeGen = lsStart(tobeExtracted);
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
      fanins = lsStart(bnode->fanins);
      while (lsNext(fanins, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
          if (st_is_member(printed, (char *) fanode)) {
	      continue;
          }
	  (void) fprintf(fp,"\"%lx\" [label = \"%s\"];\n",((long) fanode)/sizeof(BnetNode),fanode->name);
	  st_add_direct(printed, (char *) fanode, (char *) NULL);
      }
      lsFinish(fanins);
  }
  lsFinish(bnodeGen);

  /* Print all edges */
  bnodeGen = lsStart(tobeExtracted);
  while (lsNext(bnodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
      fanins = lsStart(bnode->fanins);
      while (lsNext(fanins, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
          (void) fprintf(fp,"\"%lx\" -> \"%lx\";\n",((long) bnode)/sizeof(BnetNode),
                       ((long) fanode) / sizeof(BnetNode));
      }
      lsFinish(fanins);
  }
  lsFinish(bnodeGen);

  /* Write tail information. */
  (void) fprintf(fp,"}\n");

  st_free_table(printed);

  return(1);

} /* end of bdsDumpBnodeArray */

/**Function********************************************************************

  Synopsis    [Dump a BDD in both dot and blif format]

  Description [This is only used for debugging]

******************************************************************************/
extern
void
debugDump(
  DdManager *bddmgr,
  DdNode **bdd,
  float cost,
  bdsOptions *option,
  int count) ///pga
{
  int   ret, numBdd = 0;
  FILE  *dfp;
  char  *dumpfile, *file_head, *dot = ".dot", *blif = ".blif", *file_count, *decomp_cost;
  char  *dotfile, *blifile, *dotdfp, *blifdfp,*dmp = "dump";
  ///static count;  ///pga r
  DdNode **q;

  /*  for(q = bdd; *q; q++) { ///pga r
      numBdd++; ///pga r
  }*/ ///pga r

  numBdd = 1; ///pga

  printf("0 "); ///pga

  dotfile = ALLOC(char, 100);
  blifile = ALLOC(char, 100);
  dumpfile = ALLOC(char, 100);
  file_count = ALLOC(char, 6);
  decomp_cost = ALLOC(char, 6);

  sprintf(file_count, "_%d_", count);

  printf("1 "); ///pga

  if (cost != 0)
      sprintf(decomp_cost, "%-4.3f", cost);
  else
      strcpy(decomp_cost, dmp);

  printf("2 ");

  file_head = BDS_GetFileHead(option->file);
  strcpy(dumpfile, file_head);
  strcat(dumpfile, file_count);
  strcat(dumpfile, decomp_cost);

  strcpy(dotfile, dumpfile);
  strcpy(blifile, dumpfile);

  printf("3 "); ///pga

  strcat(dotfile, dot);
  strcat(blifile, blif);

  printf("4 "); ///pga

  dotdfp = BDS_CreateFname(option,dotfile);
  dfp = fopen(dotdfp,"w");

  printf("5 "); ///pga

  ret = Cudd_DumpDot(bddmgr,numBdd,bdd,NULL,NULL,dfp);
  if (ret != 0) fclose(dfp);

  printf("6 "); ///pga

  blifdfp = BDS_CreateFname(option,blifile);
  dfp = fopen(blifdfp,"w");

  ret = Cudd_DumpBlif(bddmgr,numBdd,bdd,NULL,NULL,NULL,dfp,0);
  if (ret != 0) fclose(dfp);

  FREE(file_head);FREE(dumpfile);FREE(file_count);FREE(dotdfp);FREE(blifdfp);
  FREE(dotfile);FREE(blifile);FREE(decomp_cost);

  count++;

} /* end of debugDump */

/**Function********************************************************************

  Synopsis    [Writes a dot file representing the argument DDs.]

  Description [This is only used for debugging]

******************************************************************************/
extern
void
dumpDot(
  DdManager * dd,
  DdNode *bdd)
{
    int         ret;
    FILE        *dfp;
    char        *filename, *f, *suffix = ".dot", *fileHead = "0x";

    /* Geneate filename */
    f = ALLOC(char, 8);
    filename = ALLOC(char, 20);
    strcpy(filename, fileHead);
    sprintf(f, "%lx", (unsigned long) bdd);
    strcat(filename, f);
    strcat(filename, suffix);
    dfp = fopen(filename, "w");

    ret = Cudd_DumpDot(dd,1,&bdd,NULL,NULL,dfp);

    fclose(dfp);

} /* end of dumpDot */

/**Function********************************************************************

  Synopsis    [Check if the decomposition is right]

  Description [This is only used for debugging]

******************************************************************************/
extern
int
bdsDecompCheck(
  DdManager *bddmgr,
  DdNode *refBdd,       /* The BDD to be decomposed */
  int operator,
  DdNode *dpBdd,
  DdNode *dmBdd)
{
  int result;
  DdNode *compareBdd;

  switch(operator) {
  case BDS_BDD_AND:
      compareBdd = Cudd_bddAnd(bddmgr, dpBdd, dmBdd);
      if (compareBdd == NULL) fail("Wrong decomposition");
      Cudd_Ref(compareBdd);
      break;
  case BDS_BDD_OR:
      compareBdd = Cudd_bddOr(bddmgr, dpBdd, dmBdd);
      if (compareBdd == NULL) fail("Wrong decomposition");
      Cudd_Ref(compareBdd);
      break;
  case BDS_BDD_XOR:
      compareBdd = Cudd_bddXor(bddmgr, dpBdd, dmBdd);
      if (compareBdd == NULL) fail("Wrong decomposition");
      Cudd_Ref(compareBdd);
      break;
  case BDS_BDD_XNOR:
      compareBdd = Cudd_bddXnor(bddmgr, dpBdd, dmBdd);
      if (compareBdd == NULL) fail("Wrong decomposition");
      Cudd_Ref(compareBdd);
      break;
  default:
      fail("Unknown operator in bdsDecompCheck");
  }

  if (refBdd != compareBdd) {
      Cudd_RecursiveDeref(bddmgr,compareBdd);
      return(0);
  }
  Cudd_RecursiveDeref(bddmgr,compareBdd);
  return(1);

} /* end of bdsDecompCheck */

/**Function********************************************************************

  Synopsis    [Print out a BDD in the debugger]

  Description [This is only used for debugging]

******************************************************************************/
extern
void
db(
  DdManager *mgr,
  DdNode *bdd)
{
  Cudd_PrintDebug(mgr,bdd,1,3);

} /* end of db */

/**Function********************************************************************

  Synopsis    [Print the total reference count in the BDD mgr]

  Description [This is only used for debugging]

******************************************************************************/
extern
int
ref(
  DdManager *bddmgr)
{
  return(Cudd_CheckZeroRef(bddmgr));

} /* end of ref */

/**Function********************************************************************

  Synopsis    [Perform BDD manager checking.]

******************************************************************************/
extern
void
cuddCheck(
  DdManager *bddmgr,
  char *function,
  int position)
{
  if (Cudd_DebugCheck(bddmgr) && (!Cudd_CheckKeys(bddmgr))) {
      printf("BDD manager check failed in function %s, position #%d.\n", function, position);
      fail("BDD manager checking failed.");
  }

} /* end of cuddCheck */

/**Function********************************************************************

  Synopsis    [Writes a dot file representing an ftree]

  Description [This is only used for debugging]

******************************************************************************/
extern
void
dumpfdot(
  FactorTreeNode **fnode_array,
  char **PIvariables)
{
  st_table    *visited = NULL;
  st_generator *gen = NULL;
  int         result;
  int         i, j, totalfnode = 0;
  FactorTreeNode *top, *dp, *dm, *ctl, *fnode;
  FactorTreeNode **q;
  char *operator;

  FILE        *fp;
  char        *filename, *suffix = ".dot", *fileHead = "FTREE";

  /* Geneate filename */
  filename = ALLOC(char, 20);
  strcpy(filename, fileHead);
  strcat(filename, suffix);
  fp = fopen(filename, "w");

  /* Built operator char */
  operator = ALLOC(char,8);
  strcpy(operator, "z*+^@M");

  /* Initialize symbol table for visited nodes. */
  visited = st_init_table(st_ptrcmp, st_ptrhash);

  /* Collect all the nodes on the ftrees */
  for (q = fnode_array; *q; q++) {
      result = bdsCollectFNodes(visited, *q);
      totalfnode++;
  }

  fprintf(fp,"// The file is generated by %s\n",BDS_VERSION);
  fprintf(fp,"//\n");

  /* Write header information */
  result = fprintf(fp,"digraph \"ftree\" {\n");
  result = fprintf(fp,
      "size = \"7.5,10\"\ncenter = true;\nedge [dir = none];\n");

  /* Write output fnodes */
  result = fprintf(fp,"{ rank = same; node [shape = box]; edge [style = invis];\n");

  i = 0;
  for (q = fnode_array; *q; q++) {
      result = fprintf(fp,"\"ftree#%d\"", i);
      if (i == totalfnode - 1) {
          result = fprintf(fp,"; }\n");
      } else {
          result = fprintf(fp," -> ");
      }
      i++;
  }

  /* Write outputs -> ftree */
  i = 0;
  for (q = fnode_array; *q; q++) {
      result = fprintf(fp,"\"ftree#%d\"", i);
      if (Fnode_IsComplement(*q)) {
          result = fprintf(fp," -> \"%lx\" [style = dashed];\n",
                ((long) *q) / sizeof(FactorTreeNode));
      } else {
          result = fprintf(fp," -> \"%lx\" [style = solid];\n",
                ((long) *q) / sizeof(FactorTreeNode));
      }
      i++;
  }

  /* Write edges between internal fnodes */
  gen = st_init_gen(visited);
  while (st_gen(gen, (char **) &fnode, NULL)) {
      top = Fnode_Regular(fnode);
      if (Fnode_Regular(fnode)->value != BDS_FTREE_INTERNAL) { /* A terminal */
          if (top->polarity == 0) {
	      if (PIvariables != NULL) {
                  result = fprintf(fp,"\"%lx\" [shape = plaintext, label = \"!%s\"];\n",
                        ((long) fnode) / sizeof(FactorTreeNode),
                        PIvariables[top->value]);
	      }
	      else {
                  result = fprintf(fp,"\"%lx\" [shape = plaintext, label = \"!%d\"];\n",
                        ((long) fnode) / sizeof(FactorTreeNode), top->value);
	      }
          }
          else {
	      if (PIvariables != NULL) {
                  result = fprintf(fp,"\"%lx\" [shape = plaintext, label = \"%s\"];\n",
                        ((long) fnode) / sizeof(FactorTreeNode),
                        PIvariables[top->value]);
              }
	      else {
                  result = fprintf(fp,"\"%lx\" [shape = plaintext, label = \"%d\"];\n",
                        ((long) fnode) / sizeof(FactorTreeNode), top->value);
	      }
          }
          continue;
      }

      if (top->polarity == 0) {
          result = fprintf(fp,"\"%lx\" [style = dashed, \
                label = \"%x \\n%c\"];\n", ((long) fnode) / sizeof(FactorTreeNode),
                 (unsigned) fnode,
                operator[top->op]);
      }
      else {
            result = fprintf(fp,"\"%lx\" [ \
                label = \"%x \\n%c\"];\n", ((long) fnode) / sizeof(FactorTreeNode),
                (unsigned) fnode,
                operator[top->op]);
      }

      dp = fnode->siblings[0];
      dm = fnode->siblings[1];
      if (top->op == BDS_BDD_MUX) {
          ctl = fnode->siblings[2];
      }

      /* Print dp */
      if (Fnode_IsComplement(dp)) {
          result = fprintf(fp,
                "\"%lx\" -> \"%lx\" [style = dashed];\n",
                ((long) fnode) / sizeof(FactorTreeNode),
                ((long) dp) / sizeof(FactorTreeNode));
      } else {
          result = fprintf(fp,
                "\"%lx\" -> \"%lx\";\n",
                ((long) fnode) / sizeof(FactorTreeNode),
                ((long) dp) / sizeof(FactorTreeNode));
      }

      /* Print dm */
      if (Cudd_IsComplement(dm)) {
          result = fprintf(fp,
                "\"%lx\" -> \"%lx\" [style = dashed];\n",
                ((long) fnode) / sizeof(FactorTreeNode),
                ((long) dm) / sizeof(FactorTreeNode));
      } else {
          result = fprintf(fp,
                 "\"%lx\" -> \"%lx\";\n",
                 ((long) fnode) / sizeof(FactorTreeNode),
                 ((long) dm) / sizeof(FactorTreeNode));
      }

      /* Print ctl if MUX, control signal is marked by a black dot */
      if (top->op == BDS_BDD_MUX) {
          if (Cudd_IsComplement(ctl)) {
              result = fprintf(fp,
                    "\"%lx\" -> \"%lx\" [style = dashed, arrowhead = none, arrowtail = dot];\n",
                    ((long) fnode) / sizeof(FactorTreeNode),
                    ((long) ctl) / sizeof(FactorTreeNode));
          } else {
              result = fprintf(fp,
                     "\"%lx\" -> \"%lx\" [arrowhead = none, arrowtail = dot];\n",
                     ((long) fnode) / sizeof(FactorTreeNode),
                     ((long) ctl) / sizeof(FactorTreeNode));
          }
      }

  } /* end of while loop */

  st_free_gen(gen); gen = NULL;

  /* Write trailer and return. */
  result = fprintf(fp,"}\n");

  st_free_table(visited);
  FREE(operator);

  fclose(fp);

} /* end of dumpfdot */

/**Function********************************************************************

  Synopsis    [Traverse on network]

  Description [This is only used for debugging]

******************************************************************************/
extern
void
bdsNetwotkTraverseDebug(
  DdManager *bddmgr,
  BnetNetwork *net)
{
  st_table *visited;
  BnetNode *node;
  int i;

  visited = st_init_table(st_ptrcmp,st_ptrhash);

  for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash,net->outputs[i],(char **) &node)) {
            continue;
      }
      bdsNetwotkTraverseDebugRecursive(bddmgr,node,visited);
  }

  st_free_table(visited);

} /* end of bdsNetwotkTraverseDebug */

/**Function********************************************************************

  Synopsis    [Recursive program for bdsNetwotkTraverseDebug]

  Description [This is only used for debugging]

******************************************************************************/
static
void
bdsNetwotkTraverseDebugRecursive(
  DdManager *bddmgr,
  BnetNode *node,
  st_table *visited)
{
  lsGen fanins;
  BnetNode *fanode;

  if (node->type == BNET_CONSTANT_NODE) return;
  if (node->type == BNET_INPUT_NODE) return;

  if (st_is_member(visited, (char *) node)) return;

  /* Traverse dfs to the PIs */
  fanins = lsStart(node->fanins);
  while (lsNext(fanins, (lsGeneric *)&fanode, NULL) == LS_OK) {
      bdsNetwotkTraverseDebugRecursive(bddmgr,fanode,visited);
  }
  lsFinish(fanins);

  if (st_add_direct(visited, (char *) node, (char *) NULL) == ST_OUT_OF_MEM) {
      printf("Out of memory"); return;
  }

  return;

} /* end of bdsNetwotkTraverseDebugRecursive */

/**Function********************************************************************

  Synopsis    [Print network]

  Description [This is only used for debugging]

******************************************************************************/
extern
void
netPrint(
  BnetNetwork *net,
  bdsOptions* option)
{
  char *dumpfile;
  FILE *fp;

  /* Generate file name */
  dumpfile = BDS_CreateFname(option, "eliminate.dot");
  fp = fopen(dumpfile, "w");

  /* Print the blif in DOT format */
  (void) net2dot(net, fp);

  fclose(fp);
  FREE(dumpfile);

  return;

} /* end of netPrint */


/**Function********************************************************************

  Synopsis    [Print network]

  Description [This is only used for debugging]

******************************************************************************/
///static
extern
void
net2dot(
  BnetNetwork *net,
  FILE *fp)
{
  int i;
  BnetNode *POnode, *node, *fanode;
  st_generator *gen;
  lsGen fanins;

  fprintf(fp,"// The file is generated by net2dot in University of Massachusetts\n");
  fprintf(fp,"//\n");

  /* Write header information */
  (void) fprintf(fp,"digraph \"blif\" {\n");
  (void) fprintf(fp, "size = \"7.5,10\"\ncenter = true;\nedge [dir = none];\n");

  /* Write output nodes */
  (void) fprintf(fp,"{ rank = same; node [shape = box]; edge [style = invis];\n");
  for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash,net->outputs[i],(char **) &POnode)) {
          exit(2);
      }
      if (POnode->name == NULL) {
          (void) fprintf(fp,"\"F%d\"", i);
      } else {
          (void) fprintf(fp,"\"  %s  \"", POnode->name);
      }
      if (i == net->npos - 1) {
          (void) fprintf(fp,"; }\n");
      } else {
          (void) fprintf(fp," -> ");
      }
  }

  /* Write outputs -> nodes */
  for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash,net->outputs[i],(char **) &POnode)) {
          exit(2);
      }
      if (POnode->name == NULL) {
          (void) fprintf(fp,"\"F%d\"", i);
      } else {
          (void) fprintf(fp,"\"  %s  \"", POnode->name);
      }

      (void) fprintf(fp," -> \"%lx\" [style = solid];\n", ((long) POnode) / sizeof(BnetNode));
  }

  /* Write other nodes */
  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &node, NULL)) {
      if (node->type == BNET_CONSTANT_NODE) {
          if (node->f == NULL) {
              (void) fprintf(fp,"\"%lx\" [shape = plaintext, label = \"0\"];\n",
                ((long) node) / sizeof(BnetNode));
          }
          else {
              (void) fprintf(fp,"\"%lx\" [shape = plaintext, label = \"1\"];\n",
                ((long) node) / sizeof(BnetNode));
          }
      }

      if (node->type == BNET_INPUT_NODE) {
          (void) fprintf(fp,"\"%lx\" [shape = plaintext, label = \"%s\"];\n",
                        ((long) node) / sizeof(BnetNode),node->name);
      }

      if (node->type == BNET_INTERNAL_NODE || node->type == BNET_OUTPUT_NODE) {

	if (node->crit_node == 1) { /*If this is a critical node */ ///pga
	  /* Print this node first, then all its fanins */ ///pga
          (void) fprintf(fp,"\"%lx\" [label = \"*%s %d *\"];\n",((long) node)/sizeof(BnetNode),node->name,node->depth); ///pga
	} ///pga
	else { ///pga
	  /* Print this node first, then all its fanins */
          (void) fprintf(fp,"\"%lx\" [label = \"%s %d \"];\n",((long) node)/sizeof(BnetNode),node->name,node->depth); ///pga added last 1
	}
	  fanins = lsStart(node->fanins);
	  while (lsNext(fanins, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
              (void) fprintf(fp,"\"%lx\" -> \"%lx\";\n",((long) node)/sizeof(BnetNode),
                       ((long) fanode) / sizeof(BnetNode));
          }
	  lsFinish(fanins);
      }
  }
  st_free_gen(gen);

  /* Write tail information. */
  (void) fprintf(fp,"}\n");

  return;

} /* end of net2dot */

/**Function********************************************************************

  Synopsis    [Print network]

  Description [This is only used for debugging]

******************************************************************************/
extern
DdNode
reg(DdNode *bdd)
{
  return(*Cudd_Regular(bdd));

} /* end of bp */


