
/**CHeaderFile*****************************************************************

  FileName    [bnet.h]

  PackageName [bnet]

  Synopsis    [Simple-minded package to read a blif file.]

  Description []

  SeeAlso     []

  Author      [Fabio Somenzi]

  Copyright   [This file was created at the University of Colorado at
  Boulder.  The University of Colorado at Boulder makes no warranty
  about the suitability of this software for any purpose.  It is
  presented on an AS IS basis.]

  Revision    [$Id: bnet.h,v 1.9 1997/10/09 05:28:16 fabio Exp $
  Several new fields are added in BnetNode struct. -cyang 3/22/99]

******************************************************************************/

#ifndef _BNET
#define _BNET

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "util.h"
#include "st.h"
#include "list.h"
#include "cudd.h"
#include "cuddInt.h"
/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/* Different types of nodes. (Used in the "BnetNode" type.) */
#define BNET_CONSTANT_NODE 0
#define BNET_INPUT_NODE 1
#define BNET_PRESENT_STATE_NODE 2
#define BNET_INTERNAL_NODE 3
#define BNET_OUTPUT_NODE 4
#define BNET_NEXT_STATE_NODE 5

/* Type of DD of a node. */
#define BNET_LOCAL_DD 0
#define BNET_GLOBAL_DD 1

#define LIVE_BNODE 0xFFFF
#define DEAD_BNODE 0xFFF0

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/* The following types implement a very simple data structure for a boolean
** network. The intent is to be able to read a minimal subset of the blif
** format in a data structure from which it's easy to build DDs for the
** circuit.
*/

/* Type to store a line of the truth table of a node. The entire truth table
** implemented as a linked list of objects of this type.
*/
typedef struct BnetTabline {
    char *values;		/* string of 1, 0, and - */
    struct BnetTabline *next;	/* pointer to next table line */
} BnetTabline;

/* Node of the boolean network. There is one node in the network for each
** primary input and for each .names directive. This structure
** has a field to point to the DD of the node function. The function may
** be either in terms of primary inputs, or it may be in terms of the local
** inputs. The latter implies that each node has a variable index
** associated to it at some point in time. The field "var" stores that
** variable index, and "active" says if the association is currently valid.
** (It is indeed possible for an index to be associated to different nodes
** at different times.)
*/
typedef struct BnetNode {
    char *name;		/* name of the output signal */
    int type;		/* input, internal, constant, ... */
    int ninp;		/* number of inputs to the node */
    int nfo;		/* number of fanout nodes for this node */
    char **inputs;	/* input names */
    BnetTabline *f;	/* truth table for this node */
    int polarity;	/* f is the onset (0) or the offset (1) */
    int active;		/* node has variable associated to it (1) or not (0) */
    int var;		/* DD variable index associated to this node */
    DdNode *dd;		/* decision diagram for the function of this node */
    int exdc_flag;	/* whether an exdc node or not */
    struct BnetNode *exdc; /* pointer to exdc of dd node */
    int count;		/* auxiliary field for DD dropping */
    int level;		/* maximum distance from the inputs */
    int visited;	/* flag for search */
    struct BnetNode *next; /* pointer to implement the linked list of nodes */

/* The following fields are added by -cyang 3/22/99 */
    lsList fanins;	/* fanins in the lsList format */
    lsList fanouts;	/* fanouts in lsList format */
    int localVar;	/* var for local BDDs, see var above */
    int localActive;    /* If a var has been created for the local var, see active above */
    DdNode *localBdd;	/* local BDD, see dd above */
    DdNode *tmpBdd;     /* Used for calculating elimination gain */
    int	aux;		/* for misc. use */

  /* The following fields are added by nvemuri 12/06/99 */
    struct BnetNode **inpnode; /* Added by Navin 12/06/99. Ptr to input nodes */
  int no_inputs; /* Added by Navin 04/22/00 */
  int depth;  /* Added by Navin 04/03/00 */
  int no_outputs; /* Added by Navin 04/03/00 */
  int updated_inputs; /* Added by Navin 04/22/00 */
  int executeornot; /* 04/23/00 */
  int checked; /* 04/23/00 */
  int prev_highest; /* 04/24/00 */
  int crit_node; /* 04/24/00 */
  int collapsed; /* 04/25/00 */

} BnetNode;

/* Very simple boolean network data structure. */
typedef struct BnetNetwork {
    char *name;		/* network name: from the .model directive */
    int npis;		/* number of primary inputs */
    int ninputs;	/* number of inputs */
    char **inputs;	/* primary input names: from the .inputs directive */
    int npos;		/* number of primary outputs */
    int noutputs;	/* number of outputs */
    char **outputs;	/* primary output names: from the .outputs directive */
    int nlatches;	/* number of latches */
    char ***latches;	/* next state names: from the .latch directives */
    BnetNode *nodes;	/* linked list of the nodes */
    st_table *hash;	/* symbol table to access nodes by name */
    char *slope;	/* wire_load_slope */

/* The following fields are added by -cyang 3/22/99 */
    st_table *livenodes; /* Current nodes on the network */
} BnetNetwork;

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/* Define by -cyang 6/6/99 */
#define bnode_Regular(node) ((BnetNode *)((unsigned long)(node) & ~01))
#define bnode_Complement(node) ((BnetNode *)((unsigned long)(node) | 01))
#define bnode_IsComplement(node) ((int) ((long) (node) & 01))


/* These are potential duplicates. */
#ifndef EXTERN
#   ifdef __cplusplus
#	define EXTERN extern "C"
#   else
#	define EXTERN extern
#   endif
#endif
#ifndef ARGS
#   if defined(__STDC__) || defined(__cplusplus)
#	define ARGS(protos)	protos		/* ANSI C */
#   else /* !(__STDC__ || __cplusplus) */
#	define ARGS(protos)	()		/* K&R C */
#   endif /* !(__STDC__ || __cplusplus) */
#endif

#ifndef TRUE
#   define TRUE 1
#endif
#ifndef FALSE
#   define FALSE 0
#endif

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN BnetNetwork * Bnet_ReadNetwork ARGS((FILE *fp, int pr));
EXTERN BnetNetwork* build_net ARGS((int numvar, int *vars, int size));
EXTERN BnetNetwork* special_copy_net ARGS (( int *c_vars, int c_numvar,int *d_vars, int d_numvar, int size ));

EXTERN void Bnet_PrintNetwork ARGS((BnetNetwork *net));
/*EXTERN int BDS_PrintModifiedNetwork ARGS((BnetNetwork *net, DdManager *bddmgr, bdsOptions *option));*/
EXTERN void Bnet_FreeNetwork ARGS((BnetNetwork *net));
EXTERN int Bnet_BuildNodeBDD ARGS((DdManager *dd, BnetNode *nd, st_table *hash, int params, int nodrop));
EXTERN int Bnet_DfsVariableOrder ARGS((DdManager *dd, BnetNetwork *net));
EXTERN int Bnet_bddDump ARGS((DdManager *dd, BnetNetwork *network, char *dfile, int dumpFmt, int reencoded));
EXTERN int Bnet_bddArrayDump ARGS((DdManager *dd, BnetNetwork *network, char *dfile, DdNode **outputs, char **onames, int noutputs, int dumpFmt));
EXTERN int Bnet_ReadOrder ARGS((DdManager *dd, char *ordFile, BnetNetwork *net, int locGlob, int nodrop));



/* Function added here for convenience. -cyang 6/9/99. */

EXTERN char * bdsCreateUniqueNodeName ARGS((char*));
EXTERN int bdsUniqueBnetNode ARGS((lsGeneric,lsGeneric));
EXTERN void bdsFreeBnetNode ARGS((DdManager*,BnetNode*));


/**AutomaticEnd***************************************************************/

#endif /* _BNET */














