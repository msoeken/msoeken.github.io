/*************************************************************************
	-----------------------------------------------------
           		Copyright 2002, 
	   University of Massachusetts, Amherst. 
	-----------------------------------------------------

This package was created at the University of Massachusetts, Amherst. 
The University of Massachusetts makes no warranty about the suitability 
of this software for any purpose. It is presented on an "as is" basis.

CONDITIONS:

The use of software for commercial purposes is strictly forbidden
without a written consent from its authors or the University of 
Massachusetts, Amherst.

**************************************************************************/
/**CFile***********************************************************************

  FileName    [loptUtil.c]

  PackageName [BDS]

  Synopsis    [Utility functions for lopt]

  Description []

  SeeAlso     []

  Author      [Anda Congguang Yang]

  Copyright   [The file was created in Department of Electrical & Computer
	Engineering, University of Massachusetts Amherst. All source codes
	in BDS package are CONFIDENTIAL before a formal release is
	announced. The author reserve all right of the package.]

******************************************************************************/

#include "lopt.h"
#ifdef _WINDOWS
#include "winfake.h"
#else
#include <sys/utsname.h>
#endif

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static int BDS_LevelHash ARGS((DdManager*,DdNode*,DdNode*,edgeMark**,int*,int)); 
static int BDS_MarkEdgesRecursive ARGS((DdManager*,DdNode*,DdNode*,st_table*,edgeMark**,int*,int));
static int BDS_DumpSOPRecursive ARGS((DdManager*,DdNode*,int*,array_t*));
static int BDS_DumpSopAtLevelRecursive ARGS((DdManager*,DdNode*,edgeMark*,int*,array_t**,int));
static int BDS_DumpBddBlifRecursive ARGS((DdManager*,DdNode*,int*,FILE*));
static char * BDS_CreateRunDir ARGS((bdsOptions*));
static int BDS_GetNegativeRecursive ARGS((DdManager*,DdNode*,DdNode*,st_table*,int*,st_table*));
static int BDS_CountRefRecursive ARGS((DdManager*,DdNode*,st_table*,st_table*));

/**Function********************************************************************

  Synopsis    [Build hash table for each level.]

  Description [An edge(node) can appear in several hash tables, in case an edge
                spans more than one level. The function capture the precise information
                about 0-1 ADD. When the input is a BDD, it is used to find x-dominator,
                in which case only lower end of edges are important.]

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
edgeMark **
BDS_MarkEdges(
  DdManager *bddmgr, 
  DdNode *bdd, 
  int *support,
  int level)
{
  int i, result;
  st_table *visited;
  edgeMark **edgeProperty = NULL, *oneHash;
  DdNode *N;

  if (level < 0) fail ("level negative\n");

  N = Cudd_Regular(bdd);
  edgeProperty = ALLOC(edgeMark *, level);

  /* Initialize a hash table for each level. */
  for (i = 0; i < level; i++) {
      oneHash = ALLOC(edgeMark, 1);
      oneHash->decompType = 0;
      oneHash->numSigmaOne = 0;
      oneHash->numSigmaZero = 0;
      oneHash->numNegative = 0;
      oneHash->bottom = NULL;
      oneHash->table = st_init_table(st_ptrcmp,st_ptrhash);
      if (oneHash->table == NULL) return (0);
      edgeProperty[i] = oneHash;
  } 

  visited = st_init_table(st_ptrcmp,st_ptrhash);
  if (visited == NULL) return (0);
  
  result = BDS_MarkEdgesRecursive(bddmgr,N,cuddT(N),visited,edgeProperty,support,level);
  if (result == 0) return(0);

  result = BDS_MarkEdgesRecursive(bddmgr,N,cuddE(N),visited,edgeProperty,support,level);
  if (result == 0) return(0);
      
  st_free_table(visited);

  /* Sum up the number of negative edges. Exact number is not needed */
  for (i = 1; i < level; i++) {
      edgeProperty[i]->numNegative += edgeProperty[i-1]->numNegative;
  }

  return(edgeProperty);

} /* end of BDS_MarkEdges */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_MarkEdges]

  Description [The distance between two DdNodes are measured, and all hash tables
                between this distance are enabled]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
static
int
BDS_MarkEdgesRecursive(
  DdManager *bddmgr, 
  DdNode *hBdd, 
  DdNode *lBdd,
  st_table *visited, 
  edgeMark **edgeProperty, 
  int *support,
  int level) 
{
  int result;
  DdNode *Nh, *Nl;

  Nh = Cudd_Regular(hBdd);
  Nl = Cudd_Regular(lBdd);

  /* There is no need to put constant nodes into hash tables. The recursive program
     which dumps bddPool from 0-1 ADD will stop at constant nodes automatically. 
  */
  result = BDS_LevelHash(bddmgr, hBdd, lBdd, edgeProperty, support, level);
  if (result == 0) return(0);

  /* if lBdd is marked as visited, all edges below lBdd have been visited. */
  if (st_is_member(visited, (char *) Nl) == 1) {
      return(1);
  }

  if (!Cudd_IsConstant(Nl)) {
      result = BDS_MarkEdgesRecursive(bddmgr,Nl,cuddT(Nl),visited,edgeProperty,support,level);
      if (result == 0) return(0);

      result = BDS_MarkEdgesRecursive(bddmgr,Nl,cuddE(Nl),visited,edgeProperty,support,level);
      if (result == 0) return(0);

      /* Mark lBdd as visited */
      if (st_add_direct(visited, (char *) Nl, NULL) == ST_OUT_OF_MEM) {
          return(0);
      }
  }

  return(1);

} /* end of BDS_MarkEdgesRecursive */

/**Function********************************************************************

  Synopsis    [Hash internal edges into corresponding hash tables]

  Description [This function works on both 0-1 ADD and BDD.]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
static
int
BDS_LevelHash(
  DdManager *bddmgr, 
  DdNode *hBdd, 
  DdNode *lBdd, 
  edgeMark **edgeProperty,
  int *support,
  int level)
{
  int i, highLevel, lowLevel, decompType;
  DdNode *background, *Nh, *Nl;
  
  Nh = Cudd_Regular(hBdd);
  Nl = Cudd_Regular(lBdd);
  background = bddmgr->background;
  highLevel = support[Cudd_NodeReadIndex(Nh)];

  if (Cudd_IsConstant(lBdd)) { /* Constant node processing */

      if (highLevel == level) { /* The cut is on the bottom of this BDD. */
          return(1);
      }
      else {
          if ((lBdd == background) || (lBdd == Cudd_ReadLogicZero(bddmgr))) {
              decompType = BDS_BDD_DECOMP_CONJ;}
          else if (lBdd == Cudd_ReadOne(bddmgr)) { /* 0-1 ADD and BDD share this node. */
              decompType = BDS_BDD_DECOMP_DISJ;
          } 
          for (i = highLevel; i < level; i++) {
              edgeProperty[i]->decompType |= decompType;
              if (decompType == BDS_BDD_DECOMP_CONJ) { /* Sigma_0 */
                  edgeProperty[i]->numSigmaZero ++;}
              else if (decompType == BDS_BDD_DECOMP_DISJ) { /* Sigma_1 */
                  edgeProperty[i]->numSigmaOne ++;}
              else { /* not supported now */
                  fail("This type is not supported now.");
              }
          }
          return(1);
      }
  }
  else { /* Internal nodes processing */
      lowLevel = support[Cudd_NodeReadIndex(Nl)];
      for (i = highLevel; i < lowLevel; i++) {
	  if (Cudd_IsComplement(lBdd)) edgeProperty[i]->numNegative++;
          if (st_is_member(edgeProperty[i]->table, (char *) Nl) == 1) {
             continue;
          }
          else if (st_add_direct(edgeProperty[i]->table, (char *) Nl, NULL) == ST_OUT_OF_MEM) {
             return(0);
          }
          edgeProperty[i]->bottom = Nl; /* Store possible 0, 1 and x-dominators */
      }
      return(1);
  }

} /* end of BDS_LevelHash */

/**Function********************************************************************

  Synopsis    [Get number of negative edges on a BDD]

  Description [Return number of internal negative edges. Negative edges to leaf
	nodes will not be counted.]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
extern
int
BDS_GetNegative(
  DdManager *bddmgr, 
  DdNode *bdd,
  int count)
{
  int neg = 0, result, *ref;
  st_table *visited, *countRef;
  DdNode *N, *f;
  st_generator *gen;

  if (count == 0) 
      countRef = NULL;
  else
      countRef = BDS_CountRef(bddmgr,bdd);

  N = Cudd_Regular(bdd);

  visited = st_init_table(st_ptrcmp,st_ptrhash);
  if (visited == NULL) return (0);
  
  result = BDS_GetNegativeRecursive(bddmgr,N,cuddT(N),visited,&neg,countRef);
  if (result == 0) return(0);

  result = BDS_GetNegativeRecursive(bddmgr,N,cuddE(N),visited,&neg,countRef);
  if (result == 0) return(0);
      
  st_free_table(visited);
  if (count != 0) {
      gen = st_init_gen(countRef);
      while (st_gen(gen, (char **) &f, (char **) &ref)) {
	   FREE(ref);
      }
      st_free_gen(gen);
      st_free_table(countRef);
  }

  return(neg);

} /* end of BDS_MarkEdges */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_GetNegative]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
static
int
BDS_GetNegativeRecursive(
  DdManager *bddmgr, 
  DdNode *parent,
  DdNode *bdd, 
  st_table *visited,
  int *neg,
  st_table *countRef)
{
  int result, ref, *ref_ptr;
  DdNode *N;

  N = Cudd_Regular(bdd);

  if (!Cudd_IsConstant(N)) {

      if (countRef == NULL) {
          ref = N->ref;
      }
      else {
          if (!st_lookup(countRef, (char *) N, (char **) &ref_ptr)) {
	      printf("Can not find out reference count !\n");
	      exit(2);
          }
          ref = *ref_ptr;
      }

      if ((Cudd_IsComplement(bdd) && !BDS_IsLeafNode(parent)) ||
               (Cudd_IsComplement(bdd) && BDS_IsLeafNode(parent) && ref > 1))
	  (*neg)++;

      /* if N is marked as visited, all edges below bdd have been visited. */
      if (st_is_member(visited, (char *) N) == 1) {
          return(1);
      }

      result = BDS_GetNegativeRecursive(bddmgr,N,cuddT(N),visited,neg,countRef);
      if (result == 0) return(0);

      result = BDS_GetNegativeRecursive(bddmgr,N,cuddE(N),visited,neg,countRef);
      if (result == 0) return(0);

      /* Mark bdd as visited */
      if (st_add_direct(visited, (char *) N, NULL) == ST_OUT_OF_MEM) {
          return(0);
      }
  }

  return(1);

} /* end of BDS_GetNegativeRecursive */

/**Function********************************************************************

  Synopsis    [Count the reference number for a specific bdd]

  Description [Return st_table* if successful; NULL otherwise]

  SideEffects [None]

  SeeAlso     []

******************************************************************************/
extern
st_table *
BDS_CountRef(
  DdManager *bddmgr,
  DdNode *bdd)
{
  int i, result, *ref;
  st_table *visited, *countRef;
  DdNode *N;

  N = Cudd_Regular(bdd);

  countRef = st_init_table(st_ptrcmp,st_ptrhash);
  if (countRef == NULL) return(NULL);
  ref = ALLOC(int, 1);
  *ref = 1;
  if (st_add_direct(countRef, (char *) N, (char *) ref) == ST_OUT_OF_MEM) {
      printf("Out of Memeory !\n");
      exit(2);
  }

  visited = st_init_table(st_ptrcmp,st_ptrhash);
  if (visited == NULL) return (NULL);
  
  result = BDS_CountRefRecursive(bddmgr,cuddT(N),visited,countRef);
  if (result == 0) return(NULL);

  result = BDS_CountRefRecursive(bddmgr,cuddE(N),visited,countRef);
  if (result == 0) return(NULL);
      
  st_free_table(visited);

  return(countRef);

} /* end of BDS_CountRef */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_CountRef()]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

******************************************************************************/
static
int
BDS_CountRefRecursive(
  DdManager *bddmgr,
  DdNode *bdd,
  st_table *visited,
  st_table *countRef)
{
  int result, *ref;
  DdNode *N;

  N = Cudd_Regular(bdd);

  if (!Cudd_IsConstant(N)) {

      if (st_lookup(countRef, (char *) N, (char **) &ref)) {
	  (*ref)++;
      }
      else {
	  ref = ALLOC(int, 1);
	  *ref = 1;
	  if (st_add_direct(countRef, (char *) N, (char *) ref) == ST_OUT_OF_MEM) {
 	      printf("Out of memory !\n");
	      exit(2);
	  }
      }

      /* if N is marked as visited, all nodes below bdd have been visited. */
      if (st_is_member(visited, (char *) N) == 1) {
          return(1);
      }

      result = BDS_CountRefRecursive(bddmgr,cuddT(N),visited,countRef);
      if (result == 0) return(0);

      result = BDS_CountRefRecursive(bddmgr,cuddE(N),visited,countRef);
      if (result == 0) return(0);

      /* Mark bdd as visited */
      if (st_add_direct(visited, (char *) N, NULL) == ST_OUT_OF_MEM) {
          return(0);
      }
  }

  return(1);

} /* end of BDS_CountRefRecursive */

/**Function********************************************************************

  Synopsis    [Test if the BDD is unbalanced]

  Description [Return 1 if the BDD is unbalanced; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  LastDate    [2/23/99]

******************************************************************************/
extern
int
BDS_TestBalance(
  DdManager *bddmgr,
  DdNode *bdd)
{
  DdNode *tBdd, *eBdd;
  DdNode *tSupp, *eSupp, *sharedSupp = NULL;
  DdNode **miniArray;
  int result, retVal;
  int tSize, eSize, totalSize;
  int tSuppSize, eSuppSize, sharedSuppSize, totalSuppSize;
  float measure;

  tBdd = Cudd_T(bdd);
  if (tBdd != NULL) cuddRef(tBdd);
  eBdd = Cudd_E(bdd);
  if (eBdd != NULL) cuddRef(eBdd);

  tSize = Cudd_DagSize(tBdd);
  eSize = Cudd_DagSize(eBdd);

  miniArray = ALLOC(DdNode *, 2);
  miniArray[0] = tBdd;
  miniArray[1] = eBdd;

  totalSize = Cudd_SharingSize(miniArray, 2);

  result = Cudd_ClassifySupport(bddmgr, tBdd, eBdd, &sharedSupp, &tSupp, &eSupp);
  cuddRef(sharedSupp); cuddRef(tSupp); cuddRef(eSupp);

  if(totalSize == tSize + eSize - 1 || Cudd_IsConstant(sharedSupp)) {
      retVal = 1;
  }
  else { /* Calculate measure */
      tSuppSize = Cudd_SupportSize(bddmgr, tSupp);
      eSuppSize = Cudd_SupportSize(bddmgr, eSupp);
      sharedSuppSize = Cudd_SupportSize(bddmgr, sharedSupp);
      totalSuppSize = tSuppSize + eSuppSize + sharedSuppSize;

      measure = BDD_BALANCE_FACTOR * (tSize + eSize - totalSize - 1) / totalSize \
		+ (1 - BDD_BALANCE_FACTOR) * sharedSuppSize / totalSuppSize;

      if (measure <= BDD_BALANCE_THRESHOLD) 
	  retVal = 1;
      else
	  retVal = 0;
  }

  FREE(miniArray);
  Cudd_RecursiveDeref(bddmgr, tBdd); 
  Cudd_RecursiveDeref(bddmgr, eBdd); 
  Cudd_RecursiveDeref(bddmgr, sharedSupp); 
  Cudd_RecursiveDeref(bddmgr, tSupp); 
  Cudd_RecursiveDeref(bddmgr, eSupp); 

  return(retVal);

} /* end of BDS_TestBalance */

/**Function********************************************************************

  Synopsis    [Dump a BDD associated with BnetNode POnode to a file.
               The file name is option->dumpfile + "_" + POnode->name + ".dot"]

  SideEffects [None]

  SeeAlso     [Bnet_DumpDD]

******************************************************************************/
extern
void
BDS_DumpDD(
DdManager *bddmgr,
BnetNode *POnode,
BnetNetwork *net,
bdsOptions *option,
int dumpFmt /* 0-> dit; 1-> blif */ )
{
    FILE *dfp = NULL;
    DdNode **outputs = NULL;
    char **inames = NULL;
    char **onames = NULL;
    char **altnames = NULL;
    BnetNode *node;
    int i, retval, noutputs;
    char dumpfile[50]; /* The length of a filename can not exceed 50 char  */ 
    char *dash="_", *suffix=".dot", *blif=".blif";
    char *file_head, *dfn;

    /* Generate file name */ 
    file_head = BDS_GetFileHead(option->file);
    strcpy(dumpfile, file_head);
    strcat(dumpfile, dash);
    strcat(dumpfile, POnode->name);
    if (dumpFmt == 0)
        strcat(dumpfile, suffix);
    else
        strcat(dumpfile, blif);

    dfn = BDS_CreateFname(option,dumpfile);

    dfp = fopen(dfn,"w");
    if (dfp == NULL) goto endgame;

    /* Initialize data structures. */
    noutputs = 1;
    outputs = ALLOC(DdNode *,noutputs);
    if (outputs == NULL) goto endgame;
    onames = ALLOC(char *,noutputs);
    if (onames == NULL) goto endgame;
    inames = ALLOC(char *,Cudd_ReadSize(bddmgr));
    if (inames == NULL) goto endgame;

    /* Find outputs and their names. */
    onames[0] = POnode->name;
    outputs[0] = POnode->dd;

    /* Find the input names. */
    for (i = 0; i < net->ninputs; i++) {
        if (!st_lookup(net->hash,net->inputs[i],(char **)&node)) {
            goto endgame;
        }
        inames[node->var] = net->inputs[i];
    }

    /* Dump the BDDs. */
    if (dumpFmt == 1) {
        retval = Cudd_DumpBlif(bddmgr,noutputs,outputs,inames,onames,
                 net->name,dfp,0);      /* two-valued BLIF, CUDD 2.4.2, JS */
    } else {
        retval = Cudd_DumpDot(bddmgr,noutputs,outputs,inames,onames,dfp);
    }

endgame:
    if (dfp != stdout && dfp != NULL) {
        if (fclose(dfp) == EOF) retval = 0;
    }
    if (outputs != NULL) FREE(outputs);
    if (onames  != NULL) FREE(onames);
    if (inames  != NULL) FREE(inames);

} /* end of BDS_DumpDD */

/**Function********************************************************************

  Synopsis    [Print out bddmgr status]

  SideEffects [None]

  SeeAlso     []

  LastDate    [2/23/99]

******************************************************************************/
extern
void
BDS_PrintStatus(
DdManager *bddmgr,
BnetNode *POnode,
int pr)
{
    int result;

    if (pr >= 0) {
        printf("***********    Information related to BDD %s\n", POnode->name);
        result = Cudd_PrintInfo(bddmgr,stdout);
        if (result != 1) {
            (void) printf("Cudd_PrintInfo failed.\n");
        }
    }
} /* end of BDS_PrintStatus */

/**Function********************************************************************

  Synopsis    [Check bddmgr]

  SideEffects [None]

  SeeAlso     []

  LastDate    [2/23/99]

******************************************************************************/
extern
void 
BDS_CheckRefCount(
DdManager *bddmgr,
BnetNode *POnode)
{
    int ok, exitval;
    
    exitval = Cudd_CheckZeroRef(bddmgr);
    ok = exitval != 0;  /* ok == 0 means O.K. */
    if (exitval != 0) {
        printf("*******   %d non-zero DD reference counts after dereferencing %s\n", 
                                        exitval, POnode->name);
    }
} /* end of BDS_CheckRefCount */

/**Function********************************************************************

  Synopsis    [Dump a BDD into SopPool form]

  Description [Dump a disjoint sum of product cover for the function
        rooted at node. Each product corresponds to a path from node a leaf
        node different from background value(ADD) or logicZero for BDD. 
	Returns 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
SopPool * 
BDS_DumpSOP(
  DdManager *bddmgr, 
  DdNode *bdd)
{
    SopPool     *retSopPool;
    int         i, *list, result, *order, level;
    array_t     *sop;
    char        *line;
    DdNode 	*N;

    list = ALLOC(int,bddmgr->size);
    if (list == NULL) {
	fail("Out of memory");
    }

    /* Build variable ordering in this mgr. */
    order = ALLOC(int, bddmgr->size); 
    for (i=0; i < bddmgr->size; i++) {
        level = cuddI(bddmgr, i);
        order[level] = i;
    }

    sop = array_alloc(char *, 0);
    for (i = 0; i < bddmgr->size; i++) list[i] = 2;

    N = Cudd_Regular(bdd);
    if (Cudd_IsComplement(bdd)) {
        N = Cudd_Not(N);
    }

    result = BDS_DumpSOPRecursive(bddmgr, N, list, sop);

    retSopPool = ALLOC(SopPool, 1);
    retSopPool->size = bddmgr->size;
    retSopPool->sop = sop;
    retSopPool->order = order;
 
    FREE(list);
    return(retSopPool);

} /* end of BDS_DumpSOP */

/**Function********************************************************************

  Synopsis    [Performs the recursive step of BDS_DumpSOP.]

  Description []

  SideEffects [None]

******************************************************************************/
static
int
BDS_DumpSOPRecursive(
  DdManager *bddmgr,
  DdNode *bdd,
  int *list,
  array_t *currentSOP)
{
    DdNode      *N,*Nv,*Nnv;
    int         i,v,index;
    char        *line;
    DdNode      *background;

    background = bddmgr->background;
    N = Cudd_Regular(bdd);

    if (cuddIsConstant(N)) {
        /* Terminal case: Print one cube based on the current recursion
        ** path, unless we have reached the background value. */
        if (bdd != background && bdd != Cudd_ReadLogicZero(bddmgr)) {
            line = ALLOC(char, bddmgr->size + 1);
            for (i = 0; i < bddmgr->size; i++) {
                v = list[i];
                if (v == 0) line[i] = '0';
                else if (v == 1) line[i] = '1';
                else line[i] = '-';
            }
            line[i] = '\0'; 
            array_insert_last(char *, currentSOP, line); 
        }
    } else {
        Nv  = cuddT(N);
        Nnv = cuddE(N);
        if (Cudd_IsComplement(bdd)) {
            Nv  = Cudd_Not(Nv);
            Nnv = Cudd_Not(Nnv);
        }
        index = N->index;
        list[index] = 0;
        BDS_DumpSOPRecursive(bddmgr,Nnv,list,currentSOP); 
        list[index] = 1;
        BDS_DumpSOPRecursive(bddmgr,Nv,list,currentSOP);
        list[index] = 2;
    }

    return(1);

} /* end of BDS_DumpSOPRecursive */

/**Function********************************************************************

  Synopsis    [Free hash tables for BDD edge marking]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
void
BDS_FreeEdgeProperty(
  int *support,
  edgeMark **edgeProperty,
  int level)
{
  int i;

  for (i = 0; i < level; i++) {
      st_free_table(edgeProperty[i]->table);
      FREE(edgeProperty[i]);
  }
  FREE(edgeProperty);
  FREE(support);

} /* end of BDS_FreeEdgeProperty */

/**Function********************************************************************

  Synopsis    [Free a SOP struct]

  Description [Only the *next of sop is freed, the root is kept]

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
void
BDS_FreeSOP(
  SopPool *element)
{
  int i;
  char *line;

  for (i = 0; i < element->sop->num; i++) {
      line = array_fetch(char *, element->sop, i);
      FREE(line);
  }     
  array_free(element->sop);
  FREE(element->order); 
  FREE(element);

} /* end of BDS_FreeSOP */

/**Function********************************************************************

  Synopsis    [Get the support of a BDD]

  Description [return support in the form of array_t(int)]

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
array_t *
BDS_Support(
  DdManager *bddmgr,
  DdNode *f)
{
  DdNode *support, *scan;
  array_t *result;

  support = Cudd_Support(bddmgr, f);
  if (support == NULL) return(NULL);
  cuddRef(support);

  result = array_alloc(int, 0);
  scan = support;
  while (!cuddIsConstant(scan)) {
      array_insert_last(int, result, scan->index);
      scan = cuddT(scan);
  }
  Cudd_RecursiveDeref(bddmgr, support);

  return(result);

} /* end of BDS_Support */

/**Function********************************************************************

  Synopsis    [Get the support of a BDD]

  Description [return support in the form of int*. result[id] = level. This 
        function is called every time when a variable reordering is performed.
        The variable which is not on this BDD, it's level is marked as 0xFFFF.] 

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
int *
BDS_SupportArray(
  DdManager *bddmgr,
  DdNode *f,
  int *level)
{
  DdNode *support, *var, *scan;
  int *result, i, j, id;

  support = Cudd_Support(bddmgr, f);
  if (support == NULL) return(NULL);
  cuddRef(support);

  result = ALLOC(int, bddmgr->size);
  for (i = 0; i < bddmgr->size; i++) {
      result[i] = 0xFFFF; /* A variable is unlikely to sit at this level */
  } 

  i = 0;

  /* Figure out result[id] = level information. */
  for (j = 0; j < bddmgr->size; j++) {
      id = Cudd_ReadInvPerm(bddmgr, j);
      scan = support;
      while (!cuddIsConstant(scan)) {
          if (scan->index == id) {
              result[id] = i;
              i++;
              break;
          }
          scan = cuddT(scan);
      }
  }

  Cudd_RecursiveDeref(bddmgr, support);
  (*level) = i - 1; /* The number of decomp level is 1 less than # of variables. */

  return(result);

} /* end of BDS_Support */

/**Function********************************************************************

  Synopsis    [Dump a SOP form at a specific level of a BDD]

  Description [BDD traversal stops at edges when they are found in the hash table]

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
SopPool *
BDS_DumpSopAtLevel(
  DdManager *bddmgr, 
  DdNode *bdd, 
  edgeMark *levelTable, 
  int decompType)
{
  int i, *list, result, *order, level;
  array_t *sop;
  SopPool *retSop;
  char *line;

  list = ALLOC(int,bddmgr->size + 1);

  /* Build variable ordering in this mgr. */
  order = ALLOC(int, bddmgr->size); 
  for (i=0; i < bddmgr->size; i++) {
      level = cuddI(bddmgr, i);
      order[level] = i;
  }

  sop = array_alloc(char *, 0);
  for (i = 0; i < bddmgr->size; i++) list[i] = 2;

  result = BDS_DumpSopAtLevelRecursive(bddmgr, bdd, levelTable, list, &sop, decompType);

  retSop = ALLOC(SopPool, 1);
  retSop->size = bddmgr->size;
  retSop->sop = sop;
  retSop->order = order;
 
  FREE(list);
  return(retSop);

} /* end of BDS_DumpSopAtLevel */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_DumpSopAtLevel]

  Description [A miniterm is dumped if, 1) a terminal node is reached; 2) an edge
        is found in the levelTable. This simulates the cut on a 0-1 ADD.]           

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
int
BDS_DumpSopAtLevelRecursive(
  DdManager *bddmgr, 
  DdNode *bdd, 
  edgeMark *levelTable, 
  int *list, 
  array_t **sop, 
  int decompType)
{
  DdNode        *N,*Nv,*Nnv;
  int           i,v,index;
  char          *line; 
  DdNode        *background;

  background = bddmgr->background;
  N = Cudd_Regular(bdd);

  if (cuddIsConstant(N)) { 
      /* Terminal case: Print one cube based on the current recursion
         path, unless we have reached the background value (ADDs). 
      */
      if (bdd != background) {
          line = ALLOC(char, bddmgr->size + 1); 
          for (i = 0; i < bddmgr->size; i++) {
              v = list[i];
              if (v == 0) line[i] = '0';
              else if (v == 1) line[i] = '1';
              else line[i] = '-';
          }
          line[i] = '\0'; 
          array_insert_last(char *, (*sop), line); 
      }
  } else if (st_is_member(levelTable->table, (char *) bdd) == 1) { 
      /* The edge is found in levelTable. If a conjunctive decomposition is
      	 performed, dump this path to SOP; if a disjunctive decomposition
	 is performed, simply go back.
      */
      if (decompType == BDS_BDD_DECOMP_DISJ) 
          return(1); 
      else if (decompType == BDS_BDD_DECOMP_CONJ) {
          line = ALLOC(char, bddmgr->size + 1); 
          for (i = 0; i < bddmgr->size; i++) {
              v = list[i];
              if (v == 0) line[i] = '0';
              else if (v == 1) line[i] = '1';
              else line[i] = '-';
          }
          line[i] = '\0'; 
          array_insert_last(char *, (*sop), line); 
      }
      else { /* The decompType is not supported. */
          return(0);
      }
  } else { /* Internal edge above the cut */
      Nv  = cuddT(N);
      Nnv = cuddE(N);
      if (Cudd_IsComplement(bdd)) {
          Nv  = Cudd_Not(Nv);
          Nnv = Cudd_Not(Nnv);
      }
      index = N->index;
      list[index] = 0;
      BDS_DumpSopAtLevelRecursive(bddmgr,Nnv,levelTable,list,sop,decompType); 
      list[index] = 1;
      BDS_DumpSopAtLevelRecursive(bddmgr,Nv,levelTable,list,sop,decompType);
      list[index] = 2;
  }

  return(1);

} /* end of BDS_DumpSopAtLevelRecursive */

/**Function********************************************************************

  Synopsis    [Dump a BDD to a BLIF file, filename is pointer to this BDD]

  Description [result = 1, successful. 0 otherwise]

  SideEffects []

  SeeAlso     []

******************************************************************************/
/* identifiers in .model, .outputs, .names begin with '0x' JS                */
extern
char *
BDS_DumpBddBlif(
  DdManager *bddmgr,
  DdNode *bdd,
  char **PIvariables)
{
    int i, *list, result, *order, level;
    FILE *dfp;
    char *filename, *f, *suffix = ".blif";

    /* Build variable ordering in this mgr. */
    order = ALLOC(int, bddmgr->size); 
    for (i=0; i < bddmgr->size; i++) {
        level = cuddI(bddmgr, i);
        order[level] = i;
    }

    f = ALLOC(char, 8);
    filename = ALLOC(char, 20);
    sprintf(f, "%p", bdd);
    strcat(filename, f);
    strcat(filename, suffix);

    dfp = fopen(filename, "w"); 

    /* Print head information */
    fprintf(dfp, ".model %p\n", bdd);
    fprintf(dfp, ".inputs ");

    /* Print inputs */
    for (i = 0; i < bddmgr->size; i++) {
        fprintf(dfp, "%s ", PIvariables[order[i]]);
    }
    fprintf(dfp, "\n");
    fprintf(dfp, ".outputs %p\n", bdd);
    fprintf(dfp, ".names ");
    for (i = 0; i < bddmgr->size; i++) {
        fprintf(dfp, "%s ", PIvariables[order[i]]);
    }

    /* Print output */
    fprintf(dfp," %p\n", bdd);
    
    list = ALLOC(int,bddmgr->size);
    for (i = 0; i < bddmgr->size; i++) list[i] = 2;

    result = BDS_DumpBddBlifRecursive(bddmgr, bdd, list, dfp);
    fprintf(dfp, ".end\n");

    fclose(dfp);
    FREE(list);

    return(filename);

} /* end of BDS_DumpBddBlif */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_DumpBddBlif]

  Description [result = 1, successful. 0 otherwise]

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
int
BDS_DumpBddBlifRecursive(
  DdManager *bddmgr, 
  DdNode *bdd,
  int *list,
  FILE *dfp)
{
    DdNode      *N,*Nv,*Nnv;
    int         i,v,index;
    DdNode      *background;
    char        *line;

    background = bddmgr->background;
    N = Cudd_Regular(bdd);

    if (cuddIsConstant(N)) {
        /* Terminal case: Print one cube based on the current recursion
        ** path, unless we have reached the background value (ADDs). */
        if (N != background) {
            line = ALLOC(char, bddmgr->size + 1);
            for (i = 0; i < bddmgr->size; i++) {
                v = list[i];
                if (v == 0) line[i] = '0';
                else if (v == 1) line[i] = '1';
                else line[i] = '-';
            }
            line[i] = '\0'; 
            fprintf(dfp, "%s", line);
            fprintf(dfp, " 1\n");
        }
    } else {
        Nv  = cuddT(N);
        Nnv = cuddE(N);
        if (Cudd_IsComplement(bdd)) {
            Nv  = Cudd_Not(Nv);
            Nnv = Cudd_Not(Nnv);
        }
        index = N->index;
        list[index] = 0;
        BDS_DumpBddBlifRecursive(bddmgr,Nnv,list,dfp);
        list[index] = 1;
        BDS_DumpBddBlifRecursive(bddmgr,Nv,list,dfp);
        list[index] = 2;
    }

    return(1);

} /* end of BDS_DumpBddBlifRecursive */

/**Function********************************************************************

  Synopsis    [Leaf node]

  Description [Return 1 if the node is a leaf node; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
extern
int
BDS_IsLeafNode(
  DdNode *bdd)
{
  if (Cudd_IsConstant(Cudd_T(bdd)) || Cudd_IsConstant(Cudd_E(bdd)))
      return(1);
  else
      return(0);

} /* end of BDS_IsLeafNode */

/**Function********************************************************************

  Synopsis    [Applies reordering to the DDs.]

  Description [Explicitly applies reordering to the DDs. Returns 1 if
        successful; 0 otherwise.]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
extern
int
BDS_Reorder(
  DdManager *bddmgr,
  BnetNetwork * net,
  bdsOptions * option)
{
    int i,result;

    if (net != NULL) {
        (void) printf("Number of inputs = %d\n",net->ninputs);
    }

    /* Perform the final reordering */
    if (option->reordering != CUDD_REORDER_NONE) {

        bddmgr->siftMaxVar = 1000000;
        bddmgr->siftMaxSwap = 1000000000;
        result = Cudd_ReduceHeap(bddmgr,option->reordering,1);
        if (result == 0) return(0);

        /* Print symmetry stats if pertinent */
        if (bddmgr->tree == NULL &&
            (option->reordering == CUDD_REORDER_SYMM_SIFT ||
            option->reordering == CUDD_REORDER_SYMM_SIFT_CONV))
            Cudd_SymmProfile(bddmgr,0,bddmgr->size - 1);
    }

    return(1);

} /* end of BDS_Reorder */

/**Function********************************************************************

  Synopsis    [Update fields in a fnode]

  Description [Initialize an fnode]

  SideEffects []

  SeeAlso     []

  LastDate    [2/23/99]

******************************************************************************/
extern
void
BDS_WriteFnode(
  FactorTreeNode *fnode,
  int polarity,
  int operator,
  int value)
{
  fnode->polarity = polarity ? 1 : 0;
  fnode->operator = operator;
  fnode->value = value;
  fnode->count = 1;
  fnode->visited = 0;
  fnode->dd = NULL;
  fnode->local = NULL;
  fnode->control = NULL;
  fnode->fanins = NULL;
  fnode->fanouts = NULL;
} /* end of BDS_WriteFnode */

/**Function********************************************************************

  Synopsis    [Update a BDD decomposition monitor]

  Description []

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
void
BDS_UpdateBddMonitor(
  DdManager *bddmgr,
  bddStats *monitor,
  DdNode *inBdd,
  DdNode *dpBdd,
  DdNode *dmBdd,
  DdNode *auxBdd,	/* used for branch decomposition */
  int level,
  float cost,
  int decompType)
{
  if (monitor == NULL) return;

  if (inBdd != NULL) {
      monitor->inVar = Cudd_SupportSize(bddmgr, inBdd);
      monitor->inSize = Cudd_DagSize(inBdd);
  }
  if (dpBdd != NULL) {
      monitor->dpVar = Cudd_SupportSize(bddmgr, dpBdd);
      monitor->dpSize = Cudd_DagSize(dpBdd);
  }
  if (dmBdd != NULL) {
      monitor->dmVar = Cudd_SupportSize(bddmgr, dmBdd);
      monitor->dmSize = Cudd_DagSize(dmBdd);
  }
  if (auxBdd != NULL) {
      monitor->auxVar = Cudd_SupportSize(bddmgr, auxBdd);
      monitor->auxSize = Cudd_DagSize(auxBdd);
  }
  monitor->level = level;
  if (cost != 0) 
      monitor->cost = cost;
  else if (dpBdd != NULL || dmBdd != NULL)	/* probably (dpBdd != NULL && dmBdd != NULL) JS */
      monitor->cost = (float) ALPHA * (monitor->dpSize + monitor->dmSize) / monitor->inSize;

  monitor->decompType = decompType;

} /* end of BDS_UpdateBddMonitor */

/**Function********************************************************************

  Synopsis    [Create result and log file names]

  Description []

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
extern
char*
BDS_CreateFname(
  bdsOptions *option,
  char *fname)
{
    static char *dir_name;
    char *file_name;

    if (fname == NULL) {
        return NULL;
    }
    if (dir_name == NULL) {
        dir_name = BDS_CreateRunDir(option);
	if (dir_name == NULL) return(NULL);
    }
    
    file_name = ALLOC(char, strlen(dir_name) + strlen(fname) + 2);
    strcpy(file_name, dir_name);
    strcat(file_name, "/");
    strcat(file_name, fname);
    
    return(file_name);

} /* end of BDS_CreateFname */

/**Function********************************************************************

  Synopsis    [Create run directory]

  Description [All the synthesis results and intermediate results are stored here]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
static 
char*
BDS_CreateRunDir(
  bdsOptions *option)
{
  char *dir_name, *file_head;
  time_t realTime;
  char *human_month, *tmp;
  struct utsname uhost;
  struct tm *realTimePtr;

  if (option->dir) {
      dir_name = ALLOC (char, strlen (option->dir)+1);
      strcpy(dir_name, option->dir);
  } else {

      dir_name = ALLOC(char, 100);
      tmp = ALLOC(char, 100);
      file_head = BDS_GetEntireFileHead(option->file);
      strcpy(dir_name, file_head);

      if (time(&realTime) == 127) {
          (void) sprintf(tmp, "_%d_", getpid());
          strcat(dir_name, tmp);
      } else {
          realTimePtr = localtime(&realTime);
          switch (realTimePtr->tm_mon) {
          case 0: human_month = "Jan"; break;
          case 1: human_month = "Feb"; break;
          case 2: human_month = "Mar"; break;
          case 3: human_month = "Apr"; break;
          case 4: human_month = "May"; break;
          case 5: human_month = "Jun"; break;
          case 6: human_month = "Jul"; break;
          case 7: human_month = "Aug"; break;
          case 8: human_month = "Sep"; break;
          case 9: human_month = "Oct"; break;
          case 10: human_month = "Nov"; break;
          default: human_month = "Dec"; break;
          }
          (void) sprintf(tmp, "_%s_%d_%d_%d_%d_%d_",
                               human_month, realTimePtr->tm_mday, 1900+realTimePtr->tm_year, 
    		realTimePtr->tm_hour, realTimePtr->tm_min, realTimePtr->tm_sec);
          strcat(dir_name, tmp);
      }
      
	  if (uname(&uhost) != 127) {
          strcat(dir_name, uhost.nodename);
      }
	  
      FREE(tmp);
  }
  if (mkdir(dir_name, 00777) != 0) {
      fail("Can not make run directory!\n");
  }

  return(dir_name);
}

/**Function********************************************************************

  Synopsis    [Get the whole file head]

  Description [out of ddddd/xxx.yy.blif gives ddddd/xxx.yy]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
extern
char *
BDS_GetEntireFileHead(
  char *fname)
{
  int i = 0;
  char *file_head, *q;
  FILE *tstf;

  /* Test if the file exists or not */
  if ((tstf = fopen(fname,"r")) == NULL) {
      perror(fname);
      exit(2);
  } else {
      fclose(tstf);
  }

#ifdef orig
  file_head = ALLOC(char, 20); /* The maximum length of the name of a test case */
  for (q = fname; *q != '.'; q++) {
      file_head[i] = *q;
      i++;
  }
  file_head[i] = '\0';
#endif

  q = strrchr (fname, '.');     /* a quick hack to ged rid of the code above, JS */
  if (!q || q == fname) q = fname+strlen(fname);
  file_head = ALLOC (char, q-fname+1);
  strncpy (file_head, fname, q-fname);
  file_head [q-fname] = '\0';

  return(file_head);

} /* end of BDS_GetEntireFileHead */

/**Function********************************************************************

  Synopsis    [Get the whole file head]

  Description [out of ddddd/xxx.yy.blif gives xxx.yy]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
extern
char *
BDS_GetFileHead(
  char *fname)
{
  int i = 0;
  char *file_head, *fend, *fbeg;
  FILE *tstf;

  /* Test if the file exists or not */
  if ((tstf = fopen(fname,"r")) == NULL) {
      perror(fname);
      exit(2);
  } else {
      fclose(tstf);
  }

#ifdef orig
  file_head = ALLOC(char, 20); /* The maximum length of the name of a test case */
  for (fend = fname; *fend != '.'; fend++) {
      file_head[i] = *fend;
      i++;
  }
  file_head[i] = '\0';
#endif

  fend = strrchr (fname, '.');     /* a quick hack to ged rid of the code above, JS */
  if (!fend || fend == fname) fend = fname+strlen(fname);
  fbeg = strrchr (fname, '/');     /* last dir delimiter */
  if (fbeg) fbeg++; else fbeg = fname;
  file_head = ALLOC (char, fend-fbeg+1);
  strncpy (file_head, fbeg, fend-fbeg);
  file_head [fend-fbeg] = '\0';

  return(file_head);

} /* end of BDS_GetFileHead */
/**Function********************************************************************

  Synopsis    [Collect statistical information in BDS]

  Description []

  SideEffects [None]

  SeeAlso     []

  LastDate    [3/6/99]

*****************************************************************************/
extern
void
BDS_Stats(
  int cmd,		/* command */
  bddStats *bddMonitor, /* BDD stats before and after decomp */
  long number,		/* Integer */
  char *strng,		/* String */
  char **strngArray,	/* Array of string */
  DdManager *bddmgr,	/* BDD manager */
  bdsOptions *option	/* Main option */ )
{
  int i, result;
  static int snode, hardcore, bhardcore, numDecomp;
  static int numFnodeBefore, numFnodeAfter,numFnodeAfterCollapse; 
  static int verifyResultBefore, verifyResultAfter, oneD, zeroD, xD, genD, flag;
  static int litCountBefore, litCountAfter, numCofactor;
  static FILE *dfp = NULL;
  static char *dumpfile = NULL;
  static int andOp, orOp, xorOp, xnorOp, muxOp;

  if (dfp == NULL) {
      dumpfile = BDS_CreateFname(option,"BDS.run");
      dfp = fopen(dumpfile,"w");
  }

  switch(cmd) {
  case BDS_INIT:
      fprintf(dfp, "# %s\n", strng);
      fprintf(dfp, "# arguments: ");
      for (i = 0; i < number; i++) {
	  fprintf(dfp," %s", strngArray[i]);
      }
      fprintf(dfp, "\n");
      break;
  case BDS_BDD_DECOMP:
      if (bddMonitor != NULL) {
	  if (flag == 0) {
	      fprintf(dfp,"\nBDD decomposition process statistics\n");
	      fprintf(dfp,"------------------------------------\n");
	      flag++;
  	  }
	  fprintf(dfp,"BDD (var=%d, size=%d) is decomposed into", bddMonitor->inVar, bddMonitor->inSize);

	  if (bddMonitor->cost > BDS_DISQUALIFY_THRESHOLD) {
	      fprintf(dfp, "\t(cost = %f)", bddMonitor->cost);
	      fprintf(dfp, "\tDecomposition is disqualified\n");
	      break;
	  }

	  fprintf(dfp,"  (var=%d, size=%d)", bddMonitor->dpVar, bddMonitor->dpSize);
	  switch(bddMonitor->decompType) {
	  case BDS_BDD_AND:
	      fprintf(dfp," * "); 
	      break;
	  case BDS_BDD_OR:
	      fprintf(dfp," + "); 
	      break;
	  case BDS_BDD_XOR:
	      fprintf(dfp," ^ "); 
	      break;
	  case BDS_BDD_XNOR:
	      fprintf(dfp," @ "); 
	      break;
	  default:
	      fail("Unknow decomposition type in BDS_Stats");
	  }
	  if (bddMonitor->inVar == bddMonitor->dpVar + bddMonitor->dmVar) {
	      fprintf(dfp,"(var=%d, size=%d) (algebraic)\n", bddMonitor->dmVar, bddMonitor->dmSize);
	      fprintf(dfp,"\t\t\tCost = %f, decomposition level = %d\n",
					bddMonitor->cost, bddMonitor->level);
          }
	  else {
	      fprintf(dfp,"(var=%d, size=%d)\n", bddMonitor->dmVar, bddMonitor->dmSize);
	      fprintf(dfp,"\t\t\tCost = %f, decomposition level = %d\n",
					bddMonitor->cost, bddMonitor->level);
	  }
      }
      break;
  case BDS_ONE_DOMI:
      numDecomp++;
      oneD++;
      break;
  case BDS_ZERO_DOMI:
      numDecomp++;
      zeroD++;
      break;
  case BDS_X_DOMI:
      numDecomp++;
      xD++;
      break;
  case BDS_G_DOMI:
      numDecomp++;
      genD++;
      break;
  case BDS_VERIFY:
      if (strng[0] == 'b') 
          verifyResultBefore = number;
      else if (strng[0] == 'a')
	  verifyResultAfter = number;
      break;
  case BDS_XHARDCORE:
      numDecomp++;
      hardcore++;
      if (bddMonitor != NULL) {
	  if (flag == 0) {
	      fprintf(dfp,"\nBDD decomposition process statistics\n");
	      fprintf(dfp,"------------------------------------\n");
	      flag++;
  	  }
	  fprintf(dfp,"BDD (var=%d, size=%d) is gx-decomposed into", bddMonitor->inVar, bddMonitor->inSize);
	  fprintf(dfp,"  (var=%d, size=%d)", bddMonitor->dpVar, bddMonitor->dpSize);
	  fprintf(dfp," @ "); 
	  fprintf(dfp,"(var=%d, size=%d)\n", bddMonitor->dmVar, bddMonitor->dmSize);
	  fprintf(dfp,"\t\t\tCost = %f\n", bddMonitor->cost);
      }
      break;
  case BDS_BHARDCORE:
      numDecomp++;
      bhardcore++;
      if (bddMonitor != NULL) {
	  if (flag == 0) {
	      fprintf(dfp,"\nBDD decomposition process statistics\n");
	      fprintf(dfp,"------------------------------------\n");
	      flag++;
  	  }
	  fprintf(dfp,"BDD (var=%d, size=%d) is bch-decomposed into", bddMonitor->inVar, bddMonitor->inSize);
	  fprintf(dfp,"  g=(var=%d, size=%d)", bddMonitor->dpVar, bddMonitor->dpSize);
	  fprintf(dfp,"  h=(var=%d, size=%d)", bddMonitor->dmVar, bddMonitor->dmSize);
	  fprintf(dfp,"  f=(var=%d, size=%d)\n", bddMonitor->auxVar, bddMonitor->auxSize);
      }
      break;
  case BDS_COFACTOR:
      numDecomp++;
      numCofactor++;
      if (bddMonitor != NULL) {
          if (flag == 0) {
	      fprintf(dfp,"\nBDD decomposition process statistics\n");
	      fprintf(dfp,"------------------------------------\n");
	      flag++;
          }
	  fprintf(dfp,"BDD (var=%d, size=%d) is cf-decomposed into", bddMonitor->inVar, bddMonitor->inSize);
	  fprintf(dfp,"  g=(var=%d, size=%d)", bddMonitor->dpVar, bddMonitor->dpSize);
	  fprintf(dfp,"  h=(var=%d, size=%d)", bddMonitor->dmVar, bddMonitor->dmSize);
	  fprintf(dfp,"  f=(var=%d, size=%d)\n", bddMonitor->auxVar, bddMonitor->auxSize);
      }
      break;
  case BDS_REORDER:             /* useful in traqcking loops, JS */
      if (bddMonitor != NULL) {
	  if (flag == 0) {
	      fprintf(dfp,"\nBDD decomposition process statistics\n");
	      fprintf(dfp,"------------------------------------\n");
	      flag++;
  	  }
	  fprintf(dfp,"BDD (var=%d, size=%d) is reordered to", bddMonitor->inVar, bddMonitor->inSize);
	  fprintf(dfp," (var=%d, size=%d)\n", bddMonitor->dpVar, bddMonitor->dpSize);
      }
      break;
  case BDS_HACKOUT:         /* monitoring loop prevention, JS */
      if (bddMonitor != NULL) {
	  if (flag == 0) {
	      fprintf(dfp,"\nBDD decomposition process statistics\n");
	      fprintf(dfp,"------------------------------------\n");
	      flag++;
  	  }
	  fprintf(dfp,"BDD (var=%d, size=%d) decomposition to", bddMonitor->inVar, bddMonitor->inSize);
	  fprintf(dfp," (var=%d, size=%d) rejected for delta=%d (loops?)\n", bddMonitor->dpVar, bddMonitor->dpSize, option->xdelta);
      }
      break;
  case BDS_SHARED_FNODE:
      if (strng[0] == 'b') 
          numFnodeBefore = number;
      else if (strng[0] == 'a')
	  numFnodeAfter = number;
      else if (strng[0] == 'c')
	  numFnodeAfterCollapse = number;
      else
          snode = number;
      break;
  case BDS_LIT_COUNT:
      if (strng[0] == 'b') 
          litCountBefore = number;
      else 
	  litCountAfter = number;
      break;
  case BDS_FTREE_OPERATOR:
      if (!strcmp(strng, "and"))
	  andOp = number;
      else if (!strcmp(strng,"or"))
	  orOp = number;
      else if (!strcmp(strng,"xor"))
	  xorOp = number;
      else if (!strcmp(strng,"xnor"))
	  xnorOp = number;
      else if (!strcmp(strng,"mux"))
	  muxOp = number;
      else
	  fail("Unknown operator in BDS_Stats()");

      break;
  case BDS_CLOSE:
      if (option->verb > BDS_VERBOSE_LESS) {
	  fprintf(dfp,"\n\nBDD decomposition related statistics\n");
	  fprintf(dfp,"------------------------------------\n");

          fprintf(dfp,"Total number of decomposition performed = %d\n\n", numDecomp);
          fprintf(dfp,"Total number of decomposition based on 0-dominators = %d\n",zeroD);
          fprintf(dfp,"Total number of decomposition based on 1-dominators = %d\n",oneD);
          fprintf(dfp,"Total number of decomposition based on x-dominators = %d\n",xD);
          fprintf(dfp,"Total number of decomposition based on generalized dominator = %d\n",genD);
          fprintf(dfp,"Total number of decomposition based on generalized x-dominator = %d\n",hardcore);
          fprintf(dfp,"Total number of decomposition based on branch decomposition = %d\n",bhardcore);
          fprintf(dfp,"Total number of decomposition based on cofactoring = %d\n",numCofactor);

	  /*
          fprintf(dfp,"\nTotal CPU time used to decompose BDD = %s\n\n", util_print_time(number));
	  */

	  fprintf(dfp,"\nFactoring tree related statistics\n");
	  fprintf(dfp,"---------------------------------\n");

          fprintf(dfp,"Total number of nodes on the ftree before sharing extraction = %d\n",numFnodeBefore);
          fprintf(dfp,"Total number of nodes on the ftree after  sharing extraction = %d\n",numFnodeAfter);
          fprintf(dfp,"Total number of nodes on the ftree after  collapsing homogeneous fnodes = %d\n",numFnodeAfterCollapse);
          fprintf(dfp,"Total number of shared nodes on the final factoring dag = %d\n", snode);
          fprintf(dfp,"\nTotal number of AND, OR on final ftree = %d, %d\n", andOp,orOp);
          fprintf(dfp,"Total number of XOR, XNOR and MUX on final ftree = %d, %d and %d\n",xorOp,xnorOp,muxOp);

	  fprintf(dfp,"\nLiteral count related statistics\n");
	  fprintf(dfp,"--------------------------------\n");
	  if (option->verb > BDS_VERBOSE_MOST)
	      fprintf(dfp,"Total number of literals before final ftree processing = %d\n",litCountBefore);
	  fprintf(dfp,"Total number of literals after  final ftree processing = %d\n\n",litCountAfter);
      }

      if (option->verify == TRUE) {
	  fprintf(dfp,"\nSynthesis verification statistics\n");
	  fprintf(dfp,"---------------------------------\n");

          if (verifyResultAfter == 1)
              fprintf(dfp,"The verification result after  final ftree processing = EQUAL\n\n");
          else
              fprintf(dfp,"The verification result after  final ftree processing = UNEQUAL\n\n");
      }

      /*
      fprintf(dfp,"Total run time = %s\n",util_print_time(util_cpu_time() - option->initialTime));
      fprintf(dfp,"Total time used to decompose BDD = %s\n\n", util_print_time(number));
      */

      util_print_cpu_stats(dfp);

      fprintf(dfp,"\n\nThe following usage information is generated by CUDD\n");
      fprintf(dfp,"=====================================================================\n");

      Cudd_PrintInfo(bddmgr, dfp);

      fclose(dfp);
      FREE(dumpfile);
      break;
  default :
      fail("Unknown cmd in BDS_Stats");
  }

} /* end of BDS_Stats */
