#ifndef DEBUG_H
#define DEBUG_H
/*************************************************************************
	-----------------------------------------------------
           		Copyright 2002, 
	   University of Massachusetts, Amherst. 
	-----------------------------------------------------

This package was created at the University of Massachusetts, Amherst. 
The University of Massachusetts makes no warranty about the suitability 
of this software for any purpose. It is presented on an "as is" basis.

This particular file was created at the CTU in Prague. 

CONDITIONS:

The use of software for commercial purposes is strictly forbidden
without a written consent from its authors or the University of 
Massachusetts, Amherst.

**************************************************************************/
/**CHeaderFile*****************************************************************

  FileName    [debug.h]

  PackageName [BDS]

  Synopsis    [BDD decomposition-based logic optimization program]

  Description [Debug facilities control.]

  SeeAlso     []

  Author      [Jan Schmidt]

******************************************************************************/
/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/
#ifdef DEBUG
#define DBG_MEMSET(a,b,c) memset((a),(b),(c))
#else
#define DBG_MEMSET(a,b,c)
#endif

#define DEBUG_ACTIVE(flag) defined(DEBUG) && ((DEBUG) & (flag))

#define BDS_FNODE_PTR_RUBBISH (FactorTreeNode *)0xDDDDDDDD

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/
#define DEBUG_COLLECT_FTREE  0x1   /* initial FTNode construction */
#define DEBUG_TABELATE_FTREE 0x2   /* dump FTree in tabular form before and after processing */
#define DEBUG_CUDD_CHECK     0x4
#define DEBUG_DOT            0x8   /* more info in DOT files */
#define DEBUG_DECOMP_CHECK   0x10  /* check decomposition in minimize.c */
#define DEBUG_DUMP_SHARED    0x20  /* dump shared nodes in sweep.c */

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/
EXTERN void debugSharing ARGS((DdManager*,lsList,DdNode**,bdsOptions*));
EXTERN void debugDump ARGS((DdManager*,DdNode**,float,bdsOptions*));
EXTERN void debugDumps ARGS((DdManager*,DdNode*,float,bdsOptions*));
EXTERN void dumpDot ARGS((DdManager*,DdNode*));
EXTERN void db ARGS((DdManager*,DdNode*));
EXTERN int  ref ARGS((DdManager*));
EXTERN void cuddCheck ARGS((DdManager*,char*,int));
EXTERN int bdsDecompCheck ARGS((DdManager*,DdNode*,int,DdNode*,DdNode*));
EXTERN void dumpfdot ARGS((FactorTreeNode**,char**));
EXTERN void bdsNetwotkTraverseDebug ARGS((DdManager*,BnetNetwork*));
EXTERN void netPrint ARGS((BnetNetwork*,bdsOptions*));
EXTERN DdNode reg ARGS((DdNode*));
extern void checkFTable (FactorTreeNode **fnode_array, int limit, char* id);
extern void initFTable  (FactorTreeNode **fnode_array, int n);
extern int  checkFNode  (FactorTreeNode *fnode, int limit, char* id);
extern int  checkFTree  (FactorTreeNode *fnode, int limit, char* id);
extern int  dumpFNode   (FILE *fp, FactorTreeNode *fnode);
extern int  dumpFHead   (FILE *fp);
extern int  dumpFTreeArraylsList        (FILE *fp, FactorTreeNode **farray);
extern int  dumpFTreeArray              (FILE *fp, FactorTreeNode **farray);
extern int  dumpFTreeArraylsListBnode   (FILE *fp, FactorTreeNode **farray, st_table *factorTreeNode2BnetNode);
extern int  dumpFTreeArrayBnode         (FILE *fp, FactorTreeNode **farray, st_table *factorTreeNode2BnetNode);
extern int  dumpFTreeArraylsListBnodePI (FILE *fp, FactorTreeNode **farray, st_table *factorTreeNode2BnetNode, char **PIvariables);
extern int  dumpFTreeArrayBnodePI       (FILE *fp, FactorTreeNode **farray, st_table *factorTreeNode2BnetNode, char **PIvariables);
#endif

