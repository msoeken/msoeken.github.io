#ifndef WINFAKE_H
#define WINFAKE_H
/* -------------------------------------------------------------------------
    Structures and functions replacing system- and file- related
    services on Windows. Prototypes roughly approximate linux,
    but shall suit mst applications. Functionality of uname
    limited to the extent needed by BDS.
--------------------------------------------------------------------------*/
#define SYS_NMLN 257    /* MAX_COMPUTERNAME_LENGTH+1 in reality           */
                        /* bringing this constant here would require      */
                        /* including windows.h here, which is undesirable */
typedef int pid_t;              /* signed 32 bit on linux */
typedef unsigned int mode_t;    /* unsigned 32 bit on linux */
struct utsname {
    char sysname  [SYS_NMLN];
    char nodename [SYS_NMLN];
    char release  [SYS_NMLN];
    char version  [SYS_NMLN];
    char machine  [SYS_NMLN];
};
extern pid_t getpid (void);
extern int mkdir (const char*, mode_t);
extern int uname (struct utsname*);
#endif
