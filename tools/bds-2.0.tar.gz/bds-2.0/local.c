
/**CFile***********************************************************************

  FileName    [local.c]

  PackageName [BDS-pga]

  Synopsis    [Build dummy local BDDs for BDS program]

  Description [This file contains the functions for local BDDs.]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#include "local.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static int BDS_DumpSopLocalRecursive ARGS((DdManager*,DdNode*,int*,array_t*,int*,int));
static int bdsConvertDummy2RealRecursive ARGS((FactorTreeNode*,int*,st_table*,bdsOptions*));
static bddNode * BDS_StoreBddPoolLocalRecursive ARGS((DdManager*,DdNode*,st_table*));
static void bdsFreeBddPoolLocalRecursive ARGS((DdManager*,bddNode*,st_table*));
static void bdsClearBddPoolFlagLocal ARGS((DdManager*,bddPool*));
static void bdsClearBddPoolFlagLocalRecursive ARGS((DdManager*,bddNode*,st_table*));


/**AutomaticEnd***************************************************************/

/*---------------------------------------------------------------------------*/
/* Definition of exported functions                                          */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis    [Build dummy local BDDs]

  Description [For large test cases, number of ids in a bddmgr could be huge,
  therefore, it's very expensive to do variable reordering. Instead, all local
  BDDs are built based on local dummy bddmgr. Since BDS_DDDecompose() does not
  need the knowledge of network, once a BDD is in the same form as that in real
  bddmgr, the final decomposition results should be correct. After decomposition,
  those dummy variable should be converted to real variables. Return DdNode* if
  successful; NULL otherwise.]

  SideEffects []

  SeeAlso     []

  LastDate    [3/27/99]

******************************************************************************/
extern
DdNode *
BDS_BuildDummyLocalBdd( /// not used anywhere
  DdManager *bddmgr,
  SopPool *soppool,
  BnetNode *node,
  int **dummy2realId,
  int numRealVar,
  bdsOptions *option)
{
  int *real2dummy, dummyIndex, realIndex;
  lsGen fanins;
  BnetNode *fanode;
  DdNode *dummyVar, *retBdd;

  real2dummy = ALLOC(int, numRealVar);
  *dummy2realId = ALLOC(int, lsLength(node->fanins));

  /* Create dummy variables */
  fanins = lsStart(node->fanins);
  while (lsNext(fanins, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
      dummyVar = Cudd_bddNewVar(bddmgr);
      if (dummyVar == NULL) return(NULL);
      Cudd_Ref(dummyVar);

      dummyIndex = Cudd_NodeReadIndex(dummyVar);
      realIndex = fanode->localVar;

      real2dummy[realIndex] = dummyIndex;
      (*dummy2realId)[dummyIndex] = realIndex;
  }
  lsFinish(fanins);

  /* Construct local dummy BDD */
  retBdd = BDS_BuildDDFromSopLocal(bddmgr, soppool, real2dummy, option);
  if (retBdd == NULL) return(NULL);

  FREE(real2dummy);

  return(retBdd);

} /* end of BDS_BuildDummyLocalBdd */

/**Function********************************************************************

  Synopsis    [BDD store program]

  Description [A BDD is stored in SOP form. BDD variables which are not in the
  support set of the BDD are not recorded. This is only useful for storing local
  BDDs. For global BDDs, the size of SopPool may blow up. Return SopPool* if
  successful; NULL otherwise.]

  SideEffects []

  SeeAlso     [BDS_DumpSOP()]

  LastDate    [3/27/99]

******************************************************************************/
extern
SopPool *
BDS_DumpSopLocal(
  DdManager *bddmgr,
  DdNode *bdd)
{
  SopPool     *retSopPool;
  int         i, *list, result, *order, level;
  array_t     *sop;
  char        *line;
  DdNode      *N, *support, *scan;
  int         *level2Id, *id2Level;

  support = Cudd_Support(bddmgr, bdd);
  if (support == NULL) return(NULL);
  cuddRef(support);

  level = Cudd_SupportSize(bddmgr,support);
  level2Id = ALLOC(int, level);
  id2Level = ALLOC(int, bddmgr->size);

  scan = support;
  i = 0;
  while (!cuddIsConstant(scan)) {
      level2Id[i] = Cudd_NodeReadIndex(scan);
      id2Level[Cudd_NodeReadIndex(scan)] = i;
      i++;
      scan = cuddT(scan);
  }
  Cudd_RecursiveDeref(bddmgr, support);

  list = ALLOC(int, level);
  if (list == NULL) {
        fail("Out of memory");
  }

  sop = array_alloc(char *, 0);
  for (i = 0; i < level; i++) list[i] = 2;

  N = Cudd_Regular(bdd);
  if (Cudd_IsComplement(bdd)) {
        N = Cudd_Not(N);
  }

  result = BDS_DumpSopLocalRecursive(bddmgr, N, list, sop, id2Level, level);

  retSopPool = ALLOC(SopPool, 1);
  retSopPool->size = level;
  retSopPool->sop = sop;
  retSopPool->order = level2Id;

  FREE(id2Level);
  FREE(list);
  return(retSopPool);

} /* end of BDS_DumpSopLocal */

/**Function********************************************************************

  Synopsis    [Performs the recursive step of BDS_DumpSopLocal.]

  Description []

  SideEffects [None]

******************************************************************************/
static
int
BDS_DumpSopLocalRecursive(
  DdManager *bddmgr,
  DdNode *bdd,
  int *list,
  array_t *currentSOP,
  int *id2Level,
  int level /* The height of the BDD */)
{
    DdNode      *N,*Nv,*Nnv;
    int         i,v,index;
    char        *line;
    DdNode      *background;

    background = bddmgr->background;
    N = Cudd_Regular(bdd);

    if (cuddIsConstant(N)) {
        /* Terminal case: Print one cube based on the current recursion
        ** path, unless we have reached the background value. */
        if (bdd != background && bdd != Cudd_ReadLogicZero(bddmgr)) {
            line = ALLOC(char, level + 1);
            for (i = 0; i < level; i++) {
                v = list[i];
                if (v == 0) line[i] = '0';
                else if (v == 1) line[i] = '1';
                else line[i] = '-';
            }
            line[i] = '\0';
            array_insert_last(char *, currentSOP, line);
        }
    } else {
        Nv  = cuddT(N);
        Nnv = cuddE(N);
        if (Cudd_IsComplement(bdd)) {
            Nv  = Cudd_Not(Nv);
            Nnv = Cudd_Not(Nnv);
        }
        index = id2Level[N->index];
        list[index] = 0;
        BDS_DumpSopLocalRecursive(bddmgr,Nnv,list,currentSOP,id2Level,level);
        list[index] = 1;
        BDS_DumpSopLocalRecursive(bddmgr,Nv,list,currentSOP,id2Level,level);
        list[index] = 2;
    }

    return(1);

} /* end of BDS_DumpSopLocalRecursive */

/**Function********************************************************************

  Synopsis    [Build a BDD from a local SopPool]

  Description [The function operates on the SopPool* (local format), real2dummy
  is used for variable transformation. Return BDD if successful, NULL otherwise.] ///a

  SideEffects []

  SeeAlso     []

  LastDate    [3/27/99]

******************************************************************************/
extern
DdNode *
BDS_BuildDDFromSopLocal(
  DdManager *bddmgr,
  SopPool *soppool,
  int *real2dummy,
  bdsOptions *option)
{
  int      i, j;
  char     *line;
  DdNode   *resultBdd, *prod, *tmp, *var;
  int      *order;

  resultBdd = Cudd_ReadLogicZero(bddmgr);
  Cudd_Ref(resultBdd);

  order = soppool->order;
  for (i = 0; i < soppool->sop->num; i++) {
      line = array_fetch(char *, soppool->sop, i);

      /* Initialize the product to logical 1. */
      prod = Cudd_ReadOne(bddmgr);
      Cudd_Ref(prod);

      /* Scan the sop line. The order of variables is according to the index.
      ** NOT the order in the BDD mgr. */
      for (j = 0; j < soppool->size; j++) {
          if (line[j] == '-') continue;
          if (line[j] == '1') {
             var = Cudd_ReadVars(bddmgr, real2dummy[order[j]]);
          } else {
             var = Cudd_Not(Cudd_ReadVars(bddmgr, real2dummy[order[j]]));
          }
          Cudd_Ref(var);
          tmp = Cudd_bddAnd(bddmgr, prod, var);
          if (tmp == NULL) fail("Serious error in BDS_BuildDDFromSOP\n");
          Cudd_Ref(tmp);
          Cudd_Deref(var); /* keep the ref. count on vars small */
          Cudd_RecursiveDeref(bddmgr, prod);
          prod = tmp;
      }
      tmp = Cudd_bddOr(bddmgr, resultBdd, prod);
      if (tmp == NULL) exit(2);
      Cudd_Ref(tmp);

      Cudd_RecursiveDeref(bddmgr, resultBdd);
      Cudd_RecursiveDeref(bddmgr, prod);

      resultBdd = tmp;
  }

  return(resultBdd);

} /* end of BDS_BuildDDFromSopLocal */

/**Function********************************************************************

  Synopsis    [Convert all dummy varId back to real varId]

  Description []

  SideEffects []

  SeeAlso     []

  LastDate    [3/28/99]

******************************************************************************/
extern
int
bdsConvertDummy2Real(
  FactorTreeNode *fnode,
  int *dummy2realId,
  bdsOptions *option)
{
  int result;
  st_table *visited;

  visited = st_init_table(st_ptrcmp,st_ptrhash);

  result = bdsConvertDummy2RealRecursive(fnode, dummy2realId, visited, option);
  if (result == 0) return(0);

  st_free_table(visited);
  FREE(dummy2realId);

  return(1);

} /* end of bdsConvertDummy2Real */

/**Function********************************************************************

  Synopsis    [Recursive program for bdsConvertDummy2Real()]

  Description []

  SideEffects []

  SeeAlso     []

  LastDate    [3/28/99]

******************************************************************************/
static
int
bdsConvertDummy2RealRecursive(
  FactorTreeNode *fnode,
  int *dummy2realId,
  st_table *visited,
  bdsOptions *option)
{
  int result;
  FactorTreeNode *top, *dp, *dm, *ctl;

  if (st_is_member(visited, (char *) fnode)) return(1);

  /* Convert varIds on the terminal fnodes */
  if ((fnode->value != BDS_FTREE_INTERNAL)) {
      fnode->value = dummy2realId[fnode->value];

      if (st_add_direct(visited, (char *) fnode, NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory");
          return(0);
      }
      return(1);
  }

  top = Fnode_Regular(fnode);

  dp = top->siblings[0];
  dm = top->siblings[1];
  if (top->op == BDS_BDD_MUX) {
      ctl = top->siblings[2];
  }

  if (top->siblings[0] != NULL) { ///pga
  /* Traverse in dfs fashion */
  result = bdsConvertDummy2RealRecursive(dp, dummy2realId, visited, option);
  if (result == 0) return(0);
  } ///pga

  if (top->siblings[1] != NULL) { ///pga
  result = bdsConvertDummy2RealRecursive(dm, dummy2realId, visited, option);
  if (result == 0) return(0);
  } ///pga

  if (top->op == BDS_BDD_MUX) {
      result = bdsConvertDummy2RealRecursive(ctl, dummy2realId, visited, option);
      if (result == 0) return(0);
  }

  if (st_add_direct(visited, (char *) fnode, NULL) == ST_OUT_OF_MEM) {
      printf("Out of memory");
      return(0);
  }

  return(1);

} /* end of bdsConvertDummy2RealRecursive */

/**Function********************************************************************

  Synopsis    [Store a BDD into bddPool]

  Description [The function is very similar to BDS_DumpBddPool(). The only difference
  is the way to handle constant bnode. In BDS_DumpBddPool(), the constant node
  is actually the pointer to the terminal node of a specific bddmgr while in this
  function we want all constant nodes to be genric. Therefore a BDD can be constructed
  in any bddmgr based the bddPool. The function is created for efficient handling of
  storing local BDDs in which a BDD is constructed in a bddmgr which is NOT the same bddmgr
  it was originally dumped. It is also used in reordering-based eliminate. Return bddPool*
  if successful; NULL otherwise]

  SideEffects []

  SeeAlso     [BDS_DumpBddPool]

******************************************************************************/
extern
bddPool *
BDS_StoreBddPoolLocal(
  DdManager *bddmgr,
  DdNode *bdd)
{
    int         i, id, *order; /* Variable order when this BDD is dumped */
    bddPool     *ddPool; /* return pointer */
    st_table    *inPool; /* nodes already dumped */
    bddNode     *inode;
    DdNode      *support, *scan;
    int         *level2Id, level;

    support = Cudd_Support(bddmgr, bdd); /// Finds the variables on which a DD depends, Returns a BDD consisting of the product of the variables
    if (support == NULL) return(NULL);
    cuddRef(support);

    level = Cudd_SupportSize(bddmgr,support); /// Counts the variables on which a DD depends
    level2Id = ALLOC(int, level);

    scan = support;
    i = 0;
    while (!cuddIsConstant(scan)) { /// go through the BDD to record the index of nodes until the constant node is reached
        level2Id[i] = Cudd_NodeReadIndex(scan); /// Returns the index of the node. The node pointer can be either regular or complemented
        i++;
        scan = cuddT(scan); /// Returns the then child of an internal node. If node is a constant node, the result is unpredictable
    }
    Cudd_RecursiveDeref(bddmgr, support);

    inPool = st_init_table(st_ptrcmp,st_ptrhash);
    if(inPool == NULL) return(NULL);

    inode = BDS_StoreBddPoolLocalRecursive(bddmgr, bdd, inPool);
    if (inode == NULL) return(NULL);

    st_free_table(inPool);

    /* Construct return value */
    ddPool = ALLOC(bddPool, 1);
    if(ddPool == NULL) return(NULL);

    ddPool->order = level2Id; /// set index array of the variables
    ddPool->bnode = inode; /// set ddPool->bnode to inode (bddNode)
    ddPool->numVar = level; /// set # variables counted above

    return(ddPool);

} /* end of BDS_StoreBddPoolLocal */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_DumpBddPool]

  Description [Return bddNode if successful; NULL otherwise]

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
bddNode *
BDS_StoreBddPoolLocalRecursive(
  DdManager *bddmgr,
  DdNode *bdd,
  st_table *inPool)
{
    bddNode *inode, *tnode, *enode, *poolNode;
    DdNode *idd, *tdd, *edd;

    /* Construct constant bnode */
    if (Cudd_IsConstant(bdd)) { /// if constant node
        inode = ALLOC(bddNode, 1);
        inode->dd = NULL;
        inode->t_nd = NULL;
        inode->e_nd = NULL;
        if (Cudd_IsComplement(bdd)) { /* constant 0 */
            inode->index = BDDPOOL_LOCAL_ZERO; /// = 0xFFFE
        }
        else { /* constant 1 */
            inode->index = BDDPOOL_LOCAL_ONE; /// = 0xFFFF
        }
        return(inode);
    }

    idd = Cudd_Regular(bdd);
    if (st_lookup(inPool, (char *)idd, (char **) &poolNode)) { /* Already dumped */
        inode = poolNode;
        ///inode = Cudd_IsComplement(bdd) ? DumpNode_Complement(inode) : inode; ///pga r
        if (Cudd_IsComplement(bdd)) { ///pga
            DumpNode_Complement(inode); ///pga #define DumpNode_Complement(node) ((bddNode *)((unsigned long)(node) | 01)) in lopt.h
        } ///pga
        return(inode);
    }

    tdd = Cudd_Regular(Cudd_T(bdd));
    edd = Cudd_Regular(Cudd_E(bdd));

    /* Dump T branch */
    if (st_lookup(inPool, (char *)tdd, (char **) &poolNode)) {
        tnode = Cudd_IsComplement(Cudd_T(bdd)) ? DumpNode_Complement(poolNode) : poolNode;
    }
    else {
        tnode = BDS_StoreBddPoolLocalRecursive(bddmgr, Cudd_T(bdd), inPool);
    }

    /* Dump E branch */
    if (st_lookup(inPool, (char *)edd, (char **) &poolNode)) {
        enode = Cudd_IsComplement(Cudd_E(bdd)) ? DumpNode_Complement(poolNode) : poolNode;
    }
    else {
        enode = BDS_StoreBddPoolLocalRecursive(bddmgr, Cudd_E(bdd), inPool);
    }

    /* Construct bddNode */
    inode = ALLOC(bddNode, 1);
    inode->index = Cudd_NodeReadIndex(bdd);
    inode->dd = NULL;
    inode->t_nd = tnode;
    inode->e_nd = enode;

    if (st_add_direct(inPool, (char *)idd, (char *)inode) == ST_OUT_OF_MEM) { /// add inode with key idd to inPool
        printf("Out of memeory !\n");
        return(NULL);
    }

    inode = Cudd_IsComplement(bdd) ? DumpNode_Complement(inode) : inode;

    return(inode);

} /* end of BDS_StoreBddPoolLocalRecursive */

/**Function********************************************************************

  Synopsis    [Build a BDD from a local bddPool]

  Description [Build BDDs in the local bddmgr. The varId in the new bddmgr is different
  from varIds when the BDD is stored. New vars are created in the original order
  in bddPool*. Therefore, there is no need to do var shuffle. The correspondency
  between new varIds and old varIds is recorded. Return DdNode* if successful;
  NULL otherwise]

  SideEffects []

  SeeAlso     [BDS_BuildDDFromBddPool]

  LastDate    [3/29]

******************************************************************************/
extern
DdNode *
BDS_BuildDDFromBddPoolLocal(
  DdManager *bddmgr,
  bddPool *ddPool,
  int **dummy2realId,
  int numRealVar,
  bdsOptions *option,
  int **real2dumbo) ///pga
{
  int result, i;
  DdNode *retBdd;
  DdNode *dummyVar;
  int dummyIndex, realIndex, *order, *real2dummy;

  real2dummy = ALLOC(int, numRealVar);
  *dummy2realId = ALLOC(int, ddPool->numVar);
  if (option->performancedecomp == TRUE) ///pga
  *real2dumbo = ALLOC(int, numRealVar); ///pga

  /* Create dummy variables */
  order = ddPool->order;
  for (i = 0; i < ddPool->numVar; i++) {
      dummyVar = Cudd_bddNewVar(bddmgr);
      if (dummyVar == NULL) return(NULL);

      dummyIndex = i;
      realIndex = order[i];

      real2dummy[realIndex] = dummyIndex;
      (*dummy2realId)[dummyIndex] = realIndex;
       if (option->performancedecomp == TRUE) ///pga
      (*real2dumbo)[realIndex] = dummyIndex; ///pga
  }

  /* Reconstruct BDD */
  retBdd = BDS_BuildDDFromBddPoolLocalRecursive(bddmgr,ddPool->bnode, 1, real2dummy);
  if (retBdd == 0) return(NULL);

  retBdd = DumpNode_IsComplement(ddPool->bnode) ? Cudd_Not(retBdd) : retBdd;

  /* Free BDD flags on the bddPool nodes. BDDs will be re-constructed on those
  ** bddPool * later, when verification is specified. */
  (void) bdsClearBddPoolFlagLocal(bddmgr, ddPool);

  FREE(real2dummy);

  return(retBdd);

} /* end of BDS_BuildDDFromBddPoolLocal */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_BuildDDFromBddPoolLocal]

  Description [If transfer is 1, BDD is created by using real2dummy; otherwise
  whatever index stored in the bddPool will be used. Return BDD is successful;
  NULL otherwise.]

  SideEffects []

  SeeAlso     [BDS_BuildDDFromBddPool]

  LastDate    [3/29]

******************************************************************************/
extern
DdNode *
BDS_BuildDDFromBddPoolLocalRecursive(
  DdManager *bddmgr,
  bddNode *bnode,
  int transfer, /* Flag, if transfer real2dummy */
  int *real2dummy)
{
  int result;
  bddNode *inode, *tnode, *enode;
  DdNode *idd, *tdd, *edd, *var;
  DdNode *f0, *f1;

  inode = DumpNode_Regular(bnode);

  /* Construct constant nodes */
  if (inode->index == BDDPOOL_LOCAL_ZERO)    /* return logic zero */
      return(Cudd_ReadLogicZero(bddmgr));
  else if (inode->index == BDDPOOL_LOCAL_ONE) /* return 1 */
      return(Cudd_ReadOne(bddmgr));

  if (inode->dd != NULL) {
      Cudd_Ref(inode->dd);
      return(inode->dd);
  }

  tnode = inode->t_nd;
  enode = inode->e_nd;

 // printf("local %d\n",inode->index );
  if (transfer)
      var = Cudd_ReadVars(bddmgr, real2dummy[inode->index]);
  else
      var = Cudd_ReadVars(bddmgr, inode->index);
  Cudd_Ref(var);

  if (DumpNode_Regular(tnode)->index != BDDPOOL_LOCAL_ZERO
                 && DumpNode_Regular(tnode)->index != BDDPOOL_LOCAL_ONE) {
      tdd = BDS_BuildDDFromBddPoolLocalRecursive(bddmgr, tnode, transfer, real2dummy);
      tdd = DumpNode_IsComplement(tnode) ? Cudd_Not(tdd) : tdd;
  }
  else {
      if (DumpNode_Regular(tnode)->index == BDDPOOL_LOCAL_ZERO)
      tdd = Cudd_ReadLogicZero(bddmgr);
      else
      tdd = Cudd_ReadOne(bddmgr);
  }
  if (DumpNode_Regular(enode)->index != BDDPOOL_LOCAL_ZERO
                 && DumpNode_Regular(enode)->index != BDDPOOL_LOCAL_ONE) {
      edd = BDS_BuildDDFromBddPoolLocalRecursive(bddmgr, enode, transfer, real2dummy);
      edd = DumpNode_IsComplement(enode) ? Cudd_Not(edd) : edd;
  }
  else {
      if (DumpNode_Regular(enode)->index == BDDPOOL_LOCAL_ZERO)
      edd = Cudd_ReadLogicZero(bddmgr);
      else
      edd = Cudd_ReadOne(bddmgr);
  }

  idd = Cudd_bddIte(bddmgr, var, tdd, edd);
  if (idd == NULL) return(NULL);
  Cudd_Ref(idd);

  Cudd_Deref(var);
  if (!Cudd_IsConstant(tdd)) Cudd_Deref(tdd);
  if (!Cudd_IsConstant(edd)) Cudd_Deref(edd);

  inode->dd = idd;

  return(idd);

} /* end of BDS_BuildDDFromBddPoolLocalRecursive */

/**Function********************************************************************

  Synopsis    [Build local dummy BDD without creating dummy vars]

  Description [Similar to bdsBuildDDFromBddPoolLoca. This can be used to construct
  BDDs in a bddmgr in which all required vars have been created. ]

  SideEffects []

  SeeAlso     [BDS_BuildDDFromBddPoolLocal]

  Last Date   [3/30/99]

*****************************************************************************/
extern
DdNode *
bdsBuildDDFromBddPoolLocalWithOutCreateDummy(
  DdManager *bddmgr,
  bddPool *ddPool,
  int *real2dummy)
{
  DdNode *retBdd;

  retBdd = BDS_BuildDDFromBddPoolLocalRecursive(bddmgr, ddPool->bnode, 1, real2dummy);
  if (retBdd == 0) return(NULL);

  retBdd = DumpNode_IsComplement(ddPool->bnode) ? Cudd_Not(retBdd) : retBdd;

  /* Free BDDs on the bddPool nodes and free bddPool itself */
  (void) bdsFreeBddPoolLocal(bddmgr, ddPool);

  return(retBdd);

} /* end of bdsBuildDDFromBddPoolLocalWithOutCreateDummy */

/**Function********************************************************************

  Synopsis    [Clear dd field on all bddPool nodes]

  Description []

  SideEffects []

  SeeAlso     []

  LastDate    [4/2/99]

******************************************************************************/
static
void
bdsClearBddPoolFlagLocal(
  DdManager *bddmgr,
  bddPool *ddPool)
{
  bddNode *bnode;
  st_table *visited;

  visited = st_init_table(st_ptrcmp, st_ptrhash);
  bnode = ddPool->bnode;

  bdsClearBddPoolFlagLocalRecursive(bddmgr, bnode, visited);

  st_free_table(visited);

} /* end of bdsClearBddPoolFlagLocal */

/**Function********************************************************************

  Synopsis    []

  Description []

  SideEffects []

  SeeAlso     []

  LastDate    [4/2]

******************************************************************************/
static
void
bdsClearBddPoolFlagLocalRecursive(
  DdManager *bddmgr,
  bddNode *bnode,
  st_table *visited)
{
  bddNode *inode, *tnode, *enode;

  inode = DumpNode_Regular(bnode);

  if (st_is_member(visited, (char *)inode) == 1) { /* Already cleared */
      return;
  }
  if (inode->index == BDDPOOL_LOCAL_ONE || inode->index == BDDPOOL_LOCAL_ZERO) {
      return;
  }

  tnode = inode->t_nd;
  enode = inode->e_nd;

  (void) bdsClearBddPoolFlagLocalRecursive(bddmgr, tnode, visited);
  (void) bdsClearBddPoolFlagLocalRecursive(bddmgr, enode, visited);

  if (st_add_direct(visited, (char *) inode, NULL) == ST_OUT_OF_MEM) {
      printf("Out of memeory !");
      exit(2);
  }

  inode->dd = NULL;

  return;

} /* end of bdsClearBddPoolFlagLocalRecursive */

/**Function********************************************************************

  Synopsis    [Free BDD nodes in bddPool and free bddPool itself]

  Description []

  SideEffects []

  SeeAlso     []

  LastDate    [3/29]

******************************************************************************/
extern
void
bdsFreeBddPoolLocal(
  DdManager *bddmgr,
  bddPool *ddPool)
{
  bddNode *bnode;
  st_table *deleted;

  deleted = st_init_table(st_ptrcmp, st_ptrhash);

  bnode = ddPool->bnode;

  bdsFreeBddPoolLocalRecursive(bddmgr, bnode, deleted);

  st_free_table(deleted);

  FREE(ddPool->order);
  FREE(ddPool);

} /* end of bdsFreeBddPoolLocal */

/**Function********************************************************************

  Synopsis    [Free bddPool itself]

  Description []

  SideEffects []

  SeeAlso     []

  LastDate    [3/29]

******************************************************************************/
static
void
bdsFreeBddPoolLocalRecursive(
  DdManager *bddmgr,
  bddNode *bnode,
  st_table *deleted)
{
  bddNode *inode, *tnode, *enode;

  inode = DumpNode_Regular(bnode);

  if (st_is_member(deleted, (char *)inode) == 1) { /* Already cleared */
      return;
  }

  if (inode->index == BDDPOOL_LOCAL_ONE || inode->index == BDDPOOL_LOCAL_ZERO) {
      FREE(inode);
      return;
  }

  tnode = inode->t_nd;
  enode = inode->e_nd;

  (void) bdsFreeBddPoolLocalRecursive(bddmgr, tnode, deleted);
  (void) bdsFreeBddPoolLocalRecursive(bddmgr, enode, deleted);

  if (st_add_direct(deleted, (char *) inode, NULL) == ST_OUT_OF_MEM) {
      printf("Out of memeory !");
      exit(2);
  }

  FREE(inode);
  return;

} /* end of bdsFreeBddPoolLocalRecursive */







