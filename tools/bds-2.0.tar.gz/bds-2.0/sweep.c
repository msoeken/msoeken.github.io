
/**CFile***********************************************************************

  FileName    [sweep.c]

  PackageName [BDS-pga]

  Synopsis    [Sweep through Boolean network to remove contant and functionally
  duplicated bnodes. BDDs are used to carry out this mission.]

  Description [This file contains the functions for sweeping the boolean network.]

  SeeAlso     []

  Author      [Anda Congguang Yang]

  Copyright   [The file was created in Department of Electrical & Computer
    Engineering, University of Massachusetts Amherst. All source codes
    in BDS package are CONFIDENTIAL before a formal release is
    announced. The author reserve all right of the package.]

******************************************************************************/

#include "sweep.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static lsList bdsGenerateConstant ARGS((DdManager*,BnetNetwork*,bdsOptions*));
static int bdsSweepConstant ARGS((DdManager*,BnetNetwork*,lsList,bdsOptions*));
static st_table* bdsGenerateDuplicate ARGS((DdManager*,BnetNetwork*,bdsOptions*));
static void bdsCreateNewBnodeWithRef ARGS((DdManager*,BnetNode*,BnetNode*));
static int bdsSubstitutePOFanin ARGS((DdManager*,BnetNode*,BnetNode*));
static int bdsSubstituteInternal ARGS((DdManager*,BnetNetwork*,BnetNode*,BnetNode*));


/**Function********************************************************************

  Synopsis    [Sweep Boolean network to remove constant, single-variable and
  duplicate bnodes.]

  Description [This function performs two tasks. 1) constant and single-variable
  bnode propagation. 2) functionally duplicated Boolean node removal. For 1),
  the constant or single-variable bnode is composed into its fanouts; for 2),
  functionally duplicated bnodes are identified using BDDs. If a duplicated
  bnode is found, re-pointing its fanouts to the functionally equivalent existing
  bnodes, delete the bnode after that. Return 1 if successful; 0 otherwise.]

  SideEffects []

  SeeAlso     []

  LastDate    [6/2/99]

******************************************************************************/
extern
int
BDS_SweepBnetwork(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option)
{
    int result;

    printf("\nSweeping ..");
    fflush(stdout);

    result = BDS_SweepConstant(bddmgr, net, option);
    if (result == 0) return(0);

    result = BDS_SweepDuplicate(bddmgr, net, option);
    if (result == 0) return(0);

    printf("Done\n\n");

    return(1);

} /* end of BDS_SweepBnetwork */

/**Function********************************************************************

  Synopsis    [Sweep Boolean network to remove constant, single-variable bnodes.]

  Description [Constant and single-variable bnodes are composed into its fanouts.
  This function should not be used right after read-in a Boolean network, becasue
  BDS_BuildLocalBDD() does not create a separate variable for a constant bnode.
  The initial Boolean network should be sweeped by SIS sweep function.
  Since the propagation of constant and single-variable bnode may create more
  others, the sweep process is iterative.]

  SideEffects []

  SeeAlso     []

  LastDate    [6/2/99]

******************************************************************************/
extern
int
BDS_SweepConstant(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option)
{
    int result;
    lsList clist;   /* A list of bnodes whcih initiated a sweep operation. */

    /* Temporily disbale this. -cyang 6/8/99 */
    return(1);

    clist = bdsGenerateConstant(bddmgr, net, option);
    while (clist) {

        result = bdsSweepConstant(bddmgr, net, clist, option);
        if (result == 0) return(0);

        lsDestroy(clist, NULL);

        clist = bdsGenerateConstant(bddmgr, net, option);
  }

  return(1);

} /* end of BDS_SweepConstant */

/**Function********************************************************************

  Synopsis    [Sweep Boolean network to remove functionally duplicated bnodes.]

  Description [Functionally duplicated bnodes are identified using BDDs. If a
  duplicated bnode is found, re-pointing its fanouts to the functionally equivalent
  existing bnodes, delete the bnode after that.]

  SideEffects []

  SeeAlso     []

  LastDate    [6/2/99]

******************************************************************************/
extern
int
BDS_SweepDuplicate(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option)
{
    int         result, *live;
    BnetNode    *bnode;
    DdNode      *bdd;
    lsList      dlist;
    st_generator *gen;
    st_table    *dupTbl; /* a functionally duplicated node */

    dupTbl = bdsGenerateDuplicate(bddmgr, net, option); /// find duplicated nodes
    while (dupTbl) {

        result = bdsSweepDuplicate(bddmgr, net, dupTbl, option);
        if (result == 0) return(0);

        gen = st_init_gen(dupTbl);
        while (st_gen(gen, (char **) &bdd, (char **) &dlist)) {
            lsDestroy(dlist, NULL);
        }
        st_free_gen(gen);
        st_free_table(dupTbl);

        dupTbl = bdsGenerateDuplicate(bddmgr, net, option); /// iterative finding and sweeping duplicated nodes
  }

  /* Remove dead bnodes from livenode table and free bnodes. */
  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &bnode, (char **) &live)) {
      if (live == (int *) DEAD_BNODE) {
          st_delete(net->livenodes, (char **) &bnode, (char **) NULL);
          (void) bdsFreeBnetNode(bddmgr, bnode);
      }
  }
  st_free_gen(gen);

  return(1);

} /* end of BDS_SweepDuplicate */

/**Function********************************************************************

  Synopsis    [Find a constant bnode.]

  Description [All bnodes in the Boolean network are scaned to find a constant
  node. The constant bnode is referred to as a true constant or single-variable
  Boolean node. Return a list of constant nodes if found; NULL otherwise.]

  SideEffects []

  SeeAlso     []

  LastDate    [6/2/99]

******************************************************************************/
static
lsList
bdsGenerateConstant(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option)
{
  BnetNode *bnode;
  lsList clist= NULL;
  st_generator *gen;
  int *live;

  /* Generate true constant node and single-variable node. Constant node
  ** has higher priority. The native constant bnodes should be removed by
  ** initial constant propagation. Here only constant bnodes which are the
  ** resukts of logic operation are considered.
  */
  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &bnode, (char **) &live)) {
      if (live == (int *) DEAD_BNODE) continue;
      if (Cudd_IsConstant(bnode->localBdd) && bnode->type != BNET_CONSTANT_NODE) {
          if (clist == NULL) clist = lsCreate();
      if (lsNewEnd(clist, (lsGeneric) bnode, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }
      }
  }
  st_free_gen(gen);

  if (clist != NULL) return(clist);

  /* Only internal single-variable bnodes are removed. */
  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &bnode, (char **) &live)) {
      if (live == (int *) DEAD_BNODE) continue;
      if (bnode->type == BNET_INTERNAL_NODE &&
                (Cudd_IsConstant(Cudd_T(bnode->localBdd)) &&
                      Cudd_IsConstant(Cudd_E(bnode->localBdd))) ) {
          if (clist == NULL) clist = lsCreate();
      if (lsNewEnd(clist, (lsGeneric) bnode, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }
      }
  }
  st_free_gen(gen);

  return(clist);

} /* end of bdsGenerateSweepNode */

/**Function********************************************************************

  Synopsis    [Find functionally equivalent bnodes.]

  Description [All bnodes in the Boolean network are scaned to find if there is
  a existing functionally equivalent or complementary bnode. All functionally
  equivalent bnodes are put into a lsList, which in turn is stored in a hash
  table keyed by BDD nodes. The lsList may contains bnodes with both regular
  and negative pointers. Return a hash table if there are any functionally
  equivalent bnodes; NULL otherwise.]

  SideEffects []

  SeeAlso     []

  LastDate    [6/2/99]

******************************************************************************/
static
st_table*
bdsGenerateDuplicate(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option)
{
    BnetNode    *bnode;/* A Boolean network node */
    DdNode      *bdd;    /* A BDD node */
    lsList      dlist;   /* Functionally equivalent or complementary Boolean network nodes */
    st_table    *dupTbl;
    st_generator *gen;
    lsGen       nodeGen;
    int         *live;

    dupTbl = st_init_table(st_ptrcmp,st_ptrhash);
    gen = st_init_gen(net->livenodes);
    while (st_gen(gen, (char **) &bnode, (char **) &live)) {
        if (bnode->type == BNET_INPUT_NODE) continue; /// skip input nodes
        if (live == (int *) DEAD_BNODE) continue; /// = 0xFFF0 /// skip dead nodes

        bdd = bnode->localBdd;

        /* Internal constant should be sweeped. However, under some cases,
        ** POs are constant. */
        if (Cudd_IsConstant(bdd)) continue; /// skip constant nodes

        /* If both regular and complement bdd are not in the table, add it in */
        if (!st_lookup(dupTbl, (char *) bdd, (char **) &dlist)
                    && !st_lookup(dupTbl, (char *) Cudd_Not(bdd), (char **) &dlist)) {
            /* Put bnode in the beginning of slist, all the rest bnodes
            ** use it as reference; if a bnode is regular, the bnode has
            ** the same functionality; if a bnode is negative pointer, the
            ** functionality is complementary to the first element of dlist.
            */
            dlist = lsCreate();
            if (lsNewEnd(dlist, (lsGeneric) bnode, NULL) != LS_OK) { /// add the new bnode to dlist
                printf("Out of memory"); exit(2);
            }
            if (st_add_direct(dupTbl, (char *) bdd, (char *) dlist) == ST_OUT_OF_MEM) { /// add the new bdd and dlist to dupTbl
                printf("Out of memory"); exit(2);
            }
        }
        else { /* Found a duplicated bnode */ /// dlist has the dlist of the bdd in dupTbl
            /* If the bnode is an PO node and it just has one variable, it serves
            ** as the link to upper level functions, don't put it into equivalent list.
            */
            if (bnode->type == BNET_OUTPUT_NODE
                     && Cudd_IsConstant(Cudd_T(bnode->localBdd))
                 && Cudd_IsConstant(Cudd_E(bnode->localBdd))) continue;

            if (lsNewEnd(dlist, (lsGeneric) bnode, NULL) != LS_OK) { /// add the duplicated bnode to dlist of the bdd (now has more than one entry in dlist)
                printf("Out of memory"); exit(2);
            }

            /* The negative pointer associated is disabled from v-1.2, the polarity information
            ** a bnode is found by using it localBdd. -cyang 8/16/99

            if (st_lookup(dupTbl, (char *) bdd, (char **) &dlist)) {
            if (lsNewEnd(dlist, (lsGeneric) bnode, NULL) != LS_OK) {
              printf("Out of memory"); exit(2);
            }
            }
            else if (st_lookup(dupTbl, (char *) Cudd_Not(bdd), (char **) &dlist)) {
            if (lsNewEnd(dlist, (lsGeneric) bnode_Complement(bnode), NULL) != LS_OK) {
              printf("Out of memory"); exit(2);
            }
            }
            else {
              printf("Fatal error in bdsGenerateDuplicate()\n\n");
            exit(2);
            }
            */

        }
    }
    st_free_gen(gen);

    /* Clean up dupTbl, remove entry with only one bnode in the lsList */
    gen = st_init_gen(dupTbl);
    while (st_gen(gen, (char **) &bdd, (char **) &dlist)) {
        if (lsLength(dlist) == 1) {
            st_delete(dupTbl, (char **) &bdd, (char **) &dlist);
            lsDestroy(dlist, NULL);
        }
#ifdef DEBUG
        else {
            db(bddmgr,bdd); /// Cudd_PrintDebug(bddmgr,bdd,1,3)
            printf("Number of shared = %d\n\n",lsLength(dlist));
            nodeGen = lsStart(dlist);
            while (lsNext(nodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
                printf("%x;",bnode);
            }
            lsFinish(nodeGen);
            printf("\n\n");
        }
#endif
    } /// end of while
    st_free_gen(gen);

    if (!st_count(dupTbl)) { /// if dupTbl becomes empty (if no duplicated node)
        st_free_table(dupTbl);
        dupTbl = NULL;
    }

    return(dupTbl);

} /* end of bdsGenerateDuplicate */

/**Function********************************************************************

  Synopsis    [Sweep a constant node]

  Description [A constant bnode is composed into its fanouts, then the bnode is
  deleted. The same process is applied onto its fanouts until the propagation is
  settled down. Return 1 if successful; 0 otherwise.]

  SideEffects []

  SeeAlso     []

  LastDate    [6/2/99]

******************************************************************************/
static
int
bdsSweepConstant(
  DdManager *bddmgr,
  BnetNetwork *net,
  lsList clist,  /* A list of constant bnode */
  bdsOptions *option)
{

  return(1);

} /* end of bdsSweepConstant */

/**Function********************************************************************

  Synopsis    [Remove functionally duplicated nodes]

  Description [Functionally duplicated bnodes are removed from the Boolean network.
  All functionally equivalent bnodes are stored in a lsList which is keyed by a BDD
  node in dupTbl. The treatment of internal nodes and primary output nodes are
  different. The pointers allocated for POs should not be deleted, however, for internal
  nodes, since the connectivity is mantained by input and output link list, therefore,
  they are free to be deleted. The new reference variable is composed into its fanouts.
  Those to be removed bnodes are not deleted from livenodes table immediately, they
  are just marked with DEAD_BNODE, it's user's responbility to remove them from
  livenodes table and free them. Return 1 if successful; 0 otherwise.]

  SideEffects [Boolean network is modified]

  SeeAlso     []

  LastDate    [6/9/99]

******************************************************************************/
extern
int
bdsSweepDuplicate(
  DdManager *bddmgr,
  BnetNetwork *net,
  st_table *dupTbl,
  bdsOptions *option)
{
    st_generator *gen;
    lsGen       nodeGen, fanodeGen, faninGen;
    lsList      dupList;
    BnetNode    *bnode, *ref_bnode, *new_bnode, *fanode, *fanin_node, *dummy_node, *reg_bnode;
    int         result;
    DdNode      *bdd;

    gen = st_init_gen(dupTbl);
    while (st_gen(gen, (char **) &bdd, (char **) &dupList)) {

#ifndef DEBUG
        (void) printf(".");
        (void) fflush(stdout);
#endif
        /* Find out if there are any internal bnodes in the list. If there is no
        ** internal bnodes, a new bnode will be created to hold the shared bnodes.
        ** All POs are modified as a transparent bnode.
        */
        ref_bnode = NULL;
        nodeGen = lsStart(dupList);
        while (lsNext(nodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
            if (bnode_Regular(bnode)->type == BNET_INTERNAL_NODE) {
                ref_bnode = bnode;
                break;
            }
        }
        lsFinish(nodeGen);

        if (ref_bnode) { /* There is an internal bnode in the list */
            nodeGen = lsStart(dupList);
            while (lsNext(nodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
                if (bnode == ref_bnode) continue;

                if (bnode_Regular(bnode)->type == BNET_OUTPUT_NODE) {
                    result = bdsSubstitutePOFanin(bddmgr,bnode,ref_bnode);
                    if (result == 0) return(0);
                }
                else { /* BNET_INTERNAL_NODE */
                    result = bdsSubstituteInternal(bddmgr,net,bnode,ref_bnode);
                    if (result == 0) return(0);
                }
            }
            lsFinish(nodeGen);

            (void) lsSort(bnode_Regular(ref_bnode)->fanouts, bdsUniqueBnetNode);
            (void) lsUniq(bnode_Regular(ref_bnode)->fanouts, bdsUniqueBnetNode, NULL);
            (void) lsSort(bnode_Regular(ref_bnode)->fanins, bdsUniqueBnetNode);
            (void) lsUniq(bnode_Regular(ref_bnode)->fanins, bdsUniqueBnetNode, NULL);
        }
        else { /* All bnodes in the list are PO nodes. A new internal bnode should be
                ** created to hold the shared functions. */

            /* Use the first bnode in the list as reference bnode */
            lsFirstItem(dupList, (lsGeneric *) &ref_bnode, NULL);
            new_bnode = ALLOC(BnetNode, 1);
            if (st_add_direct(net->livenodes, (char *) new_bnode, (char *) LIVE_BNODE) == ST_OUT_OF_MEM) {
                printf("Out of memory !"); exit(2);
            }
            bdsCreateNewBnodeWithRef(bddmgr,new_bnode,ref_bnode);

            /* Re-structure the network */
            nodeGen = lsStart(dupList);
            while (lsNext(nodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
                result = bdsSubstitutePOFanin(bddmgr,bnode,new_bnode);
                if (result == 0) return(0);
            }
            lsFinish(nodeGen);

            /* Uniqufy fanins and fanins' fanouts list. */
            (void) lsSort(bnode_Regular(new_bnode)->fanins, bdsUniqueBnetNode);
            (void) lsUniq(bnode_Regular(new_bnode)->fanins, bdsUniqueBnetNode, NULL);
            nodeGen = lsStart(new_bnode->fanins);
            while (lsNext(nodeGen, (lsGeneric *) &bnode, NULL) != LS_NOMORE) {
                (void) lsSort(bnode->fanouts, bdsUniqueBnetNode);
                (void) lsUniq(bnode->fanouts, bdsUniqueBnetNode, NULL);
            }
            lsFinish(nodeGen);
        }
    }
    st_free_gen(gen);

    return(1);

} /* end of bdsSweepDuplicate */

/**Function********************************************************************

  Synopsis    []

  Description [Create a bnode, copy several field from reference bnode.]

  SideEffects []

  SeeAlso     []

  LastDate    [6/9/99]

******************************************************************************/
static
void
bdsCreateNewBnodeWithRef(
  DdManager *bddmgr,
  BnetNode *new_bnode,
  BnetNode *ref_bnode)
{
    DdNode      *var;
    lsGen       nodeGen;
    BnetNode    *bnode;

    var = Cudd_bddNewVar(bddmgr);

    new_bnode->type = BNET_INTERNAL_NODE;
    new_bnode->name = bdsCreateUniqueNodeName("bdsSweep");
    new_bnode->localVar = var->index;
    new_bnode->localActive = TRUE;
    new_bnode->dd = ref_bnode->dd;
    if (ref_bnode->dd != NULL) Cudd_Ref(new_bnode->dd);

    new_bnode->localBdd = ref_bnode->localBdd;
    Cudd_Ref(new_bnode->localBdd);

    new_bnode->fanins = lsCreate();
    new_bnode->fanouts = lsCreate();

    new_bnode->ninp = 0;
    new_bnode->f = NULL;
    new_bnode->inputs = NULL;

    return;

} /* end of bdsCreateNewBnodeWithRef */

/**Function********************************************************************

  Synopsis    [Substitute fanins of a PO node with a new bnode]

  Description []

  SideEffects []

  SeeAlso     [bdsSubstituteInternal]

  LastDate    [6/9/99]

******************************************************************************/
static
int
bdsSubstitutePOFanin(
  DdManager *bddmgr,
  BnetNode *ponode,
  BnetNode *ref_bnode /* New bnode */)
{
    DdNode      *ref_bdd;
    BnetNode    *reg_po, *reg_ref, *fanin_node, *fanout_node, *dummy_node;
    lsGen       faninGen, fanoutGen;

    reg_po = bnode_Regular(ponode);
    reg_ref = bnode_Regular(ref_bnode);
    ref_bdd = Cudd_ReadVars(bddmgr, reg_ref->localVar);

    /* Remove po from its fanins' fanout list. Add new_bnode as the fanout of
    ** po's fanins' fanout. Add po's fanins to new_bnode's fanins.
    */
    faninGen = lsStart(reg_po->fanins);
    while (lsNext(faninGen, (lsGeneric *) &fanin_node, NULL) != LS_NOMORE) {
        fanoutGen = lsStart(fanin_node->fanouts);
        while (lsNext(fanoutGen, (lsGeneric *) &fanout_node, NULL) != LS_NOMORE) {
            if (fanout_node == reg_po) {
            (void) lsDelBefore(fanoutGen, (lsGeneric*) &dummy_node);
            break;
            }
        }
        lsFinish(fanoutGen);

        if (lsNewEnd(fanin_node->fanouts, (lsGeneric) reg_ref, NULL) != LS_OK) {
            printf("Out of memory"); exit(2);
        }
        (void) lsSort(fanin_node->fanouts, bdsUniqueBnetNode);
        (void) lsUniq(fanin_node->fanouts, bdsUniqueBnetNode, NULL);

        if (lsNewEnd(reg_ref->fanins, (lsGeneric) fanin_node, NULL) != LS_OK) {
            printf("Out of memory"); exit(2);
        }
    }
    lsFinish(faninGen);

    /* Use new_bnode as fanin of this po node */
    lsDestroy(reg_po->fanins, NULL);
    reg_po->fanins = lsCreate();
    if (lsNewEnd(reg_po->fanins, (lsGeneric) reg_ref, NULL) != LS_OK) {
        printf("Out of memory"); exit(2);
    }

    /* Add po as a new fanout to new_bnode */
    if (lsNewEnd(reg_ref->fanouts, (lsGeneric) reg_po, NULL) != LS_OK) {
        printf("Out of memory"); exit(2);
    }

    Cudd_RecursiveDeref(bddmgr, reg_po->localBdd);

    reg_po->localBdd = (ref_bnode->localBdd == Cudd_Not(ponode->localBdd)) ? Cudd_Not(ref_bdd) : ref_bdd;

    Cudd_Ref(reg_po->localBdd);

    return(1);

} /* end of bdsSubstitutePOFanin */

/**Function********************************************************************

  Synopsis    [Substitute a internal node with a new bnode]

  Description [A bnode u is substituted by a functionally equivalent bnode. The procedure
  is 1) remove u from its fanouts' fanin list; 2) compose new bnode into u's fanouts.
  3) delete node u. The fanout list of ref_bnode may have duplication, it's user's
  responsibility to unique-lize it. Return 1 if successful; 0 otherwise.]

  SideEffects [Boolean network is modified]

  SeeAlso     [bdsSubstitutePOFanin]

  LastDate    [6/9/99]

******************************************************************************/
static
int
bdsSubstituteInternal(
  DdManager *bddmgr,
  BnetNetwork *net,
  BnetNode *inode, /* Internal node to be substituted */
  BnetNode *rnode /* A reference bnode */ )
{
    lsGen       fanodeGen, faninGen, fanoutGen;
    BnetNode    *ref_bnode, *new_bnode, *fanode, *fanin_node, *fanout_node, *dummy_node;
    BnetNode    *regn, *regr;
    DdNode      *ref_bdd, *composedBdd, *subBdd;
    int         ref_var;

    regn = bnode_Regular(inode);
    regr = bnode_Regular(rnode);

    ref_var = regr->localVar;
    ref_bdd = Cudd_ReadVars(bddmgr,ref_var);
    Cudd_Ref(ref_bdd);

    /* Remove inode from all its fanouts' fanin list, compose bdd of ref_bnode
    ** into bnode's fanouts. Delete bnode from Boolean network.
    */
    fanodeGen = lsStart(regn->fanouts);
    while (lsNext(fanodeGen, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {

        /* Remove inode from fanode's fanin list */
        faninGen = lsStart(fanode->fanins);
        while (lsNext(faninGen, (lsGeneric *) &fanin_node, NULL) != LS_NOMORE) {
            if (fanin_node == regn) {
                (void) lsDelBefore(faninGen, (lsGeneric*) &dummy_node);
                break;
            }
        }
        lsFinish(faninGen);

        /* Add ref_bnode as new fanin of fanode */
        if (lsNewEnd(fanode->fanins, (lsGeneric) regr, NULL) != LS_OK) {
            printf("Out of memory"); exit(2);
        }
        /* Remove possible duplication */
        (void) lsSort(fanode->fanins, bdsUniqueBnetNode);
        (void) lsUniq(fanode->fanins, bdsUniqueBnetNode, NULL);

        /* Add fanode as new fanout of rnode. There is possible duplication */
        if (lsNewEnd(regr->fanouts, (lsGeneric) fanode, NULL) != LS_OK) {
            printf("Out of memory"); exit(2);
        }

        /* Substitute bdd of rnode into inode's fanout */
        subBdd = (rnode->localBdd == Cudd_Not(inode->localBdd)) ? Cudd_Not(ref_bdd) : ref_bdd;

        composedBdd = Cudd_bddCompose(bddmgr,fanode->localBdd,subBdd,regn->localVar);
        if (composedBdd == NULL) return(0);
        Cudd_Ref(composedBdd);

        Cudd_RecursiveDeref(bddmgr, fanode->localBdd);
        fanode->localBdd = composedBdd;
    }
    lsFinish(fanodeGen);

    /* Remove inode from its fanins' fanout list */
    fanodeGen = lsStart(regn->fanins);
    while (lsNext(fanodeGen, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
        fanoutGen = lsStart(fanode->fanouts);
        while (lsNext(fanoutGen, (lsGeneric *) &fanout_node, NULL) != LS_NOMORE) {
            if (fanout_node == regn) {
                (void) lsDelBefore(fanoutGen, (lsGeneric*) &dummy_node);
                break;
            }
        }
        lsFinish(fanoutGen);
    }
    lsFinish(fanodeGen);

    /* Mark this bnode as dead */
    st_insert(net->livenodes, (char *) regn, (char *) DEAD_BNODE);

    /*
    st_delete(net->livenodes, (char **) &regn, (char **) NULL);
    (void) bdsFreeBnetNode(bddmgr, regn);
    */

    Cudd_RecursiveDeref(bddmgr, ref_bdd);

    return(1);

} /* end of bdsSubstituteInternal */









