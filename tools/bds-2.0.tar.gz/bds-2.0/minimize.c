
/**CFile***********************************************************************

  FileName    [minimize.c]

  PackageName [BDS-pga]

  Synopsis    [BDD Minimization Program]

  Description [This file contains a function for BDD minimization]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#include "lopt.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis    [Performs safe minimization of a BDD.]

  Description [Return minimized BDD if successful, NULL otherwise]

  SideEffects []

  SeeAlso     []

******************************************************************************/
extern
DdNode *
BDS_BddMinimization(
  DdManager *bddmgr,
  DdNode *f,        /* f BDD */
  DdNode *c,        /* c BDD */
  int decompType,   /* t = R + c OR f = Q c. */
  bdsOptions *option)
{
  int result;
  DdNode *retBdd;

  if (decompType == BDS_BDD_DECOMP_CONJ) {
      if (option->miniMethod == BDS_BDD_LICOMPACTION) {
      retBdd = Cudd_bddLICompaction(bddmgr, f, c);
      }
      else {
    /*retBdd = Cudd_bddMinimize(bddmgr, f, c);*/
    retBdd = Cudd_bddRestrict(bddmgr, f, c);
      }
  }
  else if (decompType == BDS_BDD_DECOMP_DISJ) {
      if (option->miniMethod == BDS_BDD_LICOMPACTION) {
      retBdd = Cudd_bddLICompaction(bddmgr, f, Cudd_Not(c));
      }
      else {
    /*retBdd = Cudd_bddMinimize(bddmgr, f, Cudd_Not(c));*/
    retBdd = Cudd_bddRestrict(bddmgr, f, Cudd_Not(c));
      }
  }
  else {
      fail("This type of decomposition is not supported now !");
  }

  if (retBdd == NULL) { return(NULL);}
  Cudd_Ref(retBdd);

#ifdef DEBUG
  cuddCheck(bddmgr, "BDS_BddMinimization", 2);
#endif

#ifdef DEBUG
  result = bdsDecompCheck(bddmgr,f,decompType,retBdd,c);
  if (result == 0) fail("BDD minimization error!");
#endif

  return(retBdd);

} /* BDS_BddMinimization */
