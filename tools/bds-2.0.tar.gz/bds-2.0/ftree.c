
/**CFile***********************************************************************

  FileName    [ftree.c]

  PackageName [BDS-pga]

  Synopsis    [Factoring tree processing program]

  Description [This file contains the functions for optimizing the FTrees:
               Sharing extraction, Homogeneous collapsing, and Phase assignment.
               Collapsing part was changed to get k-feasible nodes for FPGAs. (k=5)]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#include "lopt.h"
#include <stdio.h>

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/
static void bdsFreeFTreeRecursive ARGS((FactorTreeNode*,st_table*));
static int BDS_ExtractSharingOnFtree ARGS((DdManager*,BnetNetwork*,FactorTreeNode**,st_table*,st_table*,bdsOptions*));
static int BDS_ExtractSharingOnFtreeRecursive ARGS((DdManager*,FactorTreeNode*,st_table*,st_table*));
static int Fnode_RecursiveDeref ARGS((DdManager*,st_table*,st_table*,DdNode*,FactorTreeNode*,int));
static int BDS_ApplySharing ARGS((DdManager*,FactorTreeNode*,int,DdNode*,st_table*,st_table*));
static int bdsCollectInternalFNodes ARGS((st_table*,FactorTreeNode*));
static void bdsFreeFtreeBdd ARGS((DdManager*,BnetNetwork*,FactorTreeNode**));
static int BDS_CollapseHomogeneous ARGS((DdManager*,FactorTreeNode**,st_table*,bdsOptions*));
static int BDS_CollapseHomogeneousRecursive ARGS((DdManager*,FactorTreeNode*,st_table*,bdsOptions*));
static int bdsFnodeIsHomogeneous ARGS((FactorTreeNode*,FactorTreeNode*,st_table*,bdsOptions*));
static int BDS_ApplyHomogeneousCollapse ARGS((FactorTreeNode*,FactorTreeNode*,st_table*,bdsOptions*));
extern int BDS_CollapseFeasible ARGS((DdManager*,FactorTreeNode**));
extern int BDS_CollapseFeasibleRecursive ARGS((DdManager*,FactorTreeNode*));
extern int BDS_ApplyFeasibleCollapse ARGS((FactorTreeNode*,FactorTreeNode*));
static int BDS_CollapseTransferOnly ARGS((FactorTreeNode*,FactorTreeNode*,bdsOptions*,int));
static int bdsCollectInternalFNodesList ARGS((st_table*,FactorTreeNode*));
static int BDS_OperatorStats ARGS((FactorTreeNode**));

/**Function********************************************************************

  Synopsis    [Factor Tree Processing Program]

  Description [A set of things could be done on a factor tree. First, the tree
  can be reduced, the algorithm is exactly like that in BDD reduction. OR, a more
  aggressive approach is, built BDD for each node on the factor tree, then all
  nodes which are functionally equivalent are realized by the same pointer in the
  bddmgr. A factor tree is dumped. And some statistics are done also.]

  SideEffects []

  SeeAlso     []

  LastDate    [4/2/99]

******************************************************************************/
extern
int
BDS_FTreeProcessing(
  DdManager *bddmgr,
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  bdsOptions *option,
  char **PIvariables,
  st_table *factorTreeNode2BnetNode,
  int iteration)
{
  int i, j, result, inti=0;
  FactorTreeNode **q, **p;
  st_table *dd2ftreeTbl, *sharingFnodeTbl, *statsTbl;
  BnetNode *node, *tempnode;

  /* Initialize dd->fnode table */
  dd2ftreeTbl = st_init_table(st_ptrcmp,st_ptrhash); /* dd ~ fnode */

  /* Initialize a table for shared fnodes */
  sharingFnodeTbl = st_init_table(st_ptrcmp,st_ptrhash); /* sharded fnodes */

  /* Print out synthesis results right after decomposition */
  ///result = BDS_SynthesisPresentation(net,FTNode,PIvariables,sharingFnodeTbl,factorTreeNode2BnetNode,option,0,iteration);
  ///if (result == 0) fail("Synthesis results presentation failed");

  if (option->verb > BDS_VERBOSE_LESS) { /* Print ftree information */
      statsTbl= st_init_table(st_ptrcmp,st_ptrhash);
      for (q = FTNode; *q; q++) {
    inti++;
    bdsCollectInternalFNodes(statsTbl, *q);
      }
      BDS_Stats(BDS_SHARED_FNODE,NULL,st_count(statsTbl),"before",NULL,NULL,NULL);
      st_free_table(statsTbl);
  }

  /*
  if ((option->useloc == TRUE) && (option->collapseftree)) {
    for (p=FTNode;*p;p++) {
      st_lookup(factorTreeNode2BnetNode, (char *) *p, (char **) &node);
      for (j=0;j<array_n(feasiblearray);j++) {
    tempnode = array_fetch(BnetNode *, feasiblearray, j);
    if (tempnode == node) {
      printf("Collapsing all nodes for 5-feasibility\n");
        Collapse all 5-feasible fnodes
      result = BDS_CollapseFeasible(bddmgr,p);
      if (result == 0) fail("Can not collapse feasible fnodes !");
    }
      }
    }
  }
  */

  /* Identifying shared nodes on ftrees */


  result = BDS_ExtractSharingOnFtree(bddmgr,net,FTNode,dd2ftreeTbl,sharingFnodeTbl,option);
  if (result == 0) fail("Final ftree processing failed !");


  (void) bdsFreeFtreeBdd(bddmgr,net,FTNode);

  if (option->verb > BDS_VERBOSE_LESS) { /* Print ftree after processing and shared nodes information */
      statsTbl= st_init_table(st_ptrcmp,st_ptrhash);
      for (q = FTNode; *q; q++) {
          bdsCollectInternalFNodes(statsTbl, *q);
      }
      BDS_Stats(BDS_SHARED_FNODE,NULL,st_count(statsTbl),"after",NULL,NULL,NULL);
      BDS_Stats(BDS_SHARED_FNODE,NULL,st_count(sharingFnodeTbl),"sharing",NULL,NULL,NULL);
      st_free_table(statsTbl);
  }

  /* Print out results after sharing extraction */
  ///result = BDS_SynthesisPresentation(net,FTNode,PIvariables,sharingFnodeTbl,factorTreeNode2BnetNode,option,1,iteration);
  ///if (result == 0) fail("Synthesis results presentation failed");

  /* The following transformation will not destroy the shared fnodes
  */
  /* Collapse all homogeneous fnodes */

  result = BDS_CollapseHomogeneous(bddmgr,FTNode,sharingFnodeTbl,option);
  if (result == 0) fail("Can not collapse homogeneous fnodes !");

  /* Do statistis */

  if (option->verb > BDS_VERBOSE_LESS) { /// Print ftree after collapse homogeneous fnodes
      statsTbl= st_init_table(st_ptrcmp,st_ptrhash);
      for (q = FTNode; *q; q++) {
          bdsCollectInternalFNodesList(statsTbl,*q);
      }
      BDS_Stats(BDS_SHARED_FNODE,NULL,st_count(statsTbl),"collapse",NULL,NULL,NULL);
      st_free_table(statsTbl);
  }

  /* Print out syntheiss results after collapsing homogeneous fnodes */
  ///result = BDS_SynthesisPresentation(net,FTNode,PIvariables,sharingFnodeTbl,factorTreeNode2BnetNode,option,2,iteration);
  ///if (result == 0) fail("Synthesis results presentation failed");

  ////* Final sharing extraction between fnodes with common support. Only local BDDs are used.
  ///   The assumpation is, all sharing based on gloabl BDDs have been extracted, only local
  ///   sharings are left, like case, a+b+c, a+c and a+b+d+c , etc... This procedure should
  ///   be able to find out this kind of sharings. While pingpong-based algorithm may efficiently
  ///   find them, BDD-based algorithm should also be efficient, since almost all those sharings
  ///   are algebraic at this phase.
  ///*/

  /* Phase assignment on the ftree */
  result = BDS_FtreePhaseAssignment(FTNode, option);
  if (result ==0) fail("Phase assignment fails");

  /* Print out final synthesis results after phase assignment */
   result = BDS_SynthesisPresentation(net,FTNode,PIvariables,sharingFnodeTbl,factorTreeNode2BnetNode,option,3,iteration);
  if (result == 0) fail("Synthesis results presentation failed");

  /*if (option->delay == TRUE) {
    printf("NEW FILE is BEING GENERATED\n");
    result = BDS_SynthesisPresentation(net,FTNode,PIvariables,sharingFnodeTbl,factorTreeNode2BnetNode,option,4,iteration);
    if (result == 0) fail("Synthesis results presentation failed");
    }*/

  /* Statistical information on number of various operators on the ftree */
  result = BDS_OperatorStats(FTNode);
  if (result == 0) fail("Operator stats fails");

  /* Cut PTL gates from synthesis netlist, tree mapping mapper can not handle MUX and XORs
  */
  if (option->cutptl) {
      result = BDS_CutPtlFromGeneralNetlist(net,FTNode,PIvariables,sharingFnodeTbl,option,factorTreeNode2BnetNode);
      if (result == 0) fail("Cut PTLs fails");
  }

  st_free_table(dd2ftreeTbl);
  st_free_table(sharingFnodeTbl);

  return(1);

} /* end of BDS_FTreeProcessing */

/**Function********************************************************************

  Synopsis    [Find the possible sharing between fnodes]

  Description [BDDs are built bottom-up on the ftree. At an fnode, if the same BDD
  has been built before, point the fnode to that. This can help to identify sharing
  between different fnode. Return 1 success; 0 otherwise]

  SideEffects [The factoring tree is modified]

  SeeAlso     []

  LastDate    [3/26/99]

*****************************************************************************/
static
int
BDS_ExtractSharingOnFtree(
  DdManager *bddmgr,
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  st_table *dd2ftreeTbl,
  st_table *sharingFnodeTbl,
  bdsOptions *option)
{
  int result, i;
  FactorTreeNode **q;

  /* Build BDD and find sharing */
  for (q = FTNode; *q; q++) {
      result = BDS_ExtractSharingOnFtreeRecursive(bddmgr,*q,dd2ftreeTbl,sharingFnodeTbl);
      if (result == 0) return(0);
  }

  return(1);

} /* end of BDS_ExtractSharingOnFtree */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_ExtractSharingOnFtree]

  Description [Return 1 success; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
static
int
BDS_ExtractSharingOnFtreeRecursive(
  DdManager *bddmgr,
  FactorTreeNode *fnode,
  st_table *dd2ftreeTbl,
  st_table *sharingFnodeTbl)
{
  int result;
  FactorTreeNode *top, *dp, *dm, *ctl, *snode;
  DdNode *f, *dpBdd, *dmBdd, *ctlBdd, *var;
  DdNode *tmp1, *tmp2;

  /* BDD has been built for this node */
  if (fnode->dd != NULL) {
      return(1);
  }

  /* Build BDD for the terminal node */
  if (fnode->value != BDS_FTREE_INTERNAL) {

      /* Don't put terminals in the sharing table, it will generate ugly dot file. */
      var = Cudd_ReadVars(bddmgr, fnode->value);
      Cudd_Ref(var);
      fnode->dd = (fnode->polarity == 0) ? Cudd_Not(var) : var;

      return(1);
  }

  /* At this phase, all fnode, dp, dm and ctl are regular */
  top = Fnode_Regular(fnode);
  dp = top->siblings[0];
  dm = top->siblings[1];

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      ctl = top->siblings[2];
  }
#endif

  result = BDS_ExtractSharingOnFtreeRecursive(bddmgr,dp,dd2ftreeTbl,sharingFnodeTbl);
  if (result == 0) return(0);
  result = BDS_ExtractSharingOnFtreeRecursive(bddmgr,dm,dd2ftreeTbl,sharingFnodeTbl);
  if (result == 0) return(0);

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      result = BDS_ExtractSharingOnFtreeRecursive(bddmgr,ctl,dd2ftreeTbl,sharingFnodeTbl);
      if (result == 0) return(0);
  }
#endif

  dpBdd = Fnode_IsComplement(dp) ? Cudd_Not(Fnode_Regular(dp)->dd) : Fnode_Regular(dp)->dd;
  dmBdd = Fnode_IsComplement(dm) ? Cudd_Not(Fnode_Regular(dm)->dd) : Fnode_Regular(dm)->dd;

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      ctlBdd = Fnode_IsComplement(ctl) ? Cudd_Not(Fnode_Regular(ctl)->dd) : Fnode_Regular(ctl)->dd;
  }
#endif

  /* Find out possible sharing on siblings */
  result = BDS_ApplySharing(bddmgr,top,0,dpBdd,dd2ftreeTbl,sharingFnodeTbl);
  if (result == 0) return(0);
  result = BDS_ApplySharing(bddmgr,top,1,dmBdd,dd2ftreeTbl,sharingFnodeTbl);
  if (result == 0) return(0);

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      if (result == 0) return(0);
      result = BDS_ApplySharing(bddmgr,top,2,ctlBdd,dd2ftreeTbl,sharingFnodeTbl);
  }
#endif

  switch(top->op) {
  case BDS_BDD_AND:
      f = Cudd_bddAnd(bddmgr, dpBdd, dmBdd);
      break;
  case BDS_BDD_OR:
      f = Cudd_bddOr(bddmgr, dpBdd, dmBdd);
      break;
  case BDS_BDD_XOR:
      f = Cudd_bddXor(bddmgr, dpBdd, dmBdd);
      break;
  case BDS_BDD_XNOR:
      f = Cudd_bddXnor(bddmgr, dpBdd, dmBdd);
      break;

#ifdef PTL
  case BDS_BDD_MUX:
      tmp1 = Cudd_bddAnd(bddmgr, ctlBdd, dpBdd);
      if (tmp1 == NULL) return(0);
      Cudd_Ref(tmp1);
      tmp2 = Cudd_bddAnd(bddmgr, Cudd_Not(ctlBdd), dmBdd);
      if (tmp2 == NULL) return(0);
      Cudd_Ref(tmp2);

      f = Cudd_bddOr(bddmgr, tmp1, tmp2);
      Cudd_RecursiveDeref(bddmgr, tmp1);
      Cudd_RecursiveDeref(bddmgr, tmp2);

      break;
#endif

  default :
      fail("Unkonwn operator on ftree !");
  }
  Cudd_Ref(f);
  top->dd = (fnode->polarity == 0) ? Cudd_Not(f) : f;

  /* If both top->dd and Cudd_Not(top->dd) are not in the sharing tbl, add it */
  if (st_is_member(dd2ftreeTbl, (char *)top->dd) != 1 &&
                    st_is_member(dd2ftreeTbl, (char *)Cudd_Not(top->dd)) != 1) {
      if (st_add_direct(dd2ftreeTbl, (char *)top->dd, (char *)fnode) == ST_OUT_OF_MEM) {
      fail("Out of memory !");
      }
  }

  return(1);

} /* end of BDS_ExtractSharingOnFtreeRecursive */

/**Function********************************************************************

  Synopsis    [Modify ftree if sharing is identified]

  Description [If the BDD dBdd for node top->siblings[i] already exists, replace
  top->siblings[i] with snode, and deref top->siblings[i]. Return 1 success; 0 otherwise]

  SideEffects [ftree is modified]

  SeeAlso     []

*****************************************************************************/
static
int
BDS_ApplySharing(
  DdManager *bddmgr,
  FactorTreeNode *top,
  int i,        /* 0 or 1 for now, they stand for dp or dm */
  DdNode *dBdd,
  st_table *dd2ftreeTbl,
  st_table *sharingFnodeTbl)
{
  FactorTreeNode *tnode, *snode;

  tnode = top->siblings[i];

  /* Find out possible sharing */
  if (st_lookup(dd2ftreeTbl, (char *)dBdd, (char **) &snode) && snode != tnode) {
      if (snode == NULL) return (0);
      top->siblings[i] = snode;
      Fnode_Ref(snode);
      if (st_is_member(sharingFnodeTbl, (char *)snode) != 1) {
      if (st_add_direct(sharingFnodeTbl, (char *)snode, NULL) == ST_OUT_OF_MEM) {
          return(0);
          }
      }

      Fnode_RecursiveDeref(bddmgr,dd2ftreeTbl,sharingFnodeTbl,dBdd,tnode,0);
  }
  else if (st_lookup(dd2ftreeTbl, (char *)Cudd_Not(dBdd), (char **) &snode)) {
      if (snode == NULL) return (0);

      /* This is the place which regular is transformed into negative, table sharingFnodeTbl
     always holds regular pointers.
      */
      top->siblings[i] = Fnode_Complement(snode);
      Fnode_Ref(snode);
      if (st_is_member(sharingFnodeTbl, (char *)snode) != 1) {
      if (st_add_direct(sharingFnodeTbl, (char *)snode, NULL) == ST_OUT_OF_MEM) {
          return(0);
          }
      }

      Fnode_RecursiveDeref(bddmgr,dd2ftreeTbl,sharingFnodeTbl,dBdd,tnode,0);
  }

  return(1);

} /* end of BDS_ApplySharing */

/**Function********************************************************************

  Synopsis    [Recursive deref the count for nodes on the DAG, if the count = 0,
        the node is freed. BDD associated with current fnode is also freed]

  Description [Return 1 success; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
static
int
Fnode_RecursiveDeref(
  DdManager *bddmgr,
  st_table *dd2ftreeTbl,
  st_table *sharingFnodeTbl,
  DdNode *dBdd,
  FactorTreeNode *fnode,
  int deleteDD /* the case when Cudd_Not(dBdd) was found */ )
{
  int result;
  FactorTreeNode *top, *dp, *dm;

  top = Fnode_Regular(fnode);
  dp = top->siblings[0];
  dm = top->siblings[1];

  if (top->value == BDS_FTREE_ONE || top->value == BDS_FTREE_ZERO) return(1);

  /* If the node is a single variable */
  if (top->value != BDS_FTREE_INTERNAL) { /* a terminal */
      Fnode_Deref(top);
      if (top->count == 1) { /* It was a shared node */
      if (!st_delete(sharingFnodeTbl, (char **) &top, (char **)NULL)) {
          return(0);
      }
      }
      if (top->count == 0) { /* Free the node if no reference on it */
      if (top->dd != NULL) Cudd_RecursiveDeref(bddmgr, top->dd);
          FREE(top);
      }
      return(1);
  }

  if (st_is_member(sharingFnodeTbl, (char *) top)) { /* a shared node */
      Fnode_Deref(top);
      if (top->count == 1) { /* Remove this node from sharing table */
      if (!st_delete(sharingFnodeTbl, (char **) &top, (char **)NULL)) {
          return(0);
      }
      }
      return(1);
  }

  result = Fnode_RecursiveDeref(bddmgr,dd2ftreeTbl,sharingFnodeTbl,Fnode_Regular(dp)->dd,dp,1);
  if (result == 0) return(0);
  result = Fnode_RecursiveDeref(bddmgr,dd2ftreeTbl,sharingFnodeTbl,Fnode_Regular(dm)->dd,dm,1);
  if (result == 0) return(0);

  Fnode_Deref(top);
  if (top->count == 0) {
      if (deleteDD == 1) {
          if (!st_delete(dd2ftreeTbl, (char **) &dBdd, (char **)NULL)) {
          fail("The BDD was not built before, no fnode is deleted !");
          }
      }
      if(top->dd != NULL) Cudd_RecursiveDeref(bddmgr,top->dd);
      FREE(top);
  }

  return(1);

} /* end of Fnode_RecursiveDeref */

/**Function********************************************************************

  Synopsis    [Collapse all homegeneous fnodes]

  Description [Homogeneous fnodes are defined as fnodes which can be transformed
  into other fnodes with homogeneous operator. + <-> {+,*'}; * <-> {+',*};
  If the operator of a sibling fnode is homogeneous to the current fnode, then
  all sibling fnodes of the sibling fnode are joined into the fanins of current
  fnode.  Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

  LastDate    [2/25/99]

******************************************************************************/
static
int
BDS_CollapseHomogeneous(
  DdManager *bddmgr,
  FactorTreeNode **FTreeNode,
  st_table *sharingFnodeTbl,
  bdsOptions *option)
{
  FactorTreeNode **q;
  int result;

  for (q = FTreeNode; *q; q++) {

      /* If terminal, continue */
      if (!Fnode_Internal(*q)) continue;

      result = BDS_CollapseHomogeneousRecursive(bddmgr,*q,sharingFnodeTbl,option);
      if (result == 0) return(0);
  }

  printf("Collapse done\n");
  return(1);

} /* end of BDS_CollapseHomogeneous */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_CollapseHomogeneous()]

  Description [Return 1 success; 0 otherwise]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
static
int
BDS_CollapseHomogeneousRecursive(
  DdManager *bddmgr,
  FactorTreeNode *fnode,
  st_table *sharingFnodeTbl,
  bdsOptions *option)
{
  int result;
  FactorTreeNode *top, *dp, *dm, *ctl;

  /* If terminal, go back. */
  if (!Fnode_Internal(fnode)) return(1);

  top = Fnode_Regular(fnode);

  /* If the fnode is shared and has been collapsed before, go back */
  if (Fnode_Fanins(fnode) && st_is_member(sharingFnodeTbl, (char *)top)) return(1);

  /* fnode, dp, dm and ctl may not be regular */
  dp = top->siblings[0];
  dm = top->siblings[1];

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      ctl = top->siblings[2];
  }
#endif

  /* Recursively traverse down to the bottom */
  if (Fnode_Internal(dp)) {
      result = BDS_CollapseHomogeneousRecursive(bddmgr,dp,sharingFnodeTbl,option);
      if (result == 0) return(0);
  }
  if (Fnode_Internal(dm)) {
      result = BDS_CollapseHomogeneousRecursive(bddmgr,dm,sharingFnodeTbl,option);
      if (result == 0) return(0);
  }

#ifdef PTL
  if (Fnode_Operator(top) == BDS_BDD_MUX && Fnode_Internal(ctl)) {
      result = BDS_CollapseHomogeneousRecursive(bddmgr,ctl,sharingFnodeTbl,option);
      if (result == 0) return(0);
  }
#endif

  /* If the current fnode is a XOR, XNOR and MUX, transfer only and go back */
  if (Fnode_Operator(top) == BDS_BDD_XOR || Fnode_Operator(top) == BDS_BDD_XNOR ||
                                   Fnode_Operator(top) == BDS_BDD_MUX) {
      result = BDS_CollapseTransferOnly(top,NULL,option,0);
      return(result);
  }

  /* Collapse homogeneous fnodes in the sequence of dp, dm */
  if (bdsFnodeIsHomogeneous(top,dp,sharingFnodeTbl,option)) {
      result = BDS_ApplyHomogeneousCollapse(top,dp,sharingFnodeTbl,option);
      if(result == 0) return(0);
  }
  else {
      result = BDS_CollapseTransferOnly(top,dp,option,1);
      if(result == 0) return(0);
  }
  if (bdsFnodeIsHomogeneous(top,dm,sharingFnodeTbl,option)) {
      result = BDS_ApplyHomogeneousCollapse(top,dm,sharingFnodeTbl,option);
      if(result == 0) return(0);
  }
  else {
      result = BDS_CollapseTransferOnly(top,dm,option,1);
      if(result == 0) return(0);
  }

  return(1);

} /* end of BDS_CollapseHomogeneousRecursive */

/**Function********************************************************************

  Synopsis    [Find out if an fnode and its sibling are homogeneous]

  Description [Return 1 if the sibling is homogeneous to the current fnode; 0 otherwise]

  SideEffects []

  SeeAlso     []

  LastDate    [2/25/99]

*****************************************************************************/

/// Limit collapsing to k=5 for FPGA mapping

static
int
bdsFnodeIsHomogeneous(
  FactorTreeNode *top,
  FactorTreeNode *sib,
  st_table *sharingFnodeTbl,
  bdsOptions *option)
{
  int k=0;
  int retVal=0, no_fanins, no_fanouts;

  if (st_is_member(sharingFnodeTbl, (char *)Fnode_Regular(sib))) { /* A shared fnodes, no collapse */
      retVal = 0;
  }
  else if (Fnode_Operator(sib) == BDS_BDD_XOR || Fnode_Operator(sib) == BDS_BDD_XNOR || Fnode_Operator(sib) == BDS_BDD_MUX) {
      retVal = 0;
  }
  else if (!Fnode_Internal(sib)) { /* A terminal fnode, collapse */
      retVal = 1;
  }
  else { /* Check if they are homogeneous */

      switch(Fnode_Operator(top)) {
      case BDS_BDD_OR:
          if (!Fnode_Negative(sib) && Fnode_Operator(sib) == BDS_BDD_OR || Fnode_Negative(sib) && Fnode_Operator(sib) == BDS_BDD_AND)
              retVal = 1;
          else
        retVal = 0;
              break;

      case BDS_BDD_AND:
    if (!Fnode_Negative(sib) && Fnode_Operator(sib) == BDS_BDD_AND || Fnode_Negative(sib) && Fnode_Operator(sib) == BDS_BDD_OR)
      retVal = 1;
    else
      retVal = 0;
    break;

      default:
    fail("Unknown decomposition type in bdsFnodeIsHomogeneous()");
      }
  }

  /// k-feasible nodes for FPGAs

  k = option->k;

  if(option->k == 5) { /* default k value is 5 */
      if ((top->fanins != NULL) && (sib->fanins != NULL)) {
          no_fanins = lsLength(Fnode_Fanins(top)) + lsLength(Fnode_Fanins(sib));
          /// printf("TS %i ",no_fanins);
          if ((retVal == 1) && (no_fanins > 4)) {
              ///printf("Too many fanins TS %i\n",no_fanins);
              retVal = 0;
          }
      }

      else if (top->fanins != NULL) {
          no_fanins = lsLength(Fnode_Fanins(top));
          /// printf("T %i ",no_fanins);
          if ((retVal == 1) && (no_fanins > 4)) {
              ///printf("Too many fanins T %i\n",no_fanins);
              retVal = 0;
          }
      }
      else if (sib->fanins != NULL) {
          no_fanins =  lsLength(Fnode_Fanins(sib));
          /// printf("S %i ",no_fanins);
          if ((retVal == 1) && (no_fanins > 4)) {
              ///printf("Too many fanins S %i\n",no_fanins);
              retVal = 0;
          }
      }
  }
  else { /* If k value is specified */
      if ((top->fanins != NULL) && (sib->fanins != NULL)) {
          no_fanins = lsLength(Fnode_Fanins(top)) + lsLength(Fnode_Fanins(sib));
          /// printf("TS %i ",no_fanins);
          if ((retVal == 1) && (no_fanins > (k-1))) {
              ///printf("Too many fanins TS %i\n",no_fanins);
              retVal = 0;
          }
      }

      else if (top->fanins != NULL) {
          no_fanins = lsLength(Fnode_Fanins(top));
          /// printf("T %i ",no_fanins);
          if ((retVal == 1) && (no_fanins > (k-1))) {
              ///printf("Too many fanins T %i\n",no_fanins);
              retVal = 0;
          }
      }
      else if (sib->fanins != NULL) {
          no_fanins =  lsLength(Fnode_Fanins(sib));
          /// printf("S %i ",no_fanins);
          if ((retVal == 1) && (no_fanins > (k-1))) {
              ///printf("Too many fanins S %i\n",no_fanins);
              retVal = 0;
          }
      }
  }

  return(retVal);

} /* end of bdsFnodeIsHomogeneous */

/**Function********************************************************************

  Synopsis    [Collapse homogeneous fnodes]

  Description [If homogeneous, fanins of sibling fnodes are transformed into
  fanins of current fnode. Merge rule was describe in pp97-98 in the notebook.
  Return 1 success; 0 otherwise]

  SideEffects [fanins is filled up]

  SeeAlso     []

  LastDate    [2/25/99]

*****************************************************************************/
static
int
BDS_ApplyHomogeneousCollapse(
  FactorTreeNode *top,
  FactorTreeNode *sib,
  st_table *sharingFnodeTbl,
  bdsOptions *option)
{
  int result;
  lsGen sibSiblingList;
  FactorTreeNode *sibSibling, *regSib;

  regSib = Fnode_Regular(sib);
  if (top->fanins == NULL) top->fanins = lsCreate();

  if (!Fnode_Internal(sib)) {
      if (lsNewEnd(top->fanins, (lsGeneric)sib, NULL) != LS_OK) {
      printf("Out of memory"); exit(2);
      }
      return(1);
  }

  sibSiblingList = lsStart(regSib->fanins);

  /* According to rules in pp97-98 */
  if (Fnode_Operator(top) == Fnode_Operator(sib)) { /* Original sibSiblings */

      while (lsNext(sibSiblingList, (lsGeneric *)&sibSibling, NULL) == LS_OK) {
      if (lsNewEnd(top->fanins, (lsGeneric)sibSibling, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
          }
      }
  }
  else { /* Inversed sibSiblings. In case sibSibling is a shared fnode, flip the pointer */

      while (lsNext(sibSiblingList, (lsGeneric *)&sibSibling, NULL) == LS_OK) {
          if (st_is_member(sharingFnodeTbl, (char *)Fnode_Regular(sibSibling))) { /* Flip pointer */
          if (lsNewEnd(top->fanins, (lsGeneric)Fnode_Flip(sibSibling), NULL) != LS_OK) {
              printf("Out of memory"); exit(2);
              }
      }
      else { /* Flip polarity */
          Fnode_Inverse(sibSibling);
          if (lsNewEnd(top->fanins, (lsGeneric)sibSibling, NULL) != LS_OK) {
              printf("Out of memory"); exit(2);
              }
      }
      }
  }
  lsFinish(sibSiblingList);

  /* Free sib, all its siblings have been bypassed. dd field should be taken care by other functions */
  if (Fnode_Regular(sib)->fanins != NULL) {
      lsDestroy(regSib->fanins, (void (*)())0);
  }
  FREE(regSib);

  return(1);

} /* end of BDS_ApplyHomogeneousCollapse */

/**Function********************************************************************

  Synopsis    [Perform transfer from siblings -> fanins]

  Description [Return 1 success; 0 otherwise]

  SideEffects []

  SeeAlso     []

  LastDate    [2/25/99]

*****************************************************************************/
static
int
BDS_CollapseTransferOnly(
  FactorTreeNode *top,
  FactorTreeNode *sib,
  bdsOptions *option,
  int how_many)
{
  if (top->fanins == NULL) top->fanins = lsCreate();

  /* Transfer all siblings to finains */
  if (how_many == 0) {
      if (lsNewEnd(top->fanins, (lsGeneric)top->siblings[0], NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }

      if (lsNewEnd(top->fanins, (lsGeneric)top->siblings[1], NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }

#ifdef PTL
      if (Fnode_Operator(top) == BDS_BDD_MUX) top->control = top->siblings[2];
#endif

  }
  else { /* Transfer only one sibling */
      if (lsNewEnd(top->fanins, (lsGeneric)sib, NULL) != LS_OK) {
          printf("Out of memory"); exit(2);
      }
  }

  return(1);

} /* end of BDS_CollapseTransferOnly */

/**Function********************************************************************

  Synopsis    [Clear field flag on ftree]

  Description []

  SideEffects [None]

  SeeAlso     []

  LastDate    [3/26/99]

*****************************************************************************/
static
void
bdsFreeFtreeBdd(
  DdManager *bddmgr,
  BnetNetwork *net,
  FactorTreeNode **FTNode)
{
  int result, i;
  st_table    *visited = NULL;
  st_generator *gen = NULL;
  FactorTreeNode *fnode, **q;

  visited = st_init_table(st_ptrcmp,st_ptrhash);

  /* Collect all the nodes on the ftrees */
  for (q = FTNode; *q; q++) {
      result = bdsCollectFNodes(visited,*q);
      if (result == 0) fail("Fail in bdsFreeFtreeBdd");
  }

  gen = st_init_gen(visited);
  if (gen == NULL) fail("Fail in bdsFreeFtreeBdd");
  while (st_gen(gen, (char **) &fnode, NULL)) {
      Cudd_RecursiveDeref(bddmgr, Fnode_Regular(fnode)->dd);
      Fnode_Regular(fnode)->dd = NULL;
  }

  st_free_table(visited);
  st_free_gen(gen);

} /* end of bdsFreeFtreeBdd */

/**Function********************************************************************

  Synopsis    [Free factor tree]

  Description []

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
extern
void
BDS_FreeFTree(
  DdManager *bddmgr,
  FactorTreeNode **FTreeNode)
{
  st_table *deleted;
  FactorTreeNode **q;

  deleted = st_init_table(st_ptrcmp,st_ptrhash);

  for (q = FTreeNode; *q; q++) {
      (void) bdsFreeFTreeRecursive(*q, deleted);
  }

  st_free_table(deleted);

  return;

} /* end of BDS_FreeFTree */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_FreeFTree]

  Description []

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
static
void
bdsFreeFTreeRecursive(
  FactorTreeNode *fnode,
  st_table *deleted)
{
  FactorTreeNode *top, *ctl, *sib;
  lsList fanins;
  lsGen fanins_gen;

  top = Fnode_Regular(fnode);

  /* The node has been freed */
  if (st_is_member(deleted, (char *) top)) return;

  /* Reach a termianl node */
  if (!Fnode_Internal(fnode)) {
      FREE(top);
      if (st_add_direct(deleted, (char *) top, NULL) == ST_OUT_OF_MEM) {
      fail("Out of memory !");
      }
      return;
  }

  /* Traverse down to the terminal nodes */

#ifdef PTL
  if (top->op == BDS_BDD_MUX)
      (void) bdsFreeFTreeRecursive(ctl, deleted);
#endif

  fanins = Fnode_Fanins(fnode);
  fanins_gen = lsStart(fanins);
  while (lsNext(fanins_gen, (lsGeneric *) &sib, NULL) != LS_NOMORE) {
      (void) bdsFreeFTreeRecursive(sib, deleted);
  }
  lsFinish(fanins_gen);

  if (top->fanins != NULL) lsDestroy(top->fanins,NULL);
  if (top->fanouts != NULL) lsDestroy(top->fanouts,NULL);

  if (st_add_direct(deleted, (char *) top, NULL) == ST_OUT_OF_MEM) {
      fail("Out of memory !");
  }

  FREE(top);

  return;

} /* end of bdsFreeFTreeRecursive */

/**Function********************************************************************

  Synopsis    [Collect all nodes on the ftree]

  Description [All nodes on an ftree are collected. Each is just recorded once]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
extern
int
bdsCollectFNodes(
  st_table *visited,
  FactorTreeNode *fnode)
{
    FactorTreeNode *top, *dp, *dm, *ctl;
    int result;

    top = Fnode_Regular(fnode);
    dp = top->siblings[0];
    dm = top->siblings[1];

#ifdef PTL
    if (top->op == BDS_BDD_MUX) {
        ctl = top->siblings[2];
    }
#endif

    if (st_is_member(visited, (char *) top) == 1)
        return(1);

    if (st_add_direct(visited, (char *) top, NULL) == ST_OUT_OF_MEM)
        return(0);

    /* Terminal case */
    if (top->value != BDS_FTREE_INTERNAL)
        return(1);

    result = bdsCollectFNodes(visited,dp);
    if (result == 0) return(0);

    result = bdsCollectFNodes(visited,dm);
    if (result == 0) return(0);

#ifdef PTL
    if (top->op == BDS_BDD_MUX) {
        result = bdsCollectFNodes(visited,ctl);
        if (result == 0) return(0);
    }
#endif

    return(1);

} /* end of bdsCollectFNodes */

/**Function********************************************************************

  Synopsis    [Collect all internal nodes on the ftree]

  Description []

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
static
int
bdsCollectInternalFNodes(
  st_table *visited,
  FactorTreeNode *fnode)
{
    FactorTreeNode *top, *dp, *dm, *ctl;
    int result;

    top = Fnode_Regular(fnode);

    /* Terminal case */
    if (top->value != BDS_FTREE_INTERNAL)
        return(1);

    dp = top->siblings[0];
    dm = top->siblings[1];

#ifdef PTL
    if (top->op == BDS_BDD_MUX)
    ctl = top->siblings[2];
#endif

    if (st_is_member(visited, (char *) top) == 1)
        return(1);

    if (st_add_direct(visited, (char *) top, NULL) == ST_OUT_OF_MEM)
        return(0);

    result = bdsCollectInternalFNodes(visited,dp);
    if (result == 0) return(0);

    result = bdsCollectInternalFNodes(visited,dm);
    if (result == 0) return(0);

#ifdef PTL
    if (top->op == BDS_BDD_MUX) {
        result = bdsCollectInternalFNodes(visited,ctl);
        if (result == 0) return(0);
    }
#endif

    return(1);

} /* end of bdsCollectInternalFNodes */

/**Function********************************************************************

  Synopsis    [Collect all nodes on the ftree]

  Description [The ftree is traversed thru field fanins]

  SideEffects [None]

  SeeAlso     []

  LastDate    []

*****************************************************************************/
extern
int
bdsCollectFNodeslsList(
  st_table *visited,
  FactorTreeNode *fnode)
{
  FactorTreeNode *top, *sib, *ctl;
  int result;
  lsGen siblingList;

  top = Fnode_Regular(fnode);

  if (st_is_member(visited, (char *) top) == 1) return(1);
  if (st_add_direct(visited, (char *) top, NULL) == ST_OUT_OF_MEM) return(0);

  /* Terminal case */
  if (top->value != BDS_FTREE_INTERNAL) return(1);

  siblingList = lsStart(top->fanins);

  while (lsNext(siblingList, (lsGeneric *)&sib, NULL) == LS_OK) {

      result = bdsCollectFNodeslsList(visited, sib);
      if (result == 0) return(0);
  }
  lsFinish(siblingList);

#ifdef PTL
    if (top->op == BDS_BDD_MUX) {
    ctl = top->siblings[2];
        result = bdsCollectFNodeslsList(visited,ctl);
        if (result == 0) return(0);
    }
#endif

    return(1);

} /* end of bdsCollectFNodeslsList */

/**Function********************************************************************

  Synopsis    [Collect all internal nodes on the ftree]

  Description [The ftree is traversed thru field fanins]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
static
int
bdsCollectInternalFNodesList(
  st_table *visited,
  FactorTreeNode *fnode)
{
  FactorTreeNode *top, *sib, *ctl;
  int result;
  lsGen siblingList;

  top = Fnode_Regular(fnode);

  /* Terminal case */
  if (top->value != BDS_FTREE_INTERNAL) return(1);
  if (st_is_member(visited, (char *) top) == 1) return(1);
  if (st_add_direct(visited, (char *) top, NULL) == ST_OUT_OF_MEM) return(0);

  siblingList = lsStart(top->fanins);

  while (lsNext(siblingList, (lsGeneric *)&sib, NULL) == LS_OK) {

      result = bdsCollectInternalFNodesList(visited, sib);
      if (result == 0) return(0);
  }
  lsFinish(siblingList);

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      ctl = top->control;
      result = bdsCollectInternalFNodesList(visited, ctl);
      if (result == 0) return(0);
  }
#endif

  return(1);

} /* end of bdsCollectInternalFNodesList */

/**Function********************************************************************

  Synopsis    [Operator statistics]

  Description []

  SideEffects []

  SeeAlso     []

  LastDate    [3/6/99]

*****************************************************************************/
static
int
BDS_OperatorStats(
  FactorTreeNode **FTreeNode)
{
  FactorTreeNode **q, *fnode;
  st_table *statsTbl;
  st_generator *gen = NULL;
  static int andOp, orOp, xorOp, xnorOp, muxOp;

  statsTbl= st_init_table(st_ptrcmp,st_ptrhash);
  for (q = FTreeNode; *q; q++) {
      bdsCollectInternalFNodesList(statsTbl,*q);
  }

  gen = st_init_gen(statsTbl);
  if (gen == NULL) fail("Fail BDS_OperatorStats()");
  while (st_gen(gen, (char **) &fnode, NULL)) {
      switch(Fnode_Operator(fnode)) {
      case BDS_BDD_AND:
      andOp++;
      break;
      case BDS_BDD_OR:
      orOp++;
      break;
      case BDS_BDD_XOR:
      xorOp++;
      break;
      case BDS_BDD_XNOR:
      xnorOp++;
      break;
      case BDS_BDD_MUX:
      muxOp++;
      break;
      default:
          fail("Unkonwn operator in BDS_OperatorStats()");
      }
  }

  BDS_Stats(BDS_FTREE_OPERATOR,NULL,andOp,"and",NULL,NULL,NULL);
  BDS_Stats(BDS_FTREE_OPERATOR,NULL,orOp,"or",NULL,NULL,NULL);
  BDS_Stats(BDS_FTREE_OPERATOR,NULL,xorOp,"xor",NULL,NULL,NULL);
  BDS_Stats(BDS_FTREE_OPERATOR,NULL,xnorOp,"xnor",NULL,NULL,NULL);
  BDS_Stats(BDS_FTREE_OPERATOR,NULL,muxOp,"mux",NULL,NULL,NULL);

  st_free_gen(gen);
  st_free_table(statsTbl);

  return(1);

} /* end of BDS_OperatorStats */
///=====pga
/**Function********************************************************************

  Synopsis    [Collapse all homegeneous fnodes]

  Description [Homogeneous fnodes are defined as fnodes which can be transformed
  into other fnodes with homogeneous operator. + <-> {+,*'}; * <-> {+',*};
  If the operator of a sibling fnode is homogeneous to the current fnode, then
  all sibling fnodes of the sibling fnode are joined into the fanins of current
  fnode.  Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

  LastDate    [2/25/99]

******************************************************************************/
extern
int
BDS_CollapseFeasible(
  DdManager *bddmgr,
  FactorTreeNode **FTreeNode)
{
  int result;

  /* If terminal, continue */
  if (!Fnode_Internal(*FTreeNode)) return(1);

  result = BDS_CollapseFeasibleRecursive(bddmgr,*FTreeNode);
  if (result == 0) return(0);

  printf("Collapse done\n");
  return(1);

} /* end of BDS_FeasibleHomogeneous */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_CollapseHomogeneous()]

  Description [Return 1 success; 0 otherwise]

  SideEffects []

  SeeAlso     []

****************************************************************************/
extern
int
BDS_CollapseFeasibleRecursive(
  DdManager *bddmgr,
  FactorTreeNode *fnode)
{
  int result;
  FactorTreeNode *top, *dp, *dm, *ctl;
  bdsOptions *option=NULL;

  /* If terminal, go back. */
  if (!Fnode_Internal(fnode)) return(1);

  top = Fnode_Regular(fnode);

  /* fnode, dp, dm and ctl may not be regular */
  dp = top->siblings[0];
  dm = top->siblings[1];

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      ctl = top->siblings[2];
  }
#endif

  /* Recursively traverse down to the bottom */
  if (Fnode_Internal(dp)) {
      result = BDS_CollapseFeasibleRecursive(bddmgr,dp);
      if (result == 0) return(0);
  }
  if (Fnode_Internal(dm)) {
      result = BDS_CollapseFeasibleRecursive(bddmgr,dm);
      if (result == 0) return(0);
  }

#ifdef PTL
  if (Fnode_Operator(top) == BDS_BDD_MUX && Fnode_Internal(ctl)) {
      result = BDS_CollapseFeasibleRecursive(bddmgr,ctl);
      if (result == 0) return(0);
  }
#endif

  /* If the current fnode is a XOR, XNOR and MUX, transfer only and go back */
  if (Fnode_Operator(top) == BDS_BDD_XOR || Fnode_Operator(top) == BDS_BDD_XNOR ||
                                   Fnode_Operator(top) == BDS_BDD_MUX) {
      result = BDS_CollapseTransferOnly(top,NULL,option,0);
      printf("transferred\n");
      return(result);
  }

  /* Collapse homogeneous fnodes in the sequence of dp, dm */

  /* Collapsing dp
  if (bdsFnodeIsHomogeneous(top,dp,sharingFnodeTbl,option)) {*/
      result = BDS_ApplyFeasibleCollapse(top,dp);
      if(result == 0) return(0);

 /* else {
      result = BDS_CollapseTransferOnly(top,dp,option,1);
      if(result == 0) return(0);
  }*/

  /* Collapsing dm

  if (bdsFnodeIsHomogeneous(top,dm,sharingFnodeTbl,option)) {*/
      result = BDS_ApplyFeasibleCollapse(top,dm);
      if(result == 0) return(0);

 /* else {
      result = BDS_CollapseTransferOnly(top,dm,option,1);
      if(result == 0) return(0);
  }*/

  return(1);

} /* end of BDS_CollapseFeasibleRecursive */



/**Function********************************************************************

  Synopsis    [Collapse homogeneous fnodes]

  Description [If homogeneous, fanins of sibling fnodes are transformed into
  fanins of current fnode. Merge rule was describe in pp97-98 in the notebook.
  Return 1 success; 0 otherwise]

  SideEffects [fanins is filled up]

  SeeAlso     []

  LastDate    [2/25/99]

*****************************************************************************/
extern
int
BDS_ApplyFeasibleCollapse(
  FactorTreeNode *top,
  FactorTreeNode *sib)
{
  int result;
  lsGen sibSiblingList;
  FactorTreeNode *sibSibling, *regSib;

  regSib = Fnode_Regular(sib);
  if (top->fanins == NULL) top->fanins = lsCreate();

  if (!Fnode_Internal(sib)) {
      if (lsNewEnd(top->fanins, (lsGeneric)sib, NULL) != LS_OK) {
      printf("Out of memory"); exit(2);
      }
      return(1);
  }

  sibSiblingList = lsStart(regSib->fanins);

  /* According to rules in pp97-98 */
  if (Fnode_Operator(top) == Fnode_Operator(sib)) { /* Original sibSiblings */

    while (lsNext(sibSiblingList, (lsGeneric *)&sibSibling, NULL) == LS_OK) {
      if (lsNewEnd(top->fanins, (lsGeneric)sibSibling, NULL) != LS_OK) {
    printf("Out of memory"); exit(2);
      }
    }
  }
  else { /*Inversed sibSiblings. In case sibSibling is a shared fnode, flip the pointer */
    while (lsNext(sibSiblingList, (lsGeneric *)&sibSibling, NULL) == LS_OK) {

      /*if (st_is_member(sharingFnodeTbl, (char *)Fnode_Regular(sibSibling))) { Flip pointer
    if (lsNewEnd(top->fanins, (lsGeneric)Fnode_Flip(sibSibling), NULL) != LS_OK) {
    printf("Out of memory"); exit(2);
    }
    }
    else {  Flip polarity */

      Fnode_Inverse(sibSibling);
      if (lsNewEnd(top->fanins, (lsGeneric)sibSibling, NULL) != LS_OK) {
    printf("Out of memory"); exit(2);
      }
    }
  }

  lsFinish(sibSiblingList);

  /* Free sib, all its siblings have been bypassed. dd field should be taken care by other functions */
  if (Fnode_Regular(sib)->fanins != NULL) {
      lsDestroy(regSib->fanins, (void (*)())0);
  }
  FREE(regSib);

  return(1);

} /* end of BDS_ApplyFeasibleCollapse */

///==pga












