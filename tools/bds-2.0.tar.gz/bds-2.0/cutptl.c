
/**CFile***********************************************************************

  FileName    [cutptl.c]

  PackageName [BDS]

  Synopsis    [Cut PTL gates out of final synthesized netlist
               (not used for BDS-pga)]

  Description [Due to the concern of weak capability of identifying XNOR and
  MUX gates for tree-mapping-based technology mapper, all XNORs, XORs and MUXes
  are cut out from the final synthesis netlist. AND/OR and XNOR/MUX parts can
  be mapped separately.]

  Modifications  [Added functionality in order to print out file containing only
                  XORs, XNORs and MUXs in a <cktname>.ptl.blif file]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#include "lopt.h"
#include <stdio.h>

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static int bdsCutPtlFromGeneralNetlistRecursive ARGS((FactorTreeNode*,st_table*,st_table*,st_table*,st_table*,st_table*));
static int BDS_PrintBlifFromFtreeNodeList ARGS((BnetNetwork*,bdsOptions*,st_table*,st_table*,st_table*,char**,int));
static FactorTreeNode* bdsCreateNewPseudoPrimary ARGS((int));
static int bdsPrintBlifFromFtreeNodeList ARGS((st_table*,st_table*,char**,FILE*,int));
static int bdsPrintOneNodePrintVarNames ARGS((FILE*,FactorTreeNode*,FactorTreeNode*,char**,st_table*));
static int bdsIfDuplicate ARGS((lsList,FactorTreeNode*,char**));
static int bdsPrintOneNodeCutPtl ARGS((FILE*,FactorTreeNode*,FactorTreeNode*,char**,st_table*));
static int bdsPrintOneNodePrintFunction ARGS((FILE*,FactorTreeNode*));
static FactorTreeNode* bds_checkifoutputissameasPO ARGS((BnetNode*,FactorTreeNode*,int*));
static void update_allinputnodes ARGS((BnetNode*,BnetNetwork*));
static int bdsfigureoutoutputnode ARGS((FactorTreeNode*,char*,FactorTreeNode*,st_table*));

/**Function********************************************************************

  Synopsis    [Cut PTL gates from general netlist]

  Description [Since SIS mapper is weak at handling PTL and XOR mapping, those
  gates are cut from the final synthesis netlist. Submit only the AND/OR part
  to SIS mapper. After mapping, two netlist are concatenated togather. Return 1
  if successful; 0 otherwise.]

  SideEffects [Factoring trees are modified]

  SeeAlso     []

  LastDate    [3/1/99]

******************************************************************************/
extern
int
BDS_CutPtlFromGeneralNetlist(
  BnetNetwork *net,
  FactorTreeNode **FTreeNode,
  char **PIvariables,
  st_table *sharingFnodeTbl,
  bdsOptions *option,
  st_table *factorTreeNode2BnetNode)
{
  int i, result, result1,j,k=0, l=0,m=0,indicate=0;
  FactorTreeNode **q, *dummyPO, *dummyPOX, *top, *sib, *check;
  BnetNode *POnode, *Corrnode, *out;
  st_table *fnode2pseudoOutput, *fnode2pseudoInput;
  st_table *fnodeXpseudoOutput, *fnodeXpseudoInput;
  lsList fanins, fanouts, fanouts1;
  lsGen siblingList, siblist1;
  int yesorno=0;

  /* Initialize fnode->pseudo primary output table */
  fnode2pseudoOutput = st_init_table(st_ptrcmp,st_ptrhash);

  /* Initialize fnode->pseudo primary output table for xors etc*/
  fnodeXpseudoOutput = st_init_table(st_ptrcmp, st_ptrhash);

  /* Initialize fnode->pseudo primary input table */
  fnode2pseudoInput = st_init_table(st_ptrcmp,st_ptrhash);

  /* Initialize fnode->pseudo primary input table for xors */
  fnodeXpseudoInput = st_init_table(st_ptrcmp, st_ptrhash);

  i = 0;


  if (option->useglb) {

    for (i=0; i < net->npos; i++)
    {
      result = bdsCutPtlFromGeneralNetlistRecursive(FTreeNode[i],fnode2pseudoInput,fnode2pseudoOutput,fnodeXpseudoInput,fnodeXpseudoOutput,sharingFnodeTbl);
      if (result == 0) return(0);
      printf("I = %i\n",i);

      /*Add original POs. Their names are copied to new fnodes*/

    if (Fnode_Operator(FTreeNode[i]) == BDS_BDD_AND || Fnode_Operator(FTreeNode[i]) == BDS_BDD_OR) {
        dummyPO = ALLOC(FactorTreeNode, 1);
        dummyPO->value = BDS_FTREE_PSEUDO;
        dummyPO->name = ALLOC(char, 20);
        st_lookup(net->hash,net->outputs[i],(char **) &POnode);

        /*update_allinputnodes(POnode,net);
        check=bds_checkifoutputissameasPO(POnode, *q, &yesorno);
          if(yesorno == 1) {*/

        strcpy(dummyPO->name, POnode->name);
        printf("has it reached here yet 3?\n");
        if (st_add_direct(fnode2pseudoOutput, (char *) FTreeNode[i], (char *) dummyPO) == ST_OUT_OF_MEM) {
        printf("Out of memory !");
        return(0);
        }
    }

    /* Add original POs. Their names are copied to new fnodes
       for the Xor and Xnor and Mux output functions*/

    if (Fnode_Operator(FTreeNode[i]) == BDS_BDD_XOR || Fnode_Operator(FTreeNode[i]) == BDS_BDD_XNOR || Fnode_Operator(FTreeNode[i]) == BDS_BDD_MUX) {
      dummyPOX = ALLOC(FactorTreeNode, 1);
      dummyPOX->value = BDS_FTREE_PSEUDO;
      dummyPOX->name = ALLOC(char, 20);
      st_lookup(net->hash,net->outputs[i], (char **) &POnode);

      /*update_allinputnodes(POnode,net);
        check=bds_checkifoutputissameasPO(POnode, *q, &yesorno);
        if(yesorno == 1) {*/
      /*if (!st_is_member(fnodeXpseudoOutput, (char *) *q)) {*/

        strcpy(dummyPOX->name, POnode->name);
        if (st_add_direct(fnodeXpseudoOutput, (char *)  FTreeNode[i], (char *) dummyPOX) == ST_OUT_OF_MEM) {
        printf("Out of memory !");
        return(0);
          }
    }
    }
  }

 i = 0;
  if (option->useloc) {

    q = FTreeNode;
    l=0;
    while (q[l] != NULL) {
      l++;}
    printf("l = %i\n",l);

    m = l-1;
    for (q = FTreeNode; *q; q++)
      {

    result = bdsCutPtlFromGeneralNetlistRecursive(*q,fnode2pseudoInput,fnode2pseudoOutput,fnodeXpseudoInput,fnodeXpseudoOutput,sharingFnodeTbl);

    /*    l=0;
    while (q[l] != NULL) {
      l++;}
      printf("l = %i\n",l);*/

    if (result == 0) return(0);
    printf("I = %i\n",i);
    i++;

    top = Fnode_Regular(*q);
    st_lookup(factorTreeNode2BnetNode, (char *) top, (char **) &Corrnode);


    for (j=0; j < net->npos; j++) {

      /*if (Corrnode->ninp > 0) {
        printf("Corrnode is > 0\n");
        fanins = Corrnode->fanins;
        siblingList = lsStart(fanins);
        while (lsNext(siblingList, (lsGeneric *)&sib, NULL) == LS_OK) {*/
          /*  st_lookup(factorTreeNode2BnetNode, (char *) sib, (char **) &out);
        if (out->nfo > 0) {
          fanouts1 = sib->fanouts;
          siblist1 = lsStart(fanouts1);
          while(lsNext(siblist1, (lsGeneric *) &out, NULL) == LS_OK) {
          if (out->name == POnode->name) {*/
          /*Add original POs. Their names are copied to new fnodes*/


          if(Fnode_Operator(q[m])==BDS_BDD_AND || Fnode_Operator(q[m]) == BDS_BDD_OR) {

        dummyPO = ALLOC(FactorTreeNode, 1);
        dummyPO->value = BDS_FTREE_PSEUDO;
        dummyPO->name = ALLOC(char, 20);
        st_lookup(net->hash,net->outputs[j],(char **) &POnode);

        /*update_allinputnodes(POnode,net);
          check=bds_checkifoutputissameasPO(POnode, *q, &yesorno);
          if(yesorno == 1) {
         if (!st_is_member(fnode2pseudoOutput, (char *) *q)) {*/
         /* This is the MAIN problem, not enuff updating by programmer*/


        indicate = bdsfigureoutoutputnode(q[m],POnode->name,check,factorTreeNode2BnetNode);
        if(indicate) {
          k++;
        strcpy(dummyPO->name, POnode->name);
        printf("has it reached here yet 3?\n");
        if (st_add_direct(fnode2pseudoOutput, (char *) check, (char *) dummyPO) == ST_OUT_OF_MEM) {
          printf("Out of memory !");
            return(0);
          }}
          }


          /* Add original POs. Their names are copied to new fnodes
         This has been added for the Xor and Xnor and Mux output functions*/

          if (Fnode_Operator(q[m]) == BDS_BDD_XOR || Fnode_Operator(q[m]) == BDS_BDD_XNOR || Fnode_Operator(q[m]) == BDS_BDD_MUX) {

        dummyPOX = ALLOC(FactorTreeNode, 1);
        dummyPOX->value = BDS_FTREE_PSEUDO;
        dummyPOX->name = ALLOC(char, 20);
        st_lookup(net->hash,net->outputs[j], (char **) &POnode);

        /*update_allinputnodes(POnode,net);
          check=bds_checkifoutputissameasPO(POnode, *q, &yesorno);
          if(yesorno == 1) {*/
        /* if (!st_is_member(fnodeXpseudoOutput, (char *) *q)) {*/
        /*  st_lookup(factorTreeNode2BnetNode, (char *) sib, (char **) &out);
           if (out->name == POnode->name) {
           if (sib->name == POnode->name) {
           if(!st_is_member(fnodeXpseudoOutput, (char *) q[j])) {*/


        indicate = bdsfigureoutoutputnode(q[m],POnode->name,check,factorTreeNode2BnetNode);
        if (indicate) {

          k++;
          printf("this is the xor version\n");
          strcpy(dummyPOX->name, POnode->name);
          if (st_add_direct(fnodeXpseudoOutput, (char *) check, (char *) dummyPOX) == ST_OUT_OF_MEM) {
            printf("Out of memory !");
            return(0);
          }}

          }
          printf("k = %i\n",k);
    }
          /*        lsFinish(siblingList);*/
    m--;
      }
  }


  /* Print out the modified netlist in BLIF format */
  result = BDS_PrintBlifFromFtreeNodeList(net,option,fnode2pseudoInput,fnode2pseudoOutput,sharingFnodeTbl,PIvariables,1);
  if (result == 0) return(0);
  /* printf("Been there done that!!! 1 \n");
       st_free_table(fnode2pseudoOutput);
  st_free_table(fnode2pseudoInput);
  */

  /* Print out the new Xor netlist in BLIF format */
  result = BDS_PrintBlifFromFtreeNodeList(net,option,fnodeXpseudoInput,fnodeXpseudoOutput,sharingFnodeTbl, PIvariables,0);
  if (result == 0) return(0);

  st_free_table(fnodeXpseudoOutput);
  st_free_table(fnodeXpseudoInput);
  st_free_table(fnode2pseudoOutput);
  st_free_table(fnode2pseudoInput);


} /* end of BDS_CutPtlFromGeneralNetlist */

/**Function********************************************************************

   Synopsis    [Recursive program for BDS_CutPtlFromGeneralNetlist]

   Description [Return 1 if successful; 0 otherwise]

   SideEffects []

  SeeAlso     []

  LastDate    [3/1/99]

******************************************************************************/
static
int
bdsCutPtlFromGeneralNetlistRecursive(
  FactorTreeNode *fnode,
  st_table *fnode2pseudoInput,
  st_table *fnode2pseudoOutput,
  st_table *fnodeXpseudoInput,
  st_table *fnodeXpseudoOutput,
  st_table *sharingFnodeTbl)
{
  int result, result1,iterno=0;
  FactorTreeNode *top, *sib, *ctl, *pseudoPI, *pseudoPIX, *dummyPO, *listItem, *dummyPOX;
  lsList fanins;
  lsGen siblingList;
  lsHandle sibHandle,sibHandle1;
  lsStatus status,status1;

  /*printf("entered recursive cutptl program!!!");*/


  /* If terminal, go back. */
  if (!Fnode_Internal(fnode)) return(1);
  top = Fnode_Regular(fnode);

  /*printf("first part\n");*/

  /* If a pseudo input has been assigned to this fnode, go back
  */
  if (st_is_member(fnode2pseudoInput, (char *) top)) return(1);
  if (st_is_member(fnodeXpseudoInput, (char *) top)) return(1);

#ifdef PTL
  if (Fnode_Operator(top) == BDS_BDD_MUX) {
      ctl = top->control;
  }
#endif

  /* Traverse to the bottom */
  fanins = top->fanins;
  siblingList = lsStart(fanins);
  /*printf("part 2.25\n");*/

  while (lsNext(siblingList, (lsGeneric *)&sib, NULL) == LS_OK) {
      result = bdsCutPtlFromGeneralNetlistRecursive(sib,fnode2pseudoInput,fnode2pseudoOutput,fnodeXpseudoInput,fnodeXpseudoOutput,sharingFnodeTbl);
      if (result == 0) return(0);
      /*printf("part 2.5\n");*/
  }
  lsFinish(siblingList);


#ifdef PTL
  if (Fnode_Operator(top) == BDS_BDD_MUX) {
      result = bdsCutPtlFromGeneralNetlistRecursive(ctl,fnode2pseudoInput,fnode2pseudoOutput,fnodeXpseudoInput,fnodeXpseudoOutput,sharingFnodeTbl);
      if (result == 0) return(0);
  }
#endif


  /* If the operator of fnode is one of xor, xnor and mux, create pseudo primary
     outputs for all its siblings. Results are stored in fnode2pseudoOutput.
     A Dummy fnode is also created to hold its name.
     If one sibling is of the same operator, don't do anything.

     Also create pseudo primary inputs for all the xor and xnor and mux
             fnodes each input from all its siblings.
  */

  /* printf("third part\n");*/

  /*printf("we have entered the MAIN function  1 \n");*/


   if (Fnode_Operator(fnode) == BDS_BDD_XOR  ||
       Fnode_Operator(fnode) == BDS_BDD_XNOR || Fnode_Operator(fnode) == BDS_BDD_MUX)
     {

       siblingList = lsStart(fanins);
       while (lsNext(siblingList, (lsGeneric *)&sib, NULL) == LS_OK)
     {

       if ((Fnode_Operator(sib) == BDS_BDD_AND || Fnode_Operator(sib) == BDS_BDD_OR) && Fnode_Internal(sib))
         {
           if ((!st_is_member(fnode2pseudoOutput, (char *) Fnode_Regular(sib))))
         /* || (!st_is_member(fnodeXpseudoInput, (char *) Fnode_Regular(fnode)))) */
         {
           printf("we have entered the MAIN function  2\n");
           dummyPO = bdsCreateNewPseudoPrimary(1);
           /*pseudoPIX = bdsCreateNewPseudoPrimary(0);*/

           if ((st_add_direct(fnode2pseudoOutput, (char *) sib, (char *) dummyPO) == ST_OUT_OF_MEM) || (st_add_direct(fnodeXpseudoInput, (char *) dummyPO, (char *) NULL) == ST_OUT_OF_MEM))
             {
               printf("Out of memory !");
               return(0);
             }
         }
           /* Remove sib from siblist, patch new PO */
          if (Fnode_IsComplement(sib)) {
          status = lsInAfter(siblingList, (lsGeneric) Fnode_Complement(dummyPO), NULL);
          }
          else {
          status = lsInAfter(siblingList, (lsGeneric) dummyPO, NULL);
          }
          status = lsDelBefore(siblingList, (lsGeneric*) &listItem);
          status = lsNext(siblingList, (lsGeneric *)&sib, (lsHandle *)&sibHandle);

         }


       /* takes care of xors at the primary (not pseudo) inputs */
       if (!Fnode_Internal(sib))
         { /* PI */
           printf("somewhere inside\n");
           if (!st_is_member(fnodeXpseudoInput, (char *) Fnode_Regular(sib)))
         {
           if (st_add_direct(fnodeXpseudoInput, (char *) Fnode_Regular(sib), NULL) == ST_OUT_OF_MEM)
             {
               printf("Out of memory !");
               return(0);
             }
         }
         }

     }
       lsFinish(siblingList);
       /* the above portion does the job */


#ifdef PTL
       if (Fnode_Operator(top) == BDS_BDD_MUX)
     {
       if (Fnode_Operator(ctl) == BDS_BDD_AND || Fnode_Operator(ctl) == BDS_BDD_OR)
         {
           if ((!st_is_member(fnode2pseudoOutput, (char *) Fnode_Regular(ctl))))
           /*|| (!st_is_member(fnodeXpseudoInput, (char *) Fnode_Regular(top)))) */
         {
           dummyPO = bdsCreateNewPseudoPrimary(1);

           if ((st_add_direct(fnode2pseudoOutput, (char *) ctl, (char *) dummyPO) == ST_OUT_OF_MEM) || (st_add_direct(fnodeXpseudoInput, (char *) top, (char *) dummyPO) == ST_OUT_OF_MEM))
             {
               printf("Out of memory !");
               return(0);
             }
         }
         }
     }
#endif
     }
   /*end of the big loop if up there */


   else {

     printf("fourth part\n");

     /* Operator = BDS_BDD_AND or BDS_BDD_OR. Create pseudo PIs. A new primary input fnode
     ** is created to hold new PI name.
     */
     siblingList = lsStart(fanins);
     while (lsNext(siblingList, (lsGeneric *)&sib, (lsHandle *)&sibHandle) == LS_OK)
       {
     if (!Fnode_Internal(sib))
       { /* PI */
         if (!st_is_member(fnode2pseudoInput, (char *) Fnode_Regular(sib)))
           {
         if (st_add_direct(fnode2pseudoInput, (char *) Fnode_Regular(sib), NULL) == ST_OUT_OF_MEM)
           {
             printf("Out of memory !");
             return(0);
           }
           }
       }

     else if ((Fnode_Operator(sib) == BDS_BDD_XOR || Fnode_Operator(sib) == BDS_BDD_XNOR || Fnode_Operator(sib) == BDS_BDD_MUX) && Fnode_Internal(sib))
       {

         if (!st_is_member(fnodeXpseudoOutput, (char *) Fnode_Regular(sib)))
      /*||(!st_lookup(fnodeXpseudoOutput, (char *) Fnode_Regular(sib), (char **) &pseudoPI)))*/

           {

         pseudoPI = bdsCreateNewPseudoPrimary(0);

         if ((st_add_direct(fnode2pseudoInput, (char *) pseudoPI, NULL) == ST_OUT_OF_MEM) || (st_add_direct(fnodeXpseudoOutput, (char *) sib, (char *) pseudoPI) == ST_OUT_OF_MEM))
           {
             printf("Out of memory !");
             return(0);
           }
           }

         /* Remove sib from siblist, patch new PI */
         if (Fnode_IsComplement(sib)) {
           status = lsInAfter(siblingList, (lsGeneric) Fnode_Complement(pseudoPI), NULL);
         }
         else {
           status = lsInAfter(siblingList, (lsGeneric) pseudoPI, NULL);
         }
         status = lsDelBefore(siblingList, (lsGeneric*) &listItem);
         status = lsNext(siblingList, (lsGeneric *)&sib, (lsHandle *)&sibHandle);
       }
       }
     lsFinish(siblingList);
   }
   iterno++;
   printf("fifth part\n");
   printf("iteration number is %i\n",iterno);
   return(1);

} /* end of bdsCutPtlFromGeneralNetlistRecursive */


/**Function********************************************************************

  Synopsis    [Create an fnode to hold pseudo POs' and PIs' names]

  Description []

  SideEffects []

  SeeAlso     []

  LastDate    [3/2/99]

******************************************************************************/
static
FactorTreeNode *
bdsCreateNewPseudoPrimary(
  int inORout)
{
  char *pseudoIn, *pseudoOut, *pseudo_name;
  FactorTreeNode *ret_fnode;
  static int pi_count, po_count;

  pseudo_name = ALLOC(char, 10);
  ret_fnode = ALLOC(FactorTreeNode, 1);

  if (inORout) {
      sprintf(pseudo_name, "psuPO%d", po_count);
      po_count++;
  }
  else {
      sprintf(pseudo_name, "psuPI%d", pi_count);
      pi_count++;
  }

  ret_fnode->value = BDS_FTREE_PSEUDO;
  ret_fnode->name = pseudo_name;
  ret_fnode->polarity = 1;

  return(ret_fnode);

} /* end of bdsCreateNewPseudoPrimary */

/**Function********************************************************************

  Synopsis    []

  Description [Return 1 if successful; 0 otherwise.]

  SideEffects []

  SeeAlso     []

  LastDate    [3/1/99]

******************************************************************************/
static
int
BDS_PrintBlifFromFtreeNodeList(
  BnetNetwork *net,
  bdsOptions *option,
  st_table *fnode2pseudoInput,
  st_table *fnode2pseudoOutput,
  st_table *sharingFnodeTbl,
  char **PIvariables,
  int ptl_or_cutptl)
{
  FILE *dfp = NULL;
  int result;
  char *dumpfile, *dumpfile_name, *ckt_name;

  dumpfile_name = ALLOC(char, 100); /* file_name should not longer than 100 chars */

  /* Generate file_name as cktname.cutptl.blif */
  if (ptl_or_cutptl == 1) {
  ckt_name = BDS_GetFileHead(option->file);
  strcpy(dumpfile_name, ckt_name);
  strcat(dumpfile_name, ".cutptl.blif");
  }
  else {
    ckt_name = BDS_GetFileHead(option->file);
    strcpy(dumpfile_name, ckt_name);
    strcat(dumpfile_name, ".ptl.blif");
  }

  /* Put this file in the run dir */
  dumpfile = BDS_CreateFname(option, dumpfile_name);

  dfp = fopen(dumpfile,"w");
  if (dfp == NULL) fail("Can not open file to write !");


  result = bdsPrintBlifFromFtreeNodeList(fnode2pseudoInput,fnode2pseudoOutput,PIvariables,dfp,ptl_or_cutptl);
  if (result == 0) return(0);


  if (fclose(dfp) == EOF) return(0);
  FREE(dumpfile); FREE(dumpfile_name); FREE(ckt_name);

  return(1);

} /* end of BDS_PrintBlifFromFtreeNodeList */

/**Function********************************************************************

  Synopsis    []

  Description [Return 1 if successful; 0 otherwise.]

  SideEffects []

  SeeAlso     []

  LastDate    [3/1/99]

******************************************************************************/
static
int
bdsPrintBlifFromFtreeNodeList(
  st_table *fnode2pseudoInput,
  st_table *fnode2pseudoOutput,
  char **PIvariables,
  FILE *fp,
  int ptl_or_cutptl)
{
  FactorTreeNode *fnode, *dummy_node;
  st_table       *visited;
  st_generator   *gen = NULL;
  int            result;
  int            i, j;
  BnetNode       *POnode;
  FactorTreeNode *top, *dp, *dm, *ctl;
  lsList     newPIs;

   /* Initialize symbol table for visited nodes. */
  visited = st_init_table(st_ptrcmp, st_ptrhash);
  if (visited == NULL) return(0);

  /* Collect all the nodes on the ftrees */
  gen = st_init_gen(fnode2pseudoOutput);
  if (gen == NULL) return(0);
  while (st_gen(gen, (char **) &fnode, NULL)) {
      result = bdsCollectFNodeslsList(visited,fnode);
      if (result == 0) return(0);
  }
  st_free_gen(gen);

  result = fprintf(fp,"# The file is generated by %s\n",BDS_VERSION);
  if (result == EOF) return(0);
  result = fprintf(fp,"#\n");
  if (result == EOF) return(0);

  /* Write header information */
  if (ptl_or_cutptl == 1) {
  result = fprintf(fp, ".model cutptl\n");
  if (result == EOF) return(0);
  }
  else {
     result = fprintf(fp, ".model ptl\n");
     if (result == EOF) return(0);
  }

  /* Write the inputs & outputs list by scanning the list in blif file
     Since fnode2pseudoInput may contains multi-definition of a PI, filter
     it before print .inputs
  */
  result = fprintf(fp, ".inputs ");
  if (result == EOF) return(0);

  newPIs = lsCreate();
  gen = st_init_gen(fnode2pseudoInput);

   if (ptl_or_cutptl == 1 || ptl_or_cutptl == 0) {
      if (gen == NULL) return(0);
     printf("so its not NULL!!\n");
     while (st_gen(gen, (char **) &fnode, NULL))
       {
     printf("hey im in MAN\n");
     if (bdsIfDuplicate(newPIs, fnode, PIvariables))
       {
         st_delete(fnode2pseudoInput, (char **) &fnode, NULL);
       }
     else
       {
         lsNewEnd(newPIs, (lsGeneric) fnode, NULL);
         if (Fnode_Regular(fnode)->value == BDS_FTREE_PSEUDO)
           {
           result = fprintf(fp, "%s ", Fnode_Regular(fnode)->name);
         if (result == EOF) return(0);
           }
         else
           {
         result = fprintf(fp, "%s ", PIvariables[Fnode_Regular(fnode)->value]);
         if (result == EOF) return(0);
           }
       }
       }
     st_free_gen(gen);
   }
     printf("MAN its good so far!  6\n");
     lsDestroy(newPIs, NULL);
     result = fprintf(fp,"\n");
     if (result == EOF) return(0);


     result = fprintf(fp,".outputs ");
     if (result == EOF) return(0);
     gen = st_init_gen(fnode2pseudoOutput);
     if (gen == NULL) return(0);
     while (st_gen(gen, (char **) &fnode, (char **)&dummy_node)) {
       printf("MAN its good so far!  6.5 \n");
       result = fprintf(fp, "%s ", Fnode_Regular(dummy_node)->name);
       printf("MAN its good so far!  6.7 \n");
       if (result == EOF) return(0);
       printf("MAN its good so far!  6.8 \n");
     }
     st_free_gen(gen);
     result = fprintf(fp, "\n");
     if (result == EOF) return(0);

     printf("MAN its good so far!  7\n");


     /* Write outputs -> ftree first, this will put pos in the beginning of BLIF file */
     gen = st_init_gen(fnode2pseudoOutput);
     if (gen == NULL) return(0);

     printf("MAN its good so far!  8\n");

     while (st_gen(gen, (char **) &fnode, (char **)&dummy_node)) {
       result = bdsPrintOneNodeCutPtl(fp, fnode, dummy_node, PIvariables, fnode2pseudoOutput);
       if (result == 0) return(0);
     }
     st_free_gen(gen);

     printf("MAN its good so far!  9\n");

     /* Write all other internal nodes */
     gen = st_init_gen(visited);
     if (gen == NULL) return(0);
     while (st_gen(gen, (char **) &fnode, NULL)) {

       /* Skip POs, they have been dumped */
       if (st_is_member(fnode2pseudoOutput, (char *) fnode) == 1) { /* PO node */
     continue;
       }
       /* Skip terminal nodes */
       if (Fnode_Regular(fnode)->value != BDS_FTREE_INTERNAL) {
     continue;
       }
       /*added to allow ONLY xors, xnors and muxs to be printed in .ptl.blif file*/

       if ((ptl_or_cutptl == 0) && ((Fnode_Operator(fnode) == BDS_BDD_AND) || (Fnode_Operator(fnode) == BDS_BDD_OR))) {
     continue;
     }

       /* to allow ONLY Ands, Nands, Ors etc to be printed in .cutptl.blif file

       if ((ptl_or_cutptl == 1) && ((Fnode_Operator(fnode) == BDS_BDD_XOR) || (Fnode_Operator(fnode) == BDS_BDD_XNOR))) {
     continue;
     }*/

       if (ptl_or_cutptl == 1) {
     result = bdsPrintOneNodeCutPtl(fp, fnode, NULL, PIvariables, fnode2pseudoOutput);
       if (result == 0) return(0);
       }

       if (ptl_or_cutptl == 0) {
     result = bdsPrintOneNodeCutPtl(fp, fnode, NULL, PIvariables, fnode2pseudoOutput);
       if (result == 0) return(0);
       }

     }

     /* write end */
     result = fprintf(fp, ".end\n");
     if (result == EOF) return(0);

  st_free_gen(gen);
  st_free_table(visited);

  return(1);

} /* end of bdsPrintBlifFromFtreeNodeList */

/**Function********************************************************************

  Synopsis    []

  Description [Return 1 if successful; 0 otherwise.]

  SideEffects []

  SeeAlso     []

vvv  LastDate    [3/2/99]

******************************************************************************/
static
int
bdsPrintOneNodeCutPtl(
  FILE *fp,
  FactorTreeNode *fnode,
  FactorTreeNode *dummy_node,
  char **PIvariables,
  st_table *fnode2pseudoOutput)
{
  int result;
  FactorTreeNode *top;

  printf("i have reached inside one node!!! 20\n");

  top = Fnode_Regular(fnode);

  /* Screen out the possibility that po node is a terminal */
  if (top->value != BDS_FTREE_INTERNAL && dummy_node != NULL) {
      result = fprintf(fp,".names ");
      if (result == EOF) return(0);
      result = fprintf(fp,"%s %s\n",PIvariables[top->value],dummy_node->name);
      if (result == EOF) return(0);
      result = fprintf(fp,"%c 1\n",(top->polarity)?'0':'1');
      if (result == EOF) return(0);

      return(1);
  }

   printf("MAN its good so far!  19\n");

  /* print variable names */
  result = bdsPrintOneNodePrintVarNames(fp,top,dummy_node,PIvariables,fnode2pseudoOutput);
  if (result == 0) return(0);

  /* print functionality */
  result = bdsPrintOneNodePrintFunction(fp,top);

  return(result);

} /* end of bdsPrintOneNodeCutPtl */

/**Function********************************************************************

  Synopsis    [Print out the support of this fnode]

  Description [In cases like, (a+b)' and (fg+f'h)', instead of printing a'b' and
  fg'+f'h', inverters are inserted to keep their original forms. Dummy variables
  are introduced by alloc new FactorTreeNode. The memory allocated for them are
  leaked. Return 1 if successful, 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  Last date   [2/28/99]

*****************************************************************************/
static
int
bdsPrintOneNodePrintVarNames(
  FILE *fp,
  FactorTreeNode *top,
  FactorTreeNode *dummy_node,
  char **PIvariables,
  st_table *fnode2pseudoOutput)
{
  int result;
  FactorTreeNode *sib, *ctl, *inverter;
  FactorTreeNode *po;
  lsList fanins;
  lsGen fanin_list;


   printf("MAN its good so far!  29\n");

  fanins = Fnode_Fanins(top);

  /* In case of (a+b)' and (fg+f'h)', insert an inverter */
  if (Fnode_Operator(top) == BDS_BDD_OR && Fnode_Negative(top) ||
               Fnode_Operator(top) == BDS_BDD_MUX && Fnode_Negative(top)) {
      inverter = ALLOC(FactorTreeNode, 1);

      result = fprintf(fp, ".names ");
      if (result == EOF) return(0);

      /* Print intermediate name */
      result = fprintf(fp,"0x%x ",(unsigned) inverter);
      if (result == EOF) return(0);

      /* Print functional node's name */
      if (dummy_node == NULL) { /* internal node */
          result = fprintf(fp,"0x%x\n",(unsigned) top);
          if (result == EOF) return(0);
      }
      else { /* PO node, print its name */
          result = fprintf(fp,"%s\n",dummy_node->name);
          if (result == EOF) return(0);
      }

      /* Print inverter's functionality */
      result = fprintf(fp,"0 1\n");
      if (result == EOF) return(0);
  }


   printf("MAN its good so far!  39\n");

  /* Print names under normal conditions */
  result = fprintf(fp, ".names ");
  if (result == EOF) return(0);

#ifdef PTL
  /* Print name corresponding to f in MUX */
  if (top->op == BDS_BDD_MUX) { /* a MUX node */
      ctl = top->control;
      if (Fnode_Regular(ctl)->value == BDS_FTREE_INTERNAL) { /* internal node */
          if (!st_lookup(fnode2pseudoOutput, (char *) Fnode_Regular(ctl), (char **) &po)) {
              result = fprintf(fp,"0x%x ",(unsigned) Fnode_Regular(ctl));
              if (result == EOF) return(0);
          }
          else {
              result = fprintf(fp,"%s ",po->name);
              if (result == EOF) return(0);
          }
      }
      else { /* terminal node, print pi name */
          result = fprintf(fp,"%s ",PIvariables[Fnode_Regular(ctl)->value]);
          if (result == EOF) return(0);
      }
  }
#endif

  printf("MAN its good so far!  49\n");


  /* Print support names on this fnode */
  fanin_list = lsStart(fanins);
  while (lsNext(fanin_list, (lsGeneric *)&sib, NULL) != LS_NOMORE) {

      if (Fnode_Regular(sib)->value == BDS_FTREE_INTERNAL) { /* internal node */
          if (!st_lookup(fnode2pseudoOutput, (char *) Fnode_Regular(sib), (char **) &po)) {
              result = fprintf(fp,"0x%x ",(unsigned) Fnode_Regular(sib));
              if (result == EOF) return(0);
          }
          else {
              result = fprintf(fp,"%s ",po->name);
              if (result == EOF) return(0);
          }
      }

      else if (Fnode_Regular(sib)->value == BDS_FTREE_PSEUDO) { /* pseudo PI */
           printf("MAN its good so far!  55\n");
           result = fprintf(fp,"%s ",Fnode_Regular(sib)->name);
           if (result == EOF) return(0);
      }
      else { /* terminal node, print pi name */
    printf("MAN its good so far!  57\n");
          result = fprintf(fp,"%s ",PIvariables[Fnode_Regular(sib)->value]);
         printf("MAN its good so far!  57.5\n");
     if (result == EOF) return(0);
     printf("MAN its good so far!  58\n");
      }
  }
  lsFinish(fanin_list);

   printf("MAN its good so far!  59\n");


  /* Print functional node's name. In case of (a+b)' and (fg+f'h)', print newly
     allocated inverter pointer instead
  */
  if (Fnode_Operator(top) == BDS_BDD_OR && Fnode_Negative(top) ||
               Fnode_Operator(top) == BDS_BDD_MUX && Fnode_Negative(top)) {

      result = fprintf(fp,"0x%x\n",(unsigned) inverter);
      if (result == EOF) return(0);
  }
  else {
      if (dummy_node == NULL) { /* internal node */
          result = fprintf(fp,"0x%x\n",(unsigned) top);
          if (result == EOF) return(0);
      }
      else { /* PO node, print its name */
          result = fprintf(fp,"%s\n",dummy_node->name);
          if (result == EOF) return(0);
      }
  }


   printf("MAN its good so far!  69\n");

  return(1);

} /* end of bdsPrintOneNodePrintVarNames */

/**Function********************************************************************

  Synopsis    [Print out the function of this fnode]

  Description  [AND, OR, XOR and XNOR exist on the ftree. Return 1 if successful, 0 otherwise]

  SideEffects [None]

  SeeAlso     [bdsDumpFtreeBlifOneNodePrintFunction()]

  Last date   [3/3/99]

  Modifications  added functionality to take care of XOR, XNOR and MUXs

  Date of Modifications 11/27/99

*****************************************************************************/
static
int
bdsPrintOneNodePrintFunction(
  FILE *fp,
  FactorTreeNode *top)
{
  int result, i, j, num_fanins;
  FactorTreeNode *sib, *ctl, *inverter, *dp, *dm;
  FactorTreeNode *firstItem, *lastItem;
  BnetNode *po;
  lsList fanins;
  lsGen fanin_list;
  dp = top->siblings[0];
  dm = top->siblings[1];
  if (top->op == BDS_BDD_MUX) {
      ctl = top->siblings[2];
  }
  fanins = Fnode_Fanins(top);
  num_fanins = lsLength(fanins);
  fanin_list = lsStart(fanins);

  /* print functionality of this node */
  switch(Fnode_Operator(top)) {
 case BDS_BDD_XOR:
      if (Fnode_Negative(top)) { /* (a'b+ab')' = ab + a'b' */
          result = fprintf(fp,"%c%c 1\n",\
               Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c%c 1\n",\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      else { /* a'b + ab' */
      result = fprintf(fp,"%c%c 1\n",\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'),\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
      result = fprintf(fp,"%c%c 1\n",\
           Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      break;
  case BDS_BDD_XNOR:
      if (Fnode_Negative(top)) { /* (ab + a'b')' = a'b + ab' */
      result = fprintf(fp,"%c%c 1\n",\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'),\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
      result = fprintf(fp,"%c%c 1\n",\
               Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      else { /* ab + a'b' */
          result = fprintf(fp,"%c%c 1\n",\
               Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'),\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c%c 1\n",\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      break;
  case BDS_BDD_MUX:
      if (Fnode_Negative(top)) { /* (fg + f'h)' = fg' + f'h' */
          result = fprintf(fp,"%c%c- 1\n",\
           Fnode_Internal(ctl)?(Fnode_IsComplement(ctl)?'0':'1'):(Fnode_Negative(ctl)?'0':'1'),\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c-%c 1\n",\
                   Fnode_Internal(ctl)?(Fnode_IsComplement(ctl)?'1':'0'):(Fnode_Negative(ctl)?'1':'0'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      else { /* fg + f'h */
          result = fprintf(fp,"%c%c- 1\n",\
           Fnode_Internal(ctl)?(Fnode_IsComplement(ctl)?'0':'1'):(Fnode_Negative(ctl)?'0':'1'),\
           Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c-%c 1\n",\
                   Fnode_Internal(ctl)?(Fnode_IsComplement(ctl)?'1':'0'):(Fnode_Negative(ctl)?'1':'0'),\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
      }
      break;
  case BDS_BDD_AND:
      while (lsNext(fanin_list, (lsGeneric *)&sib, NULL) != LS_NOMORE) {

          result = fprintf(fp,"%c",\
               Fnode_Internal(sib)?(Fnode_IsComplement(sib)?'0':'1'):(Fnode_Negative(sib)?'0':'1'));
          if (result == EOF) return(0);
      }
      result = fprintf(fp," %c\n",Fnode_Negative(top)?'0':'1');
      if (result == EOF) return(0);
      break;

  case BDS_BDD_OR:
      /* The corresponding BLIF representation is a square, the negative case has
      ** been taken care of in bdsDumpFtreeBlifOneNodePrintVarNames().
      */
      i = 0;
      while (lsNext(fanin_list, (lsGeneric *)&sib, NULL) != LS_NOMORE) {
          for (j = 0; j < num_fanins; j++) {
              if (j == i) { /* print function */
                  result = fprintf(fp,"%c",\
                      Fnode_Internal(sib)?(Fnode_IsComplement(sib)?'0':'1'):(Fnode_Negative(sib)?'0':'1'));
                  if (result == EOF) return(0);
              }
              else { /* print - */
                  result = fprintf(fp,"-");
                  if (result == EOF) return(0);
              }
          }
          result = fprintf(fp," 1\n");
          if (result == EOF) return(0);

          i++;
      }
      break;
  default:
      printf("Unknown operator in bdsPrintOneNodePrintFunction()");
  }
  lsFinish(fanin_list);

  return(1);

} /* end of bdsPrintOneNodePrintFunction */

/**Function********************************************************************

  Synopsis    [Print out the function of this fnode]

  Description [Only AND and OR exist on the ftree. Return 1 if successful, 0 otherwise]

  SideEffects [None]

  SeeAlso     [bdsDumpFtreeBlifOneNodePrintFunction()]

  Last date   [3/3/99]

*****************************************************************************/
static
int
bdsIfDuplicate(
  lsList newPIs,
  FactorTreeNode *fnode,
  char **PIvariables)
{
  int retVal = 0;
  lsGen gen;
  FactorTreeNode *list_element;
  char *s1, *s2;

  gen = lsStart(newPIs);

  printf("MAN its good so far! 79\n");

  while (lsNext(gen, (lsGeneric *)&list_element, NULL) != LS_NOMORE) {
    printf("MAN its good so far!  79.5\n");
    if (Fnode_Regular(fnode)->value == BDS_FTREE_PSEUDO) { /* Pseudo PIs */
      printf("its a PSEUDO!!  1\n");
      if (Fnode_Regular(list_element)->value == BDS_FTREE_PSEUDO) {
    printf("its a PSEUDO!!  2\n");
    s1 = Fnode_Regular(list_element)->name;
    s2 = Fnode_Regular(fnode)->name;
    retVal = !strcmp(s1, s2);
    printf("MAN its good so far!  80\n");
    if (retVal != 0) goto endgame;
      }
      else {
    retVal = 0;
      }
    }
    else { /* Normal PIs */
      if (Fnode_Regular(list_element)->value != BDS_FTREE_PSEUDO) {
    printf("MAN its good so far!  80\n");
    s1 = PIvariables[Fnode_Regular(list_element)->value];
    s2 = PIvariables[Fnode_Regular(fnode)->value];
    retVal = !strcmp(s1, s2);
    printf("MAN its good so far!  85\n");
    if (retVal != 0) goto endgame;
      }
      else {
    retVal = 0;
      }
    }
  }

 endgame:

  lsFinish(gen);
  return(retVal);

} /* end of bdsIfDuplicate */
static
void
update_allinputnodes(
BnetNode *change,
BnetNetwork *net)

{
int i=0,j=0;
BnetNode *temp;
char *tempname;

 change->inpnode = (BnetNode **) malloc(change->ninp*sizeof(BnetNode *));

 for (i=0; i < change->ninp; i++)
   {
     temp = (BnetNode *) malloc(sizeof(BnetNode));
     change->inpnode[i] = temp;
   }

 for (i=0; i < change->ninp; i++) {
   tempname = change->inputs[i];
   st_lookup(net->hash, (char *) tempname, (char **) &temp);
   change->inpnode[i] = temp;
 }

}

static
FactorTreeNode *
bds_checkifoutputissameasPO(
BnetNode *POnode,
FactorTreeNode *node,
int *yesorno)

{
lsList fanins;
lsGen list;
int i=0;
FactorTreeNode *top, *sib;
BnetNode *Tnode;

top = Fnode_Regular(node);
fanins = top->fanins;
list = lsStart(fanins);

Tnode = ALLOC(BnetNode,1);

 while ((list != NULL) && (lsNext(list, (lsGeneric *)&sib, NULL) == LS_OK)) {

   for (i=0; i < POnode->ninp; i++) {
     Tnode = POnode->inpnode[i];
     if (Tnode->tmpBdd == sib->local)
       {
     return(sib);
     *yesorno = 1;
     continue;
       }
     else
       {
     return(0);
     *yesorno = 0;
       }
   }
 }
 lsFinish(list);
}

static
int
bdsfigureoutoutputnode(
  FactorTreeNode *fnode,
  char *nodename,
  FactorTreeNode *indicate,
  st_table *correspond)
{
  FactorTreeNode *top, *sib, *ctl, *outs;
  int result,i=0;
  lsGen siblingList, list1;
  BnetNode *corrnode, *corrout;

  if (top != NULL) {
    top = Fnode_Regular(fnode);

    st_lookup(correspond, (char *) top, (char **) &corrnode);

    if (nodename == corrnode->name)
      {
    indicate = top;
    return(1);
      }

    else {

      if ((corrnode->nfo > 0) && (corrnode->nfo < 150)) {

    list1 = lsStart(corrnode->fanouts);

    while (lsNext(list1, (lsGeneric *)&outs, NULL) == LS_OK) {

      st_lookup(correspond, (char *) outs, (char **) &corrout);

       if ((int) outs->name > 10000) {
        if (corrout->name == nodename) {
          indicate = outs;
          return(1);
        }
       }
       lsFinish(list1);
    }
      }
    }
    siblingList = lsStart(corrnode->fanins);
    while (lsNext(siblingList, (lsGeneric *)&sib, NULL) == LS_OK) {

      result = bdsfigureoutoutputnode(sib,nodename,indicate,correspond);
      if (result == 1) return(1);
    }
    lsFinish(siblingList);

    return(0);

  }
}
