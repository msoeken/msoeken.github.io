
/**CFile***********************************************************************

  FileName    [prepare.c]

  PackageName [BDS-pga]

  Synopsis    [Util programs before BDD decomposition]

  Description [This file contains the functions that decide to use local or global BDDs.]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/
#include "prepare.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis    [Decide whether global or local BDDs are used for synthesis]

  Description [Compare the complexity of both global and local BDDs. If the size
  of gloabl BDDs is significantly smaller than local BDDs (based a definite ratio
  passed in through option), global BDDs are used for synthesis. Otherwise, use
  local BDDs. The number of BDD nodes is taken after they are reordered individually.
  Return 1 if use global; 0 if use local BDDs]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
extern
int
bdsGlobalOrLocalBDD(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option,
  FILE *recdfp)
{
  int i, retVal;
  BnetNode *node;
  DdManager *newbddmgr;
  DdNode **globalBddArray, **localBddArray;
  int numGlobalBdd, numLocalBdd;
  int globalBddNodes, localBddNodes;
  st_generator *gen;

  newbddmgr = startCudd(option, 0);

#ifndef DEBUG
  Cudd_SetStdout(newbddmgr, recdfp);
  fprintf(recdfp, "\n\n<<<<<<<<<  bdsGlobalOrLocalBDD() bddmgr  >>>>>>>>>>\n\n");
#else
  printf("\n\n<<<<<<<<<  bdsGlobalOrLocalBDD() bddmgr  >>>>>>>>>>\n\n");
#endif

  numGlobalBdd = net->npos;
  globalBddArray = ALLOC(DdNode *, numGlobalBdd);
  for (i = 0; i < numGlobalBdd; i++) {
      if (!st_lookup(net->hash,net->outputs[i],(char **) &node)) {
          exit(2);
      }
      globalBddArray[i] = Cudd_bddTransfer(bddmgr, newbddmgr, node->dd);
      if (globalBddArray[i] == NULL) {
          Cudd_Quit(newbddmgr);
          return(0);
      }
      Cudd_Ref(globalBddArray[i]);
  }
  option->reordering = CUDD_REORDER_SIFT;
  BDS_Reorder(newbddmgr, NULL, option);
  globalBddNodes = Cudd_SharingSize(globalBddArray, numGlobalBdd);
  Cudd_Quit(newbddmgr);

  newbddmgr = startCudd(option, 0);

#ifndef DEBUG
  Cudd_SetStdout(newbddmgr, recdfp);
  fprintf(recdfp, "\n\n<<<<<<<<<  bdsGlobalOrLocalBDD() bddmgr  >>>>>>>>>>\n\n");
#else
  printf("\n\n<<<<<<<<<  bdsGlobalOrLocalBDD() bddmgr  >>>>>>>>>>\n\n");
#endif

  numLocalBdd = st_count(net->livenodes);
  localBddArray = ALLOC(DdNode *, numLocalBdd);
  i = 0;
  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &node, NULL)) {
      if (node->type == BNET_INPUT_NODE) continue;
      localBddArray[i] = Cudd_bddTransfer(bddmgr, newbddmgr, node->localBdd);
      if (localBddArray[i] == NULL) {
          Cudd_Quit(newbddmgr);
          return(0);
      }
      Cudd_Ref(localBddArray[i]);
      i++;
  }
  st_free_gen(gen);
  option->reordering = CUDD_REORDER_SIFT;
  BDS_Reorder(newbddmgr, NULL, option);
  localBddNodes = Cudd_SharingSize(localBddArray, i);
  Cudd_Quit(newbddmgr);

  if (localBddNodes >= BDS_LOCAL_GLOBAL * globalBddNodes)
      retVal = 1;
  else
      retVal = 0;

  FREE(globalBddArray); FREE(localBddArray);

  return(retVal);

} /* end of bdsGlobalOrLocalBDD */

/**Function********************************************************************

  Synopsis    [Build BDD Id vs. char* name association for global BDDs]

  Description [The assoc is invariant through out the rest process.
  Return value is a NULL-ended array. Return assoc if successful; NULL otherwise]

  SideEffects [None]

  SeeAlso     []

  LastDate    [5/16/99]

*****************************************************************************/
extern
char **
bdsBuildVarNameAssocGlobal(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option)
{
  int i;
  BnetNode *node;
  char **PIvariables;

  /* Since all PIs are created before intermediate variables, their id
  ** are smaller than others'. */
  PIvariables = ALLOC(char *, net->npis + 1);
  if (PIvariables == NULL) return(NULL);
  for (i = 0; i < net->npis; i++) {
      if (!st_lookup(net->hash,net->inputs[i],(char **)&node)) {
          exit(2);
      }
      PIvariables[node->var] = node->name;
  }
  PIvariables[i] = NULL;

  return(PIvariables);

} /* end of bdsBuildVarNameAssocGlobal */

/**Function********************************************************************

  Synopsis    [Build BDD Id vs. char* name association for local BDDs]

  Description [The assoc is invariant through out the rest process.
  Return value is a NULL-ended array. Return assoc if successful; NULL otherwise]

  SideEffects [None]

  SeeAlso     []

  LastDate    [5/16/99]

*****************************************************************************/
extern
char **
bdsBuildVarNameAssocLocal(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option)
{
  int i;
  BnetNode *node;
  st_generator *gen;
  char **PIvariables;

  /* Ids on all existing nodes (except PO) are collected */
  PIvariables = ALLOC(char *, bddmgr->size + 1);
  if (PIvariables == NULL) return(NULL);
  (void) memset((char *)PIvariables, 0, (bddmgr->size + 1) * sizeof(char *));
  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &node, NULL)) {
      PIvariables[node->localVar] = node->name;
  }
  st_free_gen(gen);

  return(PIvariables);

} /* end of bdsBuildVarNameAssocLocal */

/**Function********************************************************************

  Synopsis    [Free all global and local BDDs on the net]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  LastDate    [3/25/99]

*****************************************************************************/
extern
int
bdsFreeAllBDDs(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option,
  int globalReady)
{
    BnetNode *node;
    st_generator *gen;

    gen = st_init_gen(net->livenodes);
    while (st_gen(gen, (char **) &node, NULL)) {

        /* Free all PIs' BDDs. Since localVar is just a copy of var,
        ** it should not be freed, EXCEPT when global is ready in which case,
        ** Cudd_Ref() is called one more time on the same var.
        */
        if (node->type == BNET_INPUT_NODE && node->active == TRUE
                                        && (!option->useloc == TRUE) ) {
        Cudd_IterDerefBdd(bddmgr,node->dd);
        }
        if (node->type == BNET_INPUT_NODE && (globalReady && (!option->useglb == TRUE)
                                        || option->useloc == TRUE) ) {
        Cudd_IterDerefBdd(bddmgr,node->localBdd);
        }

        /* Free internal BDDs. Since localVars on the internal and output nodes
        ** are never Cudd_Refed, they should not be freed.
        */
        if ((node->type == BNET_INTERNAL_NODE || node->type == BNET_OUTPUT_NODE) && globalReady) {
        if (node->dd != NULL) Cudd_RecursiveDeref(bddmgr,node->dd);
        node->dd = NULL;
        }
        if ((node->type == BNET_INTERNAL_NODE || node->type == BNET_OUTPUT_NODE)
                                                  && (!option->useglb == TRUE) ){
        Cudd_RecursiveDeref(bddmgr,node->localBdd);
        node->localBdd = NULL;
        }
    }
    st_free_gen(gen);

    return(1);

} /* end of bdsFreeAllBDDs */

/**Function********************************************************************

  Synopsis    [Store global or local BDDs]

  Description [BDDs can be stored in both bddPool and sopPool. For local BDDs,
  sopPool is unlikely to blow up. However, at the mean time, we still use bddPool.
  The pontential drawback of this form is, number of variables in the local BDD case,
  is very large. It may take long time to shaffle bddmgr. This needs some experiemnt
  to decide whether sopPool or bddPool should be used.
  Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  LastDate    [3/25/99]

*****************************************************************************/
extern
SopPool **
bdsStoreBDDs( /// not used anywhere
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option,
  st_table *bddPoolBnodeAssoc,
  int localGlobal)
{
  int i, retVal;
  int numLocalBdd = 0; /* Number of local BDDs, this should exclude PIs */
  BnetNode *node;
  st_generator *gen;
  SopPool **bddPoolArray;

  if (!localGlobal) {
      bddPoolArray = ALLOC(SopPool *, net->npos + 1);
      if (bddPoolArray == NULL) return(NULL);
      for (i = 0; i < net->npos; i++) {
          if (!st_lookup(net->hash,net->outputs[i],(char **)&node)) {
              exit(2);
          }
          bddPoolArray[i] = BDS_DumpSopLocal(bddmgr, node->dd);

      /* Build bddPool vs. node assoc */
      retVal = st_insert(bddPoolBnodeAssoc, (char *) bddPoolArray[i], (char *) node);
      if (retVal == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
          else if (retVal == 1) {
          printf("Fatal error in bddPoolBnodeAssoc"); exit(2);
      }
      }
      bddPoolArray[i] = NULL;
  }
  else {
      gen = st_init_gen(net->livenodes);
      while (st_gen(gen, (char **) &node, NULL)) {
      if (node->type == BNET_INPUT_NODE) continue;
      numLocalBdd++;
      }
      st_free_gen(gen);

      bddPoolArray = ALLOC(SopPool *, numLocalBdd + 1);
      if (bddPoolArray == NULL) return(NULL);
      gen = st_init_gen(net->livenodes);
      i = 0;
      while (st_gen(gen, (char **) &node, NULL)) {
      if (node->type == BNET_INPUT_NODE) continue;
      bddPoolArray[i] = BDS_DumpSopLocal(bddmgr, node->localBdd);

      /* Build bddPool vs. node assoc */
      retVal = st_insert(bddPoolBnodeAssoc, (char *) bddPoolArray[i], (char *) node);
      if (retVal == ST_OUT_OF_MEM) {
          printf("Out of memory"); exit(2);
      }
          else if (retVal == 1) {
          printf("Fatal error in bddPoolBnodeAssoc"); exit(2);
      }
      i++;
      }
      bddPoolArray[i] = NULL;
      st_free_gen(gen);
  }

  return(bddPoolArray);

} /* end of bdsStoreBDDs */

/**Function********************************************************************

  Synopsis    [Store global BDDs]

  Description [BDDs are stored in bddPool form. Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  LastDate    [5/16/99]

*****************************************************************************/
extern
bddPool**
bdsStoreBDDInBddPoolGlobal(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option,
  st_table *bddPoolBnodeAssoc)
{
  int i, retVal;
  BnetNode *node;
  bddPool **bddPoolArray;

  bddPoolArray = ALLOC(bddPool *, net->npos + 1);
  if (bddPoolArray == NULL) return(NULL);
  for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash, (char *) net->outputs[i], (char **) &node)) {
          exit(2);
      }
      bddPoolArray[i] = BDS_StoreBddPoolLocal(bddmgr, node->dd);

      /* Build bddPool vs. node assoc */
      retVal = st_insert(bddPoolBnodeAssoc, (char *) bddPoolArray[i], (char *) node);
      if (retVal == ST_OUT_OF_MEM) {
      printf("Out of memory"); exit(2);
      }
      else if (retVal == 1) {
      printf("Fatal error in bddPoolBnodeAssoc"); exit(2);
      }
  }
  bddPoolArray[i] = NULL;

  return(bddPoolArray);

} /* end of bdsStoreBDDInBddPoolGlobal */


/**Function********************************************************************

  Synopsis    [Store local BDDs]

  Description [BDDs are stored in bddPool form. Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  LastDate    [5/16/99]

*****************************************************************************/
extern
bddPool **
bdsStoreBDDInBddPoolLocal(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option,
  st_table *bddPoolBnodeAssoc)
{
    int         i, retVal;
    int         numLocalBdd = 0; /* Number of local BDDs, this should NOT include PIs */
    BnetNode    *node;
    st_generator *gen;
    bddPool     **bddPoolArray;

    gen = st_init_gen(net->livenodes);
    while (st_gen(gen, (char **) &node, NULL)) { /// count # BDDs in net except INPUT nodes
        if (node->type == BNET_INPUT_NODE) continue; /// skip INPUT nodes
        numLocalBdd++;
    }
    st_free_gen(gen);

    bddPoolArray = ALLOC(bddPool *, numLocalBdd + 1);
    if (bddPoolArray == NULL) return(NULL);
    gen = st_init_gen(net->livenodes);
    i = 0;
    while (st_gen(gen, (char **) &node, NULL)) {
        if (node->type == BNET_INPUT_NODE) continue; /// skip INPUT nodes
        bddPoolArray[i] = BDS_StoreBddPoolLocal(bddmgr, node->localBdd);

        /* Build bddPool vs. node assoc */
        retVal = st_insert(bddPoolBnodeAssoc, (char *) bddPoolArray[i], (char *) node); /// add bnode with key bddPoolArray to bddPoolBnodeAssoc table
        if (retVal == ST_OUT_OF_MEM) {
            printf("Out of memory"); exit(2);
        }
        else if (retVal == 1) { /// if there was an entry already under the key, retVal = 0 if st_insert is successful
            printf("Fatal error in bddPoolBnodeAssoc"); exit(2);
        }
        i++;
    }
    bddPoolArray[i] = NULL; /// set the last item of bddPoolArray to NULL
    st_free_gen(gen);

    return(bddPoolArray);

} /* end of bdsStoreBDDInBddPoolLocal */

extern
DdNode **
bdsStoreBDDInBddPoolLocal_(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option,
  st_table *bddPoolBnodeAssoc)
{
    int         i, retVal;
    int         numLocalBdd = 0; /* Number of local BDDs, this should NOT include PIs */
    BnetNode    *node;
    st_generator *gen;
    DdNode     **bddPoolArray;

    gen = st_init_gen(net->livenodes);
    while (st_gen(gen, (char **) &node, NULL)) { /// count # BDDs in net except INPUT nodes
        if (node->type == BNET_INPUT_NODE) continue; /// skip INPUT nodes
        numLocalBdd++;
    }
    st_free_gen(gen);
  printf("sharing;%d\n",numLocalBdd);
    bddPoolArray = ALLOC(DdNode *, numLocalBdd + 1);
    if (bddPoolArray == NULL) return(NULL);
    gen = st_init_gen(net->livenodes);
    i = 0;
    while (st_gen(gen, (char **) &node, NULL)) {
        if (node->type == BNET_INPUT_NODE) continue; /// skip INPUT nodes
        bddPoolArray[i] = node->localBdd;

        /* Build bddPool vs. node assoc */
       // retVal = st_insert(bddPoolBnodeAssoc, (char *) bddPoolArray[i], (char *) node); /// add bnode with key bddPoolArray to bddPoolBnodeAssoc table
      //  if (retVal == ST_OUT_OF_MEM) {
       //     printf("Out of memory"); exit(2);
      //  }
      //  else if (retVal == 1) { /// if there was an entry already under the key, retVal = 0 if st_insert is successful
      //      printf("Fatal error in bddPoolBnodeAssoc"); exit(2);
      //  }
        i++;
    }
    bddPoolArray[i] = NULL; /// set the last item of bddPoolArray to NULL
    st_free_gen(gen);

    return(bddPoolArray);

}








