
/**CHeaderFile*****************************************************************

  FileName    [prepare.h]

  PackageName [BDS-pga]

  Synopsis    [Util program before BDD decomposition]

  Description []

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#ifndef _BDSPREPARE
#define _BDSPREPARE

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "lopt.h"
#include "local.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN int bdsGlobalOrLocalBDD ARGS((DdManager*,BnetNetwork*,bdsOptions*,FILE*));
EXTERN SopPool** bdsStoreBDDs ARGS((DdManager*,BnetNetwork*,bdsOptions*,st_table*,int));
EXTERN int bdsFreeAllBDDs ARGS((DdManager*,BnetNetwork*,bdsOptions*,int));
EXTERN char** bdsBuildVarNameAssocGlobal ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN char** bdsBuildVarNameAssocLocal ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN bddPool** bdsStoreBDDInBddPoolGlobal ARGS((DdManager*,BnetNetwork*,bdsOptions*,st_table*));
EXTERN bddPool** bdsStoreBDDInBddPoolLocal ARGS((DdManager*,BnetNetwork*,bdsOptions*,st_table*));
EXTERN DdNode** bdsStoreBDDInBddPoolLocal_ ARGS((DdManager*,BnetNetwork*,bdsOptions*,st_table*));

#endif /* _BDSPREPARE */







