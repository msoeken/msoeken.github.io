
/**CFile***********************************************************************

  FileName    [export.c]

  PackageName [BDS-pga]

  Synopsis    [Synthesis result presentation program]

  Description [This file contains the functions for writing FTrees to a BLIF
               file and a DOT file after FTree processing.]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#include "lopt.h"
#include <stdio.h>


/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

#define Fnode_PrintLiteral(fnode,complement) \
    ( (complement == 0) ? Fnode_Internal(fnode)?(Fnode_IsComplement(fnode)?'0':'1'):(Fnode_Negative(fnode)?'0':'1') : \
              Fnode_Internal(fnode)?(Fnode_IsComplement(fnode)?'1':'0'):(Fnode_Negative(fnode)?'1':'0') )


/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static int BDS_DumpFTree ARGS((BnetNetwork*,FactorTreeNode**,st_table*,char**,st_table*,bdsOptions*,int));
static int BDS_DumpFtreeDot ARGS((BnetNetwork*,FactorTreeNode**,st_table*,char**,bdsOptions*,int));
static int BDS_DumpFtreeBlif ARGS((BnetNetwork*,FactorTreeNode**,st_table*,char**,bdsOptions*,int,int)); ///pga added last 1
static int bdsDumpFtreeDot ARGS((BnetNetwork*,FactorTreeNode**,char**,FILE*));
static int bdsDumpFtreeDotlsList ARGS((BnetNetwork*,FactorTreeNode**,st_table*,char**,FILE*));
static int bdsDumpFtreeBlif ARGS((BnetNetwork*,FactorTreeNode**,char**,FILE*));
static int bdsDumpFtreeBliflsList ARGS((BnetNetwork*,FactorTreeNode**,st_table*,char**,FILE*));
static int bdsDumpFtreeBlifOneNode ARGS((FILE*,FactorTreeNode*,BnetNode*,char**,st_table*));
static int BDS_DumpSingleFTree ARGS((FILE*,FactorTreeNode*,st_table*,char**,int*,int));
static int BDS_DumpFTreeRecursive ARGS((FILE*,FactorTreeNode*,st_table*,char**,int*));
static int BDS_DumpFTreeRecursivelsList ARGS((FILE*,FactorTreeNode*,st_table*,char**,int*));
static int bdsPrintOneLiteral ARGS((FactorTreeNode*,FILE*,st_table*,char**));
static int bdsPrintOneOperator ARGS((FactorTreeNode*,FILE*));
static int bdsDumpFtreeBlifOneNodelsList ARGS((FILE*,FactorTreeNode*,BnetNode*,char**,st_table*));
static int bdsDumpFtreeBlifOneNodePrintVarNames ARGS((FILE*,FactorTreeNode*,BnetNode*,char**,st_table*));
static int bdsDumpFtreeBlifOneNodePrintFunction ARGS((FILE*,FactorTreeNode*));
static char ** bdsBuildOperatorString ARGS((int));


/**Function********************************************************************

  Synopsis    [Present synthesis results]

  Description [Synthesis results are presented as eqn form, dot format and BLIF format.
  Variable flag corresponds to different phase of ftree optimization, it is used to generate
  filenames corresponding to those phases. Return 1, success; 0 otherwise]

  SideEffects []

  SeeAlso     []

  LastDate    [2/26/99]

******************************************************************************/
extern
int
BDS_SynthesisPresentation(
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  char **PIvariables,
  st_table *sharingFnodeTbl,
  st_table *factorTreeNode2BnetNode,
  bdsOptions *option,
  int flag,
  int iteration) /* 0 - bds; 1 - sharing; 2 - collapse; 3 - final; 4 - delay*/ ///pga
{
  int result;
  ///=====a
  if(flag == 0) {
          result = BDS_DumpFtreeBlif(net,FTNode,factorTreeNode2BnetNode,PIvariables,option,flag,iteration);
          if (result == 0) return(0);
  }
  if(flag == 1) {
          result = BDS_DumpFtreeBlif(net,FTNode,factorTreeNode2BnetNode,PIvariables,option,flag,iteration);
          if (result == 0) return(0);
  }
  if(flag == 2) {
          result = BDS_DumpFtreeBlif(net,FTNode,factorTreeNode2BnetNode,PIvariables,option,flag,iteration);
          if (result == 0) return(0);
  }
  ///==a
  if (option->verb > BDS_VERBOSE_MOST || flag == 3) { /* Dump ftree before final processing */
      if (option->dumpftree) {
          result = BDS_DumpFTree(net,FTNode,factorTreeNode2BnetNode,PIvariables,sharingFnodeTbl,option,flag);
          if (result == 0) return(0);
      }
      if (option->dumpfdot) {
          result = BDS_DumpFtreeDot(net,FTNode,factorTreeNode2BnetNode,PIvariables,option,flag);
          if (result == 0) return(0);
      }
      if (option->dumpblif) {
          result = BDS_DumpFtreeBlif(net,FTNode,factorTreeNode2BnetNode,PIvariables,option,flag,iteration); ///pga added last 1
          if (result == 0) return(0);
      }
  }
///=====pga
  /*  if (flag == 4) {
    if (option->dumpblif) {
      result = BDS_DumpFtreeBlif(net,FTNode,factorTreeNode2BnetNode,PIvariables,option,flag,iteration);
      if (result == 0) return(0);
    }
  }
  */
 ///==pga
  return(1);

} /* end of BDS_SynthesisPresentation */

/**Function********************************************************************

  Synopsis    [Dump a factoring tree]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
int
BDS_DumpFTree(
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  st_table *factorTreeNode2BnetNode,
  char **PIvariables,
  st_table *sharingFnodeTbl,
  bdsOptions *option,
  int flag)
{
  FILE *dfp = NULL;
  BnetNode *bnode;
  int i,result;
  st_generator *gen = NULL;
  FactorTreeNode *fnode, **q;
  int totalLiteralCount = 0, litCount = 0;

  char *dumpfile, *dumpfile_name, *ckt_name;

  dumpfile_name = ALLOC(char, 100); /* file_name should not longer than 100 chars */

  /* Generate file_name as cktname.final(before ...).eqn */
  ckt_name = BDS_GetFileHead(option->file);
  strcpy(dumpfile_name, ckt_name);

  switch(flag) {
      case 0:
          strcat(dumpfile_name, ".bds.eqn");
          break;
      case 1:
          strcat(dumpfile_name, ".sharing.eqn");
          break;
      case 2:
          strcat(dumpfile_name, ".collapse.eqn");
          break;
      case 3:
          strcat(dumpfile_name, ".final.eqn");
          break;
      case 4: ///pga
      printf("Printing Delay File now\n"); ///pga
      break; ///pga
      default:
          printf("Unkown flag in BDS_SynthesisPresentation()");
          exit(2);
  }

  /* Put this file in the run dir */
  dumpfile = BDS_CreateFname(option, dumpfile_name);

  dfp = fopen(dumpfile,"w");
  if (dfp == NULL) fail("Can not open file to write !");

  fprintf(dfp,"#The file is generated by %s\n",BDS_VERSION);
  fprintf(dfp,"#\n");

  /* The dumping will stop at the shared nodes */
  for (q = FTNode; *q; q++) {
      if (!st_lookup(factorTreeNode2BnetNode, (char *) *q, (char **) &bnode)) {
          fail("Network error, can not find output !");
      }

      fprintf(dfp, "\nFactoring tree of output %s : \n", bnode->name);
      fprintf(dfp, "------------------------\n");
      result = BDS_DumpSingleFTree(dfp,*q,sharingFnodeTbl,PIvariables,&litCount,flag);
      if (result == 0) return(0);
      totalLiteralCount += litCount;
  }

  /* Dump DAG rooted at shared nodes */
  if (flag != 0) { /* After final processing which generates shared nodes */
      fprintf(dfp,"\n\nThe followings are shared nodes.\t");
      fprintf(dfp,"Number of shared nodes :  %d\n", st_count(sharingFnodeTbl));
      fprintf(dfp,"=======================================================================\n");
      gen = st_init_gen(sharingFnodeTbl);
      while (st_gen(gen, (char **) &fnode, NULL)) {
          fprintf(dfp,"\n");
          result = BDS_DumpSingleFTree(dfp,fnode,sharingFnodeTbl,PIvariables,&litCount,flag);
          if (result == 0) return(0);
          totalLiteralCount += litCount;
      }
      st_free_gen(gen);
  }

  fprintf(dfp,"\n=======================================================================\n");
  fprintf(dfp, "Total number of literals = %d\n", totalLiteralCount);

  /* Record literal count statistics */
  if (flag == 0)
      BDS_Stats(BDS_LIT_COUNT,NULL,totalLiteralCount,"before",NULL,NULL,NULL);
  else
      BDS_Stats(BDS_LIT_COUNT,NULL,totalLiteralCount,"after",NULL,NULL,NULL);

  if (fclose(dfp) == EOF) return(0);
  FREE(dumpfile); FREE(dumpfile_name); FREE(ckt_name);

  return(1);

} /* end of BDS_DumpFTree */

/**Function********************************************************************

  Synopsis    [Dump a factoring tree of one output]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

******************************************************************************/
static
int
BDS_DumpSingleFTree(
  FILE *dfp,
  FactorTreeNode *fnode,
  st_table *sharingFnodeTbl,
  char **PIvariables,
  int *litCount,
  int flag)
{
  int result;

  *litCount = 0;
  if (fnode->value != BDS_FTREE_INTERNAL) { /* Reach a terminal node, go back */
      fprintf(dfp, "top 0x%x  =  ", (unsigned) fnode);
      (*litCount)++;
      if (fnode->polarity == 0)
          fprintf(dfp, "(!%s)", PIvariables[Fnode_Regular(fnode)->value]);
      else
          fprintf(dfp, "( %s)", PIvariables[fnode->value]);

      result = fprintf(dfp,"\nNumber of literals = %d\n", *litCount);
      if (result == EOF) return (0);

      return(1);
  }

  if (flag == 0 || flag == 1) { /* traverse thru siblings */
      result = BDS_DumpFTreeRecursive(dfp,fnode,sharingFnodeTbl,PIvariables,litCount);
      if (result == 0) return(0);
  }
  else { /* traverse thru fanins */
      result = BDS_DumpFTreeRecursivelsList(dfp,fnode,sharingFnodeTbl,PIvariables,litCount);
      if (result == 0) return(0);
  }

  result = fprintf(dfp,"\nNumber of literals = %d\n", *litCount);
  if (result == EOF) return (0);

  return(1);

} /* BDS_DumpSingleFTree */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_DumpFTree]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

  Last date   [2/26/99]

******************************************************************************/
static
int
BDS_DumpFTreeRecursive(
  FILE *dfp,
  FactorTreeNode *fnode,
  st_table *sharingFnodeTbl,
  char **PIvariables,
  int *litCount)
{
  int result;
  FactorTreeNode *top, *dp, *dm, *ctl;

  /* Reach a termianl node OR it should have been printed */
  if (Fnode_Regular(fnode)->value != BDS_FTREE_INTERNAL) return(1);

  /* The node had been visited */
  if (Fnode_Regular(fnode)->visited != 0) return(1);

  top = Fnode_Regular(fnode);
  dp = top->siblings[0];
  dm = top->siblings[1];

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      ctl = top->siblings[2];
  }
#endif

  /* Print top node */
  if (top->polarity == 0)
      fprintf(dfp, "!0x%x  =  ", (unsigned) top);
  else
      fprintf(dfp, " 0x%x  =  ", (unsigned) top);

#ifdef PTL
  /* Print control if the fnode is a MUX, print as f */
  if (top->op == BDS_BDD_MUX) {
      if (Fnode_Regular(ctl)->value != BDS_FTREE_INTERNAL ||
            st_is_member(sharingFnodeTbl, (char *) Fnode_Regular(ctl))) {
      (*litCount)++;
      }
      result = bdsPrintOneLiteral(ctl, dfp, sharingFnodeTbl, PIvariables);
  }
#endif

  /* Print dp and do literal statistic */
  if (Fnode_Regular(dp)->value != BDS_FTREE_INTERNAL ||
            st_is_member(sharingFnodeTbl, (char *) Fnode_Regular(dp))) {
    (*litCount)++;
  }
  result = bdsPrintOneLiteral(dp, dfp, sharingFnodeTbl, PIvariables);

  /* Print operator on the fnode */
  result = bdsPrintOneOperator(top, dfp);

#ifdef PTL
  /* Print control if the fnode is a MUX, print as f' */
  if (top->op == BDS_BDD_MUX) {
      if (Fnode_Regular(ctl)->value != BDS_FTREE_INTERNAL ||
            st_is_member(sharingFnodeTbl, (char *) Fnode_Regular(ctl))) {
      (*litCount)++;
      }
      result = bdsPrintOneLiteral(Fnode_Flip(ctl), dfp, sharingFnodeTbl, PIvariables);
  }
#endif

  /* Print dm and do literal statistic */
  if (Fnode_Regular(dm)->value != BDS_FTREE_INTERNAL ||
            st_is_member(sharingFnodeTbl, (char *) Fnode_Regular(dm))) {
    (*litCount)++;
  }
  result = bdsPrintOneLiteral(dm, dfp, sharingFnodeTbl, PIvariables);

  /* new line */
  fprintf(dfp, "\n");

  /* Print out recursivly */
  if (Fnode_Regular(dp)->value == BDS_FTREE_INTERNAL &&
                !st_is_member(sharingFnodeTbl, (char *)Fnode_Regular(dp)))
      BDS_DumpFTreeRecursive(dfp,dp,sharingFnodeTbl,PIvariables,litCount);

  if (Fnode_Regular(dm)->value == BDS_FTREE_INTERNAL &&
                !st_is_member(sharingFnodeTbl, (char *)Fnode_Regular(dm)))
      BDS_DumpFTreeRecursive(dfp,dm,sharingFnodeTbl,PIvariables,litCount);

#ifdef PTL
  if (top->op == BDS_BDD_MUX && Fnode_Regular(ctl)->value == BDS_FTREE_INTERNAL &&
                !st_is_member(sharingFnodeTbl, (char *)Fnode_Regular(ctl)))
      BDS_DumpFTreeRecursive(dfp,ctl,sharingFnodeTbl,PIvariables,litCount);
#endif

  return(1);

} /* BDS_DumpFTreeRecursive */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_DumpFTree]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

  Last date   [2/26/99]

******************************************************************************/
static
int
BDS_DumpFTreeRecursivelsList(
  FILE *dfp,
  FactorTreeNode *fnode,
  st_table *sharingFnodeTbl,
  char **PIvariables,
  int *litCount)
{
  int result;
  FactorTreeNode *top, *sib, *ctl, *firstItem, *lastItem;
  lsGen fanin_list;
  lsList fanins;

  /* Reach a termianl node */
  if (Fnode_Regular(fnode)->value != BDS_FTREE_INTERNAL) return(1);

  top = Fnode_Regular(fnode);
  fanins = Fnode_Fanins(top);
  if (lsLastItem(fanins, (lsGeneric *)&lastItem, NULL) != LS_OK) {
      printf("lsList retrieve fails in BDS_DumpFTreeRecursivelsList()");
      exit(2);
  }

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      ctl = top->control;
      if (lsFirstItem(fanins, (lsGeneric *)&firstItem, NULL) != LS_OK) {
          printf("lsList retrieve fails in BDS_DumpFTreeRecursivelsList()");
      exit(2);
      }
  }
#endif

  /* Print top node */
  if (top->polarity == 0)
      fprintf(dfp, "!0x%x  =  ", (unsigned) top);
  else
      fprintf(dfp, " 0x%x  =  ", (unsigned) top);

  fanin_list = lsStart(fanins);
  while (lsNext(fanin_list, (lsGeneric *)&sib, NULL) != LS_NOMORE) {

#ifdef PTL
      /* Print control if the fnode is a MUX, print as f */
      if (top->op == BDS_BDD_MUX) {
          if (Fnode_Regular(ctl)->value != BDS_FTREE_INTERNAL ||
            st_is_member(sharingFnodeTbl, (char *) Fnode_Regular(ctl))) {
          (*litCount)++;
          }
      if (sib == firstItem) { /* print fg */
              result = bdsPrintOneLiteral(ctl, dfp, sharingFnodeTbl, PIvariables);
      }
      else { /* print f'h */
              result = bdsPrintOneLiteral(Fnode_Flip(ctl), dfp, sharingFnodeTbl, PIvariables);
      }
      }
#endif

      /* Print the first sib and do literal statistic */
      if (Fnode_Regular(sib)->value != BDS_FTREE_INTERNAL ||
            st_is_member(sharingFnodeTbl, (char *) Fnode_Regular(sib))) {
        (*litCount)++;
      }
      result = bdsPrintOneLiteral(sib, dfp, sharingFnodeTbl, PIvariables);

      /* Print operator on the fnode */
      if (sib != lastItem) {
          result = bdsPrintOneOperator(top, dfp);
      }

  }
  lsFinish(fanin_list);

  /* Print a new line, recursively traverse down to the bottom */
  fprintf(dfp, ";\n");

  fanin_list = lsStart(fanins);
  while (lsNext(fanin_list, (lsGeneric *)&sib, NULL) != LS_NOMORE) {

      if (Fnode_Regular(sib)->value == BDS_FTREE_INTERNAL &&
                !st_is_member(sharingFnodeTbl, (char *)Fnode_Regular(sib)))
          BDS_DumpFTreeRecursivelsList(dfp,sib,sharingFnodeTbl,PIvariables,litCount);
  }
  lsFinish(fanin_list);

#ifdef PTL
  if (top->op == BDS_BDD_MUX && Fnode_Regular(ctl)->value == BDS_FTREE_INTERNAL &&
                !st_is_member(sharingFnodeTbl, (char *)Fnode_Regular(ctl)))
      BDS_DumpFTreeRecursivelsList(dfp,ctl,sharingFnodeTbl,PIvariables,litCount);
#endif

  return(1);

} /* end of BDS_DumpFTreeRecursivelsList */

/**Function********************************************************************

  Synopsis    [Print one literal on the factoring tree]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
static
int
bdsPrintOneLiteral(
  FactorTreeNode *fnode,
  FILE *dfp,
  st_table *sharingFnodeTbl,
  char **PIvariables)
{
  FactorTreeNode *rnode;

  rnode = Fnode_Regular(fnode);

  if (rnode->value != BDS_FTREE_INTERNAL) { /* terminal */

      if ( (rnode->polarity == 0 && !Fnode_IsComplement(fnode)) ||
            (rnode->polarity == 1 && Fnode_IsComplement(fnode)) )
          fprintf(dfp, "(!%s)", PIvariables[rnode->value]);
      else
          fprintf(dfp, "( %s)", PIvariables[rnode->value]);
  }
  else if (st_is_member(sharingFnodeTbl, (char *) rnode)) { /* shared node */

      if (Fnode_IsComplement(fnode))
          fprintf(dfp, "!0x%x(shared)", (unsigned) rnode);
      else
          fprintf(dfp, " 0x%x(shared)", (unsigned) rnode);
  }
  else { /* normal internal node */
      if (Fnode_IsComplement(fnode))
          fprintf(dfp, "!0x%x", (unsigned) rnode);
      else
          fprintf(dfp, " 0x%x", (unsigned) rnode);
  }

  return(1);

} /* end of bdsPrintOneLiteral */

/**Function********************************************************************

  Synopsis    [Print the operator on a fnode]

  Description [* stands for AND;
           + stands for OR or MUX;
           ^ stands for XOR;
           @ stands for XNOR;
           Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

*****************************************************************************/
static
int
bdsPrintOneOperator(
  FactorTreeNode *rnode,
  FILE *dfp)
{
  switch(rnode->op) {
  case BDS_BDD_AND:
      fprintf(dfp, " * ");
      break;
  case BDS_BDD_OR:
  case BDS_BDD_MUX:
      fprintf(dfp, " + ");
      break;
  case BDS_BDD_XOR:
      fprintf(dfp, " ^ ");
      break;
  case BDS_BDD_XNOR:
      fprintf(dfp, " @ ");
      break;
  default:
      fail("Unknown decomposition type");
  }

  return(1);

} /* end of bdsPrintOneOperator */

/**Function********************************************************************

  Synopsis    [Dump the ftree in dot format]

  Description [A factoring tree is written in dot format. Dashed nodes and edges
  mean complementary. Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
static
int
BDS_DumpFtreeDot(
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  st_table *factorTreeNode2BnetNode,
  char **PIvariables,
  bdsOptions *option,
  int flag)
{
  FILE *dfp = NULL;
  BnetNode *POnode;
  int i,result;
  char *dumpfile, *dumpfile_name, *ckt_name;

  dumpfile_name = ALLOC(char, 100); /* file_name should not longer than 100 chars */

  /* Generate file_name as cktname.final(before ...).dot */
  ckt_name = BDS_GetFileHead(option->file);
  strcpy(dumpfile_name, ckt_name);

  switch(flag) {
      case 0:
          strcat(dumpfile_name, ".bds.dot");
          break;
      case 1:
          strcat(dumpfile_name, ".sharing.dot");
          break;
      case 2:
          strcat(dumpfile_name, ".collapse.dot");
          break;
      case 3:
          strcat(dumpfile_name, ".final.dot");
          break;
      case 4: ///pga
      printf("Printing delay file \n"); ///pga
      break; ///pga
      default:
          printf("Unkown flag in BDS_SynthesisPresentation()");
          exit(2);
  }

  /* Put this file in the run dir */
  dumpfile = BDS_CreateFname(option, dumpfile_name);

  dfp = fopen(dumpfile,"w");
  if (dfp == NULL) fail("Can not open file to write !");

  if (flag == 0 || flag == 1) { /* Traverse thru siblings */
      result = bdsDumpFtreeDot(net,FTNode,PIvariables,dfp);
      if (result == 0) return(0);
  }
  else {
      result = bdsDumpFtreeDotlsList(net,FTNode,factorTreeNode2BnetNode,PIvariables,dfp);
      if (result == 0) return(0);
  }

  if (fclose(dfp) == EOF) return(0);
  FREE(dumpfile); FREE(dumpfile_name); FREE(ckt_name);

  return(1);

} /* end of BDS_DumpFtreeDot */

/**Function********************************************************************

  Synopsis    [Dump the ftrees in dot format]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
static
int
bdsDumpFtreeDot(
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  char **PIvariables,
  FILE *fp)
{
  FactorTreeNode *fnode;
  st_table    *visited = NULL;
  st_generator *gen = NULL;
  int         result;
  int         i, j;

  BnetNode    *POnode;
  FactorTreeNode *top, *dp, *dm, *ctl;
  char *operator;

  /* Built operator char */
  operator = ALLOC(char,8);
  strcpy(operator, "z*+^@M");

  /* Initialize symbol table for visited nodes. */
  visited = st_init_table(st_ptrcmp, st_ptrhash);
  if (visited == NULL) return(0);

  /* Collect all the nodes on the ftrees */
  for (i = 0; i < net->npos; i++) {
      result = bdsCollectFNodes(visited,FTNode[i]);
      if (result == 0) return(0);
  }

  fprintf(fp,"// The file is generated by %s\n",BDS_VERSION);
  fprintf(fp,"//\n");

  /* Write header information */
  result = fprintf(fp,"digraph \"ftree\" {\n");
  if (result == EOF) return(0);
  result = fprintf(fp,
      "size = \"7.5,10\"\ncenter = true;\nedge [dir = none];\n");
  if (result == EOF) return(0);

  /* Write output fnodes */
  result = fprintf(fp,"{ rank = same; node [shape = box]; edge [style = invis];\n");
  if (result == EOF) return(0);
  for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash,net->outputs[i],(char **) &POnode)) {
      exit(2);
      }
      if (POnode->name == NULL) {
          result = fprintf(fp,"\"F%d\"", i);
      } else {
          result = fprintf(fp,"\"  %s  \"", POnode->name);
      }
      if (result == EOF) return(0);
      if (i == net->npos - 1) {
          result = fprintf(fp,"; }\n");
      } else {
          result = fprintf(fp," -> ");
      }
      if (result == EOF) return(0);
  }

  /* Write outputs -> ftree */
  for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash,net->outputs[i],(char **) &POnode)) {
      exit(2);
      }
      if (POnode->name == NULL) {
          result = fprintf(fp,"\"F%d\"", i);
      } else {
          result = fprintf(fp,"\"  %s  \"", POnode->name);
      }
      if (result == EOF) return(0);

      if (Fnode_IsComplement(FTNode[i])) {
          result = fprintf(fp," -> \"%lx\" [style = dashed];\n",
                ((long) FTNode[i]) / sizeof(FactorTreeNode));
      } else {
          result = fprintf(fp," -> \"%lx\" [style = solid];\n",
                ((long) FTNode[i]) / sizeof(FactorTreeNode));
      }
      if (result == EOF) return(0);
  }

  /* Write edges between internal fnodes */
  gen = st_init_gen(visited);
  if (gen == NULL) return(0);
  while (st_gen(gen, (char **) &fnode, NULL)) {
      top = Fnode_Regular(fnode);
      if (Fnode_Regular(fnode)->value != BDS_FTREE_INTERNAL) { /* A terminal */
      if (top->polarity == 0) {
          result = fprintf(fp,"\"%lx\" [shape = plaintext, label = \"!%s\"];\n",
            ((long) fnode) / sizeof(FactorTreeNode),
            PIvariables[top->value]);
      }
      else {
          result = fprintf(fp,"\"%lx\" [shape = plaintext, label = \"%s\"];\n",
            ((long) fnode) / sizeof(FactorTreeNode),
            PIvariables[top->value]);
      }
      if (result == EOF) return(0);

      continue;
      }

#ifdef DEBUG /* Print out both address and operator on each node */
      if (top->polarity == 0) {
      result = fprintf(fp,"\"%lx\" [style = dashed, \
        label = \"%x \\n%c\"];\n", ((long) fnode) / sizeof(FactorTreeNode),
         (unsigned) fnode,
        operator[top->op]);
      }
      else {
        result = fprintf(fp,"\"%lx\" [ \
        label = \"%x \\n%c\"];\n", ((long) fnode) / sizeof(FactorTreeNode),
        (unsigned) fnode,
        operator[top->op]);
      }

#else /* Only print operator on each node */

      if (top->polarity == 0) {
      result = fprintf(fp,"\"%lx\" [style = dashed, \
        label = \"%c\"];\n",
        ((long) fnode) / sizeof(FactorTreeNode),
        operator[top->op]);
      }
      else {
      result = fprintf(fp,"\"%lx\" [ \
        label = \"%c\"];\n",
        ((long) fnode) / sizeof(FactorTreeNode),
        operator[top->op]);
      }
#endif

      dp = fnode->siblings[0];
      dm = fnode->siblings[1];
      if (top->op == BDS_BDD_MUX) {
      ctl = fnode->siblings[2];
      }

      /* Print dp */
      if (Fnode_IsComplement(dp)) {
          result = fprintf(fp,
                "\"%lx\" -> \"%lx\" [style = dashed];\n",
                ((long) fnode) / sizeof(FactorTreeNode),
                ((long) dp) / sizeof(FactorTreeNode));
      } else {
          result = fprintf(fp,
                "\"%lx\" -> \"%lx\";\n",
                ((long) fnode) / sizeof(FactorTreeNode),
                ((long) dp) / sizeof(FactorTreeNode));
      }
      if (result == EOF) return(0);

      /* Print dm */
      if (Cudd_IsComplement(dm)) {
          result = fprintf(fp,
                "\"%lx\" -> \"%lx\" [style = dashed];\n",
                ((long) fnode) / sizeof(FactorTreeNode),
                ((long) dm) / sizeof(FactorTreeNode));
      } else {
          result = fprintf(fp,
                 "\"%lx\" -> \"%lx\";\n",
                 ((long) fnode) / sizeof(FactorTreeNode),
                 ((long) dm) / sizeof(FactorTreeNode));
      }
      if (result == EOF) return(0);

      /* Print ctl if MUX, control signal is marked by a black dot */
      if (top->op == BDS_BDD_MUX) {
          if (Cudd_IsComplement(ctl)) {
              result = fprintf(fp,
                    "\"%lx\" -> \"%lx\" [style = dashed, arrowhead = none, arrowtail = dot];\n",
                    ((long) fnode) / sizeof(FactorTreeNode),
                    ((long) ctl) / sizeof(FactorTreeNode));
          } else {
              result = fprintf(fp,
                     "\"%lx\" -> \"%lx\" [arrowhead = none, arrowtail = dot];\n",
                     ((long) fnode) / sizeof(FactorTreeNode),
                     ((long) ctl) / sizeof(FactorTreeNode));
          }
      }
      if (result == EOF) return(0);

  } /* end of while loop */

  st_free_gen(gen); gen = NULL;

  /* Write trailer and return. */
  result = fprintf(fp,"}\n");
  if (result == EOF) return(0);

  st_free_table(visited);
  FREE(operator);

  return(1);

} /* end of bdsDumpFtreeDot */

/**Function********************************************************************

  Synopsis    [Dump the ftrees in dot format]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  LastDate    [2/26/99]

*****************************************************************************/
static
int
bdsDumpFtreeDotlsList(
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  st_table *factorTreeNode2BnetNode,
  char **PIvariables,
  FILE *fp)
{
  FactorTreeNode *fnode, **q;
  st_table *visited = NULL;
  st_generator *gen = NULL;
  int result;
  int i, j, numFTreeNode = 0;
  lsGen fanin_list;
  lsList fanins;
  BnetNode *bnode;
  FactorTreeNode *top, *sib, *ctl;
  char **operator;

  /* Built operator string */
  operator = bdsBuildOperatorString(BDS_NUMBER_OPERATOR);

  /* Initialize symbol table for visited nodes. */
  visited = st_init_table(st_ptrcmp, st_ptrhash);
  if (visited == NULL) return(0);

  /* Collect all the nodes on the ftrees */
  for (q = FTNode; *q; q++) {
      result = bdsCollectFNodeslsList(visited,*q);
      if (result == 0) return(0);
      numFTreeNode++;
  }

  fprintf(fp,"// The file is generated by %s\n",BDS_VERSION);
  fprintf(fp,"//\n");

  /* Write header information */
  result = fprintf(fp,"digraph \"ftree\" {\n");
  if (result == EOF) return(0);
  result = fprintf(fp,
      "size = \"7.5,10\"\ncenter = true;\nedge [dir = none];\n");
  if (result == EOF) return(0);

  /* Write output fnodes */
  result = fprintf(fp,"{ rank = same; node [shape = box]; edge [style = invis];\n");
  if (result == EOF) return(0);
  i = 0;
  for (q = FTNode; *q; q++) {
      if (!st_lookup(factorTreeNode2BnetNode, (char *) *q, (char **) &bnode)) {
      exit(2);
      }
      if (bnode->name == NULL) {
          result = fprintf(fp,"\"F%d\"", i);
      } else {
          result = fprintf(fp,"\"  %s  \"", bnode->name);
      }
      if (result == EOF) return(0);
      if (i == numFTreeNode - 1) {
          result = fprintf(fp,"; }\n");
      } else {
          result = fprintf(fp," -> ");
      }
      if (result == EOF) return(0);
      i++;
  }

  /* Write outputs -> ftree */
  for (q = FTNode; *q; q++) {
      if (!st_lookup(factorTreeNode2BnetNode, (char *) *q, (char **) &bnode)) {
      exit(2);
      }
      if (bnode->name == NULL) {
          result = fprintf(fp,"\"F%d\"", i);
      } else {
          result = fprintf(fp,"\"  %s  \"", bnode->name);
      }
      if (result == EOF) return(0);

      if (Fnode_IsComplement(*q)) {
          result = fprintf(fp," -> \"%lx\" [style = dashed];\n",
                ((long) *q) / sizeof(FactorTreeNode));
      } else {
          result = fprintf(fp," -> \"%lx\" [style = solid];\n",
                ((long) *q) / sizeof(FactorTreeNode));
      }
      if (result == EOF) return(0);
  }

  /* Write edges between internal fnodes */
  gen = st_init_gen(visited);
  if (gen == NULL) return(0);
  while (st_gen(gen, (char **) &fnode, NULL)) {
      top = Fnode_Regular(fnode);
      if (Fnode_Regular(fnode)->value != BDS_FTREE_INTERNAL) { /* A terminal */
      if (top->polarity == 0) {
          result = fprintf(fp,"\"%lx\" [shape = plaintext, label = \"!%s\"];\n",
            ((long) fnode) / sizeof(FactorTreeNode),
            PIvariables[top->value]);
      }
      else {
          result = fprintf(fp,"\"%lx\" [shape = plaintext, label = \"%s\"];\n",
            ((long) fnode) / sizeof(FactorTreeNode),
            PIvariables[top->value]);
      }
      if (result == EOF) return(0);

      continue;
      }

#ifdef DEBUG /* Print out both address and operator on each node */
      if (top->polarity == 0) {
      result = fprintf(fp,"\"%lx\" [style = dashed, \
        label = \"%x \\n%s\"];\n", ((long) fnode) / sizeof(FactorTreeNode),
         (unsigned) fnode, operator[top->op]);
      }
      else {
        result = fprintf(fp,"\"%lx\" [ \
        label = \"%x \\n%s\"];\n", ((long) fnode) / sizeof(FactorTreeNode),
        (unsigned) fnode, operator[top->op]);
      }

#else /* Only print operator on each node */

      if (top->polarity == 0) {
      result = fprintf(fp,"\"%lx\" [style = dashed, \
        label = \"%s\"];\n", ((long) fnode) / sizeof(FactorTreeNode),
        operator[top->op]);
      }
      else {
      result = fprintf(fp,"\"%lx\" [ \
        label = \"%s\"];\n", ((long) fnode) / sizeof(FactorTreeNode),
        operator[top->op]);
      }
#endif

      fanins = Fnode_Fanins(top);
      fanin_list = lsStart(fanins);
      while (lsNext(fanin_list, (lsGeneric *)&sib, NULL) != LS_NOMORE) {

          if (Fnode_IsComplement(sib)) {
              result = fprintf(fp,
                    "\"%lx\" -> \"%lx\" [style = dashed];\n",
                    ((long) fnode) / sizeof(FactorTreeNode),
                    ((long) sib) / sizeof(FactorTreeNode));
          } else {
              result = fprintf(fp,
                    "\"%lx\" -> \"%lx\";\n",
                    ((long) fnode) / sizeof(FactorTreeNode),
                    ((long) sib) / sizeof(FactorTreeNode));
          }
          if (result == EOF) return(0);
      }
      lsFinish(fanin_list);

#ifdef PTL
      /* Print ctl if MUX, control signal is marked by a black dot */
      if (top->op == BDS_BDD_MUX) {
      ctl = fnode->control;
          if (Cudd_IsComplement(ctl)) {
              result = fprintf(fp,
                    "\"%lx\" -> \"%lx\" [style = dashed, arrowhead = none, arrowtail = dot];\n",
                    ((long) fnode) / sizeof(FactorTreeNode),
                    ((long) ctl) / sizeof(FactorTreeNode));
          } else {
              result = fprintf(fp,
                     "\"%lx\" -> \"%lx\" [arrowhead = none, arrowtail = dot];\n",
                     ((long) fnode) / sizeof(FactorTreeNode),
                     ((long) ctl) / sizeof(FactorTreeNode));
          }
      }
      if (result == EOF) return(0);
#endif

  } /* end of while loop */

  st_free_gen(gen); gen = NULL;

  /* Write trailer and return. */
  result = fprintf(fp,"}\n");
  if (result == EOF) return(0);

  st_free_table(visited);
  for (i = 1; i < BDS_NUMBER_OPERATOR; i++) {
      FREE(operator[i]);
  }
  FREE(operator);

  return(1);

} /* end of bdsDumpFtreeDotlsList */

/**Function********************************************************************

  Synopsis    [Dump the ftree in BLIF format]

  Description [A factoring tree is written in BLIF format. Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  Last date   [1/12/99]

*****************************************************************************/
static
int
BDS_DumpFtreeBlif(
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  st_table *factorTreeNode2BnetNode,
  char **PIvariables,
  bdsOptions *option,
  int flag,
  int iteration) ///pga
{
  FILE *dfp = NULL;
  int result;
  char *dumpfile, *dumpfile_name, *ckt_name, *new_filename; ///pga added last 1

  dumpfile_name = ALLOC(char, 100); /* file_name should not longer than 100 chars */

  new_filename = ALLOC(char, 100); ///pga

  /* Generate file_name as cktname.final(before ...).blif */
  ckt_name = BDS_GetFileHead(option->file);
  strcpy(dumpfile_name, ckt_name);

    switch(flag) {
      case 0:
          strcat(dumpfile_name, ".bds.blif");
      break;
      case 1:
          strcat(dumpfile_name, ".sharing.blif");
      break;
      case 2:
          strcat(dumpfile_name, ".collapse.blif");
      break;
      case 3:
          strcat(dumpfile_name, ".final.blif");
      break;
    case 4: ///pga
          printf("Printing delay file \n"); ///pga
      break; ///pga
      default:
      printf("Unkown flag in BDS_SynthesisPresentation()");
      exit(2);
  }


  /* Put this file in the run dir */
  dumpfile = BDS_CreateFname(option, dumpfile_name);

 ///=====pga
  /*  if ((option->delay == TRUE) && (iteration == 0)) {
    strcpy(new_filename, ckt_name);
    strcat(new_filename, ".blif.delay");
    }*/
 ///==pga
  dfp = fopen(dumpfile,"w");
  if (dfp == NULL) fail("Can not open file to write !");
 ///=====pga
  /* if ((option->delay == TRUE) && (iteration == 0)) {
    fclose(dfp);
    dfp = fopen(new_filename, "w");
    if (dfp == NULL) fail("Cannot open file to write!");
    printf("MATHERCHUD %i\n",iteration);
    }*/
 ///==pga
  if (flag == 0 || flag == 1) { /* Traverse thru siblings */
    result = bdsDumpFtreeBlif(net,FTNode,PIvariables,dfp);
    if (result == 0) return(0);
  }
  else { /* Traverse thru fanins */
    result = bdsDumpFtreeBliflsList(net,FTNode,factorTreeNode2BnetNode,PIvariables,dfp);
    if (result == 0) return(0);
  }

  if (fclose(dfp) == EOF) return(0);
  FREE(dumpfile); FREE(dumpfile_name); FREE(ckt_name);
  FREE(new_filename); ///pga
  return(1);

} /* end of BDS_DumpFtreeBlif */

/**Function*****************************************************************

Synopsis   [Update the BnetNetwork structure using the Fnode data]

Description [After all Ftree processing has been completed, the updated Boolean
        network will be reflected in the BnetNetwork data structure.  This
        structure contains the network information and needs to be updated]

*****************************************************************************/

extern
int
BDS_UpdateNetwork(
BnetNetwork *net,
FactorTreeNode **fnode,
st_table *factorTreeNode2BnetNode,
st_table *sharingFnodeTbl)
{
  int i,result;
  BnetNode *node;
  FactorTreeNode *f_node, *q;
  st_table *visited = NULL;

  /*********
         Initially collect all new information about the network from the
         fnode variable
  **********/

  /* Initialize symbol table for visited nodes. */
  visited = st_init_table(st_ptrcmp, st_ptrhash);
  if (visited == NULL) return(0);

  /* Collect all the nodes on the ftrees
  for (i = 0; i < net->npos; i++) {
    result = bdsCollectFNodes(visited,fnode[i]);
    if (result == 0) return(0);
  }
  */

/* The dumping will stop at the shared nodes
  for (q = fnode; *q; q++) {
      if (!st_lookup(factorTreeNode2BnetNode, (char *) *q, (char **) &node)) {
          fail("Network error, can not find output !");
      }

      result = BDS_DumpSingleFTree(dfp,*q,sharingFnodeTbl,PIvariables,&litCount,flag);
      if (result == 0) return(0);
  }
*/
  /* Dump DAG rooted at shared nodes */
  /*  if (flag != 0) { After final processing which generates shared nodes
      fprintf(dfp,"\n\nThe followings are shared nodes.\t");
      fprintf(dfp,"Number of shared nodes :  %d\n", st_count(sharingFnodeTbl));

      gen = st_init_gen(sharingFnodeTbl);
      while (st_gen(gen, (char **) &fnode, NULL)) {
    result = BDS_DumpSingleFTree(dfp,fnode,sharingFnodeTbl,PIvariables,&litCount,flag);
          if (result == 0) return(0);
          totalLiteralCount += litCount;
      }
      st_free_gen(gen);
      }*/

}



/**Function********************************************************************

  Synopsis    [Dump the ftrees in blif format]

  Description [This function will be removed after all intermediate results are stored
  in fanins instead of siblings. Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  Last date   [1/12/99]

*****************************************************************************/
static
int
bdsDumpFtreeBlif(
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  char **PIvariables,
  FILE *fp)
{
  FactorTreeNode *fnode;
  st_table       *visited, *ponodes;
  st_generator   *gen = NULL;
  int            result;
  int            i, j;
  char           *model_name, *bds = "BDS.";
  BnetNode       *POnode;
  FactorTreeNode *top, *dp, *dm, *ctl;

  /* Initialize symbol table for visited nodes. */
  visited = st_init_table(st_ptrcmp, st_ptrhash);
  if (visited == NULL) return(0);

  /* Record of dumped nodes */
  ponodes = st_init_table(st_ptrcmp, st_ptrhash);
  if (ponodes == NULL) return(0);

  /* Collect all the nodes on the ftrees */
  for (i = 0; i < net->npos; i++) {
      result = bdsCollectFNodes(visited,FTNode[i]);
      if (result == 0) return(0);
  }

  result = fprintf(fp,"# The file is generated by %s\n",BDS_VERSION);
  if (result == EOF) return(0);
  result = fprintf(fp,"#\n");
  if (result == EOF) return(0);

  model_name = ALLOC(char, 50); /* model name should not longer than 50 chars */

  /* Write header information */
  strcpy(model_name, bds);
  strcat(model_name, net->name);
  result = fprintf(fp, ".model %s\n", model_name);
  if (result == EOF) return(0);
  FREE(model_name);

  /* Write the inputs & outputs list by scanning the list in blif file */
  result = fprintf(fp, ".inputs ");
  if (result == EOF) return(0);
  for (i = 0; i < net->npis; i++) {
      result = fprintf(fp, "%s ", net->inputs[i]);
      if (result == EOF) return(0);
  }
  result = fprintf(fp,"\n");
  if (result == EOF) return(0);
  result = fprintf(fp,".outputs ");
  if (result == EOF) return(0);
  for (i = 0; i < net->npos; i++) {
      result = fprintf(fp, "%s ", net->outputs[i]);
      if (result == EOF) return(0);
  }
  result = fprintf(fp, "\n");
  if (result == EOF) return(0);

  /* Collect all pos, some internal nodes may use them as inputs */
  for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash,net->outputs[i],(char **) &POnode)) {
      exit(2);
      }
      if (st_add_direct(ponodes, (char *)FTNode[i], (char *) POnode) == ST_OUT_OF_MEM) {
      printf("Out of memeory !\n");
      return(0);
      }
  }

  /* Write outputs -> ftree first, this will put pos in the beginning of BLIF file */
  for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash,net->outputs[i],(char **) &POnode)) {
      exit(2);
      }
      result = bdsDumpFtreeBlifOneNode(fp, FTNode[i], POnode, PIvariables, ponodes);
      if (result == 0) return(0);
  }

  /* Write all other internal nodes */
  gen = st_init_gen(visited);
  if (gen == NULL) return(0);
  while (st_gen(gen, (char **) &fnode, NULL)) {

      /* Skip POs, they have been dumped */
      if (st_is_member(ponodes, (char *) fnode) == 1) { /* PO node */
      continue;
      }
      /* Skip terminal nodes */
      if (Fnode_Regular(fnode)->value != BDS_FTREE_INTERNAL) {
      continue;
      }

      result = bdsDumpFtreeBlifOneNode(fp, fnode, NULL, PIvariables, ponodes);
      if (result == 0) return(0);
  }

  /* write end */
  result = fprintf(fp, ".end\n");
  if (result == EOF) return(0);

  st_free_gen(gen);
  st_free_table(visited);
  st_free_table(ponodes);

  return(1);

} /* end of bdsDumpFtreeBlif */

/**Function********************************************************************

  Synopsis    [Dump one node in BLIF format]

  Description [All fnodes provided for this function are internal nodes, except that
  the po node is a terminal, all other terminal nodes had been screened out. In case
  of MUXes, the first name is f, second is g and third is h.]

  SideEffects [None]

  SeeAlso     []

  Last date   [1/12/99]

*****************************************************************************/

static
int
bdsDumpFtreeBlifOneNode(
  FILE *fp,
  FactorTreeNode *fnode,
  BnetNode *POnode,
  char **PIvariables,
  st_table *ponodes)
{
  int result;
  FactorTreeNode *top, *dp, *dm, *ctl;
  BnetNode *po;

  top = Fnode_Regular(fnode);
  dp = top->siblings[0];
  dm = top->siblings[1];
  if (top->op == BDS_BDD_MUX) {
      ctl = top->siblings[2];
  }

  /* Screen out the possibility that po node is a terminal */
  if (top->value != BDS_FTREE_INTERNAL && POnode != NULL) {
      result = fprintf(fp,".names ");
      if (result == EOF) return(0);
      result = fprintf(fp,"%s %s\n",PIvariables[top->value],POnode->name);
      if (result == EOF) return(0);
      result = fprintf(fp,"%c 1\n",(top->polarity)?'0':'1'); ///
      if (result == EOF) return(0);

      return(1);
  }

  /* print variable names */
  result = fprintf(fp, ".names ");

#ifdef PTL
  /* Print name corresponding to f in MUX */
  if (top->op == BDS_BDD_MUX) { /* a MUX node */
      if (Fnode_Regular(ctl)->value == BDS_FTREE_INTERNAL) { /* internal node */
          if (!st_lookup(ponodes, (char *) Fnode_Regular(ctl), (char **) &po)) {
              result = fprintf(fp,"0x%x ",(unsigned) Fnode_Regular(ctl));
              if (result == EOF) return(0);
          }
          else {
              result = fprintf(fp,"%s ",po->name);
              if (result == EOF) return(0);
          }
      }
      else { /* terminal node, print pi name */
          result = fprintf(fp,"%s ",PIvariables[Fnode_Regular(ctl)->value]);
          if (result == EOF) return(0);
      }
  }
#endif

  /* Print name corresponding to dp */
  if (Fnode_Regular(dp)->value == BDS_FTREE_INTERNAL) { /* internal node */
      if (!st_lookup(ponodes, (char *) Fnode_Regular(dp), (char **) &po)) {
          result = fprintf(fp,"0x%x ",(unsigned) Fnode_Regular(dp));
          if (result == EOF) return(0);
      }
      else {
          result = fprintf(fp,"%s ",po->name);
          if (result == EOF) return(0);
      }
  }
  else { /* terminal node, print pi name */
      result = fprintf(fp,"%s ",PIvariables[Fnode_Regular(dp)->value]);
      if (result == EOF) return(0);
  }

  /* Print name corresponding to dm */
  if (Fnode_Regular(dm)->value == BDS_FTREE_INTERNAL) { /* internal node */
      if (!st_lookup(ponodes, (char *) Fnode_Regular(dm), (char **) &po)) {
          result = fprintf(fp,"0x%x ",(unsigned) Fnode_Regular(dm));
          if (result == EOF) return(0);
      }
      else {
          result = fprintf(fp,"%s ",po->name);
          if (result == EOF) return(0);
      }
  }
  else { /* terminal node, print pi name */
      result = fprintf(fp,"%s ",PIvariables[Fnode_Regular(dm)->value]);
      if (result == EOF) return(0);
  }

  /* Print node function name */
  if (POnode == NULL) { /* internal node */
      result = fprintf(fp,"0x%x\n",(unsigned) top);
      if (result == EOF) return(0);
  }
  else { /* po node, print its name */
      result = fprintf(fp,"%s\n",POnode->name);
      if (result == EOF) return(0);
  }

  /* print functionality of this node */
  switch(top->op) {
  case BDS_BDD_AND:
      result = fprintf(fp,"%c%c %c\n",\
               Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'),\
               Fnode_Negative(top)?'0':'1');
      if (result == EOF) return(0);
      break;
  case BDS_BDD_OR:
      if (Fnode_Negative(top)) { /* (a+b)' = a'b' */
          result = fprintf(fp,"%c%c 1\n",\
               Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'),\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
      }
      else { /* a + b */
          result = fprintf(fp,"%c- 1\n",\
           Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'));;
          if (result == EOF) return(0);
          result = fprintf(fp,"-%c 1\n",\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
      }
      break;
  case BDS_BDD_XOR:
      if (Fnode_Negative(top)) { /* (a'b+ab')' = ab + a'b' */
          result = fprintf(fp,"%c%c 1\n",\
               Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c%c 1\n",\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      else { /* a'b + ab' */
      result = fprintf(fp,"%c%c 1\n",\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'),\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
      result = fprintf(fp,"%c%c 1\n",\
           Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      break;
  case BDS_BDD_XNOR:
      if (Fnode_Negative(top)) { /* (ab + a'b')' = a'b + ab' */
      result = fprintf(fp,"%c%c 1\n",\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'),\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
      result = fprintf(fp,"%c%c 1\n",\
               Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      else { /* ab + a'b' */
          result = fprintf(fp,"%c%c 1\n",\
               Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'),\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c%c 1\n",\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      break;
  case BDS_BDD_MUX:
      if (Fnode_Negative(top)) { /* (fg + f'h)' = fg' + f'h' */
          result = fprintf(fp,"%c%c- 1\n",\
           Fnode_Internal(ctl)?(Fnode_IsComplement(ctl)?'0':'1'):(Fnode_Negative(ctl)?'0':'1'),\
                   Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'1':'0'):(Fnode_Negative(dp)?'1':'0'));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c-%c 1\n",\
                   Fnode_Internal(ctl)?(Fnode_IsComplement(ctl)?'1':'0'):(Fnode_Negative(ctl)?'1':'0'),\
               Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'1':'0'):(Fnode_Negative(dm)?'1':'0'));
          if (result == EOF) return(0);
      }
      else { /* fg + f'h */
          result = fprintf(fp,"%c%c- 1\n",\
           Fnode_Internal(ctl)?(Fnode_IsComplement(ctl)?'0':'1'):(Fnode_Negative(ctl)?'0':'1'),\
           Fnode_Internal(dp)?(Fnode_IsComplement(dp)?'0':'1'):(Fnode_Negative(dp)?'0':'1'));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c-%c 1\n",\
                   Fnode_Internal(ctl)?(Fnode_IsComplement(ctl)?'1':'0'):(Fnode_Negative(ctl)?'1':'0'),\
           Fnode_Internal(dm)?(Fnode_IsComplement(dm)?'0':'1'):(Fnode_Negative(dm)?'0':'1'));
          if (result == EOF) return(0);
      }
      break;
  default:
      fail("Unknown decomposition type");
  }

  return(1);

} /* end of bdsDumpFtreeBlifOneNode */

/**Function********************************************************************

  Synopsis    [Dump the ftrees in blif format]

  Description [Return 1 if successful; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  Last date   [2/26/99]

*****************************************************************************/
static
int
bdsDumpFtreeBliflsList(
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  st_table *factorTreeNode2BnetNode,
  char **PIvariables,
  FILE *fp)
{
  FactorTreeNode *fnode, **q;
  st_table       *visited;
  st_generator   *gen = NULL;
  int            result;
  int            i, j;
  char           *model_name, *bds = "BDS.";
  BnetNode       *bnode;
  FactorTreeNode *top, *dp, *dm, *ctl;

  /* Initialize symbol table for visited nodes. */
  visited = st_init_table(st_ptrcmp, st_ptrhash);
  if (visited == NULL) return(0);

  /* Collect all the nodes on the ftrees */
  for (q = FTNode; *q; q++) {
      result = bdsCollectFNodeslsList(visited,*q);
      if (result == 0) return(0);
  }

  result = fprintf(fp,"# The file is generated by %s\n",BDS_VERSION);
  if (result == EOF) return(0);
  result = fprintf(fp,"#\n");
  if (result == EOF) return(0);

  model_name = ALLOC(char, 50); /* model name should not longer than 50 chars */

  /* Write header information */
  strcpy(model_name, bds);
  strcat(model_name, net->name);
  result = fprintf(fp, ".model %s\n", model_name);
  if (result == EOF) return(0);
  FREE(model_name);

  /* Write the inputs & outputs list by scanning the list in blif file */
  result = fprintf(fp, ".inputs ");
  if (result == EOF) return(0);
  for (i = 0; i < net->npis; i++) {
      result = fprintf(fp, "%s ", net->inputs[i]);
      if (result == EOF) return(0);
  }
  result = fprintf(fp,"\n");
  if (result == EOF) return(0);
  result = fprintf(fp,".outputs ");
  if (result == EOF) return(0);
  for (i = 0; i < net->npos; i++) {
      result = fprintf(fp, "%s ", net->outputs[i]);
      if (result == EOF) return(0);
  }
  result = fprintf(fp, "\n");
  if (result == EOF) return(0);

  /* Write outputs -> ftree first, this will put pos in the beginning of BLIF file */
  for (q = FTNode; *q; q++) {
      if (!st_lookup(factorTreeNode2BnetNode, (char *) *q, (char **) &bnode)) {
      exit(2);
      }
      result = bdsDumpFtreeBlifOneNodelsList(fp,*q,bnode,PIvariables,factorTreeNode2BnetNode);
      if (result == 0) return(0);
  }

  /* Write all other internal nodes */
  gen = st_init_gen(visited);
  if (gen == NULL) return(0);
  while (st_gen(gen, (char **) &fnode, NULL)) {

      /* Skip POs, they have been dumped */
      if (st_is_member(factorTreeNode2BnetNode, (char *) fnode) == 1) { /* PO node */
      continue;
      }
      /* Skip terminal nodes */
      if (Fnode_Regular(fnode)->value != BDS_FTREE_INTERNAL) {
      continue;
      }

      result = bdsDumpFtreeBlifOneNodelsList(fp,fnode,NULL,PIvariables,factorTreeNode2BnetNode);
      if (result == 0) return(0);
  }

  /* write end */
  result = fprintf(fp, ".end\n");
  if (result == EOF) return(0);

  st_free_gen(gen);
  st_free_table(visited);

  return(1);

} /* end of bdsDumpFtreeBliflsList */

/**Function********************************************************************

  Synopsis    [Dump one node in BLIF format]

  Description [All fnode provided for this function are internal nodes, except that the
  po node is a terminal, all other terminal nodes had been screened out. In case of MUX,
  the first name is f, second is g and third is h.]

  SideEffects [None]

  SeeAlso     []

  Last date   [2/26/99]

*****************************************************************************/
static
int
bdsDumpFtreeBlifOneNodelsList(
  FILE *fp,
  FactorTreeNode *fnode,
  BnetNode *POnode,
  char **PIvariables,
  st_table *ponodes)
{
  int result;
  FactorTreeNode *top;

  top = Fnode_Regular(fnode);

  /* Screen out the possibility that po node is a terminal */
  if (top->value != BDS_FTREE_INTERNAL && POnode != NULL) {
      result = fprintf(fp,".names ");
      if (result == EOF) return(0);
      result = fprintf(fp,"%s %s\n",PIvariables[top->value],POnode->name);
      if (result == EOF) return(0);
      result = fprintf(fp,"%c 1\n",(top->polarity)?'1':'0');///change 0 and 1 positions
      if (result == EOF) return(0);

      return(1);
  }

  /* print variable names */
  result = bdsDumpFtreeBlifOneNodePrintVarNames(fp,top,POnode,PIvariables,ponodes);
  if (result == 0) return(0);

  /* print functionality */
  result = bdsDumpFtreeBlifOneNodePrintFunction(fp,top);

  return(result);

} /* end of bdsDumpFtreeBlifOneNodelsList */

/**Function********************************************************************

  Synopsis    [Print out the support of this fnode]

  Description [In cases like, (a+b)' and (fg+f'h)', instead of printing a'b' and
  fg'+f'h', inverters are inserted to keep their original forms. Dummy variables
  are introduced by alloc new FactorTreeNode. The memory allocated for them are
  leaked. Return 1 if successful, 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  Last date   [2/28/99]

*****************************************************************************/
static
int
bdsDumpFtreeBlifOneNodePrintVarNames(
  FILE *fp,
  FactorTreeNode *top,
  BnetNode *POnode,
  char **PIvariables,
  st_table *ponodes)
{
  int result;
  FactorTreeNode *sib, *ctl, *inverter;
  BnetNode *po;
  lsList fanins;
  lsGen fanin_list;

  fanins = Fnode_Fanins(top);

  /* In case of (a+b)' and (fg+f'h)', insert an inverter */
  if (Fnode_Operator(top) == BDS_BDD_OR && Fnode_Negative(top) ||
               Fnode_Operator(top) == BDS_BDD_MUX && Fnode_Negative(top)) {
      inverter = ALLOC(FactorTreeNode, 1);

      result = fprintf(fp, ".names ");
      if (result == EOF) return(0);

      /* Print intermediate name */
      result = fprintf(fp,"0x%x ",(unsigned) inverter);
      if (result == EOF) return(0);

      /* Print functional node's name */
      if (POnode == NULL) { /* internal node */
          result = fprintf(fp,"0x%x\n",(unsigned) top);
          if (result == EOF) return(0);
      }
      else { /* PO node, print its name */
          result = fprintf(fp,"%s\n",POnode->name);
          if (result == EOF) return(0);
      }

      /* Print inverter's functionality */
      result = fprintf(fp,"0 1\n");
      if (result == EOF) return(0);
  }

  /* Print names under normal conditions */
  result = fprintf(fp, ".names ");
  if (result == EOF) return(0);

#ifdef PTL
  /* Print name corresponding to f in MUX */
  if (top->op == BDS_BDD_MUX) { /* a MUX node */
      ctl = top->control;
      if (Fnode_Regular(ctl)->value == BDS_FTREE_INTERNAL) { /* internal node */
          if (!st_lookup(ponodes, (char *) Fnode_Regular(ctl), (char **) &po)) {
              result = fprintf(fp,"0x%x ",(unsigned) Fnode_Regular(ctl));
              if (result == EOF) return(0);
          }
          else {
              result = fprintf(fp,"%s ",po->name);
              if (result == EOF) return(0);
          }
      }
      else { /* terminal node, print pi name */
          result = fprintf(fp,"%s ",PIvariables[Fnode_Regular(ctl)->value]);
          if (result == EOF) return(0);
      }
  }
#endif

  /* Print support names on this fnode */
  fanin_list = lsStart(fanins);
  while (lsNext(fanin_list, (lsGeneric *)&sib, NULL) != LS_NOMORE) {

      if (Fnode_Regular(sib)->value == BDS_FTREE_INTERNAL) { /* internal node */
          if (!st_lookup(ponodes, (char *) Fnode_Regular(sib), (char **) &po)) {
              result = fprintf(fp,"0x%x ",(unsigned) Fnode_Regular(sib));
              if (result == EOF) return(0);
          }
          else {
              result = fprintf(fp,"%s ",po->name);
              if (result == EOF) return(0);
          }
      }
      else { /* terminal node, print pi name */
          result = fprintf(fp,"%s ",PIvariables[Fnode_Regular(sib)->value]);
          if (result == EOF) return(0);
      }
  }
  lsFinish(fanin_list);

  /* Print functional node's name. In case of (a+b)' and (fg+f'h)', print newly
     allocated inverter pointer instead
  */
  if (Fnode_Operator(top) == BDS_BDD_OR && Fnode_Negative(top) ||
               Fnode_Operator(top) == BDS_BDD_MUX && Fnode_Negative(top)) {

      result = fprintf(fp,"0x%x\n",(unsigned) inverter);
      if (result == EOF) return(0);
  }
  else {
      if (POnode == NULL) { /* internal node */
          result = fprintf(fp,"0x%x\n",(unsigned) top);
          if (result == EOF) return(0);
      }
      else { /* PO node, print its name */
          result = fprintf(fp,"%s\n",POnode->name);
          if (result == EOF) return(0);
      }
  }

  return(1);

} /* end of bdsDumpFtreeBlifOneNodePrintVarNames */

/**Function********************************************************************

  Synopsis    [Print out the function of this fnode]

  Description [Return 1 if successful, 0 otherwise]

  SideEffects [None]

  SeeAlso     []

  Last date   [2/28/99]

*****************************************************************************/
static
int
bdsDumpFtreeBlifOneNodePrintFunction(
  FILE *fp,
  FactorTreeNode *top)
{
  int result, i, j, num_fanins;
  FactorTreeNode *sib, *ctl, *inverter;
  FactorTreeNode *firstItem, *lastItem;
  BnetNode *po;
  lsList fanins;
  lsGen fanin_list;

  fanins = Fnode_Fanins(top);
  num_fanins = lsLength(fanins);
  fanin_list = lsStart(fanins);

  if (Fnode_Operator(top) == BDS_BDD_XOR ||
               Fnode_Operator(top) == BDS_BDD_XNOR || Fnode_Operator(top) == BDS_BDD_MUX) {

      /* Obtain fanins from list */
      if (lsFirstItem(fanins, (lsGeneric *)&firstItem, NULL) != LS_OK) {
      printf("List element retrieve fails\n");
      exit(2);
      }
      if (lsLastItem(fanins, (lsGeneric *)&lastItem, NULL) != LS_OK) {
      printf("List element retrieve fails\n");
      exit(2);
      }
  }

  /* print functionality of this node */
  switch(Fnode_Operator(top)) {
  case BDS_BDD_AND:
      while (lsNext(fanin_list, (lsGeneric *)&sib, NULL) != LS_NOMORE) {

      result = fprintf(fp,"%c",\
           Fnode_Internal(sib)?(Fnode_IsComplement(sib)?'0':'1'):(Fnode_Negative(sib)?'0':'1'));
          if (result == EOF) return(0);
      }
      result = fprintf(fp," %c\n",Fnode_Negative(top)?'0':'1');
      if (result == EOF) return(0);
      break;
  case BDS_BDD_OR:
      /* The corresponding BLIF representation is a square, the negative case has
      ** been taken care of in bdsDumpFtreeBlifOneNodePrintVarNames().
      */
      i = 0;
      while (lsNext(fanin_list, (lsGeneric *)&sib, NULL) != LS_NOMORE) {
      for (j = 0; j < num_fanins; j++) {
          if (j == i) { /* print function */
          result = fprintf(fp,"%c",\
              Fnode_Internal(sib)?(Fnode_IsComplement(sib)?'0':'1'):(Fnode_Negative(sib)?'0':'1'));
          if (result == EOF) return(0);
          }
          else { /* print - */
          result = fprintf(fp,"-");
          if (result == EOF) return(0);
          }
      }
      result = fprintf(fp," 1\n");
      if (result == EOF) return(0);

      i++;
      }
      break;

  /* The following operators just have two operands */
  case BDS_BDD_XOR:
      if (Fnode_Negative(top)) { /* (a'b+ab')' = ab + a'b' */
          result = fprintf(fp,"%c%c 1\n",Fnode_PrintLiteral(firstItem,0),Fnode_PrintLiteral(lastItem,0));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c%c 1\n",Fnode_PrintLiteral(firstItem,1),Fnode_PrintLiteral(lastItem,1));
          if (result == EOF) return(0);
      }
      else { /* a'b + ab' */
      result = fprintf(fp,"%c%c 1\n",Fnode_PrintLiteral(firstItem,1),Fnode_PrintLiteral(lastItem,0));
          if (result == EOF) return(0);
      result = fprintf(fp,"%c%c 1\n",Fnode_PrintLiteral(firstItem,0),Fnode_PrintLiteral(lastItem,1));
          if (result == EOF) return(0);
      }
      break;
  case BDS_BDD_XNOR:
      if (Fnode_Negative(top)) { /* (ab + a'b')' = a'b + ab' */
      result = fprintf(fp,"%c%c 1\n",Fnode_PrintLiteral(firstItem,1),Fnode_PrintLiteral(lastItem,0));
          if (result == EOF) return(0);
      result = fprintf(fp,"%c%c 1\n",Fnode_PrintLiteral(firstItem,0),Fnode_PrintLiteral(lastItem,1));
          if (result == EOF) return(0);
      }
      else { /* ab + a'b' */
          result = fprintf(fp,"%c%c 1\n",Fnode_PrintLiteral(firstItem,0),Fnode_PrintLiteral(lastItem,0));
          if (result == EOF) return(0);
          result = fprintf(fp,"%c%c 1\n",Fnode_PrintLiteral(firstItem,1),Fnode_PrintLiteral(lastItem,1));
          if (result == EOF) return(0);
      }
      break;
  case BDS_BDD_MUX:
      /* The complementary case has been taken care of in bdsDumpFtreeBlifOneNodePrintVarNames().
      ** Always print fg + f'h */
      ctl = top->control;
      result = fprintf(fp,"%c%c- 1\n",Fnode_PrintLiteral(ctl,0),Fnode_PrintLiteral(firstItem,0));
      if (result == EOF) return(0);
      result = fprintf(fp,"%c-%c 1\n",Fnode_PrintLiteral(ctl,1),Fnode_PrintLiteral(lastItem,0));
      if (result == EOF) return(0);
      break;
  default:
      fail("Unknown decomposition type");
  }
  lsFinish(fanin_list);

  return(1);

} /* end of bdsDumpFtreeBlifOneNodePrintFunction */

/**Function********************************************************************

  Synopsis    [Build an array of string which corresponds different operator]

  Description [Return the array if successful; NULL otherwise]

  SideEffects [None]

  SeeAlso     []

  Last date   [2/26/99]

*****************************************************************************/
static
char **
bdsBuildOperatorString(
  int number)
{
  int i, maxlong = 4; /* Max # of char inside an fnode */
  char *bds_inv = "INV", *bds_and = "*", *bds_or = "+";
  char *bds_xor = "^", *bds_xnor = "@", *bds_mux = "MUX";
  char **operator;

  operator = ALLOC(char *, number);

  for (i = 0; i < number; i++) {
      switch(i) {
          case 0:
          operator[i] = ALLOC(char, maxlong);
              strcpy(operator[i],bds_inv);
          break;
      case 1:
          operator[i] = ALLOC(char, maxlong);
              strcpy(operator[i],bds_and);
          break;
      case 2:
          operator[i] = ALLOC(char, maxlong);
              strcpy(operator[i],bds_or);
          break;
      case 3:
          operator[i] = ALLOC(char, maxlong);
              strcpy(operator[i],bds_xor);
          break;
      case 4:
          operator[i] = ALLOC(char, maxlong);
              strcpy(operator[i],bds_xnor);
          break;
      case 5:
          operator[i] = ALLOC(char, maxlong);
              strcpy(operator[i],bds_mux);
          break;
      default:
          fail("Unkonwn operator on ftree !");
      }
  }

  return(operator);

} /* end of bdsBuildOperatorString */
