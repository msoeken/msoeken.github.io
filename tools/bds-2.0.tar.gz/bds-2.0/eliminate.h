/// Definitions for eliminate.c


/**CHeaderFile*****************************************************************

  FileName    [eliminate.h]

  PackageName [BDS-pga]

  Synopsis    [Network partition program]

  Description []

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#ifndef _BNETELIMINATE
#define _BNETELIMINATE

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "lopt.h"
#include "bnet.h"
#include "build.h"
#include "local.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

#define BDS_ELIMINATE_THRESHOLD 0

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN int BDS_EliminateBasedOnLocal ARGS((DdManager*,BnetNetwork*,bdsOptions*,int,int,FILE*,int));
EXTERN int BDS_EliminateBasedOnGlobal ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN void BDS_FreeNetworkAfterEliminate ARGS((BnetNetwork*));
EXTERN void PrintNet2Blif ARGS((BnetNetwork*, DdManager*, bdsOptions*, FILE*));
#endif /* _BNETELIMINATE */












