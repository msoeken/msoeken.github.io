
/**CFile***********************************************************************

  FileName    [verify.c]

  PackageName [BDS-pga]

  Synopsis    [A Primitive Synthesis verification progrm]

  Description [This file contains the functions for verification of final FTrees.]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/
#include "verify.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static DdNode * bdsVerifyPartitionRecursive ARGS((DdManager*,BnetNode*,bdsOptions*,st_table*));
static int BDS_BuildFtreeDD ARGS((DdManager*,BnetNetwork*,FactorTreeNode**));
static int BDS_BuildFtreeDDRecursive ARGS((DdManager*,FactorTreeNode*));


/**Function********************************************************************

  Synopsis    [Partitioning verification program]

  Description [Local BDDs are composed to form global BDDs. Then compare with
  global BDDs. Return 1 if equal; 0 otherwise]

  SideEffects []

  SeeAlso     []

  Last Date   [4/1/99]

*****************************************************************************/
extern
int
bdsVerifyPartition(
  DdManager *bddmgr,
  BnetNetwork *net,
  bdsOptions *option)
{
  BnetNode *node;
  int result, i;
  st_generator *gen;
  DdNode *bdd;
  st_table *globalBddTbl; /* node ~ global BDD table */

  globalBddTbl = st_init_table(st_ptrcmp,st_ptrhash);

  /* Construct global thru local BDD composition. BDDs are compared */
  for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash,net->outputs[i],(char **) &node)) {
          return(0);;
      }
      bdd = bdsVerifyPartitionRecursive(bddmgr,node,option,globalBddTbl);
      if (bdd == 0) return(0);

      /* compare with PO BDDs */
      if (bdd != node->dd) return(0);
  }

  /* Free all new contructed global BDDs */
  gen = st_init_gen(globalBddTbl);
  while (st_gen(gen, (char **) &node, (char **) &bdd)) {
      Cudd_RecursiveDeref(bddmgr, bdd);
  }
  st_free_gen(gen);

  st_free_table(globalBddTbl);

  return(1);

} /* end of bdsVerifyPartition */

/**Function********************************************************************

  Synopsis    [Partition verification program]

  Description [Global BDDs for a primary output are built thru composition of local
  BDDs. The functionality of any existing nodes should be equivalent to the corresponding
  global BDDs. Return 1 if equivalent; 0 otherwise]

  SideEffects []

  SeeAlso     []

  Last Date   [4/1/99]

*****************************************************************************/
static
DdNode *
bdsVerifyPartitionRecursive(
  DdManager *bddmgr,
  BnetNode *node,
  bdsOptions *option,
  st_table *globalBddTbl)
{
  lsGen fanins;
  BnetNode *fanode;
  DdNode *retBdd, *composedBdd, *localBdd;

  /* Check if the BDD has been built */
  if (st_lookup(globalBddTbl, (char *) node, (char **) &retBdd)) return(retBdd);

  /* Prevent node is an input node */
  if (node->type == BNET_INPUT_NODE) return(node->dd);

  /* Construct global BDD recursively */
  retBdd = node->localBdd;
  Cudd_Ref(retBdd);
  fanins = lsStart(node->fanins);
  while (lsNext(fanins, (lsGeneric *) &fanode, NULL) != LS_NOMORE) {
      if (fanode->type == BNET_INPUT_NODE) continue;
      localBdd = bdsVerifyPartitionRecursive(bddmgr,fanode,option,globalBddTbl);
      if (localBdd == NULL) return(0);

      /* Compose into node */
      composedBdd = Cudd_bddCompose(bddmgr,retBdd,localBdd,fanode->localVar);
      if (composedBdd == NULL) return(0);
      Cudd_Ref(composedBdd);

      Cudd_RecursiveDeref(bddmgr,retBdd);
      retBdd = composedBdd;
  }
  lsFinish(fanins);

  /* Compare with global BDD on the node */
  if (retBdd != node->dd) return(0);

  /* Record the global BDD */
  if (st_insert(globalBddTbl, (char *) node, (char *) retBdd) == ST_OUT_OF_MEM) {
      printf("Out of memory");
      exit(2);
  }

  return(retBdd);

} /* end of bdsVerifyPartitionRecursive */

/**Function********************************************************************

  Synopsis    [Final synthesis results verification program]

  Description [Verify the final synthesis results by re-building BDDs on Boolean
  network and on ftrees. Since network partition has been verified in main(). The
  final synthesis results are verified against local BDDs.
  Return 1 if equivalent; 0 otherwise]

  SideEffects []

  SeeAlso     []

  LastDate    [4/1/99]

*****************************************************************************/
extern
int
bdsVerifySynthesis(
  DdManager *bddmgr,
  BnetNetwork *net,
  FactorTreeNode **FTNode,
  st_table *factorTreeNode2BnetNode,
  bddPool **bddPoolArray,
  st_table *bddPoolBnodeAssoc,
  bdsOptions *option)
{
  BnetNode *bnode;
  FactorTreeNode **q;
  bddPool **p;
  int i, result;
  DdNode *retBdd;
  st_table *node2bdd;

  node2bdd = st_init_table(st_ptrcmp,st_ptrhash);

  /* Construct local BDDs on the boolean network */
  for (p = bddPoolArray; *p; p++) {
      retBdd = BDS_BuildDDFromBddPoolLocalRecursive(bddmgr, (*p)->bnode, 0, NULL);
      if (retBdd == NULL) return(0);
      retBdd = DumpNode_IsComplement((*p)->bnode) ? Cudd_Not(retBdd) : retBdd;

      /* Retrieve bnode */
      if (!st_lookup(bddPoolBnodeAssoc, (char *) *p, (char **) &bnode)) {
      printf("Fatal error in bddPool table ");
      exit(2);
      }

      /* Put bdd into node2bdd table */
      if (st_insert(node2bdd, (char *) bnode, (char *) retBdd) == ST_OUT_OF_MEM) {
          printf("Out of memory");
          exit(2);
      }
  }

  /* Build BDDs on the ftrees */
  result = BDS_BuildFtreeDD(bddmgr,net,FTNode);
  if (result == 0) return(0);

  /* Compare BDDs on bnode with those on ftrees */
  for (q = FTNode; *q; q++) {
      if (!st_lookup(factorTreeNode2BnetNode, (char *) *q, (char **) &bnode)) {
          fail("Boolean network error in bdsVerifySynthesis");
      }
      if (!st_lookup(node2bdd, (char *) bnode, (char **) &retBdd)){
      printf("Fatal error in node2bdd table ");
      exit(2);
      }

      if ((*q)->dd != retBdd) return(0);
  }

  st_free_table(node2bdd);

  return(1);

} /* end of bdsVerifySynthesis */

/**Function********************************************************************

  Synopsis    [Build BDD on ftree]

  Description [Return 1 successful, 0 failure]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
static
int
BDS_BuildFtreeDD(
  DdManager *bddmgr,
  BnetNetwork *net,
  FactorTreeNode **FTNode)
{
  int result, i;
  FactorTreeNode **q;

  for (q = FTNode; *q; q++) {
      result = BDS_BuildFtreeDDRecursive(bddmgr, *q);
      if (result == 0) return(0);
  }

  return(1);

} /* end of BDS_BuildFtreeDD */

/**Function********************************************************************

  Synopsis    [Recursive program for BDS_BuildFtreeDD]

  Description [Return 1 success; 0 otherwise]

  SideEffects [None]

  SeeAlso     []

*****************************************************************************/
static
int
BDS_BuildFtreeDDRecursive(
  DdManager *bddmgr,
  FactorTreeNode *fnode)
{
  int result;
  FactorTreeNode *top, *dp, *dm, *ctl, *sib, *g, *h;
  DdNode *ctlBdd, *gBdd, *hBdd, *var, *sibBdd;
  DdNode *retBdd, *tmpBdd;
  lsGen fanins_gen;
  lsList fanins;

  top = Fnode_Regular(fnode);

  /* BDD has been built for this node */
  if (top->dd != NULL) {
      return(1);
  }
  /* Build BDD for the terminal node */
  if (top->value != BDS_FTREE_INTERNAL) {
      var = Cudd_ReadVars(bddmgr, top->value);
      Cudd_Ref(var);
      top->dd = (top->polarity == 0) ? Cudd_Not(var) : var;
      return(1);
  }

  fanins = Fnode_Fanins(top);

#ifdef PTL
  if (top->op == BDS_BDD_MUX) {
      ctl = top->control;
      if (Fnode_Regular(ctl)->dd == NULL){
          result = BDS_BuildFtreeDDRecursive(bddmgr, ctl);
      if (result == 0) return(0);
      }
      ctlBdd = Fnode_IsComplement(ctl) ? Cudd_Not(Fnode_Regular(ctl)->dd) : ctl->dd;

      lsFirstItem(fanins, (lsGeneric *) &g, NULL);
      if (Fnode_Regular(g)->dd == NULL){
          result = BDS_BuildFtreeDDRecursive(bddmgr, g);
      if (result == 0) return(0);
      }
      gBdd = Fnode_IsComplement(g) ? Cudd_Not(Fnode_Regular(g)->dd) : g->dd;

      lsLastItem(fanins, (lsGeneric *) &h, NULL);
      if (Fnode_Regular(h)->dd == NULL){
          result = BDS_BuildFtreeDDRecursive(bddmgr, h);
      if (result == 0) return(0);
      }
      hBdd = Fnode_IsComplement(h) ? Cudd_Not(Fnode_Regular(h)->dd) : h->dd;

      retBdd = Cudd_bddIte(bddmgr, ctlBdd, gBdd, gBdd);
      if (retBdd == NULL) return(0);
      Cudd_Ref(retBdd);

      top->dd = (top->polarity == 0) ? Cudd_Not(retBdd) : retBdd;
      return(1);
  }
#endif

  if (top->op == BDS_BDD_XOR || top->op == BDS_BDD_XNOR) {
      lsFirstItem(fanins, (lsGeneric *) &g, NULL);
      if (Fnode_Regular(g)->dd == NULL){
          result = BDS_BuildFtreeDDRecursive(bddmgr, g);
      if (result == 0) return(0);
      }
      gBdd = Fnode_IsComplement(g) ? Cudd_Not(Fnode_Regular(g)->dd) : g->dd;

      lsLastItem(fanins, (lsGeneric *) &h, NULL);
      if (Fnode_Regular(h)->dd == NULL){
          result = BDS_BuildFtreeDDRecursive(bddmgr, h);
      if (result == 0) return(0);
      }
      hBdd = Fnode_IsComplement(h) ? Cudd_Not(Fnode_Regular(h)->dd) : h->dd;

      if (top->op == BDS_BDD_XOR)
      retBdd = Cudd_bddXor(bddmgr, gBdd, hBdd);
      else
      retBdd = Cudd_bddXnor(bddmgr, gBdd, hBdd);

      if (retBdd == NULL) return(0);
      Cudd_Ref(retBdd);

      top->dd = (top->polarity == 0) ? Cudd_Not(retBdd) : retBdd;
      return(1);
  }

  if (top->op == BDS_BDD_AND || top->op == BDS_BDD_OR) {
      if (top->op == BDS_BDD_AND)
      retBdd = Cudd_ReadOne(bddmgr);
      else
      retBdd = Cudd_ReadLogicZero(bddmgr);

      Cudd_Ref(retBdd);

      fanins_gen = lsStart(fanins);
      while (lsNext(fanins_gen, (lsGeneric *) &sib, NULL) != LS_NOMORE) {
      if (Fnode_Regular(sib)->dd == NULL) {
          result = BDS_BuildFtreeDDRecursive(bddmgr, sib);
          if (result == 0) return(0);
      }
      sibBdd = Fnode_IsComplement(sib) ? Cudd_Not(Fnode_Regular(sib)->dd) : sib->dd;

      if (top->op == BDS_BDD_AND)
          tmpBdd = Cudd_bddAnd(bddmgr, retBdd, sibBdd);
      else
          tmpBdd = Cudd_bddOr(bddmgr, retBdd, sibBdd);

      if (tmpBdd == NULL) return(0);
      Cudd_Ref(tmpBdd);

      Cudd_RecursiveDeref(bddmgr, retBdd);
      retBdd = tmpBdd;
      }
      lsFinish(fanins_gen);

      top->dd = (top->polarity == 0) ? Cudd_Not(retBdd) : retBdd;
      return(1);
  }

  return(0);

} /* end of BDS_BuildFtreeDDRecursive */


