
/**CFile***********************************************************************

  FileName    [eliminate.c]

  PackageName [BDS-pga]

  Synopsis    [BnetNode eliminate program]

  Description [This file contains the functions for the MFFC-based iterative
               eliminate for local BDDs (eliminate for global BDDs was not implemented).

               Iterative Eliminate program has two phase in each iteration:

               Phase 1: Collect all eliminatable nodes.
                        Traverse a topologically ordered list of nodes from primary
                        inputs to primary outputs to identify collapsible nodes.
                        Nodes in a Bnetwork can be removed by the following conditions:
                        1) if the node is functionally equivalent (or complementary) to
                           other nodes.
                        2) satisfy an eliminate gain threshold.
                        3) MFFCs: if the collapsed node has only one output and satisfies the limit
                           of the number of nodes in a new BDD for the supernode.

               Phase 2: Collapse the collapsible nodes.
                        Once the collapsible nodes have been marked, the topologically
                        ordered list of nodes is traversed from inputs to outputs.
                        Any collapsible node encountered during the traversal is collapsed
                        into its fan-outs and a BDD for the composite function is constructed.
                        The collapsible node is then erased from the network list if the
                        number of inputs to the new node is <= iconst = 100000 (default).

               In the first iteration, MFFCs are identified and collapsed, by allowing
               only nodes with one output fanout to be collapsed into the fanout. The
               -largefanout option can be used to allow the collapse of multiple fan-out nodes.
               In subsequent iterations, multiple fan-out nodes can be collapsed into their
               fan-outs. The threshold limit option: -ethred allows setting a limit on the
               size differential between the old and new BDDs.

                   In the delay re-synthesis phase, only the nodes on the critical path are
               collapsed into a supernode. In the process, some new nodes with replicated
               logic are created. Identifying the critical path is based on the depth
               from a primary output to primary inputs.]

  SeeAlso     []

  Author      [Congguang Yang]

  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

 ******************************************************************************/
#include "eliminate.h"
#include "array.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static int BDS_LocalEliminateCollect ARGS((DdManager*, BnetNetwork*, bdsOptions*, st_table*, int, FILE*, int, st_table*, array_t*));
static int BDS_LocalEliminateExecute ARGS((DdManager*, BnetNetwork*, bdsOptions*, st_table*, int, st_table*, array_t*));
static int BDS_DelayEliminateExecute ARGS((DdManager*, BnetNetwork*, bdsOptions*, st_table*, int));
static int BDS_PrintMod ARGS((BnetNetwork*, DdManager*, bdsOptions*));
static int bdsFreeOneBnetNode ARGS((DdManager*, BnetNode*, int));
static int BDS_EliminateNodeOrNot ARGS((DdManager*, BnetNode*, bdsOptions*, st_table*, st_table*, int*, int, FILE*, st_table**, int, int*, FILE*));
static int bdsCalculateFanoutBddSize ARGS((DdManager*, BnetNode*, int));
static int BDS_ComposeIntoFanouts ARGS((DdManager*, BnetNode*, bdsOptions*));
static int BDS_CheckEliminateGain ARGS((DdManager*, BnetNode*, bdsOptions*, int, FILE*));
static int BDS_CheckEliminateGainWithOutReorder ARGS((DdManager*, BnetNode*, bdsOptions*));
static int BDS_CheckEliminateGainWithReorder ARGS((DdManager*, BnetNode*, bdsOptions*, FILE*));
static int bdsCreateDummyVar ARGS((DdManager*, BnetNode*, int**, int**, st_table*));
static void outputList ARGS((char**, int));

/**Function********************************************************************

  Synopsis    [MFFC-based iterative eliminate internal node based on BDD complexity]

  Description [Internal nodes are iteratively eliminated. In each iteration,
               all valid candidates are recorded. Then they are merged into their
               fanouts. The elimination criteria is based on MFFCs, # of BDD nodes,
               and threshold. The threshold is passed in through option*.

               In the delay re-synthesis phase, only the nodes on the critical path are
               collapsed into a supernode. But some replicated logic nodes may also be
               created in the process.
               Return 1 if successful; 0 otherwise]

  SideEffects [network is modified]

  SeeAlso     []

 *****************************************************************************/
extern
int
BDS_EliminateBasedOnLocal(
 DdManager *bddmgr,
 BnetNetwork *net,
 bdsOptions *option,
 int globalReady, /* to free node->dd field in bdsFreeOneBnetNode() */
 int reorder, /* = 0 (if no rodelim), = 1 (if rodelim) */
 FILE *recdfp, /* for rodelim */
 int a) /* (not used, 0 in main()) */ {
  int result, i;
  BnetNode *top_node, *highest_node, *fanin_node, *temp_fanin;
  int removableNodes = 1; /* Force the first iteration */
  st_table *tobeRemovedTbl, *mergeSinkTbl; /* nodes table which fanins will be merged into */
  int iteration = 1;
  int crit;
  FILE *debug_file;
  char *filename;
  st_generator *gen, *highest;
  st_table *delayNodeTbl;
  array_t *removable_nodes;
  int BDS_sorting_on_depth();
  int quant = 10000, pand = 0, counter = 0; /* limit the iteration to 10000 times */
  lsGen fan_in;
  float price = 0.0;
  int indicate = 0;

  printf("Eliminating internal nodes ");
  (void) fflush(stdout);

  /********** Delay re-synthesis *******************************************/

  /* Finding critical path for delay re-synthesis. Identifying the critical path
   ** is based on the depth from a primary output to primary inputs.
   */

  if (option->delay == TRUE) {
    delayNodeTbl = st_init_table(st_ptrcmp, st_ptrhash);
    printf("\nFinding Critical Path ");
    crit = BDS_FindCriticalPath(net, delayNodeTbl, option);
  }

  /* Collapsing nodes on the critical paths in delay re-synthesis phase.
   ** Some logic may be replicated in the process.
   */

  if (option->delay == TRUE) {
    result = BDS_DelayEliminateExecute(bddmgr, net, option, delayNodeTbl, globalReady);
    if (result == 0) return (0);
    printf("\n");

    highest = st_init_gen(delayNodeTbl);
    while (st_gen(highest, (char **) &highest_node, NULL)) { /* for each node in delayNodeTbl */
      if (highest_node->type == BNET_OUTPUT_NODE) {
        printf("OUTPUT NODE\n");
        continue;
      }
    }
    st_free_gen(highest);

    pand = 0;
    gen = st_init_gen(net->livenodes);
    while (st_gen(gen, (char **) &top_node, NULL)) { /* for each livenode in net */
      if (top_node == highest_node) continue;
    }
    st_free_gen(gen);

    fan_in = lsStart(top_node->fanins);
    while (lsNext(fan_in, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {
      pand++;
      if (pand == 1) temp_fanin = fanin_node;
    }
    lsFinish(fan_in);

    if (pand == 1) {
      printf("Node name is %s\n", temp_fanin->name);
    }
    st_free_table(delayNodeTbl);
  }

  /********** MFFC-based Iterative Elimination *****************************/

  /* Main loop for MFFC-based iterative eliminate procedure
   ** While removableNodes is not 0, go through eliminate procedure iteratively.
   ** First, collapsible or eliminatable nodes are identified by calling BDS_LocalEliminateCollect()
   ** function, and then BDS_LocalEliminateExecute() is called to do the actual eliminations.
   ** After eliminating a node, that node can be freed if the new node satisfied the limit of the
   ** number of inputs to it.
   */

  while ((removableNodes) && (iteration <= quant) && (option->delay == FALSE)) {
    tobeRemovedTbl = st_init_table(st_ptrcmp, st_ptrhash);
    mergeSinkTbl = st_init_table(st_ptrcmp, st_ptrhash);
    removable_nodes = array_alloc(BnetNode *, 0);

    /* Collect all eliminatable internal nodes */
    result = BDS_LocalEliminateCollect(bddmgr, net, option, tobeRemovedTbl, reorder, recdfp, iteration, mergeSinkTbl, removable_nodes);
    if (result == 0) return (0);

    /* Sort this array in the increasing order of depth */
    array_sort(removable_nodes, BDS_sorting_on_depth);

    /* Return # of nodes to be eliminated */
    removableNodes = st_count(tobeRemovedTbl);
    printf("Removable Nodes = %i\n", removableNodes);

    /* Conduct node elimination, modify the boolean network */
    result = BDS_LocalEliminateExecute(bddmgr, net, option, tobeRemovedTbl, globalReady, mergeSinkTbl, removable_nodes);
    if (result == 0) return (0);
    iteration++;
    st_free_table(mergeSinkTbl);
    st_free_table(tobeRemovedTbl);
    array_free(removable_nodes);
  }
  printf("Done\n\n");

  return (1);

} /* end of BDS_EliminateBasedOnLocal */

/**Function********************************************************************

  Synopsis    [Collect all internal nodes which can be eliminated]

  Description [Local BDDs are used to carry out the elimination process. The BDD for
               a node is composed into its fanouts. The decision of elimination
               is based on elimination gain threshold and identifying MFFCs by
               calling BDS_EliminateNodeOrNot().
               Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_LocalEliminateCollect(
 DdManager *bddmgr,
 BnetNetwork *net,
 bdsOptions *option,
 st_table *tobeRemovedTbl, /* list of to-be-removed nodes */
 int reorder, /* = 0 (if no rodelim), = 1 (if rodelim) */
 FILE *recdfp, /* for rodelim */
 int iteration, /* iteration count in BDS_EliminateBasedOnLocal() */
 st_table *mergeSinkTbl, /* list of merge-sink nodes (not used in BDS_EliminateBasedOnLocal()) */
 array_t *removable_nodes) /* list of to-be-removed nodes (not used in other functions) */ {
  int result;
  lsGen fanouts;
  FILE *debug;
  BnetNode *node, *fanode;
  st_generator *gen;
  int eliminateOrNot; /* 0: don't eliminate; 1: elimnate */
  int invalid_due_to_fanouts = 0;
  int no_nodes = 0;
  st_table *updated_inputs;

  updated_inputs = st_init_table(st_ptrcmp, st_ptrhash);

  /* Go through nodes one by one in the Boolean network */
  gen = st_init_gen(net->livenodes);
  no_nodes = 0;
  while (st_gen(gen, (char **) &node, NULL)) {
    no_nodes++;

    /* skip CONSTANT, INPUT, and OUTPUT nodes */
    if (node->type == BNET_CONSTANT_NODE || node->type == BNET_INPUT_NODE || node->type == BNET_OUTPUT_NODE) continue;

    debug = fopen("debug.txt", "w");

    /* Identifying MFFCs and eliminatable nodes */
    result = BDS_EliminateNodeOrNot(bddmgr, node, option, tobeRemovedTbl, mergeSinkTbl, &eliminateOrNot, reorder, recdfp, &updated_inputs, iteration, &invalid_due_to_fanouts, debug);
    fclose(debug);
    if (result == 0) return (0);


    if (eliminateOrNot) { /* if do eliminate */
      /* Store the merge sinks. This will prevent other nodes from merging into it */
      fanouts = lsStart(node->fanouts);
      while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
        if (st_add_direct(mergeSinkTbl, (char *) fanode, (char *) NULL) == ST_OUT_OF_MEM) {
          printf("Out of memory");
          return (0);
        }
      }
      lsFinish(fanouts);

      /* Store the nodes to be merged*/
      if (st_add_direct(tobeRemovedTbl, (char *) node, (char *) NULL) == ST_OUT_OF_MEM) {
        printf("Out of memory");
        return (0);
      }
      array_insert_last(BnetNode *, removable_nodes, node);
    }
  } /* end of while */

  printf("\nNo of total nodes = %i\n", no_nodes);
  printf("No of invalid nodes due to large fanout = %i\n", invalid_due_to_fanouts);
  st_free_table(updated_inputs);
  st_free_gen(gen);
  return (1);

} /* end of BDS_LocalEliminateCollect */

/**Function********************************************************************

  Synopsis    [Carry out node elimination]

  Description [Collapse MFFC-based identified collapsable nodes.
               Node in the tobeRemovedTbl are composed into their fanouts, then
               the node is freed. Boolean network is updated.
               Return 1 if successful; 0 otherwise]

  SideEffects [The connectivity and overall structure of the Boolean network is changed]

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_LocalEliminateExecute(
 DdManager *bddmgr,
 BnetNetwork *net,
 bdsOptions *option,
 st_table *tobeRemovedTbl, /* list of to-be-removed nodes */
 int globalReady, /* used in calling bdsFreeOneBnetNode() */
 st_table *mergeSinkTbl, /* (not used in this function) */
 array_t *removable_nodes) /* (not used in any function) */ {
  int iter = 0;
  st_generator *gen, *net_gen;
  BnetNode *node, *fanode, *fanin_node, *fanout_node, *dummy_node;
  BnetNode *net_node;
  lsGen fanouts, fanins, fanin_node_fanout;
  int nodeLocalId, gen_index;
  DdNode *nodeLocalBdd, *composedBdd, *fanoutBdd;
  int doIexecute = 0; /* 0=execute, 1=do not execute */
  int no_nodes = 1;
  int i, array_length;
  int signals = 0;

  /* eliminate node one by one, update the Boolean network */
  net_gen = st_init_gen(net->livenodes);

  while (st_gen(net_gen, (char **) &node, NULL)) {

    /* skip CONSTANT, INPUT, and OUTPUT nodes */
    if (node->type == BNET_CONSTANT_NODE || node->type == BNET_INPUT_NODE || node->type == BNET_OUTPUT_NODE)
      continue;

    /* If the node is in the tobeRemoved list, do elimination */
    if (st_is_member(tobeRemovedTbl, (char *) node)) {

      iter++;
      if (iter > 1000) /* if more than 1000 livenodes, stop after going through 1000 livenodes */
        return (1);

#ifndef DEBUG
      (void) printf(".");
      (void) fflush(stdout);
#endif

      nodeLocalId = node->localVar;
      nodeLocalBdd = node->localBdd;
      fanouts = lsStart(node->fanouts);

      /* For each fanout node, do collapsing */
      doIexecute = 0;
      while ((lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE)) {

        signals = BDS_GetInputs(fanode); /* # inputs of the fanout node */

        /* If the number of inputs of the fanout node is larger than
         ** the predefined limit of iconst = 10000, stop the collapsing.
         */
        if (signals >= option->iconst) {
          printf("No. of inputs is large  %i!!!\n", signals);
          doIexecute = 1;
          fanode->executeornot = 0;
          node->executeornot = 0;
          node->checked = 1;
          continue; /* stop the collapsing, but need to go through the entirelsNext loop */
        }
        /* Transfer BDDs */
        fanoutBdd = fanode->localBdd;
        composedBdd = Cudd_bddCompose(bddmgr, fanoutBdd, nodeLocalBdd, nodeLocalId); /* collapse nodeLocalBDD and fanoutBdd */
        if (composedBdd == NULL) return (0);
        Cudd_Ref(composedBdd);
        Cudd_RecursiveDeref(bddmgr, fanode->localBdd);
        fanode->localBdd = composedBdd;

        /* Move fanins of node to fanode */
        fanins = lsStart(node->fanins);
        while (lsNext(fanins, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {
          if (lsNewEnd(fanode->fanins, (lsGeneric) fanin_node, NULL) != LS_OK) {
            printf("Out of memory");
            return (0);
          }
        }
        lsFinish(fanins);

        /* Remove possible duplications */
        (void) lsSort(fanode->fanins, bdsUniqueBnetNode);
        (void) lsUniq(fanode->fanins, bdsUniqueBnetNode, NULL);
        if (abs(fanode->depth) == (abs(node->depth) - 1))
          fanode->depth = abs(node->depth);
        else
          fanode->depth = abs(fanode->depth);
        /* Remove node from fanode's fanin list */
        fanins = lsStart(fanode->fanins);
        while (lsNext(fanins, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {
          if (fanin_node == node) {
            (void) lsDelBefore(fanins, (lsGeneric*) & dummy_node);
            break;
          }
        }
        lsFinish(fanins);

        /* Update the fanouts of fanin_node. Add fanode to fanin_node's fanout list */
        fanins = lsStart(node->fanins);
        while (lsNext(fanins, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {

          /* The following line is commented out to fix a bug. When the fanout
           ** of a PI node is changed, the fanout field of that PI should also
           ** be updated. The bug was found in the implementation of sharing extraction
           ** -cyang 5/24/99
          if (fanin_node->type == BNET_INPUT_NODE) continue;
           */

          if (lsNewEnd(fanin_node->fanouts, (lsGeneric) fanode, NULL) != LS_OK) {
            printf("Out of memory");
            return (0);
          }
        }
        lsFinish(fanins);
      }/* End of 1st while loop with lsStart(fanouts) */
      lsFinish(fanouts);

      if (doIexecute == 0) { /* if execute */
        /* Remove node from fanin_node's fanout list before node is freed */
        fanins = lsStart(node->fanins);
        while ((lsNext(fanins, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE)) { /* for each fanin node of the node */

          /* The following line is commented out. See explanation above. -cyang 5/24/99
          if (fanin_node->type == BNET_INPUT_NODE) continue;
           */

          fanin_node_fanout = lsStart(fanin_node->fanouts);
          while (lsNext(fanin_node_fanout, (lsGeneric *) & fanout_node, NULL) != LS_NOMORE) { /* for each fanout of the fanin node */
            if (fanout_node == node) {
              (void) lsDelBefore(fanin_node_fanout, (lsGeneric*) & dummy_node);
              break;
            }
          }
          lsFinish(fanin_node_fanout);

          /* Remove possible duplications */
          (void) lsSort(fanin_node->fanouts, bdsUniqueBnetNode);
          (void) lsUniq(fanin_node->fanouts, bdsUniqueBnetNode, NULL);
        }
        lsFinish(fanins);

        /* Since fanode already contains information of node, node can be freed */

        if (!st_delete(net->livenodes, (char **) &node, (char **) NULL)) {
          return (0);
        }
        (void) bdsFreeOneBnetNode(bddmgr, node, globalReady);
      } /* end of if (doIexecute == 0)... */
    } /* end of if (st_is_member(tobeRemovedTbl, (char *) node))... */
  } /* end of while (st_gen(net_gen... */
  st_free_gen(net_gen);

  return (1);

} /* end of BDS_LocalEliminateExecute */

/**Function********************************************************************

  Synopsis    [Free one BnetNode]

  Description []

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
bdsFreeOneBnetNode(
 DdManager *bddmgr,
 BnetNode *node,
 int globalReady) /* to free node->dd if global BDDs were built (globalReady = 1) before */ {
  int i;
  BnetTabline *line, *nextline;

  /* Free all input names on the ORIGINAL bnetwork */
  for (i = 0; i < node->ninp; i++) {
    FREE(node->inputs[i]);
  }
  FREE(node->inputs);

  /* Free table line */
  line = node->f;
  while (line != NULL) {
    nextline = line->next;
    FREE(line->values);
    FREE(line);
    line = nextline;
  }

  FREE(node->name);
  Cudd_RecursiveDeref(bddmgr, node->localBdd);
  if (globalReady && node->dd != NULL)
    Cudd_RecursiveDeref(bddmgr, node->dd);

  lsDestroy(node->fanins, NULL);
  lsDestroy(node->fanouts, NULL);

  FREE(node);

  return (1);

} /* end of bdsFreeOneBnetNode */

/**Function********************************************************************

  Synopsis    [Check if a node can be eliminated.]

  Description [First, check if node is legal or not. "Legal" means several things,
               1) the node is a sink other nodes are going to be merged into;
               2) its fanouts are nodes which other nodes will be merged into;
               3) its fanouts are going to merge into other nodes;
               4) all its fanouts are single-variable PO nodes.
               5) MFFC in the first iteration, if -largefanout is specified, the
                  collapse of multiple fan-out nodes is allowed in the first iteration.
               Second, check the eligibility of eliminating the node.
               This process is based on "elimination gain threshold".
               Return 1 if successful; 0 otherwise.]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_EliminateNodeOrNot(
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option,
 st_table *tobeRemovedTbl,
 st_table *mergeSinkTbl,
 int *eliminateOrNot, /* Return value. 0 don't eliminate; 1 eliminate. */
 int reorder, /* = 0 (if no rodelim), = 1 (if rodelim) */
 FILE *recdfp, /* for rodelim */
 st_table **updated_inputs, /* for printing to 'debug' file */
 int iteration, /* iteration count in BDS_EliminateBasedOnLocal() */
 int *invalid_due_to_fanouts, /* for printing to stdout in BDS_LocalEliminateCollect() */
 FILE *debug) /* for printing to 'debug' file */ {
  lsGen fanouts;
  BnetNode *fanode;
  int egain; /* Elimination gain */
  int trivialPO;
  int whichiter = 1;

  *eliminateOrNot = 1; /* Set flag to eliminate, legality check will disqualify this */

  /* if it is first iteration and not allow largefanout, do MFFC-based eliminate */
  if ((iteration == 1) && (option->largefanout == FALSE)) {
    if (node->no_outputs > 1) { /* if there is more than one fanout of the node, do not eliminate */
      (*invalid_due_to_fanouts)++;
      *eliminateOrNot = 0;
      return (1);
    }
  }

  /* level1 is not used anymore, crit_node = 0 initially and not changed in regular-collapse */
  if ((option->level1 == TRUE) && (node->crit_node == 1)) {
    *eliminateOrNot = 0;
    return (1);
  }

  /* for delay part, if node was delay-collapsed (0 initially and not changed in regular-collapse) */
  if (node->collapsed == 1) {
    *eliminateOrNot = 0;
    return (1);
  }

  /* if not option->elim (not used anymore), do the following at the second iteration */
  if (option->elim == FALSE)
    whichiter = 1;
  else whichiter = 1000; /* if option->elim, do the following only after 1000th iteration */

  if (iteration > whichiter) { /* if it is not first iteration */

    /* Go through each fanout of the node */
    fanouts = lsStart(node->fanouts);
    while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
      /* If the node is a sink into which other node will merge. */
      if (st_is_member(mergeSinkTbl, (char *) node)) {
        *eliminateOrNot = 0;
        return (1);
      }
    }

    /* If its fanouts fall into above mentioned 2 and 3 categories */

    fanouts = lsStart(node->fanouts);
    while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
      if (st_is_member(mergeSinkTbl, (char*) fanode) || st_is_member(tobeRemovedTbl, (char*) fanode)) {
        *eliminateOrNot = 0;
        break;
      }
    }
    lsFinish(fanouts);
    if (*eliminateOrNot == 0) return (1);

  }

  /* Check if all its fanouts are single-variable PO nodes. If this is the case,
   ** those single-variable PO nodes are used to hold previously allocated pointers.
   ** They are the interface between internal and external, don't eliminate the node.
   */

  trivialPO = 0;
  fanouts = lsStart(node->fanouts);
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    if (fanode->type == BNET_OUTPUT_NODE
     && Cudd_IsConstant(Cudd_T(fanode->localBdd))
     && Cudd_IsConstant(Cudd_E(fanode->localBdd)))
      trivialPO++;
  }
  lsFinish(fanouts);
  if (trivialPO == lsLength(node->fanouts)) {
    *eliminateOrNot = 0;
    return (1);
  }

  /* Check the elimination gain */
  egain = BDS_CheckEliminateGain(bddmgr, node, option, reorder, recdfp);

  if (egain <= option->ethred) { /* if egain is <= eliminate threshould, do eliminate */
    *eliminateOrNot = 1;
  } else { /* if egain is > eliminate threshould, do not eliminate */
    *eliminateOrNot = 0;
    if (option->rodelim != TRUE) { /* if do not eliminate and not rodelim */
      /*Clean up intermediate results */
      fanouts = lsStart(node->fanouts);
      while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
        Cudd_RecursiveDeref(bddmgr, fanode->tmpBdd);
      }
      lsFinish(fanouts);
    }
  }

  /* If do eliminate and it is not the first iteration, update the inputs of
   ** the node with its fanout nodes.
   */
  if (((*eliminateOrNot) == 1) && (iteration > 1)) {
    fanouts = lsStart(node->fanouts);
    while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
      fanode->updated_inputs += node->updated_inputs; /* node->updated_inputs is initially node->ninp */
      fprintf(debug, "No. inputs %i\n", fanode->updated_inputs);
    }
    lsFinish(fanouts);

  }

  /* if # inputs of a fanout node of the node is >= option->iconst = 100000, do not eliminate */
  if (node->checked == 1)
    *eliminateOrNot = 0;
  return (1);

} /* end of BDS_EliminateNodeOrNot */

/**Function********************************************************************

  Synopsis    [Evaluate the gain of eliminating the node]

  Description [The node is merged into its fanouts. The number of BDD nodes
  on new local BDDs of its fanouts are compared with their old local BDDs'.]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_CheckEliminateGain(
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option,
 int reorder,
 FILE *recdfp) {
  int gain;

  if (option->rodelim == TRUE && reorder)
    gain = BDS_CheckEliminateGainWithReorder(bddmgr, node, option, recdfp);
  else
    gain = BDS_CheckEliminateGainWithOutReorder(bddmgr, node, option);

  return (gain);

} /* end of BDS_CheckEliminateGain */

/**Function********************************************************************

  Synopsis    [Calculate the gain of eliminating node]

  Description [localBdd on node and localBdds on all its fanouts are reordered first.
  Then localBdd on node is composed into all its fanouts. Reorder the composed BDD again.
  Compare the total number of BDD nodes before and after composition. To prevent from
  carrying large number of empty BDD variables along with the reordering, a new bddmgr
  is initialized. All operations mentioned above are carried out in this new bddmgr.
  Unlike BDS_CheckEliminateGainWithReorderOld(), bddPool is used.
  Return gain if successful; exit(2) otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_CheckEliminateGainWithReorder(
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option,
 FILE *recdfp) {
  int result, numFanouts, i;
  int *real2dummy, *dummy2realId, dummyIndex, realIndex, numDummyVar, nodeDummyIndex, *jointSupport;
  DdManager *microbddmgr;
  DdNode *dummyVar, *nodeDummyBdd, **fanoutDummyBdds, **composedBddArray;
  DdNode *nodeLocalBdd, **fanoutBddArray, *jointSupportBdd, *scan;
  lsGen fanouts, fanins;
  int no_fanins, *no_support;
  BnetNode *fanode;
  int numOnNode, numOnFanoutsOld, numOnFanoutsNew;
  bddPool *nodeBddPool, **fanoutBddPool;
  int gain;

  /* Figure out how many dummyVar may need. Since the supports on different BDDs may
   ** overlap, the union of all supports should be found.
   */
  nodeLocalBdd = node->localBdd;
  if (nodeLocalBdd == NULL) return (0);
  Cudd_Ref(nodeLocalBdd);

  numFanouts = lsLength(node->fanouts);
  fanoutBddArray = ALLOC(DdNode *, numFanouts + 1);
  fanoutDummyBdds = ALLOC(DdNode *, numFanouts + 1);
  fanoutBddPool = ALLOC(bddPool *, numFanouts);
  composedBddArray = ALLOC(DdNode *, numFanouts);
  fanouts = lsStart(node->fanouts);
  i = 0;
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    fanoutBddArray[i] = fanode->localBdd;
    i++;
  }
  lsFinish(fanouts);
  fanoutBddArray[i] = nodeLocalBdd;

  /* Get the joint support on all BDDs in the order of level */
  jointSupportBdd = Cudd_VectorSupport(bddmgr, fanoutBddArray, numFanouts + 1);
  if (jointSupportBdd == NULL) return (0);
  Cudd_Ref(jointSupportBdd);

  /* Store all BDDs in bddPool locally */
  nodeBddPool = BDS_StoreBddPoolLocal(bddmgr, node->localBdd);
  fanouts = lsStart(node->fanouts);
  i = 0;
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    fanoutBddPool[i] = BDS_StoreBddPoolLocal(bddmgr, fanode->localBdd);
    i++;
  }
  lsFinish(fanouts);

  /* Find out dummy ~ real correspondency */
  numDummyVar = Cudd_SupportSize(bddmgr, jointSupportBdd);
  real2dummy = ALLOC(int, bddmgr->size);
  jointSupport = ALLOC(int, numDummyVar);

  scan = jointSupportBdd;
  i = 0;
  while (!cuddIsConstant(scan)) {
    jointSupport[i] = Cudd_NodeReadIndex(scan);
    i++;
    scan = cuddT(scan);
  }
  Cudd_RecursiveDeref(bddmgr, jointSupportBdd);

  microbddmgr = startCudd(option, 0);
  if (microbddmgr == NULL) fail("2");

#ifndef DEBUG
  Cudd_SetStdout(microbddmgr, recdfp);
#endif

  /* Create dummy variables in new bddmgr */
  for (i = 0; i < numDummyVar; i++) {
    dummyVar = Cudd_bddNewVar(microbddmgr);
    if (dummyVar == NULL) exit(2);
    Cudd_Ref(dummyVar);

    real2dummy[jointSupport[i]] = i;
  }

  /* Start to build dummy BDDs in the microbddmgr. Get BDD node before compose */
  nodeDummyBdd = bdsBuildDDFromBddPoolLocalWithOutCreateDummy(microbddmgr, nodeBddPool, real2dummy);
  if (nodeDummyBdd == NULL) fail("2");
  nodeDummyIndex = real2dummy[node->localVar];
  for (i = 0; i < numFanouts; i++) {
    fanoutDummyBdds[i] = bdsBuildDDFromBddPoolLocalWithOutCreateDummy(microbddmgr, fanoutBddPool[i], real2dummy);
    if (fanoutDummyBdds[i] == NULL) fail("2");
  }
  fanoutDummyBdds[i] = nodeDummyBdd;
  option->reordering = CUDD_REORDER_SIFT;
  BDS_Reorder(microbddmgr, NULL, option);

  numOnFanoutsOld = Cudd_SharingSize(fanoutDummyBdds, numFanouts + 1);

  /* Compose node BDD into all it fanouts */
  fanouts = lsStart(node->fanouts);
  i = 0;
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    composedBddArray[i] = Cudd_bddCompose(microbddmgr, fanoutDummyBdds[i], nodeDummyBdd, nodeDummyIndex);
    if (composedBddArray[i] == NULL) fail("2");
    Cudd_Ref(composedBddArray[i]);
    Cudd_RecursiveDeref(microbddmgr, fanoutDummyBdds[i]);
    i++;
  }
  lsFinish(fanouts);
  Cudd_RecursiveDeref(microbddmgr, nodeDummyBdd);
  option->reordering = CUDD_REORDER_SIFT;
  BDS_Reorder(microbddmgr, NULL, option);

  numOnFanoutsNew = Cudd_SharingSize(composedBddArray, numFanouts);

  no_support = BDS_SupportArray(bddmgr, *composedBddArray, &no_fanins);
  if (no_support == NULL) return (0);

  /* Calculate gain */
  gain = numOnFanoutsNew - numOnFanoutsOld;

  /*gain = no_fanins;*/

  FREE(jointSupport);
  FREE(composedBddArray);
  FREE(real2dummy);
  FREE(fanoutDummyBdds);
  FREE(fanoutBddArray);
  FREE(fanoutBddPool);
  Cudd_Quit(microbddmgr);

  return (gain);

} /* end of BDS_CheckEliminateGainWithReorder */

/**Function********************************************************************

  Synopsis    [Calculate the gain of eliminating node]

  Description [localBdd on node and localBdds on all its fanouts are reordered first.
  Then localBdd on node is composed into all its fanouts. Reorder the composed BDD again.
  Compare the total number of BDD nodes before and after composition. To prevent from
  carrying large number of empty BDD variables along with the reordering, a new bddmgr
  is initialized. All operations mentioned above are carried out in this new bddmgr.
  Return gain if successful; exit(2) otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_CheckEliminateGainWithReorderOld(
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option) {
  int result, numFanouts, i;
  int *real2dummy, *dummy2realId, dummyIndex, realIndex, numDummyVar, nodeDummyIndex;
  DdManager *microbddmgr;
  DdNode *dummyVar, *nodeDummyBdd, **fanoutDummyBdds, *composedBdd;
  lsGen fanouts, fanins;
  BnetNode *fanode;
  int numOnNode, numOnFanoutsOld, numOnFanoutsNew;
  SopPool *nodeBddPool, **fanoutBddPool;
  st_table *visited;
  int gain;

  /* Figure out how many dummyVar may need */
  numDummyVar = lsLength(node->fanins);
  fanouts = lsStart(node->fanouts);
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    numDummyVar += lsLength(fanode->fanins);
  }
  lsFinish(fanouts);

  real2dummy = ALLOC(int, bddmgr->size);
  dummy2realId = ALLOC(int, numDummyVar);
  visited = st_init_table(st_ptrcmp, st_ptrhash);

  /* Store real localBdd on node and all its fanouts */
  nodeBddPool = BDS_DumpSopLocal(bddmgr, node->localBdd);
  if (nodeBddPool == NULL) fail("2");

  numFanouts = lsLength(node->fanouts);
  fanoutBddPool = ALLOC(SopPool *, numFanouts);
  fanoutDummyBdds = ALLOC(DdNode *, numFanouts + 1);
  fanouts = lsStart(node->fanouts);
  i = 0;
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    fanoutBddPool[i] = BDS_DumpSopLocal(bddmgr, fanode->localBdd);
    if (fanoutBddPool[i] == NULL) fail("2");
    i++;
  }
  lsFinish(fanouts);

  microbddmgr = startCudd(option, 0);
  if (microbddmgr == NULL) fail("2");

  /*
  #ifndef DEBUG
  Cudd_SetStdout(microbddmgr, recdfp);
  #endif
   */

  /* Initialize new bdd variables in the new microbddmgr. node first, then its fanouts */
  result = bdsCreateDummyVar(microbddmgr, node, &real2dummy, &dummy2realId, visited);
  if (result == 0) fail("2");

  fanouts = lsStart(node->fanouts);
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    result = bdsCreateDummyVar(microbddmgr, fanode, &real2dummy, &dummy2realId, visited);
    if (result == 0) fail("2");
  }
  lsFinish(fanouts);

  /* Get the varId to be composed */
  if (!st_lookup(visited, (char *) node, (char **) &dummyVar)) {
    fail("2");
  }
  nodeDummyIndex = Cudd_NodeReadIndex(dummyVar);
  st_free_table(visited);

  /* Start to build dummy BDDs in the microbddmgr. Get BDD node information before compose */
  nodeDummyBdd = BDS_BuildDDFromSopLocal(microbddmgr, nodeBddPool, real2dummy, option);
  if (nodeDummyBdd == NULL) fail("2");
  for (i = 0; i < numFanouts; i++) {
    fanoutDummyBdds[i] = BDS_BuildDDFromSopLocal(microbddmgr, fanoutBddPool[i], real2dummy, option);
    if (fanoutDummyBdds[i] == NULL) fail("2");
  }
  fanoutDummyBdds[i] = nodeDummyBdd;
  option->reordering = CUDD_REORDER_SIFT;
  BDS_Reorder(microbddmgr, NULL, option);

  numOnFanoutsOld = Cudd_SharingSize(fanoutDummyBdds, numFanouts + 1);

  /* Compose node BDD into all it fanouts */
  fanouts = lsStart(node->fanouts);
  i = 0;
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    composedBdd = Cudd_bddCompose(microbddmgr, fanoutDummyBdds[i], nodeDummyBdd, nodeDummyIndex);
    if (composedBdd == NULL) fail("2");
    Cudd_Ref(composedBdd);
    i++;
  }
  lsFinish(fanouts);
  option->reordering = CUDD_REORDER_SIFT;
  BDS_Reorder(microbddmgr, NULL, option);

  numOnFanoutsNew = Cudd_SharingSize(fanoutDummyBdds, numFanouts);

  /* Constant node 1 is counted twice */
  gain = numOnFanoutsNew - numOnFanoutsOld;

  FREE(real2dummy);
  FREE(dummy2realId);
  FREE(fanoutDummyBdds);
  BDS_FreeSOP(nodeBddPool);
  for (i = 0; i < numFanouts; i++) {
    BDS_FreeSOP(fanoutBddPool[i]);
  }
  Cudd_Quit(microbddmgr);

  return (gain);

} /* end of BDS_CheckEliminateGainWithReorderOld */

/**Function********************************************************************

  Synopsis    [Create dummy var]

  Description [Dummy variables are created for all fanins of node. Return 1 if
  successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
bdsCreateDummyVar(
 DdManager *bddmgr,
 BnetNode *node,
 int **real2dummy,
 int **dummy2realId,
 st_table *visited) {
  lsGen fanins;
  int dummyIndex, realIndex;
  DdNode *dummyVar;
  BnetNode *fanode;

  fanins = lsStart(node->fanins);
  while (lsNext(fanins, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    if (st_is_member(visited, (char *) fanode)) continue;

    dummyVar = Cudd_bddNewVar(bddmgr);
    if (dummyVar == NULL) return (0);
    Cudd_Ref(dummyVar);

    dummyIndex = Cudd_NodeReadIndex(dummyVar);
    realIndex = fanode->localVar;

    (*real2dummy)[realIndex] = dummyIndex;
    (*dummy2realId)[dummyIndex] = realIndex;

    if (st_add_direct(visited, (char *) fanode, (char *) dummyVar) == ST_OUT_OF_MEM) {
      printf("Out of memory");
      return (0);
    }
  }
  lsFinish(fanins);

  return (1);

} /* end of bdsCreateDummyVar */

/**Function********************************************************************

  Synopsis    [Calculate the gain of eliminating node]

  Description [localBdd on node is composed into all its fanouts. Number of BDD
  nodes are compared. Return gain if successful; exit(2) otherwise]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_CheckEliminateGainWithOutReorder(
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option) {
  int result, i;
  int numOnFanoutsOld, numOnFanoutsNew, numFanout;
  lsGen fanouts;
  BnetNode *fanode;
  DdNode *nodeBdd, **fanoutBddArray;
  int gain;
  int no_fanins, *no_support;

  nodeBdd = node->localBdd;
  /* Build BDD array */
  numFanout = lsLength(node->fanouts);
  fanoutBddArray = ALLOC(DdNode *, numFanout + 1);

  i = 0;
  fanouts = lsStart(node->fanouts);
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    fanoutBddArray[i] = fanode->localBdd;
    i++;
  }
  lsFinish(fanouts);
  fanoutBddArray[i] = nodeBdd; /* the last element of the array is nodeBDD itself */

  numOnFanoutsOld = Cudd_SharingSize(fanoutBddArray, numFanout + 1);

  /* Compose localBdd on node into its fanouts */
  result = BDS_ComposeIntoFanouts(bddmgr, node, option); /* put the composed BDD into fanout->tmpBdd */
  if (result == 0) {
    printf("Bdd composition failed in BDS_CheckEliminateGain!");
    exit(2);
  }

  fanouts = lsStart(node->fanouts);
  i = 0;
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    fanoutBddArray[i] = fanode->tmpBdd; /* tmpBdd is the new composed BDD of the fanout node */
    i++;
  }
  lsFinish(fanouts);

  numOnFanoutsNew = Cudd_SharingSize(fanoutBddArray, numFanout);

  no_support = BDS_SupportArray(bddmgr, *fanoutBddArray, &no_fanins);
  if (no_support == NULL) return (0);

  /* Constant node 1 is counted twice */
  gain = numOnFanoutsNew - numOnFanoutsOld;

  FREE(fanoutBddArray);
  return (gain);

} /* end of BDS_CheckEliminateGainWithoutReorder */

/**Function********************************************************************

  Synopsis    [Compose the BDD on the node into its fanouts]

  Description [The BDD on this node is composed into its fanouts, one by one.
  Return 1 if successful; 0 otherwise]

  SideEffects [tmpBdd field on the fanout nodes is used to store results.]

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_ComposeIntoFanouts(
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option) {
  int retVal = 1;
  BnetNode *fanode;
  lsGen fanouts;
  int localId; /* index of local variable on the node */
  DdNode *localBdd; /* local BDD on the node */
  DdNode *fanoutBdd; /* local BDD on the fanout node */
  DdNode *composedBdd;

  localId = node->localVar;
  localBdd = node->localBdd;

  fanouts = lsStart(node->fanouts);
  while (lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE) {
    fanoutBdd = fanode->localBdd;
    composedBdd = Cudd_bddCompose(bddmgr, fanoutBdd, localBdd, localId);
    if (composedBdd == NULL) {
      retVal = 0;
      break;
    } else { /* Put the composedBdd into tmpBdd on the fanode */
      Cudd_Ref(composedBdd);
      fanode->tmpBdd = composedBdd;
    }
  }
  lsFinish(fanouts);

  return (retVal);

} /* end of BDS_ComposeIntoFanouts */

/**Function********************************************************************

  Synopsis    [Eliminate all internal nodes which are functional duplication of
  other internal nodes. Global BDDs are used to detect functional equivalent
  node. Return 1 if successful; 0 otherwise]

  Description [This function is of little use when the test case is large.]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
extern
int
BDS_EliminateBasedOnGlobal(
 DdManager *bddmgr,
 BnetNetwork *net,
 bdsOptions *option) {
  return (1);

} /* end of BDS_EliminateBasedOnGlobal */

/**Function********************************************************************

  Synopsis    [Free Boolean network]

  Description [The Boolean network is different from the original one becasue of
  the eliminate process. ]

  SideEffects []

  SeeAlso     []

 *****************************************************************************/
extern
void
BDS_FreeNetworkAfterEliminate(
 BnetNetwork *net) {
  int i;
  BnetNode *node;
  BnetTabline *line, *nextline;
  st_generator *gen;

  gen = st_init_gen(net->livenodes);
  while (st_gen(gen, (char **) &node, NULL)) {

    /* Free all input names on the original node */
    for (i = 0; i < node->ninp; i++) {
      FREE(node->inputs[i]);
    }
    if (node->inputs != NULL) FREE(node->inputs);

    /* Free table line */
    line = node->f;
    while (line != NULL) {
      nextline = line->next;
      FREE(line->values);
      FREE(line);
      line = nextline;
    }
    //if ((node->name) != NULL)
    // FREE(node->name);

   // if (node->fanins != NULL) lsDestroy(node->fanins, NULL);
   //  if (node->fanouts != NULL) lsDestroy(node->fanouts, NULL);
   // if (node != NULL)
   // FREE(node);
  }
  st_free_gen(gen);

  return;

} /* end of BDS_FreeNetworkAfterEliminate */

/**Function********************************************************************

  Synopsis    [Eliminating nodes on critical path for Delay re-synthesis]

  Description [Collapsing identified nodes on critical paths for Delay re-synthesis phase
               some replicated logic nodes may be created in the process.
               (Navin's paper: Page 18 Section 5.1.2)
               Node in the tobeRemovedTbl are composed into their fanouts,
               then the node is freed. Boolean network is updated.
               Return 1 if successful; 0 otherwise]

  SideEffects [The connectivity and overall structure of the Boolean network is changed]

  SeeAlso     []

 *****************************************************************************/
static
int
BDS_DelayEliminateExecute(
 DdManager *bddmgr,
 BnetNetwork *net,
 bdsOptions *option,
 st_table *delayNodeTbl,
 int globalReady) {
  int iter = 0;
  st_generator *gen, *net_gen;
  BnetNode *node, *fanode, *fanin_node, *fanout_node, *dummy_node;
  BnetNode *net_node;
  lsGen fanouts, fanins, fanin_node_fanout;
  int nodeLocalId, gen_index;
  DdNode *nodeLocalBdd, *composedBdd, *fanoutBdd;
  int doIexecute = 0;
  int no_nodes = 1;

  /* eliminate node one by one, update the boolean network */

  printf("\nCollapsing Critical path ");
  net_gen = st_init_gen(net->livenodes);

  while (st_gen(net_gen, (char **) &node, NULL)) {
    if (node->type == BNET_CONSTANT_NODE || node->type == BNET_INPUT_NODE || node->type == BNET_OUTPUT_NODE)
      continue;

    if (st_is_member(delayNodeTbl, (char *) node)) {

      iter++;
      if (iter > 1000)
        return (1);

      printf("#");


#ifndef DEBUG
      (void) printf(".");
      (void) fflush(stdout);
#endif

      nodeLocalId = node->localVar;
      nodeLocalBdd = node->localBdd;
      fanouts = lsStart(node->fanouts);
      doIexecute = 0;
      while ((lsNext(fanouts, (lsGeneric *) & fanode, NULL) != LS_NOMORE)) {

        fanode->collapsed = 1;

        if (fanode->crit_node == 0) {
          doIexecute = 1; /* do not execute */
          continue;
        }

        fanode->crit_node = 1;
        fanoutBdd = fanode->localBdd;
        composedBdd = Cudd_bddCompose(bddmgr, fanoutBdd, nodeLocalBdd, nodeLocalId);
        if (composedBdd == NULL) return (0);
        Cudd_Ref(composedBdd);
        Cudd_RecursiveDeref(bddmgr, fanode->localBdd);
        fanode->localBdd = composedBdd;

        /* Move fanins of node to fanode */
        fanins = lsStart(node->fanins);
        while (lsNext(fanins, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {
          if (lsNewEnd(fanode->fanins, (lsGeneric) fanin_node, NULL) != LS_OK) {
            printf("Out of memory");
            return (0);
          }
        }
        lsFinish(fanins);

        /* Remove possible duplications */
        (void) lsSort(fanode->fanins, bdsUniqueBnetNode);
        (void) lsUniq(fanode->fanins, bdsUniqueBnetNode, NULL);

        /* Remove node from fanode's fanin list */
        fanins = lsStart(fanode->fanins);
        while (lsNext(fanins, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {
          if (fanin_node == node) {
            (void) lsDelBefore(fanins, (lsGeneric*) & dummy_node);
            break;
          }
        }
        lsFinish(fanins);

        /* Update the fanouts of fanin_node. Add fanode to fanin_node's fanout list */
        fanins = lsStart(node->fanins);
        while (lsNext(fanins, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {

          /* The following line is commented out to fix a bug. When the fanout
           ** of a PI node is changed, the fanout field of that PI should also
           ** be updated. The bug was found in the implementation of sharing extraction
           ** -cyang 5/24/99
          if (fanin_node->type == BNET_INPUT_NODE) continue;
           */

          if (lsNewEnd(fanin_node->fanouts, (lsGeneric) fanode, NULL) != LS_OK) {
            printf("Out of memory");
            return (0);
          }
        }
        lsFinish(fanins);
      }/* End of 1st while loop with lsStart(fanouts) */
      lsFinish(fanouts);
      node->crit_node = 1;

      if (doIexecute == 0) {
        /* Remove node from fanin_node's fanout list before node is freed */
        fanins = lsStart(node->fanins);
        while ((lsNext(fanins, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE)) {

          /* The following line is commented out. See explanation above. -cyang 5/24/99
          if (fanin_node->type == BNET_INPUT_NODE) continue;
           */

          fanin_node_fanout = lsStart(fanin_node->fanouts);
          while (lsNext(fanin_node_fanout, (lsGeneric *) & fanout_node, NULL) != LS_NOMORE) {
            if (fanout_node == node) {
              (void) lsDelBefore(fanin_node_fanout, (lsGeneric*) & dummy_node);
              break;
            }
          }
          lsFinish(fanin_node_fanout);

          /* Remove possible duplications */
          (void) lsSort(fanin_node->fanouts, bdsUniqueBnetNode);
          (void) lsUniq(fanin_node->fanouts, bdsUniqueBnetNode, NULL);
        }
        lsFinish(fanins);

        /* Since fanode already contains information of node, node can be freed */

        if (!st_delete(net->livenodes, (char **) &node, (char **) NULL)) {
          return (0);
        }
        (void) bdsFreeOneBnetNode(bddmgr, node, globalReady);
      }
    }
  }
  st_free_gen(net_gen);

  return (1);

} /* end of BDS_DelayEliminateExecute */

BDS_sorting_on_depth(s1, s2)
BnetNode **s1;
BnetNode **s2;

{
  BnetNode *ssink1;
  BnetNode *ssink2;

  ssink1 = *s1;
  ssink2 = *s2;

  /*  if(ssink1->measure < ssink2->measure)  return (1);
  if(ssink1->measure > ssink2->measure)  return (-1);*/

  if (ssink1->depth < ssink2->depth) return (-1); /*  it is -1 originally*/
  if (ssink1->depth > ssink2->depth) return ( 1);
  return 0;
}

/**Function********************************************************************

  Synopsis    [Prints a boolean network created by readNetwork.]

  Description [Prints to the standard output a boolean network created
  by Bnet_ReadNetwork. Uses the blif format; this way, one can verify the
  equivalence of the input and the output with, say, sis.]

  SideEffects [None]

  SeeAlso     [Bnet_ReadNetwork]

 ******************************************************************************/
static
int
BDS_PrintMod(
 BnetNetwork *net,
 DdManager *bddmgr,
 bdsOptions *option) {
  BnetNode *nd, *fanin_node;
  BnetTabline *tl;
  int i, signals = 0, counter = 0;
  st_generator *net_gen;
  lsGen fan_in;
  float price = 0.0;

  if (net == NULL) return;

  (void) fprintf(stdout, ".model %s\n", net->name);
  (void) fprintf(stdout, ".inputs");
  outputList(net->inputs, net->npis);
  (void) fprintf(stdout, ".outputs");
  outputList(net->outputs, net->npos);
  for (i = 0; i < net->nlatches; i++) {
    (void) fprintf(stdout, ".latch");
    outputList(net->latches[i], 3);
  }

  net_gen = st_init_gen(net->livenodes);
  while (st_gen(net_gen, (char **) &nd, NULL)) {

    if (nd->type != BNET_INPUT_NODE && nd->type != BNET_PRESENT_STATE_NODE) {

      (void) fprintf(stdout, ".names");
      signals = 0;
      fan_in = lsStart(nd->fanins);
      while (lsNext(fan_in, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {
        (void) fprintf(stdout, " %s", fanin_node->name);
        signals++;
      }
      nd->ninp = signals;
      lsFinish(fan_in);


      (void) fprintf(stdout, " %s\n", nd->name);
      if ((nd->crit_node == 1) && (nd->ninp > 5)) {
        counter++;
        (void) debugDump(bddmgr, &nd->localBdd, price, option, counter);
      }
      tl = nd->f;
      while (tl != NULL) {
        if (tl->values != NULL) {
          (void) fprintf(stdout, "%s %d\n", tl->values,
           1 - nd->polarity);
        } else {
          (void) fprintf(stdout, "%d\n", 1 - nd->polarity);
        }
        tl = tl->next;
      }
    }

  }
  st_free_gen(net_gen);
  (void) fprintf(stdout, ".end\n");
  return (1);
} /* end of Bnet_PrintModifiedNetwork */

/**Function********************************************************************

  Synopsis    [Prints a list of strings to the standard output.]

  Description [Prints a list of strings to the standard output. The list
  is in the format created by readList.]

  SideEffects [None]

  SeeAlso     [readList Bnet_PrintNetwork]

 ******************************************************************************/
static
void
outputList(
 char ** list /* list of pointers to strings */,
 int n /* length of the list */) {
  int i;

  for (i = 0; i < n; i++) {
    (void) fprintf(stdout, " %s", list[i]);
  }
  (void) fprintf(stdout, "\n");

} /* end of printList */

EXTERN
int
BDS_GetInputs(
 BnetNode *node) {
  int signals = 0;
  lsGen fan_in;
  BnetNode *fanin_node;

  if (node->type != BNET_INPUT_NODE && node->type != BNET_PRESENT_STATE_NODE) {

    fan_in = lsStart(node->fanins);
    while (lsNext(fan_in, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {
      signals++;
    }
    lsFinish(fan_in);
    return (signals);
  }
}

/**Function********************************************************************

  Synopsis    [Prints the boolean network in Delay re-synthesis phase]

  Description [Prints the network with the supernode for critical path and replicated
               logic nodes and the unchanged nodes together to .delay BLIF file to
               do manual extraction of the collapsed nodes to do simplification in
               Espresso.]

  SideEffects [None]

  SeeAlso     []

 ******************************************************************************/
extern
void
PrintNet2Blif(
 BnetNetwork *net,
 DdManager *bddmgr,
 bdsOptions *option,
 FILE *fileBlif) {
  BnetNode *nd2;
  st_generator *net_gen2;
  int retval;
  DdNode **outputs = NULL;
  char **inamesTemp;
  char **inames;
  char **onames;
  BnetNode *nd, *fanin_node;
  BnetTabline *tl;
  int i, signals = 0, counter = 0;
  st_generator *net_gen;
  lsGen fan_in;
  float price = 0.0;

  if (net == NULL) return;

  (void) fprintf(fileBlif, ".model %s\n", net->name);
  (void) fprintf(fileBlif, ".inputs");
  i = 0;
  for (i = 0; i < net->npis; i++) {
    (void) fprintf(fileBlif, " %s", net->inputs[i]);
  }
  (void) fprintf(fileBlif, "\n");

  (void) fprintf(fileBlif, ".outputs");
  i = 0;
  for (i = 0; i < net->npos; i++) {
    (void) fprintf(fileBlif, " %s", net->outputs[i]);
  }
  (void) fprintf(fileBlif, "\n");

  outputs = ALLOC(DdNode *, 1);
  inamesTemp = ALLOC(char *, 50);
  inames = ALLOC(char *, Cudd_ReadSize(bddmgr));
  onames = ALLOC(char *, 1); ///a
  printf("Cudd_ReadSize(bddmgr) or bddmgr->size: %i\n", bddmgr->size);

  net_gen = st_init_gen(net->livenodes);
  while (st_gen(net_gen, (char **) &nd, NULL)) {

    if (nd->type != BNET_INPUT_NODE && nd->type != BNET_PRESENT_STATE_NODE) {

      (void) fprintf(fileBlif, ".names");
      signals = 0;
      i = 0;
      fan_in = lsStart(nd->fanins);
      while (lsNext(fan_in, (lsGeneric *) & fanin_node, NULL) != LS_NOMORE) {
        (void) fprintf(fileBlif, " %s", fanin_node->name);
        inamesTemp[i] = fanin_node->name;
        i++;
        signals++;
      }
      lsFinish(fan_in);

      if (nd->crit_node == 1) {
        printf("signals: %i\n", signals);
        net_gen2 = st_init_gen(net->livenodes);
        while (st_gen(net_gen2, (char **) &nd2, NULL)) {
          i = 0;
          for (i = 0; i < signals; i++) {
            if (strcmp((nd2->name), (inamesTemp[i])) == 0) {
              inames[nd2->localVar] = nd2->name;
              printf("nd2->name: %s, nd2->localVar: %i\n", nd2->name, nd2->localVar);
            }
          }
        }
        st_free_gen(net_gen2);
      }

      (void) fprintf(fileBlif, " %s\n", nd->name);
      onames[0] = nd->name;
      if (nd->crit_node == 1) {
        outputs[0] = nd->localBdd;
        retval = Cudd_DumpBlif(bddmgr, 1, outputs, inames, onames, NULL, fileBlif, 0);
      } else {
        tl = nd->f;
        while (tl != NULL) {
          if (tl->values != NULL) {
            (void) fprintf(fileBlif, "%s %d\n", tl->values, 1 - nd->polarity);
          } else {
            (void) fprintf(fileBlif, "%d\n", 1 - nd->polarity);
          }
          tl = tl->next;
        }
      }
    }
  }
  FREE(outputs);
  FREE(inamesTemp);
  FREE(inames);
  FREE(onames);
  st_free_gen(net_gen);
  (void) fprintf(fileBlif, ".end\n");
  return;
} /* end of PrintNet2Blif */
