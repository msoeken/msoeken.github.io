
/**CFile***********************************************************************

  FileName    [build.c]

  PackageName [BDS-pga]

  Synopsis    [This file contains the functions for building global and local
  BDDs from boolean network.]

  Description [BDD construction functions. ntrInitializeCount and ntrCountDFS
  are borrowed from nanotrav.]

  SeeAlso     []

  Author      [Congguang Yang]

 ******************************************************************************/

#include "lopt.h"
#include "build.h"
#include "cuddInt.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

#define NTR_MAX_DEP_SIZE 20

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/**AutomaticStart*************************************************************/

/*---------------------------------------------------------------------------*/
/* Static function prototypes                                                */
/*---------------------------------------------------------------------------*/

static int BDS_BuildGlobalNodeBDD ARGS((DdManager*, BnetNode*, bdsOptions*, int*));
static int BDS_BuildLocalNodeBDD ARGS((DdManager*, BnetNode*, bdsOptions*));
static int BDS_BuildLocalNodeBDD_ ARGS((DdManager*, BnetNode*, bdsOptions*, int order, DdNode *decomposed, DdNode * dominator));
static int bdsFreePartialBddsRecursive ARGS((DdManager*, BnetNode*, bdsOptions*, st_table*));
static void ntrInitializeCount ARGS((BnetNetwork *net, bdsOptions *option));
static void ntrCountDFS ARGS((BnetNetwork *net, BnetNode *node));

/**AutomaticEnd***************************************************************/

/*---------------------------------------------------------------------------*/
/* Definition of exported functions                                          */
/*---------------------------------------------------------------------------*/

/**Function********************************************************************

  Synopsis    [Builds DDs for a network outputs.]

  Description [Builds DDs for a network output. Return 1 in case of success;
  0 otherwise. To make more freedom for individual output, each BDD manager is
  started for each output.]

  SideEffects [the dd fields of the network nodes are modified. Uses the
  count fields of the nodes.]

  SeeAlso     []

 ******************************************************************************/
extern
int
BDS_buildDDs(
 BnetNetwork * net,
 DdManager *bddmgr,
 BnetNode *POnode,
 bdsOptions * option) {
  int pr = option->verb;
  int result;
  int i, j; /* loop indices  */
  BnetNode *node, *tmpnode;

  /* Build BDD for each variable */
  if (option->order == PI_PS_FROM_FILE) { /* Only case supported in BDS. */
    /* Follow order given in input file */
    for (j = 0; j < net->npis; j++) {
      if (!st_lookup(net->hash, net->inputs[j], (char **) &node)) {
        return (0);
      }
      result = BDS_BuildNodeBDD(bddmgr, node, net->hash);
      if (result == 0) return (0);
    }
  }

  ntrInitializeCount(net, option);

  /* Check input-output relation. This will prevent do BDD decomposition
     on circuits with the same input and output.
   */
  if (POnode->dd != NULL) {
    printf("\nWARNING: PO output %s is used as input to other nodes !\n", POnode->name);
    printf("\t Please check input circuit.\n");
  }

  result = BDS_BuildNodeBDD(bddmgr, POnode, net->hash);
  if (result == 0) return (0);

  /* Make sure all inputs have a DD and dereference the DDs of
     the nodes that are not reachable from the outputs.
   */
  for (j = 0; j < net->npis; j++) {
    if (!st_lookup(net->hash, net->inputs[j], (char **) &node)) {
      return (0);
    }
    result = BDS_BuildNodeBDD(bddmgr, node, net->hash);
    if (result == 0) return (0);
    if (node->count == -1) Cudd_RecursiveDeref(bddmgr, node->dd);
  }

  /* clean up the parameter associated with node. For example, node->dd = TRUE after
     one round, must be cleaned up before the next, otherwise the next round
     will pick up the wrong BDD at that node.  THIS CLEANUP SHOULD NOT INCLUDE PO.
     All INTERNAL BDDs should BE FREED. All PI->active must remain TRUE.
   */
  tmpnode = net->nodes;
  while (tmpnode != NULL) {
    if ((tmpnode->type == BNET_INTERNAL_NODE) && (tmpnode->dd != NULL)) {
      Cudd_IterDerefBdd(bddmgr, tmpnode->dd);
      tmpnode->dd = NULL;
      tmpnode->active = FALSE;
    } else if ((tmpnode->type == BNET_INPUT_NODE) && (tmpnode->dd != NULL)) {
      Cudd_IterDerefBdd(bddmgr, tmpnode->dd);
      tmpnode->dd = NULL;
    }
    tmpnode = tmpnode->next;
  }

  return (1);

} /* end of buildDD */

/**Function********************************************************************

  Synopsis    [Build global BDDs for the Boolean network]

  Description [Global BDDs are built in dfs fashion. gloabl field in each node
  is updated. Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     [BDS_BuildLocalBDD]

  LastDate    [3/22/99]

 ******************************************************************************/
extern
int
BDS_BuildGlobalBDD(
 DdManager *bddmgr,
 BnetNetwork *net,
 bdsOptions *option,
 int *globalReady) {
  int result, i;
  int globalUnable = 0; /* 0: global BDD ready; 1: not being able to build */
  BnetNode *node;
  st_table *visited; /* Used to free BDDs */

  printf("Constructing global BDDs ");
  (void) fflush(stdout);

  /* Create each variable in file order if dfs is not specified
   */
  if (option->order == PI_PS_FROM_FILE) {
    for (i = 0; i < net->npis; i++) {
      if (!st_lookup(net->hash, net->inputs[i], (char **) &node)) {
        return (0);
      }
      result = BDS_BuildGlobalNodeBDD(bddmgr, node, option, &globalUnable);
      if (result == 0) return (0);
    }
  }

  ntrInitializeCount(net, option); /// Initializes the count fields used to drop DDs.

  for (i = 0; i < net->npos; i++) {
    if (!st_lookup(net->hash, net->outputs[i], (char **) &node)) {
      continue;
    }
    result = BDS_BuildGlobalNodeBDD(bddmgr, node, option, &globalUnable);
    if (result == 0) return (0);
    if (globalUnable == 1) break;
  }

  /* Make sure all inputs have a DD and dereference the DDs of
   ** the nodes that are not reachable from the outputs.
   */
  for (i = 0; i < net->npis; i++) {
    if (!st_lookup(net->hash, net->inputs[i], (char **) &node)) {
      return (0);
    }
    result = BDS_BuildGlobalNodeBDD(bddmgr, node, option, &globalUnable);
    if (result == 0) return (0);
    if (node->count == -1) Cudd_RecursiveDeref(bddmgr, node->dd);
  }

  /* If global BDDs can not be built. BDDs which are partially built must be freed
   */
  if (globalUnable == 1) {
    visited = st_init_table(st_ptrcmp, st_ptrhash);
    for (i = 0; i < net->npos; i++) {
      if (!st_lookup(net->hash, net->outputs[i], (char **) &node)) {
        continue;
      }
      if (node->dd != NULL) {
        result = bdsFreePartialBddsRecursive(bddmgr, node, option, visited);
        if (result == 0) return (0);
      }
    }
    st_free_table(visited);

    printf("Aborted\n\n");
    *globalReady = 0;
    return (1);
  }

  /* All BDDs on the internal nodes should be preserved for global elimination
   */

  printf("Done\n\n");
  *globalReady = 1;
  return (1);

} /* end of BDS_BuildGlobalBDD */

/**Function********************************************************************

  Synopsis    [Build global BDDs for a node]

  Description [iGlobal BDDs are built in dfs fashion. At any node, if the size
  of total nodes is larger than option->globalLimit, the process is aborted.
  To comply with future implementation, all traversal on Bnet is through
  fanins and fanouts. Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     [BDS_BuildLocalNodeBDD]

  LastDate    [3/22/99]

 ******************************************************************************/
static
int
BDS_BuildGlobalNodeBDD(
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option,
 int *globalUnable) {
  DdNode *func;
  DdNode *tmp, *prod, *var;
  BnetNode *auxnd;
  BnetTabline *line;
  lsGen fanins;
  int i;

  if (node->dd != NULL) return (1);

  /* If total number of BDD nodes is over limit, feedback logic zero. This will
   ** prevent BDD node from further increasing. We should let recirsive process
   ** to be finished. Othewise, the ref count on PI nodes will be messed up.
   */
  if (*globalUnable == 1 && node->type != BNET_CONSTANT_NODE) {
    node->dd = Cudd_ReadLogicZero(bddmgr);
    return (1);
  }

  if (node->type == BNET_CONSTANT_NODE) {
    if (node->f == NULL) { /* constant 0 */
      func = Cudd_ReadLogicZero(bddmgr);
    } else { /* either constant depending on the polarity */
      func = Cudd_ReadOne(bddmgr);
    }
    Cudd_Ref(func);
  } else if (node->type == BNET_INPUT_NODE) {
    if (node->active == TRUE) { /* a variable is already associated: use it */
      func = Cudd_ReadVars(bddmgr, node->var);
      if (func == NULL) fail("Serious error in BDS_BuildGlobalNodeBDD\n");
    } else { /* no variable associated: get a new one */
      func = Cudd_bddNewVar(bddmgr);
      if (func == NULL) fail("Serious error in BDS_BuildGlobalNodeBDD\n");
      node->var = func->index;
      node->active = TRUE;
    }
    Cudd_Ref(func);
  } else { /* node->type == BNET_INTERNAL_NODE or BNET_OUTPUT_NODE */
    /* Initialize the sum to logical 0.
     */
    func = Cudd_ReadLogicZero(bddmgr);
    Cudd_Ref(func);

    /* Build a term for each line of the table and add it to the accumulator (func).
     */
    line = node->f;
    while (line != NULL) {
      /* Initialize the product to logical 1. */
      prod = Cudd_ReadOne(bddmgr);
      Cudd_Ref(prod);

      /* Scan the table line. */
      i = 0;
      fanins = lsStart(node->fanins);
      while (lsNext(fanins, (lsGeneric *) & auxnd, NULL) == LS_OK) {
        if (line->values[i] == '-') {
          i++;
          continue;
        }
        if (auxnd->dd == NULL) {
          if (!BDS_BuildGlobalNodeBDD(bddmgr, auxnd, option, globalUnable)) {
            fail("Serious error in BDS_BuildGlobalNodeBDD\n");
          }
        }
        if (line->values[i] == '1') {
          var = auxnd->dd;
        } else { /* line->values[i] == '0' */
          var = Cudd_Not(auxnd->dd);
        }
        tmp = Cudd_bddAnd(bddmgr, prod, var);
        if (tmp == NULL) fail("Serious error in BDS_BuildGlobalNodeBDD\n");
        Cudd_Ref(tmp);
        Cudd_IterDerefBdd(bddmgr, prod);
        prod = tmp;
        i++;
      }
      lsFinish(fanins);

      tmp = Cudd_bddOr(bddmgr, func, prod);
      if (tmp == NULL) fail("Serious error in BDS_BuildGlobalNodeBDD\n");
      Cudd_Ref(tmp);
      Cudd_IterDerefBdd(bddmgr, func);
      Cudd_IterDerefBdd(bddmgr, prod);
      func = tmp;
      line = line->next;
    }

    /* If the total number of BDD nodes is larger than limit, global BDD construction
     ** is aborted. Since the global BDDs are constructed in dfs, the recursive process
     ** should allow to be finished; otherwise, bddmgr will be messy.
     */
    if (Cudd_ReadKeys(bddmgr) - Cudd_ReadDead(bddmgr) > option->globalLimit) {
      *globalUnable = 1;
    }
  }

#ifndef DEBUG
  (void) printf(".");
  (void) fflush(stdout);
#endif

  if (node->polarity == 1) {
    node->dd = Cudd_Not(func);
  } else {
    node->dd = func;
  }

  return (1);

} /* end of BDS_BuildGlobalNodeBDD */

/**Function********************************************************************

  Synopsis    [Free partially built globals BDDs]

  Description [Global BDDs are freed in dfs fashion. BDD on internal each node
  is freed only once. BDDs on input nodes are freed until no ref count on them.
  Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     []

  LastDate    [3/23/99]

 ******************************************************************************/
static
int
bdsFreePartialBddsRecursive(
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option,
 st_table *visited) {
  int result;
  lsGen fanins;
  BnetNode *fanode;

  if (node->type == BNET_CONSTANT_NODE) return (1);
  if (st_is_member(visited, (char *) node)) return (1);

  if (node->type == BNET_INPUT_NODE && node->active == TRUE) {
    Cudd_IterDerefBdd(bddmgr, node->dd);
    if (st_add_direct(visited, (char *) node, (char *) NULL) == ST_OUT_OF_MEM) {
      printf("Out of memory");
      return (0);
    }
    return (1);
  }

  /* Traverse dfs to the PIs */
  fanins = lsStart(node->fanins);
  while (lsNext(fanins, (lsGeneric *) & fanode, NULL) == LS_OK) {
    result = bdsFreePartialBddsRecursive(bddmgr, fanode, option, visited);
    if (result == 0) return (0);
  }
  lsFinish(fanins);

  /* Free global BDDs node by node */
  if (node->dd != NULL) {
    if (!Cudd_IsConstant(node->dd)) {
      Cudd_RecursiveDeref(bddmgr, node->dd);
      node->dd = NULL;
    } else { /* dd field is the dummy value when BDD construction is aborted */
      node->dd = NULL;
    }
  }
  if (st_add_direct(visited, (char *) node, (char *) NULL) == ST_OUT_OF_MEM) {
    printf("Out of memory");
    return (0);
  }

  return (1);

} /* end of bdsFreePartialBddsRecursive */

/**Function********************************************************************

  Synopsis    [Build local BDDs for the Boolean network]

  Description [Local BDDs are built in dfs fashion. New variables are created for
  each internal node. Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     [BDS_BuildGlobalBDD]

  LastDate    [3/23/99]

 ******************************************************************************/
extern
int
BDS_BuildLocalBDD(
 DdManager *bddmgr,
 BnetNetwork *net,
 bdsOptions *option) {
  int result, i;
  BnetNode *node;

  (void) printf("Constructing local BDDs ");

  /* Since global BDDs may not successfully built on the network, in case of
   ** dfs variable order, some PI variables may have not been created. All PIs
   ** are visited to make sure variable in bddmgr has been created. This will
   ** make all PIs have small id in the bddmgr.
   */
  for (i = 0; i < net->npis; i++) {
    if (!st_lookup(net->hash, net->inputs[i], (char **) &node)) {
      return (0);
    }
    result = BDS_BuildLocalNodeBDD(bddmgr, node, option);
    if (result == 0) return (0);
  }

  /* Build local BDDs for all internal nodes in dfs fashion. */
  for (i = 0; i < net->npos; i++) { /// for each primary output of net
    if (!st_lookup(net->hash, net->outputs[i], (char **) &node)) {
      continue;
    }
    result = BDS_BuildLocalNodeBDD(bddmgr, node, option);
    if (result == 0) return (0);
  }

  (void) printf("Done\n\n");
  return (1);

} /* end of BDS_BuildLocalBDD */

/**Function********************************************************************

  Synopsis    [Build local BDDs for a node]

  Description [Local BDDs are built in dfs fashion. Cases on constant and PI
  nodes are complicated. Because they may already be built in the global BDD
  phase, but that process was aborted due to over limit.
  Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     [BDS_BuildGlobalNodeBDD]

  LastDate    [3/23/99]

 ******************************************************************************/
static
int
BDS_BuildLocalNodeBDD(/// << for each bnode >>
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option) {
  DdNode *func, *tmp, *prod, *var, *localNewVar;
  BnetTabline *line;
  BnetNode *fanode;
  int i;
  lsGen fanins;

  /* If local BDD has been built on this node, local variable should have also
   ** been created. No need to traverse down further.
   */
  //printf("TYPE= %d\n  ; ", node->type);
  if (node->localBdd != NULL) return (1);

  if (node->type == BNET_CONSTANT_NODE) {
    if (node->f == NULL) { /* constant 0 */
      func = Cudd_ReadLogicZero(bddmgr);
    } else { /* either constant depending on the polarity */
      func = Cudd_ReadOne(bddmgr);
    }
    Cudd_Ref(func);
  } else if (node->type == BNET_INPUT_NODE) {
    if (node->localActive == TRUE) { /* a variable has been created */
      func = Cudd_ReadVars(bddmgr, node->localVar);
      if (func == NULL) return (0);
    } else if (node->active == TRUE) { /* a variable has been created during global */
      func = Cudd_ReadVars(bddmgr, node->var);
      if (func == NULL) return (0);
      node->localVar = node->var;
      node->localActive = TRUE;
    } else { /* create a new local variable */
      func = Cudd_bddNewVar(bddmgr);
      if (func == NULL) return (0);
      node->localVar = func->index;
      node->localActive = TRUE;
    }
    Cudd_Ref(func);
  } else { /* type == BNET_INTERNAL_NODE or BNET_OUTPUT_NODE */
    /* Initialize the sum to logical 0. */
    func = Cudd_ReadLogicZero(bddmgr);
    Cudd_Ref(func);

    line = node->f; /// line->values only has input values, output value is node->polarity
    while (line != NULL) { /// while there are more truth-table lines /// << for each truth-table line (wothout output value) >>
      /* Initialize the product to logical 1. */
      prod = Cudd_ReadOne(bddmgr);
      Cudd_Ref(prod);
      /* Scan the table line. */
      i = 0;
      fanins = lsStart(node->fanins);
      while (lsNext(fanins, (lsGeneric *) & fanode, NULL) == LS_OK) { /// << for each input value in a truth-table line >>
        if (line->values[i] == '-') { /// skip '_' only increase the position of the line
          i++;
          continue;
        }
        if (fanode->localActive == FALSE) { /// if a variable has not been created
          if (!BDS_BuildLocalNodeBDD(bddmgr, fanode, option)) { /// Recursive call to BDS_BuildLocalNodeBDD()
            return (0);
          }
        }
        var = Cudd_ReadVars(bddmgr, fanode->localVar);
        if (var == NULL) return (0);
        Cudd_Ref(var);
        if (line->values[i] == '0') { /// if value is '0', call Cudd_Not. If value is '1', doesn't need to call Cudd_Not
          var = Cudd_Not(var);
        }
        tmp = Cudd_bddAnd(bddmgr, prod, var);
        if (tmp == NULL) return (0);
        Cudd_Ref(tmp);
        Cudd_IterDerefBdd(bddmgr, prod);
        Cudd_IterDerefBdd(bddmgr, var);
        prod = tmp;
        i++;
      }
      lsFinish(fanins);

      tmp = Cudd_bddOr(bddmgr, func, prod);
      if (tmp == NULL) return (0);
      Cudd_Ref(tmp);
      Cudd_IterDerefBdd(bddmgr, func);
      Cudd_IterDerefBdd(bddmgr, prod);
      func = tmp;
      line = line->next; /// goto the next truth-table line of the linked-list
    }

    /* Create a new local variable */
    localNewVar = Cudd_bddNewVar(bddmgr);
    if (localNewVar == NULL) return (0);
    Cudd_Ref(localNewVar);
    node->localVar = localNewVar->index;
    node->localActive = TRUE;
    Cudd_IterDerefBdd(bddmgr, localNewVar);
  } /// end of if-else

#ifndef DEBUG
  (void) printf(".");
  (void) fflush(stdout);
#endif

  if (node->polarity == 1) {
    node->localBdd = Cudd_Not(func);
  } else {
    node->localBdd = func;
  }

  return (1);

} /* end of BDS_BuildLocalNodeBDD */

/******************************************************************************/
extern
int
BDS_BuildLocalBDD_(
 DdManager *bddmgr,
 BnetNetwork *net,
 bdsOptions *option,
 DdNode *decomposed,
 int *c_vars,
 int c_numvar,
 DdNode * dominator,
 int *d_vars,
 int d_numvar) {
  int result, i;
  BnetNode *node;

  (void) printf("Constructing local BDDs ");

  /* Since global BDDs may not successfully built on the network, in case of
   ** dfs variable order, some PI variables may have not been created. All PIs
   ** are visited to make sure variable in bddmgr has been created. This will
   ** make all PIs have small id in the bddmgr.
   */
  //printf("intput= %i\n",net->npis);
  for (i = 0; i < net->npis; i++) {
   //  printf("intput= %i\n",i);
    if (!st_lookup(net->hash, net->inputs[i], (char **) &node)) {
      return (0);
    }
    result = BDS_BuildLocalNodeBDD_(bddmgr, node, option, i, decomposed, dominator);
    if (result == 0) return (0);
  }
  // printf("here  ; \n");
  /* Build local BDDs for all internal nodes in dfs fashion. */
  for (i = 0; i < net->npos; i++) { /// for each primary output of net
    //  printf("output= %s\n",net->outputs[i]);
    if (!st_lookup(net->hash, net->outputs[i], (char **) &node)) {
      continue;
    }
   // printf(" i= %d\n", i);
    result = BDS_BuildLocalNodeBDD_(bddmgr, node, option, i, decomposed, dominator);
    if (result == 0) return (0);
  }

  (void) printf("Done\n\n");
  return (1);

} /* end of BDS_BuildLocalBDD */

/**Function********************************************************************

  Synopsis    [Build local BDDs for a node]

  Description [Local BDDs are built in dfs fashion. Cases on constant and PI
  nodes are complicated. Because they may already be built in the global BDD
  phase, but that process was aborted due to over limit.
  Return 1 if successful; 0 otherwise]

  SideEffects []

  SeeAlso     [BDS_BuildGlobalNodeBDD]

  LastDate    [3/23/99]

 ******************************************************************************/
static
int
BDS_BuildLocalNodeBDD_(/// << for each bnode >>
 DdManager *bddmgr,
 BnetNode *node,
 bdsOptions *option,
 int order,
 DdNode *decomposed,
 DdNode * dominator
 ) {
  DdNode *func, *tmp, *prod, *var, *localNewVar;
  BnetTabline *line;
  BnetNode *fanode;
  int i;
  lsGen fanins;
 // FILE *fp;
  //printf("TYPE= %d- %d\n", node->type,i);
  /* If local BDD has been built on this node, local variable should have also
   ** been created. No need to traverse down further.
   */
  if (node->localBdd != NULL) return (1);

  if (node->type == BNET_CONSTANT_NODE) {
    if (node->f == NULL) { /* constant 0 */
      func = Cudd_ReadLogicZero(bddmgr);
    } else { /* either constant depending on the polarity */
      func = Cudd_ReadOne(bddmgr);
    }
    Cudd_Ref(func);
  } else if (node->type == BNET_INPUT_NODE) {
    // printf("local %d\n", node->localVar);
      if (node->localActive == TRUE) { /* a variable has been created */
      func = Cudd_ReadVars(bddmgr, node->localVar);
      if (func == NULL) return (0);
    } else if (node->active == TRUE) { /* a variable has been created during global */
      func = Cudd_ReadVars(bddmgr, node->var);
      if (func == NULL) return (0);
      node->localVar = node->var;
      node->localActive = TRUE;
    } else { /* create a new local variable */
      func = Cudd_bddNewVar(bddmgr);
      if (func == NULL) return (0);
      node->localVar = func->index;
      // printf("local %d\n", node->localVar);
      node->localActive = TRUE;
    }
     //  printf("%d\n", node->localVar);
    Cudd_Ref(func);
  } else { /* type == BNET_INTERNAL_NODE or BNET_OUTPUT_NODE */
    /* Initialize the sum to logical 0. */
    // printf("%d\n", node->localVar);
    if (order == 0)
      func = decomposed;
    else if (order == 1)
      func = dominator;
    //  printf("order=%d\n", order);
    //line = node->f; /// line->values only has input values, output value is node->polarity
  // fp = fopen("/tmp/bdd3.dot", "w");
   // Cudd_DumpDot(bddmgr, 1, &func, NULL, NULL, fp);
  //  fclose(fp);

    /* Create a new local variable */
 //   localNewVar = Cudd_bddNewVar(bddmgr);
 //   if (localNewVar == NULL) return (0);
 //   Cudd_Ref(localNewVar);
   // node->localVar = localNewVar->index;
    node->localActive = TRUE;
 //   Cudd_IterDerefBdd(bddmgr, localNewVar);
  //    printf("%d\n", node->localVar);
  } /// end of if-else

#ifndef DEBUG
  (void) printf(".");
  (void) fflush(stdout);
#endif

  if (node->polarity == 1) {
    node->localBdd = Cudd_Not(func);
  } else {
    node->localBdd = func;
  }

  return (1);

} /* end of BDS_BuildLocalNodeBDD */

/**Function********************************************************************

  Synopsis    [Initializes the count fields used to drop DDs.]

  Description [Initializes the count fields used to drop DDs.
  Before actually building the BDDs, we perform a DFS from the outputs
  to initialize the count fields of the nodes.  The initial value of the
  count field will normally coincide with the fanout of the node.
  However, if there are nodes with no path to any primary output or next
  state variable, then the initial value of count for some nodes will be
  less than the fanout. For primary outputs and next state functions we
  add 1, so that we will never try to free their DDs. The count fields
  of the nodes that are not reachable from the outputs are set to -1.]

  SideEffects [Changes the count fields of the network nodes. Uses the
  visited fields.]

  SeeAlso     []

 ******************************************************************************/
static void
ntrInitializeCount(
 BnetNetwork * net,
 bdsOptions * option) {
  BnetNode *node;
  int i;

  for (i = 0; i < net->npos; i++) {
    if (!st_lookup(net->hash, net->outputs[i], (char **) &node)) {
      (void) fprintf(stdout,
       "Warning: output %s is not driven!\n", net->outputs[i]);
      continue;
    }
    ntrCountDFS(net, node);
    node->count++;
  }

  /* Clear visited flags. */
  node = net->nodes;
  while (node != NULL) {
    if (node->visited == 0) {
      node->count = -1;
    } else {
      node->visited = 0;
    }
    node = node->next;
  }

} /* end of ntrInitializeCount */

/**Function********************************************************************

  Synopsis    [Does a DFS from a node setting the count field.]

  Description []

  SideEffects [Changes the count and visited fields of the nodes it
  visits.]

  SeeAlso     [ntrLevelDFS]

 ******************************************************************************/
static void
ntrCountDFS(
 BnetNetwork * net,
 BnetNode * node) {
  int i;
  BnetNode *auxnd;

  node->count++;

  if (node->visited == 1) {
    return;
  }

  node->visited = 1;

  for (i = 0; i < node->ninp; i++) {
    if (!st_lookup(net->hash, (char *) node->inputs[i], (char **) &auxnd)) {
      exit(2);
    }
    ntrCountDFS(net, auxnd);
  }

} /* end of ntrCountDFS */

/**Function********************************************************************

  Synopsis    [Builds the BDD for the function of a node.]

  SideEffects [Sets the dd field of the node.]

  SeeAlso     []

 ******************************************************************************/
int
BDS_BuildNodeBDD(
 DdManager * dd /* DD manager */,
 BnetNode * nd /* node of the boolean network */,
 st_table * hash /* symbol table of the boolean network */) {
  DdNode *func;
  BnetNode *auxnd;
  DdNode *tmp;
  DdNode *prod, *var;
  BnetTabline *line;
  int i;

  if (nd->dd != NULL) return (1);

  if (nd->type == BNET_CONSTANT_NODE) {
    if (nd->f == NULL) { /* constant 0 */
      func = Cudd_ReadLogicZero(dd);
    } else { /* either constant depending on the polarity */
      func = Cudd_ReadOne(dd);
    }
    Cudd_Ref(func);
  } else if (nd->type == BNET_INPUT_NODE) {
    if (nd->active == TRUE) { /* a variable is already associated: use it */
      func = Cudd_ReadVars(dd, nd->var);
      if (func == NULL) fail("Serious error in BDS_BuildNodeBDD\n");
    } else { /* no variable associated: get a new one */
      func = Cudd_bddNewVar(dd);
      if (func == NULL) fail("Serious error in BDS_BuildNodeBDD\n");
      nd->var = func->index;
      nd->active = TRUE;
    }
    Cudd_Ref(func);
  } else { /* nd->type == BNET_INTERNAL_NODE or BNET_OUTPUT_NODE */
    /* Initialize the sum to logical 0. */
    func = Cudd_ReadLogicZero(dd);
    Cudd_Ref(func);

    /* Build a term for each line of the table and add it to the
     ** accumulator (func).
     */
    line = nd->f;
    while (line != NULL) {
      /* Initialize the product to logical 1. */
      prod = Cudd_ReadOne(dd);
      Cudd_Ref(prod);
      /* Scan the table line. */
      for (i = 0; i < nd->ninp; i++) {
        if (line->values[i] == '-') continue;
        if (!st_lookup(hash, (char *) nd->inputs[i], (char **) &auxnd)) {
          fail("Serious error in BDS_BuildNodeBDD\n");
        }
        if (auxnd->dd == NULL) {
          if (!BDS_BuildNodeBDD(dd, auxnd, hash)) {
            fail("Serious error in BDS_BuildNodeBDD\n");
          }
        }
        if (line->values[i] == '1') {
          var = auxnd->dd;
        } else { /* line->values[i] == '0' */
          var = Cudd_Not(auxnd->dd);
        }
        tmp = Cudd_bddAnd(dd, prod, var);
        if (tmp == NULL) fail("Serious error in BDS_BuildNodeBDD\n");
        Cudd_Ref(tmp);
        Cudd_IterDerefBdd(dd, prod);
        prod = tmp;
      }
      tmp = Cudd_bddOr(dd, func, prod);
      if (tmp == NULL) fail("Serious error in BDS_BuildNodeBDD\n");
      Cudd_Ref(tmp);
      Cudd_IterDerefBdd(dd, func);
      Cudd_IterDerefBdd(dd, prod);
      func = tmp;
      line = line->next;
    }
  }

  if (nd->polarity == 1) {
    nd->dd = Cudd_Not(func);
  } else {
    nd->dd = func;
  }

  return (1);

} /* end of BDS_BuildNodeBDD */

/**Function********************************************************************

  Synopsis    [Build a BDD from a SopPool]
  Description []

  SideEffects []

  SeeAlso     []

 ******************************************************************************/
extern
DdNode *
BDS_BuildDDFromSOP(
 DdManager *bddmgr,
 SopPool *soppool) {
  int i, j;
  char *line;
  DdNode *resultBdd, *prod, *tmp, *var;

  resultBdd = Cudd_ReadLogicZero(bddmgr);
  Cudd_Ref(resultBdd);

  for (i = 0; i < soppool->sop->num; i++) {
    line = array_fetch(char *, soppool->sop, i);

    /* Initialize the product to logical 1. */
    prod = Cudd_ReadOne(bddmgr);
    Cudd_Ref(prod);

    /* Scan the sop line. The order of variables is according to the index.
     ** NOT the order in the BDD mgr. */
    for (j = 0; j < soppool->size; j++) {
      if (line[j] == '-') continue;
      if (line[j] == '1') {
        var = Cudd_ReadVars(bddmgr, j);
      } else {
        var = Cudd_Not(Cudd_ReadVars(bddmgr, j));
      }
      Cudd_Ref(var);
      tmp = Cudd_bddAnd(bddmgr, prod, var);
      if (tmp == NULL) fail("Serious error in BDS_BuildDDFromSOP\n");
      Cudd_Ref(tmp);
      Cudd_Deref(var); /* keep the ref. count on vars small */
      Cudd_RecursiveDeref(bddmgr, prod);
      prod = tmp;
    }
    tmp = Cudd_bddOr(bddmgr, resultBdd, prod);
    if (tmp == NULL) exit(2);
    Cudd_Ref(tmp);

    Cudd_RecursiveDeref(bddmgr, resultBdd);
    Cudd_RecursiveDeref(bddmgr, prod);

    resultBdd = tmp;
  }

#ifdef DEBUG
  cuddCheck(bddmgr, "BDS_BDS_BuildDDFromSOP", 1);
#endif

  return (resultBdd);

} /* end of BDS_BuildDDFromSOP */

/**Function********************************************************************

Synopsis    [Transform all the BDDs related to the output of net into ADD]

 ******************************************************************************/
void
BDS_BDD2ADD(
 DdManager *bddmgr,
 BnetNode *node) {
  DdNode *tmp;

  tmp = Cudd_BddToAdd(bddmgr, node->dd);
  Cudd_Ref(tmp);
  Cudd_IterDerefBdd(bddmgr, node->dd);
  node->dd = tmp;

} /* end of BDS_BDD2ADD */




