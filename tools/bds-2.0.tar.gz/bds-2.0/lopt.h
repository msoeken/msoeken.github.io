
/**CHeaderFile*****************************************************************

  FileName    [lopt.h]

  PackageName [BDS-pga]

  Synopsis    [BDD decomposition program]

  Description []

  SeeAlso     []

  Author      [Congguang Yang]
  Copyright   [The file was created for academic use only in Department of
  Electrical and Computer Engineering, University of Massachusetts, Amherst.

  IN NO EVENT SHALL THE UNIVERSITY OF MASSACHUSETTS BE LIABLE FOR ANY DAMAGE
  CAUSED BY THE USE OF THIS SOFTWARE.]

******************************************************************************/

#ifndef _BDS
#define _BDS

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "build.h"
#include "bnet.h"
#include "array.h"
#include "list.h"
#include <st.h>
#include <cuddInt.h>
#include <time.h>
#include <sys/utsname.h>

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

#define BDS_VERSION "BDS Version #1.1, Release date 06/18/99"

/* Constants for operator field in factor tree */
#define BDS_BDD_INV 0
#define BDS_BDD_AND 1
#define BDS_BDD_OR 2
#define BDS_BDD_XOR 3
#define BDS_BDD_XNOR 4
#define BDS_BDD_MUX 5

#define BDS_NUMBER_OPERATOR 6

/* Decomposition type */
#define BDS_BDD_DECOMP_NONE 0
#define BDS_BDD_DECOMP_CONJ 1
#define BDS_BDD_DECOMP_DISJ 2
#define BDS_BDD_DECOMP_BOTH 3
#define BDS_BDD_DECOMP_X    4
#define BDS_BDD_DECOMP_B    5

/* Return values of BDD decomposition */
#define BDS_BDD_NO_DECOMP     0xFFF0
#define BDS_BDD_NO_MINIMI     0xFFF1
#define BDS_DECOMP_DISQUALIFY 0xFFF2

/* Cmd for BDS_Stats */
#define BDS_INIT	  	0xFFF0
#define BDS_BDD_DECOMP   	0xFFF2
#define BDS_XHARDCORE	  	0xFFF4
#define BDS_BHARDCORE 	        0xFFF5
#define BDS_SHARED_FNODE 	0xFFF6
#define BDS_CLOSE	  	0xFFF8
#define BDS_VERIFY	  	0xFF0F
#define BDS_ONE_DOMI	  	0xFF00
#define BDS_ZERO_DOMI	  	0xFF02
#define BDS_X_DOMI	  	0xFF04
#define BDS_G_DOMI	  	0xFF06
#define BDS_LIT_COUNT		0xFF08
#define BDS_COFACTOR		0xFF0A
#define BDS_FTREE_OPERATOR     0xFF0C

/* Verbosity level */
#define BDS_VERBOSE_LESS 0
#define BDS_VERBOSE_MORE 1
#define BDS_VERBOSE_MOST 2

/* Default startup parameters */
#define BDS_BDD_STARTUP_CACHE  10*1024
#define BDS_BDD_STARTUP_MEMORY 10*1024*1024
#define BDS_BDD_REORDER_LIMIT  200    /* The largest BDD on which exact reordering can apply. */

/* BDD minimization method */
#define BDS_BDD_RESTRICT	0
#define BDS_BDD_LICOMPACTION	1

/* ftree node */
#define BDS_FTREE_INTERNAL	0xFFFF /* Internal node of a ftree */
#define BDS_FTREE_ONE		0xFFF1 /* Constant 1 on a ftree */
#define BDS_FTREE_ZERO		0xFFF0 /* Constant 0 on a ftree */
#define BDS_FTREE_PSEUDO       0xFFF2 /* Used for cut PTLs */

/* Weight-realted constants */
#define BDS_HUGE_NUMBER 0xFFFF
#define ALPHA 0.5		       /* Weight constant for BDD decomp cost function(GD) */
#define BETA 0.5		       /* Weight constant for BDD decomp cost function(XD) */
#define BDS_DISQUALIFY_THRESHOLD 0.80 /* Threshold of cost to disqualify a decomposition */
#define BDS_DISQUALIFY_GXD_RATIO 0.95 /* The threshold to disqualify decomposition based on gx-d */

/* BDD balancing related parameters */
#define BDD_BALANCE_FACTOR 0.5
#define BDD_BALANCE_THRESHOLD 0.3

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/
typedef int boolean;
///=====pga
typedef struct Cost {
  int 		index;
  int 		cost;
} Cost;
///==pga
typedef struct FactorTreeNode {
    int 	op;	/* operator on two children,  +, *, ^ and @ */
    int		value;		/* Value of this FTNode, i.e., the index of the variable */
    char	*name;		/* Used for cut PTLs */
    DdNode	*dd;		/* Corresponding global BDD */
    DdNode	*local;	    /* Local BDD, supports are intermediate variables */
    int		var;		/* Local variable index */
    int		count;		/* Reference count on this node */
    int 	visited;	/* Used for factor tree traversal */
    int		polarity;	/* Complementary or not */
    struct 	FactorTreeNode *siblings[5];	/* Operands on this fnode, used to hold intermediate results */
    struct 	FactorTreeNode *control;     /* Used to store control signal after collapse fnodes */
    lsList	fanins;		/* fanin nodes */
    lsList	fanouts;	/* fanout nodes */
} FactorTreeNode;

typedef struct bddNode {
    int     index;       	/* Index of the node */
    DdNode  *dd;         	/* BDD corresponds to this node */
    struct 	bddNode *t_nd;  /* THEN child */
    struct 	bddNode *e_nd;  /* ELSE child */
} bddNode;

typedef struct bddPool {
    int     *order;		/* Variable order when this BDD is dumped */
    bddNode *bnode;
    int		numVar;		/* Number of vars on the BDD */
} bddPool;

typedef struct SopPool {	/* Struct used to store tmp result of a BDD decomposition */
    int 	size;		/* # of variables in a bdd mgr */
    int 	*order;		/* variable order, used to rebuild the BDD from SOP */
    array_t *sop;		/* miniterms stored here */
} SopPool;

typedef struct SQueue {		/* A naive queue struct. */
  long int 	head;
  long int 	tail;
  array_t 	*queue;
} SQueue;

typedef struct decompCost {	/* Cost associated with a decomposition */
  float 	cost;		/* Cost for this decomposition */
  int		numQR;		/* # of nodes on the decomposed BDD */
  int		numD;		/* # of nodes on the dominator */
  int 		op;	/* operator for this decomposition */
  int 		level;		/* The level on which the best decomp is found */
  int 		decompType;
  bddPool	*decomposed;
  bddPool	*dominator;
} decompCost;

typedef struct XdecompCost {	/* Cost associated with a X decomposition */
  float 	cost;		/* Cost for this decomposition */
  int 		op;	/* operator for this decomposition */
  int 		decompType;
  DdNode	*f;
  DdNode 	*g;
  DdNode 	*h;
} XdecompCost;

typedef struct edgeMark {	/* Hash table used to store edge property */
  int 		decompType;		/* Type of possible decomp on this level. */
  int 		numSigmaOne;	/* Number of Sigma_1 on this level */
  int 		numSigmaZero;	/* Number of Sigma_0 on this level */
  int		numNegative;	/* Number of negative edges on and above this level */
  DdNode 	*bottom;		/* The lower end of an edge */
  st_table 	*table;			/* Store the lower end (lBdd) of edges */
  int       k_feasible;     /* New variable added by Navin to check if level is k feasible level */ ///pga
  int       K_FEAS; 		///pga
  int       numIncident; 	///pga
} edgeMark;
///=====pga
typedef struct HCost {
  int       edges; 			/* No. of SigmaOne and SigmaZero edges on this node */
  int       decomp_type; 	/* 0-NoDecomp  1-Conjunction 2-Disjunction */
                           	/* 3-XNor  4-Xor  5-Mux*/
  int       level; 			/* Which level is this!! */
  int       *order;
  int       cost;
} HCost;
///==pga

typedef struct bddStats {   /* BDD decomposition statistical monitor */
   int      inVar;         	/* # of variables on the in coming BDD */
   int      inSize;        	/* Size of incoming BDD */
   int      dpVar;
   int      dpSize;
   int      dmVar;
   int      dmSize;
   int		auxVar;			/* Only used for branch decomposition */
   int		auxSize;
   int      level;
   int      decompType;
   float    cost;
} bddStats;

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

extern int numLocal; ///pga


/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/* ftree.c */
#define Fnode_Regular(node) ((FactorTreeNode *)((unsigned long)(node) & ~01))
#define Fnode_Complement(node) ((FactorTreeNode *)((unsigned long)(node) | 01))
#define Fnode_Flip(node) ((FactorTreeNode *)((unsigned long)(node) ^ 01))
#define Fnode_IsComplement(node) ((int) ((long) (node) & 01))
#define Fnode_Ref(node) (Fnode_Regular(node)->count ++)
#define Fnode_Deref(node) (Fnode_Regular(node)->count --)
#define Fnode_Internal(node) (Fnode_Regular(node)->value == BDS_FTREE_INTERNAL)
#define Fnode_Negative(node) (Fnode_Regular(node)->polarity == 0)
#define Fnode_Inverse(node) (Fnode_Regular(node)->polarity = 1 - Fnode_Regular(node)->polarity)
#define Fnode_Operator(node) (Fnode_Regular(node)->op)
#define Fnode_Fanins(node) (Fnode_Regular(node)->fanins)
#define Fnode_Fanouts(node) (Fnode_Regular(node)->fanouts)

/* store.c */
#define DumpNode_Regular(node) ((bddNode *)((unsigned long)(node) & ~01))
#define DumpNode_Complement(node) ((bddNode *)((unsigned long)(node) | 01))
#define DumpNode_Flip(node) ((bddNode *)((unsigned long)(node) ^ 01))
#define DumpNode_IsComplement(node) ((int) ((long) (node) & 01))

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

/* main.c */



/* lopt.c */
EXTERN int BDS_DDDecompose ARGS((DdManager*,DdNode*,bdsOptions*,FactorTreeNode**,int*,int*,int*)); ///pga added last 3
EXTERN int BDS_DDDecompose_alternative ARGS((DdManager*,BnetNetwork*,DdNode*,bdsOptions*, FactorTreeNode**,int*,int*,int*,bddPool**,bddPool**,bddPool**,int*)); ///pga added last 3

/* queue.c */
EXTERN void BDS_Q_Init ARGS((SQueue*));
EXTERN void BDS_EQ ARGS((SQueue*, bddPool*));
EXTERN bddPool * BDS_DQ ARGS((SQueue*));
EXTERN void BDS_Q_Quit ARGS((SQueue*));

/* minimize.c */
EXTERN DdNode * BDS_BddMinimization ARGS((DdManager*,DdNode*,DdNode*,int,bdsOptions*));

/* ftree.c */
EXTERN int BDS_FTreeProcessing ARGS((DdManager*,BnetNetwork*,FactorTreeNode**,bdsOptions*,char**,st_table*,int)); ///pga added last 1
EXTERN void BDSFreeFTree ARGS((DdManager*,FactorTreeNode**));
EXTERN int bdsCollectFNodes ARGS((st_table*,FactorTreeNode*));
EXTERN int bdsCollectFNodeslsList ARGS((st_table*,FactorTreeNode*));

/* export.c */
EXTERN int BDS_SynthesisPresentation ARGS((BnetNetwork*,FactorTreeNode**,char**,st_table*,st_table*,bdsOptions*,int,int)); ///pga added last 1

/* cutptl.c */
EXTERN int BDS_CutPtlFromGeneralNetlist ARGS((BnetNetwork*,FactorTreeNode**,char**,st_table*,bdsOptions*,st_table*)); ///pga added last 1

/* phase.c */
EXTERN int BDS_FtreePhaseAssignment ARGS((FactorTreeNode**,bdsOptions*));

/* store.c */
EXTERN bddPool * BDS_DumpBddPool ARGS((DdManager*,DdNode*));
EXTERN DdNode * BDS_BuildDDFromBddPool ARGS((DdManager*,bddPool*,int));
EXTERN bddPool * BDS_DumpBddPoolAtLevel ARGS((DdManager*,DdNode*,st_table*,edgeMark*,int));
EXTERN void BDS_FreeBddPool ARGS((DdManager*,bddPool*));

/* debug.c */
EXTERN void debugSharing ARGS((DdManager*,lsList,DdNode**,bdsOptions*));
EXTERN void debugDump ARGS((DdManager*,DdNode**,float,bdsOptions*,int)); ///pga added last 1
EXTERN void dumpDot ARGS((DdManager*,DdNode*));
EXTERN void db ARGS((DdManager*,DdNode*));
EXTERN int  ref ARGS((DdManager*));
EXTERN void cuddCheck ARGS((DdManager*,char*,int));
EXTERN int bdsDecompCheck ARGS((DdManager*,DdNode*,int,DdNode*,DdNode*));
EXTERN void dumpfdot ARGS((FactorTreeNode**,char**));
EXTERN void bdsNetwotkTraverseDebug ARGS((DdManager*,BnetNetwork*));
EXTERN void netPrint ARGS((BnetNetwork*,bdsOptions*));
EXTERN DdNode reg ARGS((DdNode*));

/* loptUtil.c */
EXTERN edgeMark ** BDS_MarkEdges(DdManager*,DdNode*,int*,int,int,bdsOptions*); ///pga added last 1
EXTERN DdNode* BDS_BuildDDFromSOP ARGS((DdManager*,SopPool*));
EXTERN SopPool * BDS_DumpSOP ARGS((DdManager*,DdNode*));
EXTERN void BDS_FreeEdgeProperty ARGS((int*,edgeMark**,int));
EXTERN void BDS_FreeSOP ARGS((SopPool*));
EXTERN array_t * BDS_Support ARGS((DdManager*,DdNode*));
EXTERN SopPool * BDS_DumpSopAtLevel ARGS((DdManager*,DdNode*,edgeMark*,int));
EXTERN int* BDS_SupportArray ARGS((DdManager*,DdNode*,int*));
EXTERN int* BDS_Support_Index ARGS((DdManager*,DdNode*,int *,int *));
EXTERN char * BDS_ReadBdd ARGS((DdManager*,DdNode*,char**));
EXTERN char * BDS_DumpBddBlif ARGS((DdManager*,DdNode*,char**));
EXTERN int BDS_Reorder ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN void BDS_DumpDD ARGS((DdManager*,BnetNode*,BnetNetwork*,bdsOptions*,int));
EXTERN void BDS_PrintStatus ARGS((DdManager*,BnetNode*,int));
EXTERN void BDS_CheckRefCount ARGS((DdManager*,BnetNode*));
EXTERN char * BDS_CreateFname ARGS((bdsOptions*,char*));
EXTERN char * BDS_GetFileHead ARGS((char*));
EXTERN void BDS_Stats ARGS((int,bddStats*,long,char*,char**,DdManager*,bdsOptions*));
EXTERN void BDS_WriteFnode ARGS((FactorTreeNode*,int,int,int));
EXTERN void BDS_UpdateBddMonitor ARGS((DdManager*,bddStats*,DdNode*,DdNode*,DdNode*,DdNode*,int,float,int));
EXTERN int BDS_GetNegative ARGS((DdManager*,DdNode*,int));
EXTERN st_table * BDS_CountRef ARGS((DdManager*,DdNode*));
EXTERN int BDS_TestBalance ARGS((DdManager*,DdNode*));
EXTERN int BDS_Delay_Reorder ARGS((DdManager*,int*,int*,int*,bddPool*,int**));  /*Navin 8/18/00 */ ///pga


/* Added by Navin 6/14/00 for sharing extraction stuff */ ///pga

EXTERN DdNode * bdsBuildResubBddFromBddPool ARGS((DdManager*,bddPool*));
EXTERN bddPool * bdsDumpResubBddPool ARGS((DdManager*,DdNode*,DdNode*,DdNode*));
EXTERN void debugDumps ARGS((DdManager*,DdNode*,float,bdsOptions*));


#endif /* _BDS */




