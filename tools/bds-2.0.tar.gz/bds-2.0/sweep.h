
/**CHeaderFile*****************************************************************

  FileName    [sweep.h]

  PackageName [BDS-pga]

  Synopsis    [Boolean netowrk sweep programs]

  Description []

  SeeAlso     []

  Author      [Congguang(Anda) Yang]

  Last date   [6/2/99]

******************************************************************************/

#ifndef _BDSSWEEP
#define _BDSSWEEP

/*---------------------------------------------------------------------------*/
/* Nested includes                                                           */
/*---------------------------------------------------------------------------*/

#include "lopt.h"
#include "list.h"
#include "st.h"
#include "cuddInt.h"
#include "bnet.h"

/*---------------------------------------------------------------------------*/
/* Constant declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Stucture declarations                                                     */
/*---------------------------------------------------------------------------*/

typedef struct bnode_pair { /* Used for duplication detection */
  BnetNode *enode; /* existing bnode */
  BnetNode *dnode; /* duplicate bnode */
} bnode_pair;

/*---------------------------------------------------------------------------*/
/* Type declarations                                                         */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Variable declarations                                                     */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Macro declarations                                                        */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Function prototypes                                                       */
/*---------------------------------------------------------------------------*/

EXTERN int BDS_SweepBnetwork ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN int BDS_SweepConstant ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN int BDS_SweepDuplicate ARGS((DdManager*,BnetNetwork*,bdsOptions*));
EXTERN int bdsSweepDuplicate ARGS((DdManager*,BnetNetwork*,st_table*,bdsOptions*));

#endif /* _BDSSWEEP */



