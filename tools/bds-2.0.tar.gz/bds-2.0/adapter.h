/* 
 * File:   adapter.h
 * Author: nabila
 *
 * Created on November 10, 2014, 10:21 AM
 */

#ifndef ADAPTER_H
#define	ADAPTER_H



#include "lopt.h"





EXTERN DdNode ** bds_decomposition ARGS((DdManager *mgr, DdNode *function,int *op,int *size));


#endif	/* ADAPTER_H */

